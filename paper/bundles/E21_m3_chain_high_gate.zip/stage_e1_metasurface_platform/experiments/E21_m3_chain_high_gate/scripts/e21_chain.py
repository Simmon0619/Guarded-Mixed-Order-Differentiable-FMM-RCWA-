"""(3,0) monotone BH chain with the elevated, non-arbitrageable acceptance
gate: (32,8) on the 2x upsampled grid (D-012 rule: certification order scales
with target order m).

Protocol otherwise letter-for-letter E19: same parent latent, alpha cycle
{0.1, 0.25, 0.5}, 30-step beta=64 re-descent with a fresh Adam, monotone
accept.  Descent and audits on GPU/c64 (D-011); final verification ladder
(40,10)/(48,12)@2x plus one c128 spot check.

    python e21_chain.py               # writes ../data/chain.json
"""
import json
import os
import sys
import time

import numpy as np
import torch

THREADS = int(os.environ.get("P0_THREADS", "3"))
torch.set_num_threads(THREADS)
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.abspath(os.path.join(
    _HERE, "..", "..", "E16_inherited_baseline", "scripts")))
import e10_common as C  # noqa: E402
import trustworthy_fmm.fourier.convolution as _conv  # noqa: E402
import trustworthy_fmm.solvers.vector_2d as _v2d  # noqa: E402
from trustworthy_fmm.solvers.vector_2d import solve_multilayer_vector_2d  # noqa: E402

_conv.VECTORIZED_CONV = True
_v2d.FAST_DIAGNOSTICS = True

E16_DESIGNS = os.path.abspath(os.path.join(
    _HERE, "..", "..", "E16_inherited_baseline", "data", "main", "designs"))
DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
GPU = C.DEFAULT.variant(dtype=torch.complex64, device="cuda")

TARGET = (3, 0)
PARENT = "3_0_2029_torcwa_M12_latent.npy"
GATE = (32, 8)                 # on the 2x grid
N_JUMPS = 60
STEPS = 30
BETA = 64.0
ALPHAS = [0.1, 0.25, 0.5]
PARENT_REFS = {"(32, 8)@2x": 0.3673, "(40, 10)@2x": 0.3327,
               "(48, 12)@2x": 0.3070}          # E20 measured


def filtered_noise(seed):
    g = torch.Generator().manual_seed(int(seed))
    noise = torch.randn((C.NY, C.NX), generator=g, dtype=torch.float64)
    smooth = C.periodic_gaussian_filter(noise, C.LATTICE, C.FILTER_NM)
    return smooth / smooth.std()


def redescend(rho0, target):
    rho = rho0.to("cuda")
    adam = C.Adam(rho.shape, GPU)
    for t in range(STEPS):
        lr = C.cosine_lr(t / STEPS, GPU)
        _, g = C.value_grad_latent(rho, (12, 3), target, BETA, GPU)
        rho = adam.step(rho, g, lr)
    return rho.cpu()


def upsample(mask, k=2):
    return torch.repeat_interleave(
        torch.repeat_interleave(mask, k, dim=0), k, dim=1)


def eta_at(binary_1x, level, k, dtype, device):
    dens = upsample(binary_1x, k) if k == 2 else binary_1x
    eps = (C.EPS_BG + (C.EPS_FEAT - C.EPS_BG) * dens).to(dtype).to(device)
    with torch.no_grad():
        r = solve_multilayer_vector_2d(
            [eps], [C.THICK], C.WL, C.LATTICE, C.N_IN, C.N_OUT, tuple(level),
            incident_jones=C.DEFAULT.incident_jones)
        return float(r.power_t[r.orders.index(TARGET)])


def gate_eta(binary_1x):
    return eta_at(binary_1x, GATE, 2, torch.complex64, "cuda")


def main():
    t0 = time.perf_counter()
    incumbent = torch.from_numpy(
        np.load(os.path.join(E16_DESIGNS, PARENT)).astype("float64"))
    inc_bin = C.hard_binary(incumbent, C.DEFAULT)
    inc_eta = gate_eta(inc_bin)
    start_eta = inc_eta
    print("parent gate eta (32,8)@2x: %.4f (E20 recorded %.4f)"
          % (inc_eta, PARENT_REFS["(32, 8)@2x"]), flush=True)
    jumps, accepts = [], 0
    for k in range(N_JUMPS):
        alpha = ALPHAS[k % len(ALPHAS)]
        noise = filtered_noise(6000 + k)
        pert = C.symmetrize(
            (incumbent + alpha * C.DEFAULT.init_scale * noise).clamp(0, 1))
        rho = redescend(pert, TARGET)
        b = C.hard_binary(rho, C.DEFAULT)
        eta = gate_eta(b)
        accepted = eta > inc_eta
        jumps.append({"jump": k, "alpha": alpha, "eta_gate": eta,
                      "accepted": bool(accepted)})
        if accepted:
            incumbent, inc_bin, inc_eta = rho, b, eta
            accepts += 1
        print("jump %2d a=%.2f: gate %.4f  (incumbent %.4f) %s [%.0f s]"
              % (k, alpha, eta, inc_eta,
                 "ACCEPT" if accepted else "reject",
                 time.perf_counter() - t0), flush=True)

    np.save(os.path.join(DATA, "3_0_highgate_binary.npy"), inc_bin.numpy())
    np.save(os.path.join(DATA, "3_0_highgate_latent.npy"), incumbent.numpy())

    # final verification ladder
    final = {"(32, 8)@2x": inc_eta}
    for lv in [(40, 10), (48, 12)]:
        final["%s@2x" % (lv,)] = eta_at(inc_bin, lv, 2,
                                        torch.complex64, "cuda")
    spot_c128 = eta_at(inc_bin, (32, 8), 2, torch.complex128, "cpu")
    out = {
        "target": list(TARGET), "parent": PARENT, "gate": list(GATE),
        "start_gate_eta": start_eta, "final_gate_eta": inc_eta,
        "accepts": accepts, "n_jumps": len(jumps), "jumps": jumps,
        "final_ladder": final, "final_spot_c128_32_8": spot_c128,
        "parent_refs": PARENT_REFS,
        "wall_s": time.perf_counter() - t0,
    }
    with open(os.path.join(DATA, "chain.json"), "w") as f:
        json.dump(out, f, indent=1)
    print()
    print("chain: gate %.4f -> %.4f (%d/%d accepts)"
          % (start_eta, inc_eta, accepts, len(jumps)))
    print("final ladder: 32@2x %.4f (c128 %.4f)  40@2x %.4f  48@2x %.4f"
          % (final["(32, 8)@2x"], spot_c128, final["(40, 10)@2x"],
             final["(48, 12)@2x"]))
    print("parent      : 32@2x %.4f  40@2x %.4f  48@2x %.4f"
          % (PARENT_REFS["(32, 8)@2x"], PARENT_REFS["(40, 10)@2x"],
             PARENT_REFS["(48, 12)@2x"]))
    verdict = ("A: fixed for high m" if final["(48, 12)@2x"]
               > PARENT_REFS["(48, 12)@2x"] else "B: no usable BH window")
    print("verdict at (48,12): %s" % verdict)
    print("wrote chain.json  (%.0f s)" % (time.perf_counter() - t0))


if __name__ == "__main__":
    main()
