"""
FS -- the SI figures as five composite figures with panel letters (2026-10-06).

The Optica supplemental-document template has a text block of 5.25 in (133 mm), so every figure is drawn 133 mm wide and is
placed at 100 %.  Same type rules as fs_style.py (Times New Roman; tick labels 8.5 pt and axis labels 9.5 pt bold; annotations
and legends regular; capitals; colour = truncation order; key declared before the panels it serves).  Only existing data.

  python fs_composites.py [C1 C2 C3 C4 C5]          (no argument: all)

Fig. S1  solve cost, memory and validation        (old S1 + S2, + memory bars of Table S3)
Fig. S2  permittivity spectrum seen by an order   (old S3 + S4)
Fig. S3  P1 and single-precision gradients        (old S5 + S6)
Fig. S4  frozen design states                     (old S7 + S8)
Fig. S5  reference convergence, minimal model, gap along runs   (old S9 + S10 + S11)
Output: manuscript_cpc/SI/figures/figS1_*, ... (png + svg)
"""
import json
import math
import os
import sys

import numpy as np

import fs_style as S
from fs_style import (ANS, OC, MD, MG, MR, ORDERS, INK, INK2, GREY, GREY_L, DARK, TEAL, BAND, LAB, MM, EXP,
                      note, reg_legend, bold_ticks, olab, key_strip)
import fs_si_figures as O
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

W = 133.0                                   # mm, text block of the Optica supplemental-document template


def new_fig(h):
    return plt.figure(figsize=(W * MM, h * MM))


def axm(fig, h, left, top, w, hh):
    """Axes of w x hh mm whose left edge is at `left` mm and whose top edge is `top` mm below the top of a W x h figure."""
    return fig.add_axes([left / W, (h - top - hh) / h, w / W, hh / h])


def letter(fig, ax, s, dx=-13.0, dy=1.5):
    """Bold panel letter at dx mm left of and dy mm above the upper left corner of the axes."""
    bb = ax.get_position()
    h = fig.get_size_inches()[1] / MM
    fig.text(bb.x0 + dx / W, bb.y1 + dy / h, "(%s)" % s, fontsize=S.PLS, fontweight="bold", ha="left", va="bottom")


def save_c(fig, name):
    S.save(fig, name)


# ---------------------------------------------------------------------------------------------------------------------
# Fig. S1
# ---------------------------------------------------------------------------------------------------------------------
def figC1():
    H = 168.0
    fig = new_fig(H)
    aw, ah, l1, l2 = 47.0, 38.0, 16.0, 84.0
    tops = [6.0, 6.0 + ah + 20.0, 6.0 + 2 * (ah + 20.0)]
    # (a) cost against 2N ------------------------------------------------------------------------------------------------
    p1_10 = {350: 0.077, 902: 0.587, 2210: 5.15, 3402: 18.4, 4850: 53.8}
    p1_5 = {350: 0.069, 902: 0.555, 2210: 5.05, 3402: 18.2, 4850: 54.3}
    p2_f = {686: 0.29, 1026: 0.75, 2106: 5.3, 2314: 6.9, 2910: 13.5, 4598: 58.0, 4902: 129.0}
    p2_g = {330: 0.08, 686: 0.38, 1026: 0.99, 2106: 7.1, 2910: 18.2, 4598: 75.3}
    ax = axm(fig, H, l1, tops[0], aw, ah)
    for d, fc, lab in ((p1_10, TEAL, "Forward, P1, 10 nm"), (p1_5, "white", "Forward, P1, 5 nm")):
        x = np.array(sorted(d)); y = np.array([d[k] for k in x])
        ax.plot(x, y, "-" if fc != "white" else "none", marker="o", ms=3.6, mfc=fc, mec=TEAL, mew=0.9, color=TEAL, lw=0.9, label=lab, zorder=3)
    x = np.array(sorted(p2_f)); y = np.array([p2_f[k] for k in x])
    ax.plot(x, y, "-", marker="s", ms=3.2, color=DARK, mfc=DARK, mew=0, lw=0.9, label="Forward, P2", zorder=3)
    x = np.array(sorted(p2_g)); y = np.array([p2_g[k] for k in x])
    ax.plot(x, y, "--", marker="^", ms=3.8, color=DARK, mfc="white", mew=0.9, lw=0.9, label="Value + gradient, P2", zorder=3)
    xx = np.array([300, 6000.0])
    ax.plot(xx, 0.077 * (xx / 350.0) ** 3, ":", color=GREY, lw=1.0, zorder=1)
    note(ax, 5400, 129.0, "Paging", ha="left", va="center", fontsize=7.4)
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlim(280, 9500); ax.set_ylim(0.04, 600)
    ax.set_xticks([300, 1000, 3000]); ax.set_xticklabels(["300", "1000", "3000"])
    ax.set_xlabel("Dimension $2N$"); ax.set_ylabel("Time per evaluation (s)")
    reg_legend(ax, loc="upper left", handlelength=1.8, labelspacing=0.2, borderaxespad=0.1, fontsize=7.2)
    bold_ticks(ax); letter(fig, ax, "a")
    # (b) local exponent ------------------------------------------------------------------------------------------------
    ax = axm(fig, H, l2, tops[0], aw, ah)
    for d, fc, lab in ((p1_10, TEAL, "10 nm"), (p1_5, "white", "5 nm")):
        k = np.array(sorted(d)); t = np.array([d[i] for i in k])
        xm = np.sqrt(k[1:] * k[:-1]); sl = np.diff(np.log(t)) / np.diff(np.log(k))
        ax.plot(xm, sl, "-o" if fc != "white" else "o", ms=3.8, mfc=fc, mec=TEAL, mew=0.9, color=TEAL, lw=0.9, label="P1, " + lab)
    ax.axhline(3, color=GREY, lw=0.8, ls=":")
    ax.set_xscale("log"); ax.set_xlim(330, 6200); ax.set_ylim(1.6, 3.3)
    ax.set_xticks([500, 1000, 3000]); ax.set_xticklabels(["500", "1000", "3000"])
    ax.set_xlabel("Dimension $2N$"); ax.set_ylabel("Local exponent of the time")
    reg_legend(ax, loc="lower right", handlelength=1.4, borderaxespad=0.1, fontsize=7.4)
    bold_ticks(ax); letter(fig, ax, "b")
    # (c) memory configurations ------------------------------------------------------------------------------------------
    ax = axm(fig, H, l1, tops[1], aw, ah)
    peak = [7.37, 5.79, 10.00]; dev = [10.0, 9.1, 12.0]; tm = [75.5, 70.6, 116.2]
    cfg = ["Direct\noffload\n%.0f s" % tm[0], "Rearranged\noffload\n%.0f s" % tm[1], "Recomputed\nno offload\n%.0f s" % tm[2]]
    x = np.arange(3)
    ax.bar(x - 0.19, peak, 0.36, color=GREY_L, edgecolor=INK2, lw=0.5)
    ax.bar(x + 0.19, dev, 0.36, color=DARK, lw=0)
    ax.axhline(12, color=TEAL, lw=1.0, ls=(0, (3, 2)))
    note(ax, 2.55, 12.3, "12 GB", color=TEAL, ha="right", va="bottom", fontsize=7.4)
    ax.set_xticks(x); ax.set_xticklabels(cfg, fontsize=6.9)
    ax.set_ylim(0, 15.5); ax.set_xlim(-0.6, 2.6)
    ax.set_ylabel("Memory (GiB or GB)")
    reg_legend(ax, handles=[Patch(facecolor=GREY_L, edgecolor=INK2, label="Peak (PyTorch)"), Patch(facecolor=DARK, label="Device total")],
               loc="upper left", handlelength=1.0, borderaxespad=0.1, fontsize=7.4)
    bold_ticks(ax); letter(fig, ax, "c")
    # (d) Lumerical ------------------------------------------------------------------------------------------------------
    X = O.J(os.path.join(EXP, "E25_lumerical_xcheck", "data", "lumerical_xcheck.json"))
    P = O.J(os.path.join(EXP, "E17_stage0_gpu_c64", "data", "parity.json"))
    band = {"(1, 0)": (0.799, 0.834), "(2, 0)": (0.828, 0.848), "(3, 0)": (0.307, 0.393)}
    gcol = {"201": "#c9c8c3", "401": "#8c8b86", "801": "#3b3a37"}
    ax = axm(fig, H, l2, tops[1], aw, ah)
    for i, t in enumerate(("(1, 0)", "(2, 0)", "(3, 0)")):
        d = X["designs"][t]; lo, hi = band[t]
        ax.plot([i - 0.28, i - 0.28], [lo, hi], "-", color=TEAL, lw=4.0, solid_capstyle="butt", zorder=2)
        ax.plot([i - 0.28], [d["ours_28_7_c128"]["eta_target"]], "D", color="white", mec=TEAL, mew=1.0, ms=3.8, zorder=3)
        for j, k in enumerate(("201", "401", "801")):
            ax.plot([i + 0.05 + 0.13 * j], [d["lumerical"][k]["eta_target_Tp"]], "o", ms=4.4, color=gcol[k], mec=INK2, mew=0.5, zorder=3)
    ax.set_xticks([0, 1, 2]); ax.set_xticklabels(["(1,0)", "(2,0)", "(3,0)"])
    ax.set_xlim(-0.6, 2.6); ax.set_ylim(0.2, 1.62); ax.set_yticks([0.2, 0.4, 0.6, 0.8])
    ax.set_xlabel("Target channel"); ax.set_ylabel("Target-channel efficiency")
    reg_legend(ax, handles=[Line2D([0], [0], color=TEAL, lw=4.0, label="This work, (24,6) to (40,10)"),
                            Line2D([0], [0], marker="D", ls="none", mfc="white", mec=TEAL, mew=1.0, ms=3.8, label="This work, (28,7)"),
                            Line2D([0], [0], marker="o", ls="none", mfc=gcol["201"], mec=INK2, mew=0.5, ms=4.4, label="Lumerical, 201 k-vectors"),
                            Line2D([0], [0], marker="o", ls="none", mfc=gcol["401"], mec=INK2, mew=0.5, ms=4.4, label="Lumerical, 401"),
                            Line2D([0], [0], marker="o", ls="none", mfc=gcol["801"], mec=INK2, mew=0.5, ms=4.4, label="Lumerical, 801")],
               loc="upper left", bbox_to_anchor=(0.0, 1.02), handlelength=1.4, labelspacing=0.12, borderaxespad=0.0, fontsize=7.0)
    bold_ticks(ax); letter(fig, ax, "d")
    # (e), (f) precision --------------------------------------------------------------------------------------------------
    pr = P["projected"]
    cosd = np.maximum(np.array([1.0 - r["grad_cosine"] for r in pr]), 1e-12)
    val = np.maximum(np.array([r["rel_value_err"] for r in pr]), 1e-9)
    for k, (arr, xl, lo_, hi_, left) in enumerate(((val, "Relative value error", -9, -2.5, l1),
                                                     (cosd, "$1-$cosine of the gradients", -12, 0, l2))):
        ax = axm(fig, H, left, tops[2], aw, ah)
        ax.hist(arr, bins=np.logspace(lo_, hi_, 28), color=GREY_L, edgecolor=INK2, lw=0.4)
        ax.set_xscale("log"); ax.set_xlabel(xl); ax.set_ylabel("Number of states")
        med = np.median(arr); ax.axvline(med, color=TEAL, lw=1.0)
        e = int(math.floor(math.log10(med))); mant = med / 10 ** e
        note(ax, med * 2.2, ax.get_ylim()[1] * 0.97, "Median\n$%.1f\\times10^{%d}$" % (mant, e), color=TEAL,
             ha="left", va="top", fontsize=7.2)
        note(ax, 0.04 if k == 0 else 0.96, 0.52, "189 states", transform=ax.transAxes, ha="left" if k == 0 else "right", va="top", fontsize=7.2)
        bold_ticks(ax); letter(fig, ax, "ef"[k])
    save_c(fig, "figS1_cost_memory_validation")


# ---------------------------------------------------------------------------------------------------------------------
# Fig. S2
# ---------------------------------------------------------------------------------------------------------------------
def _collapse_data():
    pipe = os.path.join(EXP, "F1_fig1_schematic", "fmm_pipeline.py")
    src = open(pipe, encoding="utf-8").read()
    mark = "# ----------------------------- plotting"
    ns = {"__name__": "fmm_pipeline_design"}
    exec(compile(src[:src.index(mark)], pipe, "exec"), ns)
    rho = np.asarray(ns["rho_tilde"], float); P = ns["tanh_projection"]
    ETA, EB, EF = ns["ETA"], ns["EPS_LOW"], ns["EPS_HIGH"]; D = EF - EB
    N = rho.shape[0]; c = N // 2
    hy, hx = np.meshgrid(np.arange(N) - c, np.arange(N) - c, indexing="ij")
    SH = np.maximum(np.abs(hx), np.abs(hy))

    def sig(e):
        S_ = np.fft.fftshift(np.fft.fft2(e)) / e.size
        es = np.bincount(SH.ravel(), weights=(np.abs(S_) ** 2).ravel())
        beyond = np.cumsum(es[::-1])[::-1]
        return np.sqrt(np.append(beyond[1:], 0.0)) / D
    betas = np.geomspace(1.0, 1e5, 300)
    sweep = np.array([sig(EB + P(rho, b, ETA) * D) for b in betas])
    sinf = sig(EB + (rho >= ETA).astype(float) * D)
    gy, gx = np.gradient(rho)
    g = float(np.median(np.hypot(gx, gy)[np.abs(rho - ETA) < 0.01]) * N)
    return betas, sweep, sinf, g


def figC2():
    H = 118.0
    fig = new_fig(H)
    aw, ah, l1, l2 = 47.0, 38.0, 16.0, 84.0
    tops = [6.0, 6.0 + ah + 19.0]
    rt, eps, DE, (Ny, Nx), (LX, LY) = O._p2_state()
    hy = np.fft.fftfreq(Ny, 1 / Ny).astype(int); hx = np.fft.fftfreq(Nx, 1 / Nx).astype(int)
    HY, HX = np.meshgrid(hy, hx, indexing="ij")
    chk = O.J(os.path.join(O.F1D, "f1c_check_p2_state.json"))
    sg = O.J(os.path.join(S.DATA, "figS3_sigma_p2_state.json"))
    betas = np.array(sg["betas"]); sig = {k: np.array(v) for k, v in sg["sigma"].items()}; sinf = sg["sigma_inf"]
    ORD = {"M_d": MD, "M_g": MG, "M_r": MR}
    # (a) spectrum
    ax = axm(fig, H, l1, tops[0], aw, ah)
    shades = {8: "#9fd3d4", 32: "#5bb5b7", 128: TEAL, np.inf: "#0a4d4e"}
    hpos = np.arange(1, 300)
    for b in (8, 32, 128, np.inf):
        s_ = np.fft.fft2(eps(b)) / eps(b).size
        col = np.sqrt((np.abs(s_) ** 2).sum(axis=0)) / DE
        colx = {int(h): col[i] for i, h in enumerate(hx)}
        ax.plot(hpos, [max(colx[int(h)], 1e-9) for h in hpos], color=shades[b], lw=0.9,
                label=("$\\beta=%d$" % b) if np.isfinite(b) else "Binary")
    for l in (MD, MG, MR):
        ax.axvline(2 * l[0], color=OC[l], lw=1.1, ls=(0, (4, 2)), zorder=0)
        note(ax, 2 * l[0], 0.62, LAB[l], color=OC[l], ha="center", va="bottom", fontsize=8.0)
    ax.set_xscale("log"); ax.set_yscale("log"); ax.set_xlim(1, 300); ax.set_ylim(1e-6, 0.5)
    ax.set_xlabel("Harmonic $|h_x|$"); ax.set_ylabel("Spectrum, rms over $h_y$")
    reg_legend(ax, loc="lower left", bbox_to_anchor=(0.0, 0.0), handlelength=1.3, labelspacing=0.15, borderaxespad=0.1, fontsize=7.2)
    bold_ticks(ax); letter(fig, ax, "a")
    # (b) sigma
    ax = axm(fig, H, l2, tops[0], aw, ah)
    bx = {k: chk["orders"][k]["beta_x_dx"] for k in ORD}; bh = {k: chk["orders"][k]["beta_half"] for k in ORD}
    for k, l in ORD.items():
        ax.plot(betas, sig[k] / sinf[k], "-", color=OC[l], lw=1.4)
        ax.axvline(bx[k], color=OC[l], lw=0.9, ls=(0, (1.5, 1.5)), zorder=0)
        ax.plot([bh[k]], [0.5], "o", ms=3.8, color=OC[l], mec="white", mew=0.6, zorder=4)
    reg_legend(ax, handles=[Line2D([0], [0], color=INK2, marker="o", ls="none", ms=3.8, mec="white", mew=0.6, label="Half of $\\sigma_M(\\infty)$"),
                            Line2D([0], [0], color=INK2, lw=0.9, ls=(0, (1.5, 1.5)), label="$\\beta_\\times$")],
               loc="upper left", bbox_to_anchor=(0.0, 1.0), handlelength=1.5, labelspacing=0.15, borderaxespad=0.1, fontsize=7.2)
    ax.set_xscale("log"); ax.set_xlim(2, 2000); ax.set_ylim(0, 1.02)
    ax.set_xlabel("Projection sharpness $\\beta$"); ax.set_ylabel("$\\sigma_M\\,/\\,\\sigma_M(\\infty)$")
    bold_ticks(ax); letter(fig, ax, "b")
    # (c) sigma versus E
    ax = axm(fig, H, l1, tops[1], aw, ah)
    cmp_ = chk["compare"]; bb = np.array([r["beta"] for r in cmp_])
    for key, ek, l in (("sigma_Md", "E_Md", MD), ("sigma_Mg", "E_Mg", MG)):
        s_ = np.array([r[key] for r in cmp_]); ee = np.array([r[ek] for r in cmp_])
        ax.plot(bb, s_ / s_[-1], "-", color=OC[l], lw=1.4)
        ax.plot(bb, ee / ee[-1], "o", color=OC[l], ms=3.2, mew=0)
    ax.axhline(0, color=INK2, lw=0.5)
    ax.set_xscale("log"); ax.set_xlim(1.7, 2300); ax.set_ylim(-0.3, 1.12)
    ax.set_xlabel("Projection sharpness $\\beta$"); ax.set_ylabel("Normalized by the value\nat $\\beta=2000$")
    reg_legend(ax, handles=[Line2D([0], [0], color=INK2, lw=1.4, label="$\\sigma_M$"),
                            Line2D([0], [0], color=INK2, marker="o", ls="none", ms=3.2, mew=0, label="$E(M,\\beta)$")],
               loc="upper left", bbox_to_anchor=(0.0, 1.0), handlelength=1.4, labelspacing=0.15, borderaxespad=0.1, fontsize=7.2)
    note(ax, 1500, 0.52, LAB[MD], color=OC[MD], ha="right", va="center", fontsize=8.0)
    note(ax, 1500, 0.12, LAB[MG], color=OC[MG], ha="right", va="center", fontsize=8.0)
    bold_ticks(ax); letter(fig, ax, "c")
    # (d) collapse (illustrative design state of Fig. 1(c); colors of the windows of Fig. 1(c))
    cb, sweep, sinf2, g = _collapse_data()
    WIN = {3: "#ff2d2d", 7: "#ff4fd8", 15: "#ff9f1c"}
    ax = axm(fig, H, l2, tops[1], aw, ah)
    for M in (3, 5, 7, 10, 15):
        bx_ = 2 * np.pi ** 2 * M / g
        ax.plot(cb / bx_, sweep[:, 2 * M] / sinf2[2 * M], color=WIN.get(M, "#b0b0b0"), lw=1.3 if M in WIN else 0.9,
                zorder=3 if M in WIN else 2, label="$M=%d$" % M)
    ax.axvline(1.0, color=GREY, lw=0.8, ls=(0, (1, 1.5)))
    ax.set_xscale("log"); ax.set_xlim(1e-2, 1e2); ax.set_ylim(0, 1.05)
    ax.set_xlabel("$\\beta/\\beta_\\times$"); ax.set_ylabel("$\\sigma_M(\\beta)/\\sigma_M(\\infty)$")
    reg_legend(ax, loc="upper left", bbox_to_anchor=(0.0, 1.0), handlelength=1.4, labelspacing=0.15, borderaxespad=0.1, fontsize=7.2)
    bold_ticks(ax); letter(fig, ax, "d")
    save_c(fig, "figS2_permittivity_spectrum")


# ---------------------------------------------------------------------------------------------------------------------
# Fig. S3
# ---------------------------------------------------------------------------------------------------------------------
def figC3():
    H = 152.0
    fig = new_fig(H)
    S5D = os.path.join(EXP, "S5_method_control", "data")
    A = O.J(os.path.join(S5D, "s5_8a_analysis.json"))
    R = O.J(os.path.join(S5D, "s5_8a_readme_schedule.json"))
    u = R["units"]["3-0|s00"]
    SP, DP = TEAL, DARK
    aw, ah, l1, l2 = 47.0, 25.0, 16.0, 84.0
    # key of the P1 panels
    key_strip(fig, [Line2D([0], [0], color=OC[MD], lw=1.5, label="Objective at (20,5)"),
                    Line2D([0], [0], color=OC[MD], marker="o", mfc="white", mec=OC[MD], mew=0.9, ms=3.8, ls="none", label="Pattern at (20,5)"),
                    Line2D([0], [0], color=OC[MG], marker="s", ms=3.2, mew=0, lw=1.0, label="Pattern at (32,8)"),
                    Line2D([0], [0], color=OC[MR], marker="D", ms=3.2, mew=0, lw=1.0, label="Pattern at (40,10)")],
              y=1.0, ncol=2, fs=8.5, handlelength=1.8, columnspacing=1.2)
    t1 = 22.0
    # (a) P1 run
    ax = axm(fig, H, l1, t1, aw, ah)
    traj = np.array(u["trajectory"]); st = np.arange(len(traj)); tr = u["trace"]
    cs = np.array([t["step"] for t in tr])
    qd = np.array([t["eta_binary_descent"] for t in tr]); qg = np.array([t["eta_gate"] for t in tr]); qr = np.array([t["eta_trace"] for t in tr])
    ax.plot(st, traj, color=OC[MD], lw=1.1, zorder=3)
    ax.plot(cs, qd, "o", ms=2.8, mfc="white", mec=OC[MD], mew=0.8, zorder=4)
    ax.plot(cs, qg, "-s", color=OC[MG], lw=0.8, ms=2.4, mew=0, zorder=2)
    ax.plot(cs, qr, "-D", color=OC[MR], lw=0.9, ms=2.5, mew=0, zorder=2)
    note(ax, 0.97, 0.63, "Target (3,0),\nseed 53000", transform=ax.transAxes, ha="right", va="center", fontsize=7.4)
    ax.set_xlim(0, 800); ax.set_ylim(0, 1.0); ax.set_xlabel("Optimization step"); ax.set_ylabel("Efficiency")
    S.beta_top(ax, 800, ticks=(10, 100, 1000), label=True)
    bold_ticks(ax); letter(fig, ax, "a", dy=8.0)
    # (b) gap along the 18 runs
    ax = axm(fig, H, l2, t1, aw, ah)
    styles = {"1-0": "-", "2-0": "--", "3-0": ":"}
    for t, ls in styles.items():
        runs = A["targets"][t]["drift"]["per_run"]; steps = np.array(runs[0]["steps"])
        Gm = np.array([r["curve_gap"] for r in runs])
        for r in runs:
            hi = (t == "3-0" and r["seed"] == 53000)
            ax.plot(steps, r["curve_gap"], color=(TEAL if hi else GREY_L), lw=(1.0 if hi else 0.55), zorder=(2 if hi else 1))
        ax.plot(steps, np.median(Gm, axis=0), color=DARK, lw=1.4, ls=ls, zorder=3)
        ax.text(805, np.median(Gm, axis=0)[-1], "(%s)" % t.replace("-", ","), fontsize=7.2, color=INK, va="center", ha="left")
    ax.axhline(0, color=INK2, lw=0.5)
    ax.set_xlim(0, 800); ax.set_ylim(-0.15, 0.95)
    ax.set_xlabel("Optimization step"); ax.set_ylabel("Gap to the pattern at (40,10)")
    note(ax, 0.03, 0.98, "Gray: 18 runs\nBlack: median per channel\nTeal: the run of (a)", transform=ax.transAxes, va="top", ha="left", fontsize=7.0)
    S.beta_top(ax, 800, ticks=(10, 100, 1000), label=True)
    bold_ticks(ax); letter(fig, ax, "b", dy=8.0)
    # key of the precision panels
    t2 = t1 + ah + 28.0
    key_strip(fig, [Line2D([0], [0], color=SP, lw=2.2, label="Single precision"), Line2D([0], [0], color=DP, lw=2.2, label="Double precision")],
              y=1.0 - (t2 - 19.0) / H, ncol=2, fs=9.0, handlelength=2.0, columnspacing=2.0)
    # (c) error of every gradient
    F31 = O.F31
    Aud = O.J(os.path.join(F31, "f31_cliff_audit.json"))
    CF = O.J(os.path.join(F31, "f31_counterfactual.json")); CF4 = O.J(os.path.join(F31, "f31_counterfactual_426.json"))
    Z = O.J(os.path.join(F31, "f31_fig4c_s8set.json"))
    cw = 64.0
    ax = axm(fig, H, l1, t2, cw, ah)
    st = np.array([s["step"] for s in Aud["steps"]])
    err = np.array([O._rel_err(s["norm_c64"], s["norm_c128"], s["cos"]) for s in Aud["steps"]])
    ratio = np.array([s["norm_c64"] / s["norm_c128"] for s in Aud["steps"]])
    ax.semilogy(st, err, color=SP, lw=0.55)
    big = np.where(ratio >= 5)[0]
    ax.scatter(st[big], err[big], s=10, color=SP, zorder=3, linewidths=0)
    for s0, xt in ((162, 215), (426, 470)):
        i = int(np.where(st == s0)[0][0])
        ax.annotate("Step %d" % s0, (st[i], err[i]), xytext=(xt, 150), fontsize=7.4, color=INK2, ha="left", va="bottom",
                    arrowprops=dict(arrowstyle="-", color=INK2, lw=0.5, shrinkA=1, shrinkB=2))
    note(ax, 795, 4e-5, "Dots: $\\geq5\\times$ too large", ha="right", va="bottom", fontsize=7.2)
    ax.set_xlim(0, 800); ax.set_ylim(3e-5, 2e3)
    ax.set_xlabel("Optimization step"); ax.set_ylabel("Relative gradient error")
    S.beta_top(ax, 800, ticks=(10, 100, 1000), label=True)
    bold_ticks(ax); letter(fig, ax, "c", dy=8.0)
    # (d) replays
    x0 = l1 + cw + 17.0; sw = 15.5
    orig = np.array(CF["runs"]["original"]["trajectory"])
    for wi, (s0, alt) in enumerate(((162, np.array(CF["runs"]["c128_162"]["trajectory"])), (426, np.array(CF4["runs"]["c128_426"]["trajectory"])))):
        ax = axm(fig, H, x0 + wi * (sw + 3.5), t2, sw, ah)
        s = np.arange(s0 - 12, s0 + 36)
        ax.axvline(s0, color=GREY_L, lw=0.6, zorder=0)
        ax.plot(s, orig[s], color=SP, lw=1.1); ax.plot(s, alt[s], color=DP, lw=1.0)
        ax.set_xlim(s[0], s[-1]); ax.set_ylim(0.4, 1.0); ax.set_xticks([s0, s0 + 30]); ax.set_xlabel("Step")
        if wi == 0:
            ax.set_ylabel("Objective at $M_d$"); letter(fig, ax, "d", dx=-13.0, dy=8.0)
        else:
            ax.tick_params(labelleft=False)
        note(ax, s[-1] - 0.5, 0.42, "%d" % s0, va="bottom", ha="right", fontsize=7.2)
        bold_ticks(ax)
    # (e) fine scan
    t3 = t2 + ah + 16.0
    ax = axm(fig, H, l1, t3, aw, ah)
    rows = Z["scan"]; b = np.array([r["beta"] for r in rows])
    n64 = np.array([r["norm_c64"] for r in rows]); n128 = np.array([r["norm_c128"] for r in rows])
    ax.semilogy(b, n64, "-o", color=SP, lw=0.8, ms=2.0, mew=0); ax.semilogy(b, n128, "-s", color=DP, lw=0.8, ms=1.9, mew=0)
    bs = Z["meta"]["beta_spike"]
    ax.axvline(bs, color=GREY, lw=0.6, ls=(0, (2, 2)), zorder=0)
    note(ax, bs + 1.0, 3e2, "(f)", va="center", ha="left", fontsize=7.2)
    ax.set_xlim(b[0] - 2, b[-1] + 2); ax.set_xlabel("Projection sharpness $\\beta$"); ax.set_ylabel("Gradient norm")
    bold_ticks(ax); letter(fig, ax, "e")
    # (f) slopes
    ax = axm(fig, H, l2, t3, aw, ah)
    fd = Z["fd"]["%.4f" % bs]; w = 0.25
    for gi, key in enumerate(("d64", "d128")):
        rec = fd[key]; fdv = float(np.median([x["slope_fd_c128"] for x in rec["fd"]]))
        for kk, (v, col, hatch) in enumerate([(rec["ad_c64_along"], SP, None), (rec["ad_c128_along"], DP, None), (fdv, "white", "////")]):
            ax.bar(gi + (kk - 1) * w, v, width=w * 0.9, color=col, edgecolor=(INK2 if hatch else col), linewidth=0.6, hatch=hatch)
            if abs(v) < 5e-3:
                note(ax, gi + (kk - 1) * w, 0.04, "0", ha="center", va="bottom", fontsize=7.0)
    ax.axhline(0, color=INK2, lw=0.5)
    ax.set_xticks([0, 1]); ax.set_xticklabels(["Along the\nsingle-precision\ngradient", "Along the\ndouble-precision\ngradient"], fontsize=7.4)
    ax.set_ylabel("Slope of the objective")
    reg_legend(ax, handles=[Patch(facecolor=INK2, edgecolor=INK2, label="Automatic differentiation"),
                            Patch(facecolor="white", edgecolor=INK2, hatch="////", label="Finite difference")],
               loc="upper right", handlelength=1.1, fontsize=7.0, labelspacing=0.3, bbox_to_anchor=(1.0, 1.0))
    bold_ticks(ax); letter(fig, ax, "f")
    save_c(fig, "figS3_P1_and_single_precision")


# ---------------------------------------------------------------------------------------------------------------------
# Fig. S4
# ---------------------------------------------------------------------------------------------------------------------
def figC4():
    import sys as _s
    _s.path.insert(0, os.path.join(EXP, "S8_order_beta_map", "scripts"))
    import s8_plot as s8p
    A, G = s8p.load()
    H = 168.0
    fig = new_fig(H)
    handles = []
    roles = {(16, 2): "$M_d$", (28, 4): "$M_g$", (48, 7): "$M_r$"}
    for l in ORDERS:
        big = l in (MD, MG)
        handles.append(Line2D([0], [0], color=OC[l], lw=(1.5 if big else 0.9), marker="o", ms=(2.8 if big else 2.0), mew=0,
                              label=olab(l) + ("  " + roles[l] if l in roles else "")))
    key_strip(fig, handles, y=1.0, ncol=4, title="Truncation order (color in all panels)", fs=8.5, columnspacing=1.0, handlelength=1.3)
    left, aw, ah, gap = 17.0, 25.5, 25.0, 4.5
    ladd = [tuple(v) for v in A["meta"]["ladder"]]
    def rows_for(keys, big, top0, rowlabels):
        emin = min(float(np.min(O._frozen_state(A, s8p, k)[2][:, [ladd.index(l) for l in ORDERS]])) for k in keys)
        elo = min(-0.04, math.floor((emin - 0.005) * 100) / 100)
        for c, key in enumerate(keys):
            B, cl, E, ladd_, flag, bl, ref_b = O._frozen_state(A, s8p, key)
            x = left + c * (aw + gap)
            ax = axm(fig, H, x, top0, aw, ah)
            ax.axvspan(16, 128, color=BAND, zorder=0)
            for l in ORDERS:
                j = ladd_.index(l); bg = l in big
                ax.plot(B, E[:, j], "-o", color=OC[l], lw=(1.2 if bg else 0.7), ms=(2.1 if bg else 1.4), mew=0, zorder=(3 if bg else 2))
                ax.plot([2950], [bl["%d-%d" % l]["eta"] - ref_b], marker="<", color=OC[l], ms=3.2, mew=0, clip_on=False, zorder=3)
            ax.axhline(0, color=INK2, lw=0.5)
            ax.set_xscale("log"); ax.set_xlim(1.7, 2300); ax.set_ylim(elo, 0.17)
            ax.set_xticks([10, 100, 1000]); ax.set_xticklabels([])
            ax.set_title(O._title(key) + (" (Fig. 2)" if key == "m1_s00_st095" else ""), fontsize=7.0, fontweight="normal", color=INK, pad=2)
            if c == 0:
                ax.set_ylabel("$J_M-J_{\\rm ref}$"); letter(fig, ax, rowlabels[0], dx=-15.5, dy=7.5)
            else:
                ax.tick_params(labelleft=False)
            bold_ticks(ax)
            ax2 = axm(fig, H, x, top0 + ah + 4.0, aw, ah)
            for l in ORDERS:
                j = ladd_.index(l); bg = l in big
                keep = np.array([(key, float(b)) not in O.OMIT for b in B]); ok = keep & ~flag
                ax2.plot(B[ok], cl[ok, j], "-o", color=OC[l], lw=(1.2 if bg else 0.7), ms=(2.1 if bg else 1.4), mew=0, zorder=(3 if bg else 2))
                fl = keep & flag
                if fl.any():
                    ax2.plot(B[fl], cl[fl, j], "o", ms=(2.8 if bg else 2.2), mfc="white", mec=OC[l], mew=0.6, zorder=4, ls="none")
            ax2.axhline(1, color=INK2, lw=0.5)
            ax2.set_xscale("log"); ax2.set_xlim(1.7, 2300); ax2.set_ylim(-0.85, 1.06)
            ax2.set_xticks([10, 100, 1000]); ax2.set_xticklabels(["10", "100", "1000"])
            if c == 0:
                ax2.set_ylabel("Cosine"); letter(fig, ax2, rowlabels[1], dx=-15.5, dy=1.5)
            else:
                ax2.tick_params(labelleft=False)
            bold_ticks(ax2)
    rows_for(O.STATES[7], (MD, MG), 24.0, ("a", "b"))
    rows_for(O.STATES[8], ((24, 3), (40, 6)), 24.0 + 2 * ah + 4.0 + 17.0, ("c", "d"))
    fig.text(0.54, 0.052, "Projection sharpness $\\beta$ (design frozen)", ha="center", va="bottom", fontsize=S.ALS, fontweight="bold")
    save_c(fig, "figS4_frozen_states")


# ---------------------------------------------------------------------------------------------------------------------
# Fig. S5
# ---------------------------------------------------------------------------------------------------------------------
def figC5():
    H = 138.0
    fig = new_fig(H)
    aw, ah, l1, l2 = 47.0, 31.0, 16.0, 84.0
    tops = [6.0, 6.0 + ah + 20.0, 6.0 + 2 * (ah + 20.0)]
    conv, guard = O._ladders()
    # (a) ladders
    ax = axm(fig, H, l1, tops[0], aw, ah)
    for name, lad, col in (("Conventional", conv, GREY), ("Guarded", guard, DARK)):
        N = np.array([r["n_terms"] for r in lad], float); eta = np.array([r["eta"] for r in lad]); lv = [tuple(r["level"]) for r in lad]
        ax.plot(N, eta, "-", color=col, lw=1.0, zorder=2)
        for i, l in enumerate(lv):
            if l in (MD, MG, MR):
                ax.plot([N[i]], [eta[i]], "o", ms=4.4, color=OC[l], mec="white", mew=0.6, zorder=4)
        sel = np.array([l[0] >= 40 for l in lv])
        for a in (0.5, 1.0):
            e_inf, c = O._fit(N[sel], eta[sel], a)
            NN = np.geomspace(N[sel][0], 1e5, 60)
            ax.plot(NN, e_inf + c * NN ** (-a), color=col, lw=0.8, ls=(0, (1.5, 1.5)), zorder=1)
    note(ax, 2300, 0.84, "Guarded", color=DARK, ha="left", va="bottom", fontsize=7.4)
    note(ax, 2300, 0.55, "Conventional", color=INK2, ha="left", va="top", fontsize=7.4)
    ax.set_xscale("log"); ax.set_xlim(20, 1e5); ax.set_ylim(0.4, 1.0)
    ax.set_xlabel("Retained harmonics $N$"); ax.set_ylabel("Efficiency")
    bold_ticks(ax); letter(fig, ax, "a")
    # (b) change per order
    ax = axm(fig, H, l2, tops[0], aw, ah)
    for name, lad, col in (("Conventional", conv, GREY), ("Guarded", guard, DARK)):
        eta = np.array([r["eta"] for r in lad]); sel = np.array([r["level"][0] >= 28 for r in lad])
        es = eta[sel]; lv = [tuple(r["level"]) for r in lad if r["level"][0] >= 28]
        ax.bar(np.arange(len(es) - 1) + (0.2 if name == "Guarded" else -0.2), np.diff(es), width=0.38, color=col, lw=0)
    ax.axhline(0, color=INK2, lw=0.5)
    ax.set_xticks(np.arange(len(lv) - 1)); ax.set_xticklabels([olab(l) for l in lv[1:]], rotation=60, ha="right", fontsize=7.0)
    ax.set_ylabel("Change from\nthe previous order")
    reg_legend(ax, handles=[Patch(color=DARK, label="Guarded"), Patch(color=GREY, label="Conventional")], loc="lower right",
               handlelength=1.0, borderaxespad=0.1, fontsize=7.2)
    bold_ticks(ax); letter(fig, ax, "b")
    # (c) minimal model
    ax = axm(fig, H, l1, tops[1], aw, ah)
    steps = np.arange(O.STEPS + 1)
    s1, s8, s4 = O.minimal_model(None), O.minimal_model(8), O.minimal_model(4)
    ax.axvline(O.T_MIX, color=GREY, lw=0.6, ls=(0, (3, 2)))
    ax.plot(steps, s1, color=OC[MD], lw=1.3); ax.plot(steps, s8, color=OC[MG], lw=1.0, ls=(0, (4, 2))); ax.plot(steps, s4, color=OC[MG], lw=1.4)
    top = s1.max()
    note(ax, 165, 0.70 * top, "Single order", color=INK, ha="right", va="center", fontsize=7.4)
    note(ax, O.STEPS * 0.98, s8[-1] + 0.03 * top, "$k=8$", color=INK, ha="right", va="bottom", fontsize=7.4)
    note(ax, O.STEPS * 0.98, s4[-1] + 0.02 * top, "$k=4$", color=INK, ha="right", va="bottom", fontsize=7.4)
    note(ax, O.T_MIX + 3, 0.97 * top, "First gradient\nat $M_g$", ha="left", va="top", fontsize=7.2)
    ax.set_xlim(0, O.STEPS); ax.set_ylim(0, top * 1.08); ax.set_yticks([]); ax.set_xticks([0, 50, 100, 150, 200])
    ax.set_xlabel("Optimization step"); ax.set_ylabel("Model gap (arb. units)")
    bold_ticks(ax); letter(fig, ax, "c")
    # (d), (e) gap along runs
    S6 = O.J(os.path.join(EXP, "S6_lottery_pricing", "data", "s6_2d_mixed.json"))["units"]
    for j, m in enumerate((1, 2)):
        ax = axm(fig, H, (l2 if j == 0 else l1), (tops[1] if j == 0 else tops[2]), aw, ah)
        B = O.J(os.path.join(O.F33, "s10_B_m%d.json" % m))["tickets"]
        for arm, col, ls, lw in (("SINGLE", OC[MD], "-", 1.2), ("MIX8", OC[MG], (0, (4, 2)), 0.9), ("MIX4", OC[MG], (0, (1.2, 1.2)), 1.2)):
            us = [u for k, u in S6.items() if k.startswith("m%d|%s|" % (m, arm))]
            st = [c["step"] for c in us[0]["checkpoints"]]
            g = np.median(np.array([[c["gap_descent_minus_gate"] for c in u["checkpoints"]] for u in us]), axis=0)
            ax.plot(st, g, color=col, ls=ls, lw=lw)
        st = [c["step"] for c in B["s00"]["checkpoints"]]
        g = np.median(np.array([[c["gap_descent_minus_gate"] for c in u["checkpoints"]] for u in B.values()]), axis=0)
        ax.plot(st, g, color=OC[MG], lw=1.9)
        ax.axvline(54, color=GREY, lw=0.5, ls=(0, (3, 2))); ax.axvline(O.T_MIX, color=GREY, lw=0.5, ls=(0, (3, 2)))
        ax.axhline(0, color=INK2, lw=0.5)
        ax.set_xlim(0, O.STEPS); ax.set_ylim(-0.02, 0.2)
        ax.set_xlabel("Optimization step"); ax.set_ylabel("Gap between $M_d$ and $M_g$")
        note(ax, 0.04, 0.97, "Channel (%d,0)" % m, transform=ax.transAxes, va="top", ha="left", fontsize=7.4)
        bold_ticks(ax); letter(fig, ax, "de"[j])
    # key of (c)-(e)
    kx = axm(fig, H, l2, tops[2], aw, ah); kx.axis("off")
    hs = [Line2D([0], [0], color=OC[MD], lw=1.6, label="Single order (48 runs)"),
          Line2D([0], [0], color=OC[MG], lw=1.4, ls=(0, (4, 2)), label="$k=8$ from step 54 (48 runs)"),
          Line2D([0], [0], color=OC[MG], lw=1.6, ls=(0, (1.2, 1.2)), label="$k=4$ from step 54 (48 runs)"),
          Line2D([0], [0], color=OC[MG], lw=2.4, label="Guarded workflow (24 runs)")]
    leg = kx.legend(handles=hs, loc="center left", frameon=False, handlelength=2.6, labelspacing=0.6, title="Key of (c)–(e)", borderaxespad=0.0)
    for t in leg.get_texts():
        t.set_fontweight("bold"); t.set_fontsize(7.8); t.set_math_fontfamily("stix")
    leg.get_title().set_fontweight("bold"); leg.get_title().set_fontsize(8.4)
    save_c(fig, "figS5_convergence_and_gap")


if __name__ == "__main__":
    todo = sys.argv[1:] or ["C1", "C2", "C3", "C4", "C5"]
    for t in todo:
        globals()["fig" + t]()
