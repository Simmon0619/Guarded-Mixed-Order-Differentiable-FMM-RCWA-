"""
FS -- the figures of the Supplementary Information (2026-10-06).  Only existing data are used (no solves, no GPU).

  python fs_si_figures.py S1 S2 ...      (no argument: all)

Fig. S1  solve cost against 2N                       Table S3 of the SI (S5/S6/S8 timings)
Fig. S2  validation: Lumerical comparison, precision  E25 lumerical_xcheck.json, E17 parity.json
Fig. S3  band-limited permittivity of the real P2 state: spectrum, sigma_M(beta), sigma_M versus E(M, beta)
Fig. S5  P1 (second test problem): one run step by step, gap along 18 runs
Fig. S6  single-precision gradients (redrawn in the new type)
Fig. S7, S8  frozen design states: truncation error and gradient alignment, eight states
Fig. S9  convergence of the reference evaluation (the two delivered patterns of Figs. 2(a) and 4(a))
Fig. S10 minimal model of periodic injection
Fig. S11 gap between the orders along runs
(Fig. S4, the collapse of sigma_M, is drawn by F1_fig1_schematic/panels/c/fig1c_final_v2.py and copied.)
"""
import json
import math
import os
import sys

import numpy as np

import fs_style as S
from fs_style import (ANS, OC, MD, MG, MR, ORDERS, INK, INK2, GREY, GREY_L, DARK, TEAL, BAND, FILL_BIN, FILL_TRUNC, LAB, MM,
                      note, reg_legend, bold_ticks, panel, olab, beta_top, fig_mm, save, key_strip, EXP)
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

F31 = os.path.join(EXP, "F31_section31_figures", "data")
F33 = os.path.join(EXP, "F33_section33_results", "data")
F1D = os.path.join(EXP, "F1_fig1_schematic", "data")


def J(path):
    return json.load(open(path, encoding="utf-8"))


# ---------------------------------------------------------------------------------------------------------------------
# Fig. S1  Solve cost against 2N
# ---------------------------------------------------------------------------------------------------------------------
def figS1():
    # Table S3 of the SI: seconds per evaluation, host eigensolver (S5 sec. 7.3.1; S6 sec. 2.3; S8 sec. 1)
    p1_10 = {350: 0.077, 902: 0.587, 2210: 5.15, 3402: 18.4, 4850: 53.8}
    p1_5 = {350: 0.069, 902: 0.555, 2210: 5.05, 3402: 18.2, 4850: 54.3}
    p2_f = {686: 0.29, 1026: 0.75, 2106: 5.3, 2314: 6.9, 2910: 13.5, 4598: 58.0, 4902: 129.0}
    p2_g = {330: 0.08, 686: 0.38, 1026: 0.99, 2106: 7.1, 2910: 18.2, 4598: 75.3}
    fig = fig_mm(180, 62)
    gs = GridSpec(1, 2, figure=fig, width_ratios=[1.35, 1.0], wspace=0.34, left=0.085, right=0.995, top=0.97, bottom=0.2)
    ax = fig.add_subplot(gs[0, 0])
    for d, mk, fc, lab in ((p1_10, "o", TEAL, "P1, 10 nm grid"), (p1_5, "o", "white", "P1, 5 nm grid")):
        x = np.array(sorted(d)); y = np.array([d[k] for k in x])
        ax.plot(x, y, "-" if fc != "white" else "none", marker=mk, ms=4.2, mfc=fc, mec=TEAL, mew=0.9, color=TEAL, lw=0.9,
                label="Forward, " + lab, zorder=3)
    x = np.array(sorted(p2_f)); y = np.array([p2_f[k] for k in x])
    ax.plot(x, y, "-", marker="s", ms=3.6, color=DARK, mfc=DARK, mew=0, lw=0.9, label="Forward, P2", zorder=3)
    x = np.array(sorted(p2_g)); y = np.array([p2_g[k] for k in x])
    ax.plot(x, y, "--", marker="^", ms=4.4, color=DARK, mfc="white", mew=0.9, lw=0.9, label="Value and gradient, P2", zorder=3)
    xx = np.array([300, 6000.0])
    ax.plot(xx, 0.077 * (xx / 350.0) ** 3, ":", color=GREY, lw=1.0, zorder=1)
    note(ax, 330, 0.077 * (330 / 350.0) ** 3 * 5.5, r"Guide: $\propto (2N)^3$", ha="left", va="bottom", color=GREY, rotation=47, rotation_mode="anchor")
    note(ax, 5400, 129.0, "Paging", ha="left", va="center")
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlim(280, 7600); ax.set_ylim(0.04, 400)
    ax.set_xticks([300, 1000, 3000]); ax.set_xticklabels(["300", "1000", "3000"])
    ax.set_xlabel("Dimension of the layer eigenproblem $2N$")
    ax.set_ylabel("Time per evaluation (s)")
    reg_legend(ax, loc="upper left", handlelength=2.0, labelspacing=0.25, borderaxespad=0.1)
    bold_ticks(ax); panel(ax, "a", x=-0.17)
    ax = fig.add_subplot(gs[0, 1])
    for d, fc, lab in ((p1_10, TEAL, "10 nm"), (p1_5, "white", "5 nm")):
        k = np.array(sorted(d)); t = np.array([d[i] for i in k])
        xm = np.sqrt(k[1:] * k[:-1]); sl = np.diff(np.log(t)) / np.diff(np.log(k))
        ax.plot(xm, sl, "-o" if fc != "white" else "o", ms=4.2, mfc=fc, mec=TEAL, mew=0.9, color=TEAL, lw=0.9, label="P1, " + lab)
    ax.axhline(3, color=GREY, lw=0.8, ls=":")
    note(ax, 5800, 3.03, "3", ha="right", va="bottom", color=GREY)
    ax.set_xscale("log"); ax.set_xlim(330, 6200); ax.set_ylim(1.6, 3.3)
    ax.set_xticks([500, 1000, 3000]); ax.set_xticklabels(["500", "1000", "3000"])
    ax.set_xlabel("Dimension $2N$ (midpoint of each pair)")
    ax.set_ylabel("Local exponent $\\mathrm{d}\\log t\\,/\\,\\mathrm{d}\\log 2N$")
    reg_legend(ax, loc="lower right", handlelength=1.4, borderaxespad=0.1)
    bold_ticks(ax); panel(ax, "b", x=-0.2)
    save(fig, "figS01_cost_scaling")


# ---------------------------------------------------------------------------------------------------------------------
# Fig. S2  Validation: Lumerical, precision
# ---------------------------------------------------------------------------------------------------------------------
def figS2():
    X = J(os.path.join(EXP, "E25_lumerical_xcheck", "data", "lumerical_xcheck.json"))
    P = J(os.path.join(EXP, "E17_stage0_gpu_c64", "data", "parity.json"))
    # range of our own value across (24,6)-(40,10) and the grids of E24/E25 (SI Table S6)
    band = {"(1, 0)": (0.799, 0.834), "(2, 0)": (0.828, 0.848), "(3, 0)": (0.307, 0.393)}
    fig = fig_mm(180, 66)
    gs = GridSpec(1, 3, figure=fig, width_ratios=[1.45, 1.0, 1.0], wspace=0.45, left=0.075, right=0.995, top=0.88, bottom=0.2)
    ax = fig.add_subplot(gs[0, 0])
    gcol = {"201": "#c9c8c3", "401": "#8c8b86", "801": "#3b3a37"}
    for i, t in enumerate(("(1, 0)", "(2, 0)", "(3, 0)")):
        d = X["designs"][t]
        lo, hi = band[t]
        ax.plot([i - 0.28, i - 0.28], [lo, hi], "-", color=TEAL, lw=4.5, solid_capstyle="butt", zorder=2)
        ax.plot([i - 0.28], [d["ours_28_7_c128"]["eta_target"]], "D", color="white", mec=TEAL, mew=1.0, ms=4.4, zorder=3)
        for j, k in enumerate(("201", "401", "801")):
            ax.plot([i + 0.05 + 0.13 * j], [d["lumerical"][k]["eta_target_Tp"]], "o", ms=5.0, color=gcol[k], mec=INK2, mew=0.5, zorder=3)
    ax.set_xticks([0, 1, 2]); ax.set_xticklabels(["(1,0)", "(2,0)", "(3,0)"])
    ax.set_xlim(-0.6, 2.6); ax.set_ylim(0.2, 1.5)
    ax.set_yticks([0.2, 0.4, 0.6, 0.8])
    ax.set_xlabel("Target channel"); ax.set_ylabel("Efficiency of the target channel")
    reg_legend(ax, handles=[Line2D([0], [0], color=TEAL, lw=4.5, label="This work, orders (24,6) to (40,10)"),
                            Line2D([0], [0], marker="D", ls="none", mfc="white", mec=TEAL, mew=1.0, ms=4.4, label="This work, (28,7)"),
                            Line2D([0], [0], marker="o", ls="none", mfc=gcol["201"], mec=INK2, mew=0.5, ms=5, label="Lumerical, 201 k-vectors"),
                            Line2D([0], [0], marker="o", ls="none", mfc=gcol["401"], mec=INK2, mew=0.5, ms=5, label="Lumerical, 401 k-vectors"),
                            Line2D([0], [0], marker="o", ls="none", mfc=gcol["801"], mec=INK2, mew=0.5, ms=5, label="Lumerical, 801 k-vectors")],
               loc="upper left", bbox_to_anchor=(0.0, 1.02), ncol=1, handlelength=1.6, labelspacing=0.15,
               borderaxespad=0.0, fontsize=7.4)
    bold_ticks(ax); panel(ax, "a", x=-0.2)
    pr = P["projected"]
    cosd = np.array([1.0 - r["grad_cosine"] for r in pr]); cosd = np.maximum(cosd, 1e-12)
    val = np.array([r["rel_value_err"] for r in pr]); val = np.maximum(val, 1e-9)
    for k, (arr, xl, lo_, hi_, ann) in enumerate(((val, "Relative value error", -9, -2.5, "Median %.1e" % np.median(val)),
                                                    (cosd, "$1-$cosine of the gradients", -12, 0, None))):
        ax = fig.add_subplot(gs[0, 1 + k])
        bins = np.logspace(lo_, hi_, 28)
        ax.hist(arr, bins=bins, color=GREY_L, edgecolor=INK2, lw=0.4)
        ax.set_xscale("log")
        ax.set_xlabel(xl); ax.set_ylabel("Number of states" if k == 0 else "")
        med = np.median(arr)
        ax.axvline(med, color=TEAL, lw=1.0)
        e = int(math.floor(math.log10(med))); mant = med / 10 ** e
        note(ax, med * 1.8, ax.get_ylim()[1] * 0.97, "Median\n$%.1f\\times10^{%d}$" % (mant, e), color=TEAL, ha="left", va="top", fontsize=7.6)
        note(ax, 0.04 if k == 0 else 0.96, 0.97, "189 states", transform=ax.transAxes, ha="left" if k == 0 else "right",
             va="top", fontsize=7.6)
        bold_ticks(ax); panel(ax, "bc"[k], x=-0.26 if k == 0 else -0.2)
    save(fig, "figS02_validation")


# ---------------------------------------------------------------------------------------------------------------------
# Fig. S3  Band-limited permittivity of the real P2 frozen state (the state of Fig. 2(d,e))
# ---------------------------------------------------------------------------------------------------------------------
def _p2_state():
    """eps_beta(rho) of the stored latent of m1_s00_st095 (P2, y-mirror), as in f1c_check_on_p2_state.py."""
    import torch
    sys.path.insert(0, os.path.join(EXP, "..", "src"))
    from trustworthy_fmm.fabrication.process import periodic_gaussian_filter, tanh_projection
    lat = np.load(os.path.join(EXP, "S8_order_beta_map", "data", "designs", "m1_s00_st095_latent.npy"))
    Ny, Nx = lat.shape
    LX, LY, R, ETA = 3000.0, 500.0, 60.0, 0.5
    EB, EF = 1.0, 3.2 ** 2

    def Smir(a):
        return 0.5 * (a + a[::-1, :])
    rt = Smir(periodic_gaussian_filter(torch.tensor(Smir(lat)), (LX, LY), R).numpy())

    def eps(beta):
        if np.isinf(beta):
            return EB + (EF - EB) * (rt >= ETA)
        return EB + (EF - EB) * tanh_projection(torch.tensor(rt), float(beta), ETA).numpy()
    return rt, eps, EF - EB, (Ny, Nx), (LX, LY)


def figS3():
    rt, eps, DE, (Ny, Nx), (LX, LY) = _p2_state()
    hy = np.fft.fftfreq(Ny, 1 / Ny).astype(int)
    hx = np.fft.fftfreq(Nx, 1 / Nx).astype(int)
    HY, HX = np.meshgrid(hy, hx, indexing="ij")
    chk = J(os.path.join(F1D, "f1c_check_p2_state.json"))

    def sigma(e, M):
        s = np.fft.fft2(e) / e.size
        inside = (np.abs(HX) <= 2 * M[0]) & (np.abs(HY) <= 2 * M[1])
        return float(np.sqrt((np.abs(s[~inside]) ** 2).sum()) / DE)

    ORD = {"M_d": MD, "M_g": MG, "M_r": MR}
    betas = np.geomspace(2, 2000, 60)
    sig = {k: np.array([sigma(eps(b), M) for b in betas]) for k, M in ORD.items()}
    sinf = {k: sigma(eps(np.inf), M) for k, M in ORD.items()}
    json.dump({"betas": betas.tolist(), "sigma": {k: v.tolist() for k, v in sig.items()}, "sigma_inf": sinf},
              open(os.path.join(S.DATA, "figS3_sigma_p2_state.json"), "w"))

    fig = fig_mm(180, 64)
    gs = GridSpec(1, 3, figure=fig, width_ratios=[1.0, 1.0, 1.0], wspace=0.42, left=0.07, right=0.995, top=0.9, bottom=0.2)
    # (a) rms amplitude per column h_x of the spectrum for four beta, windows 2 M_x
    ax = fig.add_subplot(gs[0, 0])
    shades = {8: "#9fd3d4", 32: "#5bb5b7", 128: TEAL, np.inf: "#0a4d4e"}
    hpos = np.arange(1, 300)
    for b in (8, 32, 128, np.inf):
        s = np.fft.fft2(eps(b)) / eps(b).size
        col = np.sqrt((np.abs(s) ** 2).sum(axis=0)) / DE                  # all h_y, per h_x column
        colx = {int(h): col[i] for i, h in enumerate(hx)}
        ax.plot(hpos, [max(colx[int(h)], 1e-9) for h in hpos], color=shades[b], lw=1.0,
                label=("$\\beta=%d$" % b) if np.isfinite(b) else "Binary pattern")
    for l in (MD, MG, MR):
        ax.axvline(2 * l[0], color=OC[l], lw=1.2, ls=(0, (4, 2)), zorder=0)
        note(ax, 2 * l[0], 0.55, LAB[l], color=OC[l], ha="center", va="bottom", fontsize=8.5)
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlim(1, 300); ax.set_ylim(1e-6, 0.5)
    ax.set_xlabel("Harmonic $|h_x|$"); ax.set_ylabel("Spectrum, rms over $h_y$ ($/\\Delta\\varepsilon$)")
    reg_legend(ax, loc="lower left", bbox_to_anchor=(0.0, 0.0), handlelength=1.4, labelspacing=0.2, borderaxespad=0.1)
    bold_ticks(ax); panel(ax, "a", x=-0.22)
    # (b) sigma_M / sigma_M(inf) against beta
    ax = fig.add_subplot(gs[0, 1])
    bx = {k: chk["orders"][k]["beta_x_dx"] for k in ORD}
    bh = {k: chk["orders"][k]["beta_half"] for k in ORD}
    for k, l in ORD.items():
        ax.plot(betas, sig[k] / sinf[k], "-", color=OC[l], lw=1.5)
        ax.axvline(bx[k], color=OC[l], lw=0.9, ls=(0, (1.5, 1.5)), zorder=0)
        ax.plot([bh[k]], [0.5], "o", ms=4.2, color=OC[l], mec="white", mew=0.6, zorder=4)
    reg_legend(ax, handles=[Line2D([0], [0], color=INK2, marker="o", ls="none", ms=4.2, mec="white", mew=0.6,
                                   label="Half of $\\sigma_M(\\infty)$"),
                            Line2D([0], [0], color=INK2, lw=0.9, ls=(0, (1.5, 1.5)), label="$\\beta_\\times$, Sec. 2.1")],
               loc="upper left", bbox_to_anchor=(0.0, 1.0), handlelength=1.6, labelspacing=0.2, borderaxespad=0.1)
    ax.set_xscale("log"); ax.set_xlim(2, 2000); ax.set_ylim(0, 1.02)
    ax.set_xlabel("Projection sharpness $\\beta$"); ax.set_ylabel("$\\sigma_M\\,/\\,\\sigma_M(\\infty)$")
    bold_ticks(ax); panel(ax, "b", x=-0.2)
    # (c) sigma_M against the truncation error of the objective (S8 map), M_d and M_g
    ax = fig.add_subplot(gs[0, 2])
    cmp_ = chk["compare"]
    bb = np.array([r["beta"] for r in cmp_])
    for key, ek, l in (("sigma_Md", "E_Md", MD), ("sigma_Mg", "E_Mg", MG)):
        sg = np.array([r[key] for r in cmp_]); ee = np.array([r[ek] for r in cmp_])
        ax.plot(bb, sg / sg[-1], "-", color=OC[l], lw=1.5)
        ax.plot(bb, ee / ee[-1], "o", color=OC[l], ms=3.6, mew=0)
    ax.axhline(0, color=INK2, lw=0.5)
    ax.set_xscale("log"); ax.set_xlim(1.7, 2300); ax.set_ylim(-0.3, 1.12)
    ax.set_xlabel("Projection sharpness $\\beta$"); ax.set_ylabel("Normalized by the value at $\\beta=2000$")
    reg_legend(ax, handles=[Line2D([0], [0], color=INK2, lw=1.5, label="$\\sigma_M$"),
                            Line2D([0], [0], color=INK2, marker="o", ls="none", ms=3.6, mew=0, label="$E(M,\\beta)$")],
               loc="upper left", bbox_to_anchor=(0.0, 1.0), handlelength=1.4, labelspacing=0.2, borderaxespad=0.1)
    note(ax, 1500, 0.55, LAB[MD], color=OC[MD], ha="right", va="center", fontsize=8.5)
    note(ax, 1500, 0.12, LAB[MG], color=OC[MG], ha="right", va="center", fontsize=8.5)
    bold_ticks(ax); panel(ax, "c", x=-0.2)
    save(fig, "figS03_bandlimit_p2_state")


# ---------------------------------------------------------------------------------------------------------------------
# Fig. S4  Collapse of sigma_M (drawn in F1; copied)
# ---------------------------------------------------------------------------------------------------------------------
def figS4():
    import shutil
    src = os.path.join(EXP, "F1_fig1_schematic", "panels", "c", "final_v2")
    for ext in ("png", "svg"):
        shutil.copyfile(os.path.join(src, "SI_collapse_labelled.%s" % ext), os.path.join(S.OUT, "figS04_collapse.%s" % ext))
    print("copied figS04_collapse")


# ---------------------------------------------------------------------------------------------------------------------
# Fig. S5  P1, the second test problem
# ---------------------------------------------------------------------------------------------------------------------
def figS5():
    S5D = os.path.join(EXP, "S5_method_control", "data")
    A = J(os.path.join(S5D, "s5_8a_analysis.json"))
    R = J(os.path.join(S5D, "s5_8a_readme_schedule.json"))
    u = R["units"]["3-0|s00"]                                   # P1, m = 3, seed 53000
    P1D, P1G, P1R = (20, 5), (32, 8), (40, 10)
    fig = fig_mm(180, 74)
    gs = GridSpec(1, 2, figure=fig, width_ratios=[1.0, 1.0], wspace=0.34, left=0.07, right=0.985, top=0.74, bottom=0.18)
    key_strip(fig, [Line2D([0], [0], color=OC[MD], lw=1.6, label="Objective at (20,5)"),
                    Line2D([0], [0], color=OC[MD], marker="o", mfc="white", mec=OC[MD], mew=0.9, ms=4, ls="none", label="Pattern at (20,5)"),
                    Line2D([0], [0], color=OC[MG], marker="s", ms=3.4, mew=0, lw=1.0, label="Pattern at (32,8)"),
                    Line2D([0], [0], color=OC[MR], marker="D", ms=3.4, mew=0, lw=1.0, label="Pattern at (40,10)")],
              y=0.995, ncol=4, fs=9.0, handlelength=1.8, columnspacing=1.2)
    ax = fig.add_subplot(gs[0, 0])
    traj = np.array(u["trajectory"]); st = np.arange(len(traj))
    tr = u["trace"]
    cs = np.array([t["step"] for t in tr])
    qd = np.array([t["eta_binary_descent"] for t in tr]); qg = np.array([t["eta_gate"] for t in tr]); qr = np.array([t["eta_trace"] for t in tr])
    ax.plot(st, traj, color=OC[MD], lw=1.2, zorder=3)
    ax.plot(cs, qd, "o", ms=3.0, mfc="white", mec=OC[MD], mew=0.9, zorder=4)
    ax.plot(cs, qg, "-s", color=OC[MG], lw=0.8, ms=2.6, mew=0, zorder=2)
    ax.plot(cs, qr, "-D", color=OC[MR], lw=1.0, ms=2.7, mew=0, zorder=2)
    note(ax, 0.97, 0.62, "Run of P1, target (3,0),\nseed 53000", transform=ax.transAxes, ha="right", va="center")
    ax.set_xlim(0, 800); ax.set_ylim(0, 1.0)
    ax.set_xlabel("Optimization step"); ax.set_ylabel("Efficiency")
    beta_top(ax, 800)
    bold_ticks(ax); panel(ax, "a", x=-0.17, y=1.14)
    ax = fig.add_subplot(gs[0, 1])
    styles = {"1-0": "-", "2-0": "--", "3-0": ":"}
    for t, ls in styles.items():
        runs = A["targets"][t]["drift"]["per_run"]
        steps = np.array(runs[0]["steps"])
        G = np.array([r["curve_gap"] for r in runs])
        for r in runs:
            hi = (t == "3-0" and r["seed"] == 53000)
            ax.plot(steps, r["curve_gap"], color=(TEAL if hi else GREY_L), lw=(1.0 if hi else 0.6), zorder=(2 if hi else 1))
        ax.plot(steps, np.median(G, axis=0), color=DARK, lw=1.6, ls=ls, zorder=3)
        ax.text(805, np.median(G, axis=0)[-1], "(%s)" % t.replace("-", ","), fontsize=ANS, color=INK, va="center", ha="left")
    ax.axhline(0, color=INK2, lw=0.5)
    ax.set_xlim(0, 800); ax.set_ylim(-0.15, 0.95)
    ax.set_xlabel("Optimization step"); ax.set_ylabel("Pattern at the optimization order\nminus pattern at (40,10)")
    note(ax, 0.03, 0.98, "Gray: the 18 runs (six per target channel)\nBlack: median per channel\nTeal: the run of (a)", transform=ax.transAxes, va="top", ha="left")
    beta_top(ax, 800)
    bold_ticks(ax); panel(ax, "b", x=-0.2, y=1.14)
    save(fig, "figS05_P1_run_and_gap")


# ---------------------------------------------------------------------------------------------------------------------
# Fig. S6  Single-precision gradients
# ---------------------------------------------------------------------------------------------------------------------
def _rel_err(n64, n128, c):
    r = n64 / max(n128, 1e-300)
    return math.sqrt(max(r * r + 1.0 - 2.0 * r * c, 0.0))


def figS6():
    SP, DP = TEAL, DARK
    A = J(os.path.join(F31, "f31_cliff_audit.json"))
    CF = J(os.path.join(F31, "f31_counterfactual.json"))
    CF4 = J(os.path.join(F31, "f31_counterfactual_426.json"))
    Z = J(os.path.join(F31, "f31_fig4c_s8set.json"))
    fig = fig_mm(180, 124)
    gs = GridSpec(2, 2, figure=fig, height_ratios=[0.9, 1.0], width_ratios=[1.5, 1.0], hspace=0.62, wspace=0.34,
                  left=0.075, right=0.99, top=0.86, bottom=0.095)
    key_strip(fig, [Line2D([0], [0], color=SP, lw=2.2, label="Single precision (complex64)"),
                    Line2D([0], [0], color=DP, lw=2.2, label="Double precision (complex128)")], y=0.995, fs=10.0)
    ax = fig.add_subplot(gs[0, 0])
    st = np.array([s["step"] for s in A["steps"]])
    err = np.array([_rel_err(s["norm_c64"], s["norm_c128"], s["cos"]) for s in A["steps"]])
    ratio = np.array([s["norm_c64"] / s["norm_c128"] for s in A["steps"]])
    ax.semilogy(st, err, color=SP, lw=0.6)
    big = np.where(ratio >= 5)[0]
    ax.scatter(st[big], err[big], s=13, color=SP, zorder=3, linewidths=0)
    for s0, xt in ((162, 215), (426, 470)):
        i = int(np.where(st == s0)[0][0])
        ax.annotate("Step %d" % s0, (st[i], err[i]), xytext=(xt, 150), fontsize=ANS, color=INK2, ha="left", va="bottom",
                    arrowprops=dict(arrowstyle="-", color=INK2, lw=0.5, shrinkA=1, shrinkB=2))
    note(ax, 795, 4e-5, "Dots: gradient $\\geq5\\times$ too large", ha="right", va="bottom")
    ax.set_xlim(0, 800); ax.set_ylim(3e-5, 2e3)
    ax.set_xlabel("Optimization step (the run of Fig. 2(a,b))")
    ax.set_ylabel("Relative error of the\nsingle-precision gradient")
    beta_top(ax, 800)
    bold_ticks(ax); panel(ax, "a", x=-0.13, y=1.14)
    sub = gs[0, 1].subgridspec(1, 2, wspace=0.12)
    orig = np.array(CF["runs"]["original"]["trajectory"])
    for wi, (s0, alt) in enumerate(((162, np.array(CF["runs"]["c128_162"]["trajectory"])),
                                    (426, np.array(CF4["runs"]["c128_426"]["trajectory"])))):
        ax = fig.add_subplot(sub[0, wi])
        s = np.arange(s0 - 12, s0 + 36)
        ax.axvline(s0, color=GREY_L, lw=0.6, zorder=0)
        ax.plot(s, orig[s], color=SP, lw=1.3)
        ax.plot(s, alt[s], color=DP, lw=1.1)
        ax.set_xlim(s[0], s[-1]); ax.set_ylim(0.4, 1.0); ax.set_xticks([s0, s0 + 30]); ax.set_xlabel("Step")
        note(ax, s[-1] - 0.5, 0.42, "Step %d\nreplaced" % s0, va="bottom", ha="right", fontsize=7.4)
        if wi == 0:
            ax.set_ylabel("Smooth objective at $M_d$")
            panel(ax, "b", x=-0.62, y=1.14)
        else:
            ax.tick_params(labelleft=False)
        bold_ticks(ax)
    ax = fig.add_subplot(gs[1, 0])
    rows = Z["scan"]
    b = np.array([r["beta"] for r in rows])
    n64 = np.array([r["norm_c64"] for r in rows]); n128 = np.array([r["norm_c128"] for r in rows])
    ax.semilogy(b, n64, "-o", color=SP, lw=0.9, ms=2.4, mew=0)
    ax.semilogy(b, n128, "-s", color=DP, lw=0.9, ms=2.2, mew=0)
    ib = int(np.argmax(n64))
    note(ax, b[ib] + 1.5, n64[ib], "Single precision", color=SP, va="center", ha="left")
    note(ax, b[0] + 1, n128[0] * 1.5, "Double precision", color=DP, va="bottom", ha="left")
    bs = Z["meta"]["beta_spike"]
    ax.axvline(bs, color=GREY, lw=0.6, ls=(0, (2, 2)), zorder=0)
    note(ax, bs + 0.8, 3e2, "(d)", va="center", ha="left", fontsize=7.6)
    ax.set_xlim(b[0] - 2, b[-1] + 2)
    ax.set_xlabel("Projection sharpness $\\beta$ (frozen state of Fig. 2(d,e))")
    ax.set_ylabel("Gradient norm at $M_g$")
    bold_ticks(ax); panel(ax, "c", x=-0.13)
    ax = fig.add_subplot(gs[1, 1])
    fd = Z["fd"]["%.4f" % bs]
    w = 0.25
    for gi, key in enumerate(("d64", "d128")):
        rec = fd[key]
        fdv = float(np.median([x["slope_fd_c128"] for x in rec["fd"]]))
        for kk, (v, col, hatch) in enumerate([(rec["ad_c64_along"], SP, None), (rec["ad_c128_along"], DP, None), (fdv, "white", "////")]):
            ax.bar(gi + (kk - 1) * w, v, width=w * 0.9, color=col, edgecolor=(INK2 if hatch else col), linewidth=0.7, hatch=hatch)
            if abs(v) < 5e-3:
                note(ax, gi + (kk - 1) * w, 0.04, "0", ha="center", va="bottom", fontsize=7.6)
    ax.axhline(0, color=INK2, lw=0.5)
    ax.set_xticks([0, 1]); ax.set_xticklabels(["Along the single-\nprecision gradient", "Along the double-\nprecision gradient"])
    ax.set_ylabel("Slope of the objective")
    note(ax, 0.995, 0.57, "Frozen state,\n$\\beta=363.45$, order $M_g$", transform=ax.transAxes, ha="right", va="center", fontsize=7.6)
    reg_legend(ax, handles=[Patch(facecolor=INK2, edgecolor=INK2, label="Automatic differentiation"),
                            Patch(facecolor="white", edgecolor=INK2, hatch="////", label="Finite difference")],
               loc="upper right", handlelength=1.2, fontsize=7.6, labelspacing=0.4, bbox_to_anchor=(1.0, 1.0))
    bold_ticks(ax); panel(ax, "d", x=-0.24)
    save(fig, "figS06_single_precision")


# ---------------------------------------------------------------------------------------------------------------------
# Fig. S7, S8  Frozen design states: truncation error and gradient alignment
# ---------------------------------------------------------------------------------------------------------------------
STATES = {7: ["m1_s00_st054", "m1_s00_st095", "m1_s00_st219", "m1_s01_st095"],
          8: ["m3_s00_st054", "m3_s00_st095", "m3_s00_st219", "m3_s01_st095"]}
OMIT = {("m1_s00_st095", 8.0), ("m1_s00_st095", 256.0)}      # (48,7) also suspect there (SI Sec. S3.5)


def _frozen_state(A, s8p, key):
    betas, cl, cd, E, Q, pts = s8p.grids(A, key)
    ladd = [tuple(v) for v in A["meta"]["ladder"]]
    flag = np.array([s8p.ref_flag(p) for p in pts])
    bl = A["binary_ladder"][key]["ladder"]
    ref_b = bl["%d-%d" % ladd[-1]]["eta"]
    return np.array(betas), cl, E, ladd, flag, bl, ref_b


def _title(key):
    m = int(key[1]); si = int(key[4:6]); stg = int(key[-3:])
    return "(%d,0), run %d\nafter %d steps" % (m, si, stg)


def _figS78(num):
    sys.path.insert(0, os.path.join(EXP, "S8_order_beta_map", "scripts"))
    import s8_plot as s8p
    A, G = s8p.load()
    keys = STATES[num]
    fig = fig_mm(180, 120)
    gs = GridSpec(2, 4, figure=fig, hspace=0.30, wspace=0.12, left=0.075, right=0.99, top=0.80, bottom=0.14)
    handles = []
    roles = {(16, 2): "$M_d$", (28, 4): "$M_g$", (48, 7): "$M_r$"} if num == 7 else {(24, 3): "$M_d$", (40, 6): "$M_g$"}
    BIG = tuple(roles.keys())[:2]
    for l in ORDERS:
        big = l in BIG
        handles.append(Line2D([0], [0], color=OC[l], lw=(1.6 if big else 1.0), marker="o", ms=(3.0 if big else 2.2), mew=0,
                              label=olab(l) + ("  " + roles[l] if l in roles else "")))
    key_strip(fig, handles, y=0.995, ncol=7, title="Truncation order (color in all panels)", fs=9.0, columnspacing=0.9, handlelength=1.4)
    emin = min(float(np.min(_frozen_state(A, s8p, k)[2][:, [ [tuple(v) for v in A["meta"]["ladder"]].index(l) for l in ORDERS ]])) for k in keys)
    elo = min(-0.04, math.floor((emin - 0.005) * 100) / 100)
    for c, key in enumerate(keys):
        B, cl, E, ladd, flag, bl, ref_b = _frozen_state(A, s8p, key)
        ax = fig.add_subplot(gs[0, c])
        ax.axvspan(16, 128, color=BAND, zorder=0)
        for l in ORDERS:
            j = ladd.index(l); big = l in BIG
            ax.plot(B, E[:, j], "-o", color=OC[l], lw=(1.3 if big else 0.8), ms=(2.4 if big else 1.6), mew=0, zorder=(3 if big else 2))
            ax.plot([2950], [bl["%d-%d" % l]["eta"] - ref_b], marker="<", color=OC[l], ms=3.6, mew=0, clip_on=False, zorder=3)
        ax.axhline(0, color=INK2, lw=0.5)
        ax.set_xscale("log"); ax.set_xlim(1.7, 2300); ax.set_ylim(elo, 0.17)
        ax.set_xticks([10, 100, 1000]); ax.set_xticklabels([])
        ax.set_title(_title(key) + (" (Fig. 2)" if key == "m1_s00_st095" else ""), fontsize=7.8, fontweight="normal", color=INK, pad=3)
        if c == 0:
            ax.set_ylabel("Error of the objective,\n$J_M-J_{\\rm ref}$")
        else:
            ax.tick_params(labelleft=False)
        bold_ticks(ax)
        if c == 0:
            panel(ax, "a", x=-0.42, y=1.12)
        ax = fig.add_subplot(gs[1, c])
        for l in ORDERS:
            j = ladd.index(l); big = l in BIG
            keep = np.array([(key, float(b)) not in OMIT for b in B])
            ok = keep & ~flag
            ax.plot(B[ok], cl[ok, j], "-o", color=OC[l], lw=(1.3 if big else 0.8), ms=(2.4 if big else 1.6), mew=0, zorder=(3 if big else 2))
            fl = keep & flag
            if fl.any():
                ax.plot(B[fl], cl[fl, j], "o", ms=(3.2 if big else 2.4), mfc="white", mec=OC[l], mew=0.7, zorder=4, ls="none")
        ax.axhline(1, color=INK2, lw=0.5)
        ax.set_xscale("log"); ax.set_xlim(1.7, 2300); ax.set_ylim(-0.85, 1.06)
        ax.set_xticks([10, 100, 1000]); ax.set_xticklabels(["10", "100", "1000"])
        if c == 0:
            ax.set_ylabel("Alignment with the\nreference gradient (cosine)")
            panel(ax, "b", x=-0.42, y=1.04)
        else:
            ax.tick_params(labelleft=False)
        bold_ticks(ax)
    fig.text(0.54, 0.035, "Projection sharpness $\\beta$ (design frozen)", ha="center", va="bottom", fontsize=S.ALS, fontweight="bold")
    save(fig, "figS%02d_frozen_states_m%d" % (num, 1 if num == 7 else 3))


def figS7():
    _figS78(7)


def figS8():
    _figS78(8)


# ---------------------------------------------------------------------------------------------------------------------
# Fig. S9  Convergence of the reference evaluation
# ---------------------------------------------------------------------------------------------------------------------
def _ladders():
    t = J(os.path.join(F33, "f33_traj.json"))["part2"]["delivered_ladder"]
    f = J(os.path.join(F31, "f31_fig2.json"))["part2"]["final"]["ladder"]
    return f, t


def _fit(N, eta, a):
    """eta = e_inf + c N^-a on the given points (linear least squares in x = N^-a)."""
    x = N ** (-a)
    A = np.vstack([np.ones_like(x), x]).T
    coef, *_ = np.linalg.lstsq(A, eta, rcond=None)
    return coef


def figS9():
    conv, guard = _ladders()
    fig = fig_mm(180, 64)
    gs = GridSpec(1, 2, figure=fig, width_ratios=[1.35, 1.0], wspace=0.32, left=0.075, right=0.99, top=0.97, bottom=0.2)
    ax = fig.add_subplot(gs[0, 0])
    res = {}
    for name, lad, col, ls in (("Conventional", conv, GREY, "-"), ("Guarded", guard, DARK, "-")):
        N = np.array([r["n_terms"] for r in lad], float); eta = np.array([r["eta"] for r in lad])
        lv = [tuple(r["level"]) for r in lad]
        ax.plot(N, eta, ls, color=col, lw=1.1, zorder=2)
        for i, l in enumerate(lv):
            if l in (MD, MG, MR):
                ax.plot([N[i]], [eta[i]], "o", ms=5.2, color=OC[l], mec="white", mew=0.7, zorder=4)
        sel = np.array([l[0] >= 40 for l in lv])
        for a in (0.5, 1.0):
            e_inf, c = _fit(N[sel], eta[sel], a)
            NN = np.geomspace(N[sel][0], 1e5, 60)
            ax.plot(NN, e_inf + c * NN ** (-a), color=col, lw=0.8, ls=(0, (1.5, 1.5)), zorder=1)
            res["%s_a%.1f" % (name, a)] = float(e_inf)
    json.dump(res, open(os.path.join(S.DATA, "figS9_extrapolation.json"), "w"), indent=1)
    note(ax, 2500, 0.835, "Guarded", color=DARK, ha="left", va="bottom")
    note(ax, 2500, 0.545, "Conventional", color=INK2, ha="left", va="top")
    ax.set_xscale("log"); ax.set_xlim(20, 1e5); ax.set_ylim(0.4, 1.0)
    ax.set_xlabel("Number of retained harmonics $N$"); ax.set_ylabel("Efficiency of the delivered pattern")
    note(ax, 0.03, 0.04, "Dotted: $\\eta_\\infty+cN^{-a}$ fitted to the orders from (40,6),\n$a=1/2$ and $1$ (illustration; the exponent is unknown)",
         transform=ax.transAxes, ha="left", va="bottom", fontsize=7.4)
    bold_ticks(ax); panel(ax, "a", x=-0.16, y=1.0)
    ax = fig.add_subplot(gs[0, 1])
    for name, lad, col in (("Conventional", conv, GREY), ("Guarded", guard, DARK)):
        N = np.array([r["n_terms"] for r in lad], float); eta = np.array([r["eta"] for r in lad])
        sel = np.array([r["level"][0] >= 28 for r in lad])
        Ns, es = N[sel], eta[sel]
        ax.bar(np.arange(len(Ns) - 1) + (0.2 if name == "Guarded" else -0.2), np.diff(es), width=0.38, color=col, lw=0)
        lv = [tuple(r["level"]) for r in lad if r["level"][0] >= 28]
    ax.axhline(0, color=INK2, lw=0.5)
    ax.set_xticks(np.arange(len(lv) - 1)); ax.set_xticklabels([olab(l) for l in lv[1:]], rotation=60, ha="right", fontsize=S.TLS - 1)
    ax.set_xlabel("Order reached"); ax.set_ylabel("Change in efficiency\nfrom the previous order")
    reg_legend(ax, handles=[Patch(color=DARK, label="Guarded"), Patch(color=GREY, label="Conventional")], loc="lower right",
               handlelength=1.0, borderaxespad=0.1)
    bold_ticks(ax); panel(ax, "b", x=-0.24, y=1.0)
    save(fig, "figS09_reference_convergence")


# ---------------------------------------------------------------------------------------------------------------------
# Fig. S10, S11  Minimal model; gap along runs
# ---------------------------------------------------------------------------------------------------------------------
STEPS, T_MIX = 219, 66


def _beta_of(t):
    return 2.0 * 1000.0 ** (t / STEPS)


def minimal_model(k, t_mix=T_MIX, steps=STEPS, alpha=0.02, kappa=6.0, b1=0.9):
    """a: size of a feature that the descent order rewards (reward mu(beta), switching on over beta 16-128 as the truncation
    error does in Fig. 2(d)) and the gate order penalizes (penalty kappa*a); momentum-averaged steps; gap D = mu a + kappa a^2/2."""
    a, m, D = 0.0, 0.0, []
    for t in range(steps + 1):
        b = _beta_of(t)
        mu = 1.0 / (1.0 + math.exp(-(math.log(b) - math.log(45.0)) / 0.45))
        high = (k is not None) and t >= t_mix and (t - t_mix) % k == 0
        c = -kappa * a if high else mu
        m = b1 * m + (1 - b1) * c
        a = max(a + alpha * m / (1 - b1 ** (t + 1)), 0.0)
        D.append(mu * a + 0.5 * kappa * a * a)
    return np.array(D)


def figS10():
    fig = fig_mm(88, 62)
    ax = fig.add_axes([0.16, 0.2, 0.80, 0.76])
    steps = np.arange(STEPS + 1)
    s1, s8, s4 = minimal_model(None), minimal_model(8), minimal_model(4)
    ax.axvline(T_MIX, color=GREY, lw=0.6, ls=(0, (3, 2)))
    ax.plot(steps, s1, color=OC[MD], lw=1.4)
    ax.plot(steps, s8, color=OC[MG], lw=1.1, ls=(0, (4, 2)))
    ax.plot(steps, s4, color=OC[MG], lw=1.5)
    top = s1.max()
    note(ax, 168, 0.72 * top, "Single order", color=INK, ha="right", va="center")
    note(ax, STEPS * 0.98, s8[-1] + 0.03 * top, "$k=8$", color=INK, ha="right", va="bottom")
    note(ax, STEPS * 0.98, s4[-1] + 0.02 * top, "$k=4$", color=INK, ha="right", va="bottom")
    note(ax, T_MIX + 3, 0.95 * top, "First gradient\nat $M_g$", ha="left", va="top")
    ax.set_xlim(0, STEPS); ax.set_ylim(0, top * 1.08)
    ax.set_yticks([]); ax.set_xticks([0, 50, 100, 150, 200])
    ax.set_xlabel("Optimization step"); ax.set_ylabel("Gap $J_{M_d}-J_{M_g}$ (arbitrary units)")
    bold_ticks(ax)
    save(fig, "figS10_minimal_model")


def figS11():
    S6 = J(os.path.join(EXP, "S6_lottery_pricing", "data", "s6_2d_mixed.json"))["units"]
    fig = fig_mm(180, 70)
    gs = GridSpec(1, 2, figure=fig, wspace=0.3, left=0.075, right=0.99, top=0.72, bottom=0.17)
    key_strip(fig, [Line2D([0], [0], color=OC[MD], lw=2.0, label="Single order (48 runs)"),
                    Line2D([0], [0], color=OC[MG], lw=1.6, ls=(0, (4, 2)), label="$k=8$ from step 54 (48 runs)"),
                    Line2D([0], [0], color=OC[MG], lw=1.8, ls=(0, (1.2, 1.2)), label="$k=4$ from step 54 (48 runs)"),
                    Line2D([0], [0], color=OC[MG], lw=2.6, label="Guarded workflow (24 runs)")], y=0.995, ncol=2, fs=9.0,
              handlelength=2.6, columnspacing=1.6)
    for j, m in enumerate((1, 2)):
        ax = fig.add_subplot(gs[0, j])
        B = J(os.path.join(F33, "s10_B_m%d.json" % m))["tickets"]
        for arm, col, ls, lw in (("SINGLE", OC[MD], "-", 1.3), ("MIX8", OC[MG], (0, (4, 2)), 1.0), ("MIX4", OC[MG], (0, (1.2, 1.2)), 1.3)):
            us = [u for k, u in S6.items() if k.startswith("m%d|%s|" % (m, arm))]
            st = [c["step"] for c in us[0]["checkpoints"]]
            g = np.median(np.array([[c["gap_descent_minus_gate"] for c in u["checkpoints"]] for u in us]), axis=0)
            ax.plot(st, g, color=col, ls=ls, lw=lw)
        st = [c["step"] for c in B["s00"]["checkpoints"]]
        g = np.median(np.array([[c["gap_descent_minus_gate"] for c in u["checkpoints"]] for u in B.values()]), axis=0)
        ax.plot(st, g, color=OC[MG], lw=2.0)
        ax.axvline(54, color=GREY, lw=0.5, ls=(0, (3, 2)))
        ax.axvline(T_MIX, color=GREY, lw=0.5, ls=(0, (3, 2)))
        ax.axhline(0, color=INK2, lw=0.5)
        ax.set_xlim(0, STEPS); ax.set_ylim(-0.02, 0.2)
        ax.set_xlabel("Optimization step")
        ax.set_ylabel("Pattern at $M_d$ minus at $M_g$\n(median over runs)")
        note(ax, 0.03, 0.97, "Channel (%d,0)" % m, transform=ax.transAxes, va="top", ha="left")
        beta_top(ax, STEPS)
        bold_ticks(ax); panel(ax, "ab"[j], x=-0.2, y=1.14)
    save(fig, "figS11_gap_along_runs")


# ---------------------------------------------------------------------------------------------------------------------
if __name__ == "__main__":
    todo = sys.argv[1:] or ["S1", "S2"]
    for t in todo:
        globals()["fig" + t]()
