"""
FS -- shared style of the Supplementary-Information figures (2026-10-06).

Same rules as Fig. 1(c) v2 and Fig. 2 (user rulings 2026-10-01/03/05):
  * Times New Roman; tick labels 8.5 pt and axis labels 9.5 pt, both bold (bold math through the mathtext rc, font.weight
    left normal); annotations and legends 8 pt regular (math in STIX); every text starts with a capital letter;
  * colour = truncation order: M_d #0d0887, M_g #aa2395, M_r #f89540 on the plasma 0-0.75 ramp, other orders from the same
    ramp; non-order series use neutral inks or the teal below (never a ramp colour);
  * the colour key comes first (top of the figure) when it applies to several panels;
  * composite figures are 180 mm wide with panel letters; png (300 dpi) + svg only, no pdf.
Output: manuscript_cpc/SI/figures/
"""
import math
import os

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                        # noqa: E402

_HERE = os.path.dirname(os.path.abspath(__file__))
EXP = os.path.abspath(os.path.join(_HERE, "..", ".."))                 # .../experiments
OUT = os.path.abspath(os.path.join(EXP, "..", "..", "stage_d3_landscape_scheduling", "manuscript", "manuscript_cpc",
                                   "SI", "figures"))
DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))

ORDERS = [(16, 2), (20, 3), (24, 3), (28, 4), (32, 5), (40, 6), (48, 7)]
RAMP = ["#0d0887", "#4c02a1", "#7e03a8", "#aa2395", "#cc4778", "#e66c5c", "#f89540"]
OC = dict(zip(ORDERS, RAMP))
MD, MG, MR = (16, 2), (28, 4), (48, 7)
INK, INK2, GREY, GREY_L, DARK = "#0b0b0b", "#52514e", "#8c8b86", "#c9c8c3", "#3b3a37"
TEAL = "#0f8b8d"                                  # non-order series (e.g. single precision); not on the plasma ramp
FILL_BIN, FILL_TRUNC, BAND = "#e2e1f1", "#fdeadb", "#f0efec"
LAB = {MD: r"$M_d$", MG: r"$M_g$", MR: r"$M_r$"}
MM = 1 / 25.4
FULL_W = 180 * MM

TLS, ALS, ANS, PLS = 8.5, 9.5, 8.0, 10.5          # tick labels, axis labels, annotations/legends, panel letters
RC = {"font.family": "serif", "font.serif": ["Times New Roman"],
      "mathtext.fontset": "custom", "mathtext.rm": "Times New Roman:bold",
      "mathtext.it": "Times New Roman:italic:bold", "mathtext.bf": "Times New Roman:bold",
      "mathtext.fallback": "stix",
      "axes.labelsize": ALS, "axes.labelweight": "bold", "xtick.labelsize": TLS, "ytick.labelsize": TLS,
      "axes.linewidth": 0.6, "xtick.major.width": 0.6, "ytick.major.width": 0.6,
      "xtick.minor.width": 0.4, "ytick.minor.width": 0.4, "xtick.major.size": 3, "ytick.major.size": 3,
      "xtick.minor.size": 1.8, "ytick.minor.size": 1.8,
      "axes.edgecolor": INK2, "axes.labelcolor": INK, "xtick.color": INK2, "ytick.color": INK2, "text.color": INK,
      "axes.spines.top": False, "axes.spines.right": False, "legend.frameon": False,
      "svg.fonttype": "none", "savefig.dpi": 300}
plt.rcParams.update(RC)


def note(ax, x, y, s, **kw):
    """Annotation: regular weight, 8 pt, math in STIX."""
    kw.setdefault("fontsize", ANS)
    kw.setdefault("color", INK2)
    return ax.text(x, y, s, fontweight="normal", math_fontfamily="stix", **kw)


def reg_legend(ax_or_fig, **kw):
    """Legend in regular weight (math in STIX)."""
    leg = ax_or_fig.legend(frameon=False, **kw)
    for t in leg.get_texts():
        t.set_fontweight("normal"); t.set_math_fontfamily("stix"); t.set_fontsize(ANS)
    if leg.get_title() is not None:
        leg.get_title().set_fontweight("normal"); leg.get_title().set_math_fontfamily("stix")
        leg.get_title().set_fontsize(ANS)
    return leg


def bold_ticks(*axes):
    for a in axes:
        for t in a.get_xticklabels(which="both") + a.get_yticklabels(which="both"):
            t.set_fontweight("bold")


def panel(ax, s, x=-0.14, y=1.03):
    ax.text(x, y, "(%s)" % s, transform=ax.transAxes, fontsize=PLS, fontweight="bold", va="bottom", ha="left")


def olab(lv):
    return "(%d,%d)" % tuple(lv)


def beta_top(ax, steps, ticks=(2, 10, 100, 1000), label=True):
    """Second x axis on top: projection sharpness beta = 2 * 1000^(t/T) at step t of T."""
    top = ax.secondary_xaxis("top", functions=(lambda s: s, lambda s: s))
    top.set_xticks([steps * math.log(b / 2) / math.log(1000) for b in ticks])
    top.set_xticklabels([str(b) for b in ticks])
    if label:
        top.set_xlabel("Projection sharpness $\\beta$", labelpad=2)
    top.tick_params(length=2.5)
    bold_ticks(top)
    return top


def fig_mm(w_mm, h_mm):
    return plt.figure(figsize=(w_mm * MM, h_mm * MM))


def save(fig, name):
    os.makedirs(OUT, exist_ok=True)
    for ext in ("png", "svg"):
        fig.savefig(os.path.join(OUT, "%s.%s" % (name, ext)), bbox_inches="tight", pad_inches=0.03, facecolor="white")
    w, h = fig.get_size_inches()
    plt.close(fig)
    print("saved %s" % name)


def key_strip(fig, handles, y=0.995, ncol=None, title=None, fs=None, bold=True, **kw):
    """Colour/series key at the top of a figure (declared first).  Entries bold when they carry the key information."""
    fs = fs or ANS + 1.0
    leg = fig.legend(handles=handles, loc="upper center", bbox_to_anchor=(0.5, y), ncol=ncol or len(handles),
                     frameon=False, title=title, handlelength=kw.pop("handlelength", 1.8), handletextpad=0.5,
                     columnspacing=kw.pop("columnspacing", 1.4), borderaxespad=0.0, **kw)
    for t in leg.get_texts():
        t.set_fontweight("bold" if bold else "normal"); t.set_fontsize(fs); t.set_math_fontfamily("stix")
    if leg.get_title() is not None:
        leg.get_title().set_fontweight("bold" if bold else "normal"); leg.get_title().set_fontsize(fs + 0.5)
    return leg
