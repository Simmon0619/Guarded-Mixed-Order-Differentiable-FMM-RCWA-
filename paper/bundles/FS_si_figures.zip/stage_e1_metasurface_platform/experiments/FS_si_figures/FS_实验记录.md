# FS　支持信息（SI）的图

2026-10-06 起。**只读已有数据重画 / 新画，无求解、无 GPU、无新实验。** 输出在 `stage_d3_landscape_scheduling/manuscript/manuscript_cpc/SI/figures/`（png 300 dpi + svg，无 pdf）。SI 正文与编辑说明在 `…/manuscript_cpc/SI/`。

## 文件
- `scripts/fs_style.py`：共用样式。Times New Roman；刻度 8.5 pt、轴标签 9.5 pt 均加粗（粗体数学通过 mathtext rc，不设全局 font.weight）；注释与图例 8 pt 常规（数学用 STIX）；首字母大写；M_d #0d0887、M_g #aa2395、M_r #f89540，其余阶取同一 plasma 色带；非阶系列用中性灰或青色 #0f8b8d（单精度），不用色带里的颜色；颜色说明放图的最前面；180 mm 宽；面板字母 10.5 pt 粗体。
- `scripts/fs_si_figures.py`：每图一个函数。`python fs_si_figures.py S1 S2 …`（Windows 上先设 `PYTHONIOENCODING=utf-8`）。不带参数只跑 S1、S2。
- `data/figS3_sigma_p2_state.json`：图 S3(b,c) 的 σ_M(β)（对 S8 的 `m1_s00_st095_latent.npy` 重算，60 个 β、三个阶）。
- `data/figS9_extrapolation.json`：图 S9 的外推值 η∞（本文 0.7283/0.7714，常规 0.6172/0.6064；a = 1/2、1；拟合 (40,6) 起各档）。

## 图与数据
| 图 | 数据 |
|---|---|
| S1 成本对 2N | SI 表 S5（S5 §7.3、S6 §2.3、S8 §1） |
| S2 验证 | E25 `lumerical_xcheck.json`；E17 `parity.json`（189 态） |
| S3 带限谱 | S8 `designs/m1_s00_st095_latent.npy`；F1 `data/f1c_check_p2_state.json` |
| S4 collapse | F1 `panels/c/final_v2/SI_collapse_labelled.*`（复制） |
| S5 P1 | S5 `s5_8a_analysis.json`、`s5_8a_readme_schedule.json` |
| S6 单精度 | F31 `f31_cliff_audit.json`、`f31_counterfactual.json`、`f31_counterfactual_426.json`、`f31_fig4c_s8set.json`（2 线程） |
| S7、S8 冻结态 | S8 `s8_map.json`；`s8_plot.py` 的 `grids`/`ref_flag` |
| S9 阶收敛 | F31 `f31_fig2.json` part2；F33 `f33_traj.json` part2 |
| S10 最小模型 | 解析积分 |
| S11 缺口 | S6 `s6_2d_mixed.json`；F33 `s10_B_m1.json`、`s10_B_m2.json` |

## 版面说明
- S6、S10、S11 是旧 SI 图 S3.4、S3.6、S3.5 的重画：旧 S3.4 的单精度红 #e66c5c 与 Fig. 2 的 (40,6) 同色，改成青色；旧 S3.5 的图例压线，改成顶部颜色条。
- S7、S8：m=1 的粗线为 (16,2)、(28,4)，m=3 的粗线为 (24,3)、(40,6)（按目标的 M_d、M_g），各阶颜色不变。参考梯度被标记的行画空心点，m1_s00_st095 的 β = 8、256 与 Fig. 2(e) 一样省去。
- S3(c)：E 与 σ_M 各按 β=2000 处的值归一化；E 在 β ≤ 16 为小的负值（E 本身约 −0.015，归一化后约 −0.1），如实画出。
- S9 的外推线只是示意（指数未知），图注与 SI 正文都这样写。
- 旧图（`SI/archive_v1/figures_old_style/`）保留。

## 没做
- 图 S2 里"有限差分方向导数误差对步长"的 V 形曲线：数据没存档，重画需要新的 CPU/complex128 小计算（E9），等批准。

## 2026-10-06（晚）：合并成 5 张多面板图（Optica 补充文档格式）
Optica 补充文档模板的版心只有 5.25 in（133 mm），所以 SI 图改成 5 张多面板图，每张按 133 mm 宽重排（不是缩放），字号规则不变；
脚本 `scripts/fs_composites.py`（`python fs_composites.py [C1 … C5]`），输出 `SI/figures/figS1_…figS5_…`（png + svg）。
`fs_si_figures.py` 里的单图函数保留（`fs_composites.py` 复用它的数据读取与辅助函数；旧的单张图在 `SI/archive_v1/figures_individual_2026-10-06/`）。

| 新图 | 函数 | 面板 | 数据（同上表） |
|---|---|---|---|
| Fig. S1 | `figC1` | (a) 成本、(b) 局部指数、(c) 内存柱（SI 表 S3 的数：峰值 7.37/5.79/10.00 GiB，设备合计 10.0/9.1/12.0 GB，用时 75.5/70.6/116.2 s）、(d) Lumerical、(e,f) 精度直方图 | 旧 S1 + S2 |
| Fig. S2 | `figC2` | (a) 谱、(b) σ_M(β)、(c) σ_M 对 E、(d) 坍缩 | 旧 S3 + S4；(d) 由 `F1_fig1_schematic/fmm_pipeline.py` 的设计态在脚本内重算（300 个 β），颜色同 Fig. 1(c) |
| Fig. S3 | `figC3` | (a,b) P1、(c–f) 单精度 | 旧 S5 + S6 |
| Fig. S4 | `figC4` | 行 (a,b) m=1 四个态、行 (c,d) m=3 四个态；粗线按各自目标的 M_d、M_g | 旧 S7 + S8 |
| Fig. S5 | `figC5` | (a) 阶梯、(b) 每档变化、(c) 最小模型、(d,e) 缺口；(f) 位置放 (c)–(e) 的图例 | 旧 S9 + S10 + S11 |

高度控制：图加图注 ≤ 约 213 mm（Letter 减去上下边距）；S1 171、S2 112、S3 153、S4 169、S5 138 mm。
