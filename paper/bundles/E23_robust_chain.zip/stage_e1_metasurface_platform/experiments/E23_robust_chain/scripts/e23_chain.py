"""Robustness-aware monotone BH chain: maximin{nominal, cd+20nm}@(24,6).

Same chain protocol as E19 (same parents, alpha cycle, 30-step beta=64
re-descent, monotone accept); the ONLY change is the acceptance score:
    score(b) = min( eta_nominal(b), eta_cd+20(b) )   at (24,6)@1x, GPU/c64.
cd+20nm is the dominant held-out failure (8/8 in E18/E19).  Delivered designs
get the full 4-scenario held-out audit at c128/CPU, bitwise-comparable with
the E10/E19 numbers.

    python e23_chain.py               # writes ../data/robust_chain.json
"""
import json
import os
import sys
import time

import numpy as np
import torch

THREADS = int(os.environ.get("P0_THREADS", "3"))
torch.set_num_threads(THREADS)
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.abspath(os.path.join(
    _HERE, "..", "..", "E16_inherited_baseline", "scripts")))
import e10_common as C  # noqa: E402
import trustworthy_fmm.fourier.convolution as _conv  # noqa: E402
import trustworthy_fmm.solvers.vector_2d as _v2d  # noqa: E402
from trustworthy_fmm.fabrication.process import periodic_binary_morphology  # noqa: E402

_conv.VECTORIZED_CONV = True
_v2d.FAST_DIAGNOSTICS = True

E16_DESIGNS = os.path.abspath(os.path.join(
    _HERE, "..", "..", "E16_inherited_baseline", "data", "main", "designs"))
DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
GPU = C.DEFAULT.variant(dtype=torch.complex64, device="cuda")

CHAINS = [
    ((1, 0), "1_0_2031_certified_screened_latent.npy",
     {"nominal": 0.3968, "worst": 0.1939}),      # parent refs, E19 audit
    ((2, 0), "2_0_2030_torcwa_M12_latent.npy",
     {"nominal": 0.4837, "worst": 0.2055}),
]
N_JUMPS = 50
STEPS = 30
BETA = 64.0
ALPHAS = [0.1, 0.25, 0.5]
CD_BIAS_NM = [-20.0, 20.0]
MORPH_RADIUS_NM = 40.0


def filtered_noise(seed):
    g = torch.Generator().manual_seed(int(seed))
    noise = torch.randn((C.NY, C.NX), generator=g, dtype=torch.float64)
    smooth = C.periodic_gaussian_filter(noise, C.LATTICE, C.FILTER_NM)
    return smooth / smooth.std()


def redescend(rho0, target):
    rho = rho0.to("cuda")
    adam = C.Adam(rho.shape, GPU)
    for t in range(STEPS):
        lr = C.cosine_lr(t / STEPS, GPU)
        _, g = C.value_grad_latent(rho, (12, 3), target, BETA, GPU)
        rho = adam.step(rho, g, lr)
    return rho.cpu()


def eta24_gpu(binary, target):
    return C.forward_density(binary.to("cuda"), (24, 6), target, GPU)


def maximin(binary, target):
    nominal = eta24_gpu(binary, target)
    mask = binary.numpy().astype(bool)
    cd20 = torch.from_numpy(C.cd_bias_mask(mask, 20.0))
    worst = eta24_gpu(cd20, target)
    return min(nominal, worst), nominal, worst


def held_out_c128(binary, target):
    mask = binary.numpy().astype(bool)
    nominal = C.forward_density(binary, (24, 6), target, C.DEFAULT, audit=True)
    held = {"nominal_24_6": nominal}
    for bias in CD_BIAS_NM:
        pert = torch.from_numpy(C.cd_bias_mask(mask, bias))
        held["cd_{:+.0f}nm".format(bias)] = C.forward_density(
            pert, (24, 6), target, C.DEFAULT, audit=True)
    for op in ("opening", "closing"):
        pert = periodic_binary_morphology(mask, op, MORPH_RADIUS_NM,
                                          C.DEFAULT.pixel_yx)
        held["{}_{:.0f}nm".format(op, MORPH_RADIUS_NM)] = C.forward_density(
            torch.from_numpy(np.asarray(pert, dtype=np.float64)),
            (24, 6), target, C.DEFAULT, audit=True)
    scen = {k: v for k, v in held.items() if k != "nominal_24_6"}
    held["worst_absolute"] = min(scen.values())
    held["worst_relative"] = min(scen.values()) / max(nominal, 1e-12)
    held["worst_scenario"] = min(scen, key=scen.get)
    return held


def main():
    out = {"chains": {}}
    for tgt, parent_name, refs in CHAINS:
        t0 = time.perf_counter()
        incumbent = torch.from_numpy(
            np.load(os.path.join(E16_DESIGNS, parent_name))
            .astype("float64"))
        inc_bin = C.hard_binary(incumbent, C.DEFAULT)
        inc_score, inc_nom, inc_cd = maximin(inc_bin, tgt)
        print("%s parent: maximin %.4f (nominal %.4f, cd+20 %.4f)"
              % (tgt, inc_score, inc_nom, inc_cd), flush=True)
        start = {"score": inc_score, "nominal": inc_nom, "cd20": inc_cd}
        jumps, accepts = [], 0
        for k in range(N_JUMPS):
            alpha = ALPHAS[k % len(ALPHAS)]
            noise = filtered_noise(8000 + k)
            pert = C.symmetrize(
                (incumbent + alpha * C.DEFAULT.init_scale * noise)
                .clamp(0, 1))
            rho = redescend(pert, tgt)
            b = C.hard_binary(rho, C.DEFAULT)
            score, nom, cd = maximin(b, tgt)
            accepted = score > inc_score
            jumps.append({"jump": k, "alpha": alpha, "score": score,
                          "nominal": nom, "cd20": cd,
                          "accepted": bool(accepted)})
            if accepted:
                incumbent, inc_bin = rho, b
                inc_score, inc_nom, inc_cd = score, nom, cd
            print("%s jump %2d a=%.2f: maximin %.4f (nom %.4f cd %.4f) "
                  "(inc %.4f) %s [%.0f s]"
                  % (tgt, k, alpha, score, nom, cd, inc_score,
                     "ACCEPT" if accepted else "reject",
                     time.perf_counter() - t0), flush=True)
        tag = "%d_%d_robust" % tgt
        np.save(os.path.join(DATA, tag + "_binary.npy"), inc_bin.numpy())
        np.save(os.path.join(DATA, tag + "_latent.npy"), incumbent.numpy())
        held = held_out_c128(inc_bin, tgt)
        blind28 = C.forward_density(inc_bin, (28, 7), tgt, C.DEFAULT,
                                    audit=True)
        pareto = (held["nominal_24_6"] >= refs["nominal"]
                  and held["worst_absolute"] > refs["worst"])
        out["chains"][str(tgt)] = {
            "parent": parent_name, "parent_refs": refs, "start": start,
            "final": {"score": inc_score, "nominal": inc_nom,
                      "cd20": inc_cd},
            "accepts": accepts + sum(j["accepted"] for j in jumps) * 0,
            "n_accepts": sum(j["accepted"] for j in jumps),
            "jumps": jumps, "held_out": held, "blind_28_7": blind28,
            "pareto_improves_parent": bool(pareto),
            "wall_s": time.perf_counter() - t0, "files": tag,
        }
        print("%s done: nominal %.4f  blind28 %.4f  held-out worst %.4f "
              "(%.2f, %s)  Pareto-vs-parent: %s  [%.0f s]"
              % (tgt, held["nominal_24_6"], blind28,
                 held["worst_absolute"], held["worst_relative"],
                 held["worst_scenario"], pareto,
                 time.perf_counter() - t0), flush=True)
    with open(os.path.join(DATA, "robust_chain.json"), "w") as f:
        json.dump(out, f, indent=1)
    print("wrote robust_chain.json")


if __name__ == "__main__":
    main()
