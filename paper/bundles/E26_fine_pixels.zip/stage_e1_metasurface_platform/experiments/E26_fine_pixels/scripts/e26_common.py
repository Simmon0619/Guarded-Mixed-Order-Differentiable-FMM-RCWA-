"""E26 wiring: fine-pixel design grids (10/5 nm) with raised descent and
certification orders.

Physics, 60 nm fabrication filter, beta schedule and y-mirror symmetry are
frozen; only the parameterization density (pixel size) and the solver orders
change.  ProblemConfig carries the grid, so every e10_common map (filter,
projection, hard threshold, initial latent, Adam) works unchanged on the fine
grids; the physical filter radius means the minimum feature scale stays
fabrication-bound while boundaries gain 10/5 nm control.
"""
import os
import sys

import numpy as np
import torch

THREADS = int(os.environ.get("P0_THREADS", "3"))
torch.set_num_threads(THREADS)

_HERE = os.path.dirname(os.path.abspath(__file__))
_E16_SCRIPTS = os.path.abspath(os.path.join(
    _HERE, "..", "..", "E16_inherited_baseline", "scripts"))
if _E16_SCRIPTS not in sys.path:
    sys.path.insert(0, _E16_SCRIPTS)

import e10_common as C  # noqa: E402
import trustworthy_fmm.fourier.convolution as _conv  # noqa: E402
import trustworthy_fmm.solvers.vector_2d as _v2d  # noqa: E402
from trustworthy_fmm.solvers.vector_2d import solve_multilayer_vector_2d  # noqa: E402

_conv.VECTORIZED_CONV = True
_v2d.FAST_DIAGNOSTICS = True

DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
FIG = os.path.abspath(os.path.join(_HERE, "..", "..", "..", "notes", "figures"))
E16_DESIGNS = os.path.abspath(os.path.join(
    _HERE, "..", "..", "E16_inherited_baseline", "data", "main", "designs"))

# fine-grid problem configs (descent side GPU/c64 per D-011)
FINE = {
    10: C.DEFAULT.variant(ny=70, nx=240, dtype=torch.complex64, device="cuda"),
    5: C.DEFAULT.variant(ny=140, nx=480, dtype=torch.complex64, device="cuda"),
}
DESCENT_LEVEL = (16, 4)
GATE_LEVEL = (32, 8)          # acceptance, native grid, GPU/c64
REF_LEVEL = (40, 10)          # final reference, native grid

# 20 nm incumbents: grid-converged (40,10) values from E24 (k2/k3 band mid)
INCUMBENT_40_10 = {(1, 0): 0.8017, (2, 0): 0.8300, (3, 0): 0.3327}


def upsample(t, k):
    return torch.repeat_interleave(torch.repeat_interleave(t, k, 0), k, 1)


def solve_density(density, level, dtype, device, cfg):
    eps = (cfg.eps_background
           + (cfg.eps_feature - cfg.eps_background) * density).to(dtype).to(device)
    return solve_multilayer_vector_2d(
        [eps], [cfg.thickness_nm], cfg.wavelength_nm, cfg.lattice_nm,
        cfg.n_incident, cfg.n_output, tuple(level),
        incident_jones=cfg.incident_jones)


def eta_gpu(density, level, target, cfg):
    with torch.no_grad():
        r = solve_density(density, level, torch.complex64, "cuda", cfg)
        return float(r.power_t[r.orders.index(tuple(target))])


def eta_c128(density, level, target, cfg):
    with torch.no_grad():
        r = solve_density(density, level, torch.complex128, "cpu", cfg)
        return float(r.power_t[r.orders.index(tuple(target))])


def filtered_noise(seed, cfg):
    g = torch.Generator().manual_seed(int(seed))
    noise = torch.randn((cfg.ny, cfg.nx), generator=g, dtype=cfg.latent_dtype)
    smooth = C.periodic_gaussian_filter(noise, cfg.lattice_nm, cfg.filter_nm)
    return smooth / smooth.std()


def redescend(rho0, target, cfg, steps=30, beta=64.0):
    """beta=64 short re-descent at DESCENT_LEVEL, fresh Adam, cosine lr."""
    rho = rho0.to("cuda")
    adam = C.Adam(rho.shape, cfg)
    for t in range(steps):
        lr = C.cosine_lr(t / steps, cfg)
        _, g = C.value_grad_latent(rho, DESCENT_LEVEL, target, beta, cfg)
        rho = adam.step(rho, g, lr)
    return rho.cpu()
