"""E26 arm R: fresh restarts NATIVE to the 10 nm grid.

Frozen 219-step schedule indexed by step (progress = step/218; beta 1->64,
cosine lr), descent (16,4), self-audit every 6 steps at (16,4), running-best
delivery, final certify at (32,8).  Seeds 5001-5006 x 3 targets.

    python e26_restarts.py            # writes ../data/restarts.json
"""
import json
import os
import time

import numpy as np
import torch

from e26_common import (C, DATA, DESCENT_LEVEL, FINE, GATE_LEVEL, THREADS,
                        eta_gpu)

TARGETS = [(1, 0), (2, 0), (3, 0)]
SEEDS = [5001, 5002, 5003, 5004, 5005, 5006]
N_STEPS = 219
PX = 10


def run_restart(target, seed, cfg):
    lv = DESCENT_LEVEL
    rho = C.initial_latent(seed, cfg)
    adam = C.Adam(rho.shape, cfg)
    best_self, best_bin, best_rho = -float("inf"), None, None
    for step in range(N_STEPS):
        progress = step / (N_STEPS - 1)
        beta = C.beta_at(progress, cfg=cfg)
        lr = C.cosine_lr(progress, cfg)
        _, g = C.value_grad_latent(rho, lv, target, beta, cfg)
        if step % 6 == 0:
            b = C.hard_binary(rho, cfg)
            s = C.forward_density(b, lv, target, cfg)
            if s > best_self:
                best_self, best_bin, best_rho = s, b, rho.clone()
        rho = adam.step(rho, g, lr)
    b = C.hard_binary(rho, cfg)
    s = C.forward_density(b, lv, target, cfg)
    if s > best_self:
        best_self, best_bin, best_rho = s, b, rho.clone()
    return best_bin.cpu(), best_rho.cpu(), best_self


def main():
    torch.set_num_threads(THREADS)
    cfg = FINE[PX]
    out = {"pixel_nm": PX, "descent": list(DESCENT_LEVEL),
           "gate": list(GATE_LEVEL), "targets": {}}
    for tgt in TARGETS:
        t0 = time.perf_counter()
        rows, best = [], None
        for seed in SEEDS:
            b, rho, self_s = run_restart(tgt, seed, cfg)
            gate = eta_gpu(b, GATE_LEVEL, tgt, cfg)
            rows.append({"seed": seed, "self_16_4": self_s,
                         "eta_gate": gate})
            if best is None or gate > best[1]:
                best = (seed, gate, b, rho)
            print("%s @%dnm seed %d: self(16,4) %.4f  gate(32,8) %.4f "
                  "[%.0f s]" % (tgt, PX, seed, self_s, gate,
                                time.perf_counter() - t0), flush=True)
        tag = "%d_%d_r%dnm" % (tgt + (PX,))
        np.save(os.path.join(DATA, tag + "_binary.npy"), best[2].numpy())
        np.save(os.path.join(DATA, tag + "_latent.npy"), best[3].numpy())
        out["targets"][str(tgt)] = {
            "rows": rows, "best_seed": best[0], "best_gate_eta": best[1],
            "wall_s": time.perf_counter() - t0, "files": tag,
        }
        print("%s @%dnm restarts done: best gate %.4f (seed %d, %.0f s)"
              % (tgt, PX, best[1], best[0], time.perf_counter() - t0),
              flush=True)
    with open(os.path.join(DATA, "restarts.json"), "w") as f:
        json.dump(out, f, indent=1)
    print("wrote restarts.json")


if __name__ == "__main__":
    main()
