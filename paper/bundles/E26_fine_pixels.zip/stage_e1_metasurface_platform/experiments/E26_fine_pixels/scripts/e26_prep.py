"""E26 prep: recover the (1,0)/(2,0) incumbent LATENTS by deterministic
replay of their E22 replicates (gate: replayed delivered binary must equal the
archived binary bit for bit), then build and certify the upsampled fine-grid
warm starts.

    python e26_prep.py                # writes ../data/warmstarts.json
                                      # and ../data/*_latent20.npy
"""
import json
import os
import sys

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
sys.path.insert(0, os.path.abspath(os.path.join(
    _HERE, "..", "..", "E22_power_bh_vs_rs", "scripts")))

from e26_common import (C, DATA, E16_DESIGNS, FINE, GATE_LEVEL, THREADS,
                        eta_gpu, upsample)
import e22_power as E22  # noqa: E402  (same seeds/helpers as the records)


def replay_chain_2_0(rep=11):
    parent = torch.from_numpy(np.load(os.path.join(
        E16_DESIGNS, "2_0_2030_torcwa_M12_latent.npy")).astype("float64"))
    tgt = (2, 0)
    incumbent = parent.clone()
    inc_bin = C.hard_binary(incumbent, C.DEFAULT)
    inc_eta = E22.eta_gpu(inc_bin, (24, 6), tgt)
    for k in range(E22.N_JUMPS):
        alpha = E22.ALPHAS[k % len(E22.ALPHAS)]
        noise = E22.filtered_noise(7000 + 100 * rep + k)
        pert = C.symmetrize(
            (incumbent + alpha * C.DEFAULT.init_scale * noise).clamp(0, 1))
        rho = E22.redescend(pert, tgt)
        b = C.hard_binary(rho, C.DEFAULT)
        eta = E22.eta_gpu(b, (24, 6), tgt)
        if eta > inc_eta:
            incumbent, inc_bin, inc_eta = rho, b, eta
    return incumbent, inc_bin


def replay_rs_1_0(rep=4):
    tgt = (1, 0)
    best = (-float("inf"), None, None)
    for j in range(E22.N_RESTARTS):
        seed = 4000 + 10 * rep + j
        lv = (12, 3)
        rho = C.initial_latent(seed, E22.GPU)
        adam = C.Adam(rho.shape, E22.GPU)
        units, step = 0.0, 0
        best_self, best_bin, best_rho = -float("inf"), None, None
        while True:
            if units + C.cost_fwd(lv, E22.GPU) + C.cost_bwd(lv, E22.GPU) \
                    > E22.BUDGET:
                break
            progress = units / E22.BUDGET
            beta = C.beta_at(progress, cfg=E22.GPU)
            lr = C.cosine_lr(progress, E22.GPU)
            _, g = C.value_grad_latent(rho, lv, tgt, beta, E22.GPU)
            units += C.cost_fwd(lv, E22.GPU) + C.cost_bwd(lv, E22.GPU)
            if step % 6 == 0 and units + C.cost_fwd(lv, E22.GPU) <= E22.BUDGET:
                b = C.hard_binary(rho, E22.GPU)
                s = C.forward_density(b, lv, tgt, E22.GPU)
                units += C.cost_fwd(lv, E22.GPU)
                if s > best_self:
                    best_self, best_bin, best_rho = s, b, rho.clone()
            rho = adam.step(rho, g, lr)
            step += 1
        b = C.hard_binary(rho, E22.GPU)
        s = C.forward_density(b, lv, tgt, E22.GPU)
        if s > best_self:
            best_self, best_bin, best_rho = s, b, rho.clone()
        eta = E22.eta_gpu(best_bin.cpu(), (24, 6), tgt)
        if eta > best[0]:
            best = (eta, best_rho.cpu(), best_bin.cpu())
    return best[1], best[2]


def main():
    torch.set_num_threads(THREADS)
    out = {}
    sources = {}

    lat20, bin20 = replay_chain_2_0()
    arch = torch.from_numpy(np.load(os.path.join(
        _HERE, "..", "..", "E22_power_bh_vs_rs", "data",
        "2_0_bh_rep11_binary.npy")).astype("float64"))
    assert torch.equal(bin20, arch), "(2,0) replay does not match archive!"
    sources[(2, 0)] = lat20
    print("(2,0) latent recovered; replay binary == archive (bitwise)")

    lat10, bin10 = replay_rs_1_0()
    arch = torch.from_numpy(np.load(os.path.join(
        _HERE, "..", "..", "E22_power_bh_vs_rs", "data",
        "1_0_rs_rep4_binary.npy")).astype("float64"))
    assert torch.equal(bin10, arch), "(1,0) replay does not match archive!"
    sources[(1, 0)] = lat10
    print("(1,0) latent recovered; replay binary == archive (bitwise)")

    sources[(3, 0)] = torch.from_numpy(np.load(os.path.join(
        E16_DESIGNS, "3_0_2029_torcwa_M12_latent.npy")).astype("float64"))
    print("(3,0) latent from frozen file")

    for tgt, lat in sources.items():
        np.save(os.path.join(DATA, "%d_%d_latent20.npy" % tgt), lat.numpy())
        rec = {}
        for px, k in [(10, 2), (5, 4)]:
            cfg = FINE[px]
            lat_f = upsample(lat, k)
            b_f = C.hard_binary(lat_f, cfg)
            gate = eta_gpu(b_f, GATE_LEVEL, tgt, cfg)
            same = float((b_f == upsample(C.hard_binary(lat, C.DEFAULT), k))
                         .float().mean())
            rec["%dnm" % px] = {"gate_eta_start": gate,
                                "pixel_agreement_vs_upsampled_binary": same}
            print("  %s @%dnm: warm-start gate (32,8) = %.4f  "
                  "(pixel agreement with upsampled 20nm binary %.4f)"
                  % (tgt, px, gate, same), flush=True)
        out[str(tgt)] = rec
    with open(os.path.join(DATA, "warmstarts.json"), "w") as f:
        json.dump(out, f, indent=1)
    print("wrote warmstarts.json")


if __name__ == "__main__":
    main()
