"""E26 arm W: warm-started monotone BH chains on the fine-pixel grids.

Start = upsampled 20 nm incumbent latent (prep-verified).  Jump = filtered
noise (physical 60 nm) at alpha in {0.1,0.25,0.5} -> 30-step beta=64
re-descent at (16,4) with a fresh Adam -> monotone accept on (32,8) at the
NATIVE grid (GPU/c64).  40 jumps per chain; 3 targets x {10,5} nm.

    python e26_chains.py              # writes ../data/chains.json
"""
import json
import os
import time

import numpy as np
import torch

from e26_common import (C, DATA, DESCENT_LEVEL, FINE, GATE_LEVEL, THREADS,
                        eta_gpu, filtered_noise, redescend, upsample)

TARGETS = [(1, 0), (2, 0), (3, 0)]
PIXELS = [10, 5]
N_JUMPS = 40
ALPHAS = [0.1, 0.25, 0.5]


def main():
    torch.set_num_threads(THREADS)
    out = {"descent": list(DESCENT_LEVEL), "gate": list(GATE_LEVEL),
           "chains": {}}
    for px in PIXELS:
        cfg = FINE[px]
        k = 20 // px
        for tgt in TARGETS:
            t0 = time.perf_counter()
            lat20 = torch.from_numpy(np.load(os.path.join(
                DATA, "%d_%d_latent20.npy" % tgt)).astype("float64"))
            incumbent = upsample(lat20, k)
            inc_bin = C.hard_binary(incumbent, cfg)
            inc_eta = eta_gpu(inc_bin, GATE_LEVEL, tgt, cfg)
            start_eta = inc_eta
            jumps, accepts = [], 0
            for j in range(N_JUMPS):
                alpha = ALPHAS[j % len(ALPHAS)]
                noise = filtered_noise(9100 + 1000 * px + j, cfg)
                pert = C.symmetrize(
                    (incumbent + alpha * C.DEFAULT.init_scale * noise)
                    .clamp(0, 1))
                rho = redescend(pert, tgt, cfg)
                b = C.hard_binary(rho, cfg)
                eta = eta_gpu(b, GATE_LEVEL, tgt, cfg)
                acc = eta > inc_eta
                jumps.append({"jump": j, "alpha": alpha, "eta_gate": eta,
                              "accepted": bool(acc)})
                if acc:
                    incumbent, inc_bin, inc_eta = rho, b, eta
                    accepts += 1
                print("%s @%dnm jump %2d a=%.2f: gate %.4f (inc %.4f) %s "
                      "[%.0f s]" % (tgt, px, j, alpha, eta, inc_eta,
                                    "ACCEPT" if acc else "reject",
                                    time.perf_counter() - t0), flush=True)
            tag = "%d_%d_w%dnm" % (tgt + (px,))
            np.save(os.path.join(DATA, tag + "_binary.npy"), inc_bin.numpy())
            np.save(os.path.join(DATA, tag + "_latent.npy"),
                    incumbent.numpy())
            out["chains"][tag] = {
                "target": list(tgt), "pixel_nm": px,
                "start_gate_eta": start_eta, "final_gate_eta": inc_eta,
                "accepts": accepts, "n_jumps": len(jumps), "jumps": jumps,
                "wall_s": time.perf_counter() - t0,
            }
            print("%s @%dnm done: gate %.4f -> %.4f (%d/%d accepts, %.0f s)"
                  % (tgt, px, start_eta, inc_eta, accepts, len(jumps),
                     time.perf_counter() - t0), flush=True)
    with open(os.path.join(DATA, "chains.json"), "w") as f:
        json.dump(out, f, indent=1)
    print("wrote chains.json")


if __name__ == "__main__":
    main()
