"""E26 final audit: reference-ladder ((32,8)/(40,10) native grid, GPU/c64,
c128 spot checks) + held-out process audit for every E26 deliverable, compared
against the 20 nm incumbents' grid-converged (40,10) values.

    python e26_audit.py               # writes ../data/final_audit.json
                                      # and notes/figures/fig_fine_pixels.png
"""
import glob
import json
import os

import numpy as np
import torch

from e26_common import (C, DATA, FIG, FINE, INCUMBENT_40_10, REF_LEVEL,
                        GATE_LEVEL, THREADS, eta_c128, eta_gpu)
from trustworthy_fmm.fabrication.process import periodic_binary_morphology

CD_BIAS_NM = [-20.0, 20.0]
MORPH_RADIUS_NM = 40.0


def held_out(mask_t, target, cfg):
    mask = mask_t.numpy().astype(bool)
    cpu_cfg = cfg.variant(dtype=torch.complex128, device="cpu")
    nominal = eta_c128(mask_t, (24, 6), target, cpu_cfg)
    held = {"nominal_24_6": nominal}
    for bias in CD_BIAS_NM:
        pert = torch.from_numpy(C.cd_bias_mask(mask, bias, cpu_cfg))
        held["cd_{:+.0f}nm".format(bias)] = eta_c128(
            pert, (24, 6), target, cpu_cfg)
    for op in ("opening", "closing"):
        pert = periodic_binary_morphology(mask, op, MORPH_RADIUS_NM,
                                          cpu_cfg.pixel_yx)
        held["{}_{:.0f}nm".format(op, MORPH_RADIUS_NM)] = eta_c128(
            torch.from_numpy(np.asarray(pert, dtype=np.float64)),
            (24, 6), target, cpu_cfg)
    scen = {k: v for k, v in held.items() if k != "nominal_24_6"}
    held["worst_absolute"] = min(scen.values())
    held["worst_relative"] = min(scen.values()) / max(nominal, 1e-12)
    held["worst_scenario"] = min(scen, key=scen.get)
    return held


def main():
    torch.set_num_threads(THREADS)
    out = {"deliverables": []}
    files = sorted(glob.glob(os.path.join(DATA, "*_binary.npy")))
    for path in files:
        name = os.path.basename(path).replace("_binary.npy", "")
        parts = name.split("_")
        tgt = (int(parts[0]), int(parts[1]))
        px = int(parts[2][1:-2])
        cfg = FINE[px]
        b = torch.from_numpy(np.load(path).astype("float64"))
        e_gate = eta_gpu(b, GATE_LEVEL, tgt, cfg)
        e_ref = eta_gpu(b, REF_LEVEL, tgt, cfg)
        inc = INCUMBENT_40_10[tgt]
        held = held_out(b, tgt, cfg)
        rec = {"name": name, "target": list(tgt), "pixel_nm": px,
               "arm": "chain" if parts[2].startswith("w") else "restart",
               "eta_32_8": e_gate, "eta_40_10": e_ref,
               "incumbent20_40_10": inc,
               "vs_incumbent": (e_ref - inc) / inc,
               "held_out": held}
        out["deliverables"].append(rec)
        print("%-14s (32,8) %.4f  (40,10) %.4f  vs 20nm incumbent %+.1f%%  | "
              "held-out worst %.4f (%.2f, %s)"
              % (name, e_gate, e_ref, 100 * rec["vs_incumbent"],
                 held["worst_absolute"], held["worst_relative"],
                 held["worst_scenario"]), flush=True)

    # c128 spot check on the best deliverable
    best = max(out["deliverables"], key=lambda r: r["eta_40_10"])
    tgt = tuple(best["target"])
    cfg = FINE[best["pixel_nm"]]
    b = torch.from_numpy(np.load(os.path.join(
        DATA, best["name"] + "_binary.npy")).astype("float64"))
    v128 = eta_c128(b, GATE_LEVEL, tgt,
                    cfg.variant(dtype=torch.complex128, device="cpu"))
    out["spot_c128"] = {"name": best["name"], "eta_c64": best["eta_32_8"],
                        "eta_c128": v128,
                        "rel": abs(best["eta_32_8"] - v128) / max(v128, 1e-12)}
    print("spot c128 %s (32,8): c64 %.6f vs c128 %.6f (rel %.1e)"
          % (best["name"], best["eta_32_8"], v128, out["spot_c128"]["rel"]))

    with open(os.path.join(DATA, "final_audit.json"), "w") as f:
        json.dump(out, f, indent=1)

    # summary figure: per target, (40,10) values of 20nm incumbent vs fine arms
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams["font.family"] = ["Microsoft YaHei", "SimHei", "sans-serif"]
    fig, ax = plt.subplots(figsize=(8.6, 4.4))
    tlabels = ["(1,0)", "(2,0)", "(3,0)"]
    groups = {"20 nm 现任": ("#555555", [INCUMBENT_40_10[(m, 0)]
                                        for m in (1, 2, 3)])}
    for arm, px, color in [("chain", 10, "#1f77b4"), ("chain", 5, "#17becf"),
                           ("restart", 10, "#d62728")]:
        vals = []
        for m in (1, 2, 3):
            v = [r["eta_40_10"] for r in out["deliverables"]
                 if tuple(r["target"]) == (m, 0) and r["arm"] == arm
                 and r["pixel_nm"] == px]
            vals.append(v[0] if v else np.nan)
        label = ("热启动链 @%dnm" % px) if arm == "chain" \
            else ("原生重启 best-of-6 @%dnm" % px)
        groups[label] = (color, vals)
    n = len(groups)
    w = 0.8 / n
    for i, (label, (color, vals)) in enumerate(groups.items()):
        xs = np.arange(3) + (i - (n - 1) / 2) * w
        ax.bar(xs, vals, width=w * 0.92, color=color, label=label, zorder=3)
        for x, v in zip(xs, vals):
            if np.isfinite(v):
                ax.text(x, v + 0.008, "%.3f" % v, ha="center", fontsize=7)
    ax.set_xticks(range(3))
    ax.set_xticklabels(tlabels, fontsize=10)
    ax.set_ylabel("η @(40,10) 原生网格", fontsize=10)
    ax.legend(fontsize=8)
    ax.grid(axis="y", alpha=0.3)
    ax.set_title("细像素重新优化（E26）：20 nm 现任 vs 10/5 nm 交付（同参考阶，网格各自原生）",
                 fontsize=10.5)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "fig_fine_pixels.png"), dpi=220)
    print("wrote final_audit.json + fig_fine_pixels.png")


if __name__ == "__main__":
    main()
