"""Descriptive summary of S4-3 (design pixel 20/10/5 nm at fixed order (20,5)).

Reads data/s4_3_pixel_size.json, prints the tables used in S4_实验记录.md §7.3
and writes data/s4_3_analysis.json.  No hypothesis tests: medians, quartiles,
extremes, paired differences with a percentile-bootstrap interval, sign counts.
"""
import json
import os
import sys
from statistics import median

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "..", "data")
SRC = os.path.join(DATA, "s4_3_pixel_size.json")
OUT = os.path.join(DATA, "s4_3_analysis.json")

PIX = (20, 10, 5)
TARGETS = ("1-0", "2-0", "3-0")
RNG = np.random.default_rng(20260909)
NBOOT = 10000


def q(v):
    a = np.asarray(v, dtype=float)
    return {"n": int(a.size), "median": float(np.median(a)),
            "q1": float(np.percentile(a, 25)), "q3": float(np.percentile(a, 75)),
            "min": float(a.min()), "max": float(a.max()),
            "mean": float(a.mean()), "sd": float(a.std(ddof=1)) if a.size > 1 else 0.0}


def boot_median_ci(d):
    d = np.asarray(d, dtype=float)
    idx = RNG.integers(0, d.size, size=(NBOOT, d.size))
    meds = np.median(d[idx], axis=1)
    return float(np.percentile(meds, 2.5)), float(np.percentile(meds, 97.5))


def paired(a, b):
    """a - b, same seed order."""
    d = np.asarray(a) - np.asarray(b)
    lo, hi = boot_median_ci(d)
    return {"median": float(np.median(d)), "q1": float(np.percentile(d, 25)),
            "q3": float(np.percentile(d, 75)), "min": float(d.min()), "max": float(d.max()),
            "ci95": [lo, hi], "n_pos": int((d > 0).sum()), "n_neg": int((d < 0).sum()),
            "n_zero": int((d == 0).sum()), "n": int(d.size)}


def fmt(x, nd=4):
    return "n/a" if x is None else f"{x:+.{nd}f}" if isinstance(x, float) and nd else str(x)


def main():
    d = json.load(open(SRC, encoding="utf-8"))
    U = d["units"]
    # seed blocks are per target: 7101-7108 / 7201-7208 / 7301-7308
    SEEDS = {t: sorted({int(k.split("|")[3]) for k in U if k.startswith(t + "|")}) for t in TARGETS}

    def unit(t, p, s):
        return U[f"{t}|{p}|20-5|{s}"]

    res = {"source": os.path.basename(SRC), "n_units": len(U),
           "init_agreement_worst_rel": d["init_agreement_worst_rel"],
           "s4_2_ingest": {k: d["s4_2_ingest"][k] for k in ("n_rows", "sha1_verified", "arm")},
           "gpu_telemetry": d["gpu_telemetry"]}

    # ---------------- 0. sanity -------------------------------------------
    recheck = [unit(t, 10, s)["eta_ref_recheck_delta"] for t in TARGETS for s in SEEDS[t] if f"{t}|10|20-5|{s}" in U]
    res["eta_ref_recheck_delta_10nm"] = {"n": len(recheck), "max_abs": float(max(abs(x) for x in recheck))}
    nonfinite = {}
    for k, r in U.items():
        ev = r.get("grad_events") or r.get("n_nonfinite_grad_steps")
        if ev:
            nonfinite[k] = ev
    res["grad_events"] = nonfinite
    print("=== 0. sanity")
    print(f"units {len(U)}; init worst rel L2 {d['init_agreement_worst_rel']:.3e}; "
          f"10 nm rows reused {d['s4_2_ingest']['n_rows']} (sha1 verified {d['s4_2_ingest']['sha1_verified']}); "
          f"eta_ref recheck |delta| max {res['eta_ref_recheck_delta_10nm']['max_abs']:.2e}")
    print(f"grad events recorded in JSON: {nonfinite if nonfinite else 'none in unit rows (see console log)'}")

    # ---------------- 1. eta_ref by pixel x target -------------------------
    print("\n=== 1. eta_ref @(40,10) on 5 nm grid, by pixel x target (n=8)")
    tab = {}
    for t in TARGETS:
        for p in PIX:
            v = [unit(t, p, s)["eta_ref"] for s in SEEDS[t]]
            tab[f"{t}|{p}"] = q(v)
            e = tab[f"{t}|{p}"]
            print(f"  {t} {p:>2} nm  med {e['median']:.4f}  Q1-Q3 {e['q1']:.4f}-{e['q3']:.4f}  "
                  f"min-max {e['min']:.4f}-{e['max']:.4f}  sd {e['sd']:.4f}")
    for p in PIX:
        v = [unit(t, p, s)["eta_ref"] for t in TARGETS for s in SEEDS[t]]
        tab[f"all|{p}"] = q(v)
        e = tab[f"all|{p}"]
        print(f"  pooled {p:>2} nm  med {e['median']:.4f}  Q1-Q3 {e['q1']:.4f}-{e['q3']:.4f}  n={e['n']}")
    res["eta_ref"] = tab

    # ---------------- 2. paired differences ------------------------------
    print("\n=== 2. paired differences (same seed), median diff, bootstrap 95% CI of median, sign counts")
    pd = {}
    for (a, b) in ((5, 10), (20, 10), (5, 20)):
        for t in TARGETS + ("all",):
            ts = TARGETS if t == "all" else (t,)
            xa = [unit(tt, a, s)["eta_ref"] for tt in ts for s in SEEDS[tt]]
            xb = [unit(tt, b, s)["eta_ref"] for tt in ts for s in SEEDS[tt]]
            pd[f"{a}-{b}|{t}"] = paired(xa, xb)
            e = pd[f"{a}-{b}|{t}"]
            print(f"  {a:>2}-{b:>2} nm {t:>4}: med {e['median']:+.4f}  IQR [{e['q1']:+.4f},{e['q3']:+.4f}]  "
                  f"CI95 [{e['ci95'][0]:+.4f},{e['ci95'][1]:+.4f}]  +{e['n_pos']}/-{e['n_neg']}/0:{e['n_zero']} (n={e['n']})")
    res["paired_eta_ref"] = pd

    # spread vs pixel effect
    within = {p: float(np.median([tab[f"{t}|{p}"]["sd"] for t in TARGETS])) for p in PIX}
    res["within_target_sd_median_by_pixel"] = within
    print("  within-target sd (median over 3 targets) by pixel:", {k: round(v, 4) for k, v in within.items()})

    # ---------------- 3. self-report bias & delivery step --------------------
    print("\n=== 3. self-audit at (20,5) native grid vs eta_ref; delivery step; end/peak")
    sb = {}
    for p in PIX:
        rel = [unit(t, p, s)["self_bias_rel"] for t in TARGETS for s in SEEDS[t]]
        step = [unit(t, p, s)["best_audit_step"] for t in TARGETS for s in SEEDS[t]]
        endpk = []
        for t in TARGETS:
            for s in SEEDS[t]:
                r = unit(t, p, s)
                fa = r.get("final_audit_eta")
                if fa is None and r.get("audit_traj"):
                    fa = r["audit_traj"][-1][1]
                if fa is not None and r["best_audit_eta"] > 0:
                    endpk.append(fa / r["best_audit_eta"])
        sb[p] = {"self_bias_rel": q(rel), "best_step": q(step), "end_over_peak": q(endpk) if endpk else None}
        per_t = {t: float(np.median([unit(t, p, s)["self_bias_rel"] for s in SEEDS[t]])) for t in TARGETS}
        print(f"  {p:>2} nm: self bias rel med {np.median(rel):+.3f} (per target {per_t}); "
              f"best step med {np.median(step):.0f}; end/peak med {np.median(endpk) if endpk else float('nan'):.3f}")
    res["self_report"] = sb

    # ---------------- 4. time ----------------------------------------------
    print("\n=== 4. time: end-to-end wall, per-step solve, pure forward at (20,5), overhead, design-map probe, memory")
    tm = {}
    for p in PIX:
        rows = [unit(t, p, s) for t in TARGETS for s in SEEDS[t]]
        wall = [r["timing"]["wall_s"] for r in rows]
        solve = [r["timing"]["solve"]["median"] for r in rows]
        aud = [r["timing"]["audit_solve"]["median"] for r in rows]
        ovh = [r["timing"]["overhead"]["median"] for r in rows if r["timing"]["overhead"].get("median") is not None]
        solve_tot = [r["timing"]["solve"]["total"] for r in rows]
        aud_tot = [r["timing"]["audit_solve"]["total"] for r in rows]
        mem = [r["peak_mem_bytes"] / 2**30 for r in rows]
        memref = [r["peak_mem_ref_bytes"] / 2**30 for r in rows]
        probe = {}
        pr = [r["probe"] for r in rows if "probe" in r]
        if pr:
            for key in ("filtered", "projected", "hard_binary", "adam_step", "map_value_grad", "value_grad_at_8_2"):
                probe[key] = float(np.median([x[key]["median"] for x in pr]))
        tm[p] = {"wall_s": q(wall), "solve_step_s": q(solve), "audit_fwd_s": q(aud),
                 "overhead_step_s": q(ovh) if ovh else None,
                 "solve_share_of_wall": float(np.median([a / w for a, w in zip(solve_tot, wall)])),
                 "audit_share_of_wall": float(np.median([a / w for a, w in zip(aud_tot, wall)])),
                 "peak_mem_gib": q(mem), "peak_mem_ref_gib": q(memref), "probe_median_s": probe}
        e = tm[p]
        print(f"  {p:>2} nm: wall med {e['wall_s']['median']:.1f} s [{e['wall_s']['min']:.1f},{e['wall_s']['max']:.1f}]; "
              f"solve/step med {e['solve_step_s']['median']:.4f} s; fwd(20,5) med {e['audit_fwd_s']['median']:.4f} s; "
              f"overhead/step {'%.2e' % e['overhead_step_s']['median'] if e['overhead_step_s'] else 'n/a'} s; "
              f"solve share {e['solve_share_of_wall']:.3f}, audit share {e['audit_share_of_wall']:.3f}; "
              f"peak mem {e['peak_mem_gib']['median']:.3f} GiB (ref {e['peak_mem_ref_gib']['median']:.2f})")
        if probe:
            print("        probe medians (s):", {k: f"{v:.2e}" for k, v in probe.items()})
    res["time"] = tm
    # clock drift check: run arms alternate per seed; compare first vs second half of work order
    drift = {}
    for p in (20, 5):
        rows = sorted([unit(t, p, s) for t in TARGETS for s in SEEDS[t]], key=lambda r: r["work_order_index"])
        half = len(rows) // 2
        drift[p] = {"wall_first_half": float(np.median([r["timing"]["wall_s"] for r in rows[:half]])),
                    "wall_second_half": float(np.median([r["timing"]["wall_s"] for r in rows[half:]])),
                    "clock_first": float(np.median([r["gpu_at_start"]["clocks_sm"] for r in rows[:half]])),
                    "clock_second": float(np.median([r["gpu_at_start"]["clocks_sm"] for r in rows[half:]])),
                    "temp_first": float(np.median([r["gpu_at_start"]["temperature_gpu"] for r in rows[:half]])),
                    "temp_second": float(np.median([r["gpu_at_start"]["temperature_gpu"] for r in rows[half:]]))}
        print(f"  drift {p:>2} nm: wall first/second half {drift[p]['wall_first_half']:.1f}/{drift[p]['wall_second_half']:.1f} s; "
              f"SM clock {drift[p]['clock_first']:.0f}/{drift[p]['clock_second']:.0f} MHz; temp {drift[p]['temp_first']:.0f}/{drift[p]['temp_second']:.0f} C")
    res["drift"] = drift

    # ---------------- 5. geometry & round trips -----------------------------
    print("\n=== 5. delivered geometry and round trips (delta = eta_ref(after round trip) - eta_ref(delivered))")
    geo = {}
    for p in PIX:
        rows = [unit(t, p, s) for t in TARGETS for s in SEEDS[t]]
        geo[p] = {"fill": q([r["geometry"]["fill_fraction"] for r in rows]),
                  "interface_len_nm": q([r["geometry"]["interface_len_nm"] for r in rows]),
                  "boundary_fraction_native": q([r["geometry"]["boundary_fraction"] for r in rows])}
        e = geo[p]
        print(f"  {p:>2} nm: fill med {e['fill']['median']:.3f} [{e['fill']['min']:.3f},{e['fill']['max']:.3f}]; "
              f"interface length med {e['interface_len_nm']['median']:.0f} nm [{e['interface_len_nm']['min']:.0f},{e['interface_len_nm']['max']:.0f}]")
    res["geometry"] = geo
    rt = {}
    for p, to in ((5, "20"), (10, "20"), (5, "10")):
        for t in TARGETS + ("all",):
            ts = TARGETS if t == "all" else (t,)
            rows = [unit(tt, p, s) for tt in ts for s in SEEDS[tt]]
            dd = [r["roundtrip"][to]["delta_eta"] for r in rows]
            rel = [r["roundtrip"][to]["delta_eta"] / r["eta_ref"] for r in rows]
            ch = [r["roundtrip"][to]["changed_ref_fraction"] for r in rows]
            tie = [r["roundtrip"][to]["tie_fraction"] for r in rows]
            fs = [r["roundtrip"][to]["fill_shift"] for r in rows]
            fm = [r["roundtrip"][to]["fill_matched"]["delta_eta_vs_plain"] for r in rows
                  if r["roundtrip"][to].get("fill_matched")]
            fmd = [r["roundtrip"][to]["fill_matched"]["delta_eta"] for r in rows
                   if r["roundtrip"][to].get("fill_matched")]
            lo, hi = boot_median_ci(dd)
            rt[f"{p}->{to}->{p}|{t}"] = {"delta_eta": q(dd), "delta_eta_ci95_median": [lo, hi],
                                          "delta_rel": q(rel), "changed_ref_fraction": q(ch),
                                          "tie_fraction": q(tie), "fill_shift": q(fs),
                                          "n_pos": int(sum(x > 0 for x in dd)), "n_neg": int(sum(x < 0 for x in dd)),
                                          "fill_matched_delta_eta": q(fmd) if fmd else None,
                                          "fill_matched_minus_plain": q(fm) if fm else None}
            e = rt[f"{p}->{to}->{p}|{t}"]
            print(f"  {p:>2}->{to:>2}->{p:<2} {t:>4}: dEta med {e['delta_eta']['median']:+.4f} IQR [{e['delta_eta']['q1']:+.4f},{e['delta_eta']['q3']:+.4f}] "
                  f"CI95 [{lo:+.4f},{hi:+.4f}] +{e['n_pos']}/-{e['n_neg']}; |dEta| max {max(abs(x) for x in dd):.4f}; "
                  f"changed px {e['changed_ref_fraction']['median']*100:.2f}%; tie {e['tie_fraction']['median']*100:.2f}%; fill shift {e['fill_shift']['median']:+.4f}"
                  + (f"; fill-matched dEta med {e['fill_matched_delta_eta']['median']:+.4f}, minus plain med {e['fill_matched_minus_plain']['median']:+.4f}" if fm else ""))
    res["roundtrip"] = rt

    # ---------------- 6. spectrum ------------------------------------------
    print("\n=== 6. energy beyond the 20 nm Nyquist on the common (140,480) grid")
    sp = {}
    for p in PIX:
        rows = [unit(t, p, s) for t in TARGETS for s in SEEDS[t]]
        fl = [r["spectrum"]["filtered_latent_ref"]["frac_beyond_nyq20"] for r in rows]
        db = [r["spectrum"]["delivered_binary_ref"]["frac_beyond_nyq20"] for r in rows]
        dbac = [r["spectrum"]["delivered_binary_ref"]["frac_beyond_nyq20_ac"] for r in rows]
        db10 = [r["spectrum"]["delivered_binary_ref"]["frac_beyond_nyq10"] for r in rows]
        H = rows[0]["spectrum"]["filter_transfer_ref"]["max_transfer_beyond_nyq20"]
        sp[p] = {"filtered_latent_beyond_nyq20": q(fl), "delivered_binary_beyond_nyq20": q(db),
                 "delivered_binary_beyond_nyq20_ac": q(dbac), "delivered_binary_beyond_nyq10": q(db10),
                 "filter_transfer_max_beyond_nyq20": H}
        print(f"  {p:>2} nm: filtered latent beyond nyq20 med {np.median(fl):.1e} (filter |H|^2 ceiling {H:.1e}); "
              f"delivered binary beyond nyq20 med {np.median(db)*100:.2f}% [{min(db)*100:.2f},{max(db)*100:.2f}] "
              f"(AC-normalised {np.median(dbac)*100:.2f}%); beyond nyq10 med {np.median(db10)*100:.2f}%")
    res["spectrum"] = sp

    json.dump(res, open(OUT, "w", encoding="utf-8"), indent=1, ensure_ascii=False)
    print(f"\nwrote {OUT}")


if __name__ == "__main__":
    sys.exit(main())
