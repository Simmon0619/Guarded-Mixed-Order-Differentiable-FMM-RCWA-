"""Figures for S4_实验记录.md sections 7.1 / 7.2 / 7.3.

Every number is recomputed from the three data JSONs; nothing is transcribed
from the record's tables.  Output: ../figures/fig??_*.png (+ .pdf).

Aggregation matches the record exactly where the two overlap.  In particular the
gradient angle is read off the 1-cos quantiles (acos is monotone, so quantiles
carry through) rather than averaged in angle space -- with an even n the two
differ, and the record's column is the 1-cos one.  Paired CIs and detectable
effects use normal quantiles, as the record's 7.2.2 table does.

Colour: ordered quantities (truncation order, design pixel, target order) get a
single-hue blue ordinal ramp, light -> dark, never a categorical cycle.  The one
categorical contrast is CERT (orange), which is not a rung of the descent-order
ladder but L16's own trajectory scored at (24,6).  Labels are English because
these figures are destined for the manuscript.  Light surface only: the
deliverable is a paper figure, not a themed web page.
"""
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.lines import Line2D
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.normpath(os.path.join(HERE, "..", "data"))
FIGS = os.path.normpath(os.path.join(HERE, "..", "figures"))
os.makedirs(FIGS, exist_ok=True)
RNG = np.random.default_rng(20260909)
Z95, Z80 = stats.norm.ppf(0.975), stats.norm.ppf(0.80)   # the record's convention

# ---------------------------------------------------------------- palette ---
INK, INK2, MUTED = "#0b0b0b", "#52514e", "#898781"
GRID, AXIS, SURF = "#e1e0d9", "#c3c2b7", "#fcfcfb"
RAMP = ["#86b6ef", "#6da7ec", "#5598e7", "#3987e5", "#2a78d6",
        "#256abf", "#1c5cab", "#184f95", "#104281", "#0d366b"]
ORANGE, RED = "#eb6834", "#e34948"


def ramp(i, n):
    return RAMP[4] if n == 1 else RAMP[int(round(i * (len(RAMP) - 1) / (n - 1)))]


plt.rcParams.update({
    "figure.facecolor": SURF, "axes.facecolor": SURF, "savefig.facecolor": SURF,
    "font.family": "sans-serif",
    "font.sans-serif": ["Segoe UI", "DejaVu Sans", "Arial"],
    "font.size": 8.5, "axes.labelsize": 8.5, "axes.labelcolor": INK2,
    "axes.edgecolor": AXIS, "axes.linewidth": 0.8, "text.color": INK,
    "xtick.color": MUTED, "ytick.color": MUTED,
    "xtick.labelsize": 8, "ytick.labelsize": 8,
    "xtick.major.size": 3, "ytick.major.size": 3,
    "xtick.major.width": 0.8, "ytick.major.width": 0.8,
    "grid.color": GRID, "grid.linewidth": 0.7, "legend.frameon": False,
    "legend.fontsize": 8, "lines.linewidth": 2.0, "lines.solid_capstyle": "round",
    "axes.spines.top": False, "axes.spines.right": False,
    "figure.dpi": 110, "savefig.dpi": 220, "savefig.bbox": "tight",
})


def style(ax, xgrid=False, ygrid=True):
    ax.set_axisbelow(True)
    ax.yaxis.grid(ygrid)
    ax.xaxis.grid(xgrid)


def head(ax, main, sub=None, y=1.05, gap=0.058):
    """Bold title above the axes, muted subtitle between it and the plot."""
    ax.text(0, y + (gap if sub else 0), main, transform=ax.transAxes, color=INK,
            fontsize=9.8, fontweight="bold", va="bottom", ha="left")
    if sub:
        ax.text(0, y, sub, transform=ax.transAxes, color=MUTED, fontsize=7.8,
                va="bottom", ha="left")


def fighead(fig, main, sub, x=0.09, y=1.05, gap=0.045):
    fig.text(x, y + gap, main, ha="left", va="bottom", color=INK, fontsize=10.4,
             fontweight="bold")
    fig.text(x, y, sub, ha="left", va="bottom", color=MUTED, fontsize=7.9)


def save(fig, name):
    p = os.path.join(FIGS, name)
    fig.savefig(p + ".png")
    plt.close(fig)
    print("  wrote", os.path.basename(p) + ".png")


def qtl(a, axis=0):
    a = np.asarray(a, float)
    return (np.nanmedian(a, axis), np.nanpercentile(a, 25, axis),
            np.nanpercentile(a, 75, axis))


def deg(one_minus_cos):
    return np.degrees(np.arccos(np.clip(1.0 - np.asarray(one_minus_cos), -1.0, 1.0)))


def boot_med_ci(d, n=10000):
    d = np.asarray(d, float)
    m = np.median(d[RNG.integers(0, d.size, size=(n, d.size))], axis=1)
    return float(np.percentile(m, 2.5)), float(np.percentile(m, 97.5))


# ================================================================ load =====
D1 = json.load(open(os.path.join(DATA, "s4_1_value_grad.json"), encoding="utf-8"))
D2 = json.load(open(os.path.join(DATA, "s4_2_descent_order.json"), encoding="utf-8"))["units"]
D3 = json.load(open(os.path.join(DATA, "s4_3_pixel_size.json"), encoding="utf-8"))["units"]

LV = [(8, 2), (12, 3), (16, 4), (20, 5), (24, 6), (28, 7), (32, 8)]
LVL = ["(%d,%d)" % l for l in LV]
NTERMS = [85, 175, 297, 451, 637, 855, 1105]
ARMS = ["L12", "L16", "L20", "L24", "CERT"]
ARM_AUD = {"L12": "(12,3)", "L16": "(16,4)", "L20": "(20,5)", "L24": "(24,6)",
           "CERT": "(24,6)"}
ARM_C = {"L12": RAMP[0], "L16": RAMP[3], "L20": RAMP[5], "L24": RAMP[8], "CERT": ORANGE}
TGT = ["1-0", "2-0", "3-0"]
TGTLAB = {"1-0": "target (1,0)", "2-0": "target (2,0)", "3-0": "target (3,0)"}
PIX = [20, 10, 5]
PIX_C = {20: RAMP[0], 10: RAMP[4], 5: RAMP[9]}
S2SEED = {t: sorted({int(k.split("|")[3]) for k in D2 if k.startswith(t + "|")}) for t in TGT}
S3SEED = {t: sorted({int(k.split("|")[3]) for k in D3 if k.startswith(t + "|")}) for t in TGT}
u2 = lambda t, a, s: D2["%s|10|%s|%d" % (t, a, s)]
u3 = lambda t, p, s: D3["%s|%d|20-5|%d" % (t, p, s)]

UN1 = [u for u in D1["units"] if str(u["beta"]) in ("1.0", "8.0", "64.0")]
assert len(UN1) == 36, len(UN1)
col = lambda u, k: [next(r[k] for r in u["ladder"] if tuple(r["level"]) == l) for l in LV]
VERR = np.array([np.abs(col(u, "rel_value_err")) for u in UN1]) * 100
OMC = np.array([col(u, "one_minus_cos_vs_ref") for u in UN1])
NF = np.array([[next(r["noise_floor_one_minus_cos"] for r in u["noise_floor"]
                     if tuple(r["level"]) == l) for l in LV] for u in UN1])
ADJ = np.array([[next(r["d_cos"] for r in u["adjacent"] if tuple(r["from"]) == l)
                 for l in LV] for u in UN1])
ANG = deg(OMC)

print("figures ->", FIGS)


# ========================================================== 7.1 ============
def fig01():
    """How much of the truth each rung already has: the value, and the gradient."""
    fig, axes = plt.subplots(2, 1, figsize=(6.8, 6.6), sharex=True,
                             gridspec_kw=dict(hspace=0.26, height_ratios=[1.5, 1]))
    x = np.arange(len(LV))

    # (a) both as a dimensionless fraction of the reference, on one linear axis
    vkeep = 1.0 - np.asarray(qtl(VERR)[0]) / 100.0          # 1 - |dEta|/Eta
    vk1 = 1.0 - np.asarray(qtl(VERR)[2]) / 100.0
    vk3 = 1.0 - np.asarray(qtl(VERR)[1]) / 100.0
    mo, q1o, q3o = qtl(OMC)
    gkeep, gk1, gk3 = 1.0 - mo, 1.0 - q3o, 1.0 - q1o
    ax = axes[0]
    ax.fill_between(x, vk1, vk3, color=RAMP[4], alpha=0.13, lw=0)
    ax.fill_between(x, gk1, gk3, color=ORANGE, alpha=0.13, lw=0)
    ax.plot(x, vkeep, color=RAMP[5], marker="o", ms=6, mec=SURF, mew=1.3, zorder=4)
    ax.plot(x, gkeep, color=ORANGE, marker="s", ms=5.5, mec=SURF, mew=1.3, zorder=4)
    ax.annotate("the value:  1 $-$ |$\\Delta\\eta$| / $\\eta$", (5.05, vkeep[5]),
                textcoords="offset points", xytext=(0, 12), fontsize=8.4,
                color=RAMP[5], ha="center")
    ax.annotate("the gradient direction:  cos", (3.05, gkeep[3]),
                textcoords="offset points", xytext=(0, -20), fontsize=8.4,
                color=ORANGE, ha="center")
    ax.set_ylim(-0.10, 1.16)
    ax.set_yticks([0, 0.25, 0.5, 0.75, 1.0])
    ax.set_yticklabels(["0%", "25%", "50%", "75%", "100%"])
    ax.set_ylabel("fraction of the reference already recovered")
    # the gap at the order the earlier work actually used
    ax.plot([1, 1], [gkeep[1], vkeep[1]], color=RED, lw=1.6, zorder=5,
            solid_capstyle="butt")
    ax.scatter([1, 1], [gkeep[1], vkeep[1]], s=20, color=RED, zorder=6)
    ax.annotate("at (12,3), the order the earlier work descended with:\n"
                "the value is %.1f%% right, the direction only %.1f%%  (%.1f° off)"
                % (vkeep[1] * 100, gkeep[1] * 100, deg(mo)[1]),
                xy=(1.06, 0.70), xytext=(1.55, 0.15), fontsize=8, color=RED,
                arrowprops=dict(arrowstyle="->", color=RED, lw=1.0,
                                connectionstyle="arc3,rad=-0.25"))
    ax.axhline(1.0, color=MUTED, lw=0.8, zorder=1)
    style(ax)

    # (b) the absolute scale of the value error, in efficiency points
    ab = np.array([np.median([abs(next(r["abs_value_err"] for r in u["ladder"]
                                       if tuple(r["level"]) == l)) for u in UN1])
                   for l in LV])
    ax = axes[1]
    ax.plot(x, ab, color=RAMP[5], marker="o", ms=5, mec=SURF, mew=1.2, zorder=3)
    ax.set_yscale("log"); ax.set_ylim(8e-5, 0.9)
    ax.axhspan(0.20, 0.45, color=RAMP[0], alpha=0.25, lw=0, zorder=1)
    ax.text(6.35, 0.30, "delivered $\\eta$\nin this study", fontsize=7.5, color=RAMP[6],
            ha="right", va="center")
    ax.set_ylabel("absolute value error  |$\\Delta\\eta$|")
    for i in (0, 1):
        ax.annotate("%.3f" % ab[i], (i, ab[i]), textcoords="offset points",
                    xytext=(0, 10), ha="center", fontsize=8, color=INK)
    style(ax)

    for ax in axes:
        ax.axvline(1, color=MUTED, lw=0.8, zorder=1)
    axes[1].set_xticks(x)
    axes[1].set_xticklabels(["%s\nN = %d" % (a, b) for a, b in zip(LVL, NTERMS)])
    axes[1].set_xlabel("truncation order $(M_x, M_y)$  /  retained modes N")
    head(axes[0], "A rung that is accurate enough for the value is not accurate enough for the gradient",
         "median over 36 structure × β units, bands = interquartile range; reference (40,10), GPU/complex64, 10 nm design pixel")
    head(axes[1], "…and in absolute terms the value error is already negligible at (12,3)",
         " ", y=1.03)
    save(fig, "fig01_s4_1_value_vs_gradient")


def fig02():
    """Why complex64 is enough: floor against order-to-order change."""
    fig, axes = plt.subplots(1, 2, figsize=(8.6, 3.6), gridspec_kw=dict(wspace=0.30))
    x = np.arange(len(LV))
    ax = axes[0]
    nf, adj = np.nanmedian(NF, 0), np.nanmedian(ADJ, 0)
    ax.fill_between(x, nf, adj, color=RAMP[2], alpha=0.12, lw=0)
    ax.plot(x, adj, color=RAMP[6], marker="o", ms=5, mec=SURF, mew=1.2, zorder=3,
            label="change from one rung to the next")
    ax.plot(x, nf, color=ORANGE, marker="s", ms=4.5, mec=SURF, mew=1.2, zorder=3,
            label="complex64 noise floor")
    ax.set_yscale("log"); ax.set_ylim(1e-9, 4)
    ax.set_ylabel("1 $-$ cos  (median of 36 units)")
    ax.legend(loc="lower left", handlelength=1.4, borderpad=0.2)
    style(ax)
    ax.set_xticks(x); ax.set_xticklabels(LVL, rotation=45, ha="right")
    ax.set_xlabel("truncation order")
    head(ax, "The signal stays above the single-precision floor",
         "floor = two identical code paths, different floating-point order")

    ax = axes[1]
    snr = ADJ / NF
    m, q1, q3 = qtl(snr)
    ax.fill_between(x, q1, q3, color=RAMP[4], alpha=0.15, lw=0)
    ax.plot(x, m, color=RAMP[4], marker="o", ms=5, mec=SURF, mew=1.2, zorder=3)
    ax.axhline(2, color=RED, lw=1.2, ls=(0, (4, 3)), zorder=4)
    ax.text(0.06, 2.6, "kill line: signal = 2 × noise   (never reached)", color=RED,
            fontsize=7.6)
    for i, lab in ((0, "3×10$^7$"), (5, "15")):
        ax.annotate(lab, (i, m[i]), textcoords="offset points", xytext=(6, 6),
                    fontsize=8, color=INK)
    ax.set_yscale("log"); ax.set_ylim(0.7, 3e8)
    ax.set_ylabel("signal / noise")
    style(ax)
    ax.set_xticks(x); ax.set_xticklabels(LVL, rotation=45, ha="right")
    ax.set_xlabel("truncation order")
    head(ax, "Margin shrinks with order but never closes",
         "median with interquartile band; the pre-registered kill criterion was not triggered")
    save(fig, "fig02_s4_1_noise_floor")


def fig03():
    """All 252 (structure, beta, order) combinations."""
    fig, ax = plt.subplots(figsize=(6.8, 4.7))
    ax.add_patch(plt.Rectangle((0.003, 45), 1 - 0.003, 200 - 45, facecolor=RED,
                               alpha=0.06, lw=0, zorder=0))
    for j in range(len(LV)):
        ax.scatter(VERR[:, j], ANG[:, j], s=26, color=ramp(j, len(LV)),
                   edgecolor=SURF, linewidth=0.6, zorder=3, label=LVL[j])
    ax.axvline(1, color=MUTED, lw=0.9, zorder=1)
    ax.axhline(90, color=RED, lw=1.0, ls=(0, (4, 3)), zorder=2)
    ax.text(0.0037, 103, "90°: the gradient points into the opposite half-space",
            color=RED, fontsize=7.5)
    n_both = int(((VERR < 1) & (ANG > 45)).sum())
    ax.text(0.0037, 40, "value already inside 1%%,\ngradient off by over 45°:\n%d of 252"
            % n_both, color=INK2, fontsize=7.6, va="top")
    ax.text(1.15, 0.13, "value error = 1%", color=MUTED, fontsize=7.4, rotation=90,
            va="bottom")
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlim(0.003, 60); ax.set_ylim(0.1, 200)
    ax.set_yticks([0.3, 1, 3, 10, 30, 100])
    ax.set_yticklabels(["0.3°", "1°", "3°", "10°", "30°", "100°"])
    ax.set_xticks([0.01, 0.1, 1, 10]); ax.set_xticklabels(["0.01%", "0.1%", "1%", "10%"])
    ax.set_xlabel("relative value error  |$\\Delta\\eta$| / $\\eta$")
    ax.set_ylabel("gradient angle from the reference gradient")
    style(ax, xgrid=True)
    leg = ax.legend(title="truncation order", loc="lower right", ncol=2,
                    handletextpad=0.3, columnspacing=1.0, borderpad=0.4)
    leg.get_title().set_fontsize(7.8); leg.get_title().set_color(INK2)
    head(ax, "The two errors are not one quantity in disguise",
         "252 combinations = 12 structures × 3 β × 7 orders; if value error predicted gradient error the cloud would be a line")
    save(fig, "fig03_s4_1_decoupling_scatter")


def fig04():
    """Which of the two converges first."""
    gaps = []
    for i in range(36):
        vi = next((j for j in range(len(LV)) if VERR[i, j] < 1.0), None)
        gi = next((j for j in range(len(LV)) if OMC[i, j] < 1e-2), None)
        if vi is not None and gi is not None:
            gaps.append(gi - vi)
    gaps = np.array(gaps)
    fig, ax = plt.subplots(figsize=(5.8, 3.2))
    vals = np.arange(gaps.min(), gaps.max() + 1)
    cnt = [int((gaps == v).sum()) for v in vals]
    cols = [RAMP[6] if v < 0 else (MUTED if v == 0 else ORANGE) for v in vals]
    ax.bar(vals, cnt, width=0.6, color=cols, zorder=3)
    for v, c in zip(vals, cnt):
        if c:
            ax.annotate(str(c), (v, c), textcoords="offset points", xytext=(0, 3),
                        ha="center", fontsize=7.8, color=INK2)
    ax.set_xticks(vals); ax.set_ylim(0, max(cnt) * 1.35)
    ax.set_xlabel("rungs between the two convergence points\n(gradient rung $-$ value rung)")
    ax.set_ylabel("units")
    yl = max(cnt) * 1.18
    ax.text(-0.45, yl, "gradient first: %d" % int((gaps < 0).sum()), color=RAMP[6],
            fontsize=7.8, ha="right")
    ax.text(0, yl, "tied: %d" % int((gaps == 0).sum()), color=INK2, fontsize=7.8,
            ha="center")
    ax.text(0.45, yl, "value first: %d" % int((gaps > 0).sum()), color=ORANGE,
            fontsize=7.8, ha="left")
    style(ax)
    head(ax, "Neither error is systematically ahead of the other",
         "n = %d units that reach both thresholds (value < 1%%, 1$-$cos < 10$^{-2}$) on the ladder" % len(gaps))
    save(fig, "fig04_s4_1_who_converges_first")


# ========================================================== 7.2 ============
def _strip(ax, groups, values, colors, jitter=0.13, s=22):
    for j, (v, c) in enumerate(zip(values, colors)):
        v = np.asarray(v)
        ax.scatter(np.full(v.size, j) + RNG.uniform(-jitter, jitter, v.size), v, s=s,
                   color=c, edgecolor=SURF, linewidth=0.6, alpha=0.9, zorder=3)
        ax.plot([j - .30, j + .30], [np.median(v)] * 2, color=INK, lw=2.2, zorder=4,
                solid_capstyle="butt")
    ax.set_xticks(range(len(groups))); ax.set_xticklabels(groups)
    ax.set_xlim(-0.55, len(groups) - 0.45)


def fig05():
    """Delivered efficiency by descent order, seeds paired."""
    fig, axes = plt.subplots(1, 4, figsize=(9.8, 4.0), sharey=True,
                             gridspec_kw=dict(wspace=0.09))
    x = np.arange(len(ARMS))
    for k, t in enumerate(TGT):
        ax = axes[k]
        M = np.array([[u2(t, a, s)["eta_ref"] for a in ARMS] for s in S2SEED[t]])
        for row in M:
            ax.plot(x, row, color=MUTED, lw=0.7, alpha=0.4, zorder=2)
        for j, a in enumerate(ARMS):
            ax.scatter(np.full(M.shape[0], j), M[:, j], s=26, color=ARM_C[a],
                       edgecolor=SURF, linewidth=0.8, zorder=3)
            ax.plot([j - .30, j + .30], [np.median(M[:, j])] * 2, color=INK, lw=2.2,
                    zorder=4, solid_capstyle="butt")
        ax.set_xticks(x); ax.set_xticklabels(ARMS)
        ax.set_xlim(-0.55, len(ARMS) - 0.45); style(ax)
        ax.text(0, 1.01, TGTLAB[t], transform=ax.transAxes, color=INK2, fontsize=8.6)
    ax = axes[3]
    pooled = [np.array([u2(t, a, s)["eta_ref"] for t in TGT for s in S2SEED[t]])
              for a in ARMS]
    _strip(ax, ARMS, pooled, [ARM_C[a] for a in ARMS])
    style(ax)
    ax.text(0, 1.01, "pooled, n = 24", transform=ax.transAxes, color=INK2, fontsize=8.6)
    for j, v in enumerate(pooled):
        ax.annotate("%.3f" % np.median(v), (j, 0.045), ha="center", fontsize=7.4,
                    color=INK2, annotation_clip=False)
    ax.annotate("median", (-0.62, 0.045), ha="right", fontsize=7.4, color=MUTED,
                annotation_clip=False)
    axes[0].set_ylabel("delivered efficiency  $\\eta$ @ (40,10)")
    axes[0].set_ylim(0.02, 0.88)
    fighead(fig, "Seed-to-seed spread swamps the difference between descent orders",
            "grey lines join one seed across arms · black bar = median · equal step budget (219 steps), so wall clock spans 17× (23 s to 387 s)",
            x=0.075, y=1.055)
    fig.text(0.075, -0.10, "descent / audit order:   L12 (12,3)    L16 (16,4)    "
             "L20 (20,5)    L24 (24,6)    CERT = L16's own trajectory, scored at (24,6)",
             ha="left", color=MUTED, fontsize=7.7)
    save(fig, "fig05_s4_2_delivered_by_arm")


def fig06():
    """Ten paired comparisons and what each could have resolved."""
    rows = []
    for i, a in enumerate(ARMS):
        for b in ARMS[i + 1:]:
            d = np.array([u2(t, a, s)["eta_ref"] - u2(t, b, s)["eta_ref"]
                          for t in TGT for s in S2SEED[t]])
            se = d.std(ddof=1) / np.sqrt(d.size)
            rows.append((f"{a} − {b}", d.mean(), Z95 * se, (Z95 + Z80) * se))
    rows.sort(key=lambda r: r[3])
    fig, ax = plt.subplots(figsize=(7.0, 4.4))
    y = np.arange(len(rows))[::-1]
    for yi, (lab, m, ci, mde) in zip(y, rows):
        ax.plot([-mde, mde], [yi, yi], color=GRID, lw=10, solid_capstyle="butt", zorder=1)
        ax.plot([m - ci, m + ci], [yi, yi], color=RAMP[4], lw=2.2, zorder=3)
        ax.scatter([m], [yi], s=34, color=RAMP[7], edgecolor=SURF, linewidth=1.0, zorder=4)
    ax.axvline(0, color=INK, lw=1.0, zorder=2)
    ax.set_yticks(y); ax.set_yticklabels([r[0] for r in rows])
    ax.tick_params(axis="y", colors=INK2)
    ax.set_ylim(-1.6, len(rows) - 0.3)
    ax.set_xlim(-0.15, 0.15)
    ax.set_xlabel("paired difference in delivered $\\eta$ @ (40,10)   (n = 24)")
    style(ax, xgrid=True, ygrid=False)
    ax.annotate("grey = smallest difference this pairing could have resolved (±%.3f)"
                % rows[-1][3], xy=(rows[-1][3], y[-1]), xytext=(-0.145, -1.25),
                fontsize=7.6, color=MUTED, va="center",
                arrowprops=dict(arrowstyle="-", color=MUTED, lw=0.7,
                                connectionstyle="arc3,rad=0.15"))
    ax.annotate("same trajectory, only the scoring\norder differs → resolves ±%.3f"
                % rows[0][3], xy=(rows[0][3], y[0]), xytext=(0.033, y[0] - 0.15),
                fontsize=7.6, color=ORANGE, va="center",
                arrowprops=dict(arrowstyle="-", color=ORANGE, lw=0.8))
    head(ax, "Every interval contains zero — and so does almost every resolution limit",
         "dot = mean difference, blue = 95% CI, grey = effect detectable at 80% power; rows sorted by resolution")
    save(fig, "fig06_s4_2_paired_forest")


def fig07():
    """What a higher order buys, and what it costs."""
    LAD = ["L12", "L16", "L20", "L24"]                 # descent order == audit order
    fig, axes = plt.subplots(1, 3, figsize=(9.8, 3.8), gridspec_kw=dict(wspace=0.34))
    x = np.arange(len(LAD))
    cert_x = 3.0                                        # CERT audits at (24,6)

    # (a) what you get: delivered efficiency at the reference -- flat
    ax = axes[0]
    for j, a in enumerate(LAD):
        v = np.array([u2(t, a, s)["eta_ref"] for t in TGT for s in S2SEED[t]])
        ax.scatter(np.full(v.size, j) + RNG.uniform(-.13, .13, v.size), v, s=18,
                   color=ARM_C[a], edgecolor=SURF, linewidth=0.5, alpha=0.55, zorder=3)
    med = [np.median([u2(t, a, s)["eta_ref"] for t in TGT for s in S2SEED[t]])
           for a in LAD]
    ax.plot(x, med, color=INK, lw=2.0, marker="o", ms=6, mec=SURF, mew=1.3, zorder=5)
    ax.set_ylabel("delivered efficiency  $\\eta$ @ (40,10)")
    ax.set_ylim(0.03, 0.88)
    ax.annotate("medians span 0.28–0.35;\nall ten paired comparisons\nhave intervals containing zero",
                (0.06, 0.80), fontsize=7.6, color=INK2, va="top")
    style(ax)
    head(ax, "What it buys: nothing measurable", "median over n = 24, dots = the runs")

    # (b) what it costs: wall clock, equal step budget
    ax = axes[1]
    # descent + own audits.  NOT run_wall_s: L16 shares its run with CERT, whose
    # (24,6) audits would be billed to L16 (118 s instead of 66 s).
    w = [np.median([u2(t, a, s)["descent_wall_s"] + u2(t, a, s)["audit_wall_s"]
                    for t in TGT for s in S2SEED[t]]) for a in LAD]
    ax.plot(x, w, color=RED, lw=2.0, marker="o", ms=6, mec=SURF, mew=1.3, zorder=4)
    for j, v in enumerate(w):
        ax.annotate("%.0f s" % v, (j, v), textcoords="offset points",
                    xytext=(-2 if j == 0 else 0, 11), ha="center", fontsize=8, color=INK)
    ax.set_yscale("log"); ax.set_ylim(12, 900)
    ax.set_yticks([20, 50, 100, 200, 500])
    ax.set_yticklabels(["20 s", "50 s", "100 s", "200 s", "500 s"])
    ax.set_ylabel("wall clock for one 219-step run")
    ax.annotate("×%.0f" % (w[-1] / w[0]), (2.35, 70), fontsize=14,
                color=RED, ha="center", va="center")
    style(ax)
    head(ax, "What it costs: %.0f× the time" % (w[-1] / w[0]),
         "equal step budget, so this is a result, not a control")

    # (c) what it does change: the gap between self-report and truth
    ax = axes[2]
    b = [np.median([u2(t, a, s)["self_bias_rel"] for t in TGT for s in S2SEED[t]]) * 100
         for a in LAD]
    ax.plot(x, b, color=RAMP[6], lw=2.0, marker="o", ms=6, mec=SURF, mew=1.3, zorder=4)
    for t, sty in zip(TGT, (":", "--", "-")):
        bt = [np.median([u2(t, a, s)["self_bias_rel"] for s in S2SEED[t]]) * 100
              for a in LAD]
        ax.plot(x, bt, color=RAMP[2], lw=1.0, ls=sty, zorder=3)
        ax.annotate(TGTLAB[t].replace("target ", ""), (0, bt[0]),
                    textcoords="offset points", xytext=(-6, 0), ha="right",
                    va="center", fontsize=7.2, color=RAMP[2])
    cb = np.median([u2(t, "CERT", s)["self_bias_rel"] for t in TGT for s in S2SEED[t]]) * 100
    ax.scatter([cert_x], [cb], s=52, color=ORANGE, edgecolor=SURF, linewidth=1.2,
               zorder=6, marker="D")
    ax.annotate("CERT descends at (16,4)\nbut audits at (24,6), and\nlands on the (24,6) bias",
                (cert_x, cb), textcoords="offset points", xytext=(-14, 30),
                ha="right", fontsize=7.4, color=ORANGE,
                arrowprops=dict(arrowstyle="->", color=ORANGE, lw=0.8,
                                connectionstyle="arc3,rad=-0.2"))
    ax.axhline(0, color=INK, lw=1.0, zorder=2)
    ax.set_ylabel("self-report bias  ($\\eta_{\\rm self}-\\eta_{\\rm ref}$) / $\\eta_{\\rm ref}$")
    ax.yaxis.set_major_formatter(lambda v, p: "%+.0f%%" % v)
    ax.set_ylim(-14, 92)
    style(ax)
    head(ax, "What it does change: honesty", "pooled median (bold) and per target (thin)")

    for ax in axes:
        ax.set_xticks(list(x)); ax.set_xlim(-0.62, 3.55)
        ax.set_xticklabels([{"L12": "(12,3)", "L16": "(16,4)", "L20": "(20,5)",
                             "L24": "(24,6)"}[a] for a in LAD])
        ax.set_xlabel("descent and audit order")
    save(fig, "fig07_s4_2_what_order_buys")


def fig08():
    """L16 vs CERT: identical trajectory, different selection order."""
    fig, axes = plt.subplots(1, 2, figsize=(8.8, 3.9), gridspec_kw=dict(wspace=0.30))
    ax = axes[0]
    same = 0
    for t in TGT:
        for s in S2SEED[t]:
            a, b = u2(t, "L16", s), u2(t, "CERT", s)
            eq = a["mask_sha1"] == b["mask_sha1"]
            same += eq
            ax.scatter([a["eta_ref"]], [b["eta_ref"]], s=36,
                       color=(RAMP[3] if eq else ORANGE), edgecolor=SURF,
                       linewidth=0.9, alpha=0.9, zorder=3)
    lim = [0.10, 0.86]
    ax.plot(lim, lim, color=INK, lw=1.0, zorder=2)
    ax.set_xlim(lim); ax.set_ylim(lim); ax.set_aspect("equal")
    ax.set_xlabel("delivered $\\eta$ — selection at (16,4)")
    ax.set_ylabel("delivered $\\eta$ — selection at (24,6)")
    ax.scatter([], [], s=36, color=RAMP[3], label="identical mask (%d/24)" % same)
    ax.scatter([], [], s=36, color=ORANGE, label="different mask (%d/24)" % (24 - same))
    ax.legend(loc="upper left", handletextpad=0.4, borderpad=0.2)
    style(ax, xgrid=True)
    head(ax, "Changing only the selection order barely moves delivery",
         "95% CI on the paired difference: [−0.010, +0.005]")

    ax = axes[1]
    R = np.array([[u2(t, a, s)["final_audit_eta"] / u2(t, a, s)["best_audit_eta"]
                   for a in ("L16", "CERT")] for t in TGT for s in S2SEED[t]])
    for row in R:
        ax.plot([0, 1], row, color=MUTED, lw=0.7, alpha=0.45, zorder=2)
    for j, a in enumerate(("L16", "CERT")):
        ax.scatter(np.full(R.shape[0], j), R[:, j], s=26, color=ARM_C[a],
                   edgecolor=SURF, linewidth=0.8, zorder=3)
        ax.plot([j - .28, j + .28], [np.median(R[:, j])] * 2, color=INK, lw=2.2,
                zorder=4, solid_capstyle="butt")
        ax.annotate("median %.3f" % np.median(R[:, j]), (j, np.median(R[:, j])),
                    textcoords="offset points", xytext=(0, 10), ha="center",
                    fontsize=7.8, color=INK)
    ax.axhline(1, color=MUTED, lw=0.9, zorder=1)
    ax.set_xticks([0, 1]); ax.set_xticklabels(["judged at (16,4)", "judged at (24,6)"])
    ax.set_xlim(-0.45, 1.45); ax.set_ylim(-0.05, 1.14)
    ax.set_ylabel("value at the final step / best value along the run")
    style(ax)
    head(ax, "The same 24 runs, read by two orders",
         "grey lines join one run; the cheap order does not see the late-run decay")
    save(fig, "fig08_s4_2_l16_vs_cert")


def fig09():
    """Where along the run the delivered design comes from."""
    fig, axes = plt.subplots(1, 2, figsize=(8.8, 3.6), gridspec_kw=dict(wspace=0.26))
    ax = axes[0]
    v = [np.array([u2(t, a, s)["best_audit_step"] for t in TGT for s in S2SEED[t]])
         for a in ARMS]
    _strip(ax, ARMS, v, [ARM_C[a] for a in ARMS], jitter=0.14)
    ax.axhline(219, color=MUTED, lw=0.9, zorder=1)
    ax.text(-0.5, 223, "last step (219)", color=MUTED, fontsize=7.4)
    ax.set_ylim(-10, 245); ax.set_ylabel("step of the delivered (running-best) design")
    style(ax)
    head(ax, "Which step gets delivered", "219 steps, audited every 6 · black bar = median")

    ax = axes[1]
    v = [np.array([u2(t, a, s)["final_audit_eta"] / u2(t, a, s)["best_audit_eta"]
                   for t in TGT for s in S2SEED[t]]) for a in ARMS]
    _strip(ax, ARMS, v, [ARM_C[a] for a in ARMS], jitter=0.14)
    ax.axhline(1, color=MUTED, lw=0.9, zorder=1)
    ax.set_ylim(-0.05, 1.16)
    ax.set_ylabel("value at the final step / best value along the run")
    j = ARMS.index("L20")
    ax.annotate("L20 falls back furthest;\nthe record leaves this unexplained",
                xy=(j, np.median(v[j])), xytext=(j - 1.35, 0.30), fontsize=7.6,
                color=INK2, arrowprops=dict(arrowstyle="->", color=MUTED, lw=0.8))
    style(ax)
    head(ax, "How far each run falls back after its peak",
         "each arm read at its own audit order, so the ranking mixes decay with what the order can see")
    save(fig, "fig09_s4_2_trajectory")


# ========================================================== 7.3 ============
def fig10():
    """Delivered efficiency by design pixel, seeds paired."""
    fig, axes = plt.subplots(1, 4, figsize=(9.4, 4.0), sharey=True,
                             gridspec_kw=dict(wspace=0.09))
    x = np.arange(len(PIX))
    lab = ["%d nm" % p for p in PIX]
    for k, t in enumerate(TGT):
        ax = axes[k]
        M = np.array([[u3(t, p, s)["eta_ref"] for p in PIX] for s in S3SEED[t]])
        for row in M:
            ax.plot(x, row, color=MUTED, lw=0.7, alpha=0.4, zorder=2)
        for j, p in enumerate(PIX):
            ax.scatter(np.full(M.shape[0], j), M[:, j], s=28, color=PIX_C[p],
                       edgecolor=SURF, linewidth=0.8, zorder=3)
            ax.plot([j - .28, j + .28], [np.median(M[:, j])] * 2, color=INK, lw=2.2,
                    zorder=4, solid_capstyle="butt")
        ax.set_xticks(x); ax.set_xticklabels(lab)
        ax.set_xlim(-0.5, len(PIX) - 0.5); style(ax)
        ax.text(0, 1.01, TGTLAB[t], transform=ax.transAxes, color=INK2, fontsize=8.6)
    ax = axes[3]
    pooled = [np.array([u3(t, p, s)["eta_ref"] for t in TGT for s in S3SEED[t]])
              for p in PIX]
    _strip(ax, lab, pooled, [PIX_C[p] for p in PIX], jitter=0.12, s=24)
    ax.set_xlim(-0.5, len(PIX) - 0.5); style(ax)
    ax.text(0, 1.01, "pooled, n = 24", transform=ax.transAxes, color=INK2, fontsize=8.6)
    for j, p in enumerate(PIX):
        sd = np.median([np.std([u3(t, p, s)["eta_ref"] for s in S3SEED[t]], ddof=1)
                        for t in TGT])
        ax.annotate("%.3f" % np.median(pooled[j]), (j, 0.058), ha="center",
                    fontsize=7.4, color=INK2, annotation_clip=False)
        ax.annotate("%.3f" % sd, (j, 0.028), ha="center", fontsize=7.4, color=PIX_C[p],
                    annotation_clip=False)
    ax.annotate("median", (-0.57, 0.058), ha="right", fontsize=7.4, color=MUTED,
                annotation_clip=False)
    ax.annotate("within-target sd", (-0.57, 0.028), ha="right", fontsize=7.4,
                color=MUTED, annotation_clip=False)
    axes[0].set_ylabel("delivered efficiency  $\\eta$ @ (40,10)")
    axes[0].set_ylim(0.0, 0.72)
    fighead(fig, "Finer design pixels widen the spread without shifting the middle",
            "truncation order fixed at (20,5), 219 steps, paired initial fields (worst mismatch 8.1×10$^{-4}$); grey lines join one seed",
            x=0.075, y=1.055)
    save(fig, "fig10_s4_3_delivered_by_pixel")


def fig11():
    """Cost is set by the retained mode count, not by the design grid."""
    fig, axes = plt.subplots(1, 2, figsize=(9.6, 3.7),
                             gridspec_kw=dict(wspace=0.42, width_ratios=[1.15, 1]))
    quant = [("value + gradient, one step", lambda r: r["timing"]["solve"]["median"], "%.3f s"),
             ("forward only at (20,5)", lambda r: r["timing"]["audit_solve"]["median"], "%.3f s"),
             ("whole 219-step run", lambda r: r["timing"]["wall_s"], "%.0f s"),
             ("peak GPU memory", lambda r: r["peak_mem_bytes"] / 2 ** 30, "%.3f GiB")]
    ax = axes[0]
    base_i = PIX.index(10)
    for qi, (name, get, fmt) in enumerate(quant):
        med = [np.median([get(u3(t, p, s)) for t in TGT for s in S3SEED[t]]) for p in PIX]
        for j, p in enumerate(PIX):
            yj = qi + (1 - j) * 0.17
            ax.scatter([med[j] / med[base_i]], [yj], s=44, color=PIX_C[p],
                       edgecolor=SURF, linewidth=0.9, zorder=4)
            if qi == len(quant) - 1:      # direct labels on the top row only
                ax.annotate("%d nm  (%d×%d)" % (p, *u3("1-0", p, S3SEED["1-0"][0])["grid"]),
                            (med[j] / med[base_i], yj), textcoords="offset points",
                            xytext=(9, 0), va="center", fontsize=7.4, color=PIX_C[p])
        ax.annotate(fmt % med[base_i], (0.9805, qi), fontsize=7.5, color=INK2,
                    va="center")
    ax.axvspan(0.99, 1.01, color=RAMP[0], alpha=0.20, lw=0, zorder=1)
    ax.axvline(1, color=MUTED, lw=0.9, zorder=2)
    ax.text(1.0, -0.80, "±1%", color=RAMP[5], fontsize=7.4, ha="center")
    ax.set_yticks(range(len(quant)))
    ax.set_yticklabels([q[0] for q in quant])
    ax.tick_params(axis="y", colors=INK2)
    ax.set_ylim(-0.85, len(quant) + 0.15); ax.set_xlim(0.9755, 1.052)
    ax.set_xlabel("cost relative to the 10 nm arm")
    ax.xaxis.set_major_formatter(lambda v, p: "%.2f×" % v)
    style(ax, xgrid=True, ygrid=False)
    head(ax, "16× more design freedom, the same cost",
         "median of 24 runs per pixel; the three times agree to 0.9%, memory to 1.5%")

    ax = axes[1]
    comp = [("filtered", "filter"), ("projected", "tanh projection"),
            ("hard_binary", "hard threshold"), ("adam_step", "Adam update"),
            ("map_value_grad", "design map, fwd + bwd")]
    y = np.arange(len(comp))
    for j, p in enumerate([20, 5]):
        rows = [u3(t, p, s) for t in TGT for s in S3SEED[t] if "probe" in u3(t, p, s)]
        vals = [np.median([r["probe"][c]["median"] for r in rows]) * 1000 for c, _ in comp]
        yy = y + (0.5 - j) * 0.22
        ax.barh(yy, vals, height=0.36, color=PIX_C[p], zorder=3)
        ax.annotate("%d nm design pixel" % p, (vals[-1], yy[-1]),
                    textcoords="offset points", xytext=(7, 0), va="center",
                    fontsize=7.4, color=PIX_C[p])
    solve_ms = np.median([u3(t, 5, s)["timing"]["solve"]["median"]
                          for t in TGT for s in S3SEED[t]]) * 1000
    ax.axvline(solve_ms, color=RED, lw=1.2, ls=(0, (4, 3)), zorder=4)
    ax.text(solve_ms * 0.78, len(comp) - 0.75, "one solve\n%.0f ms" % solve_ms,
            color=RED, fontsize=7.5, ha="right", va="top")
    ax.set_xscale("log"); ax.set_xlim(0.1, 2200)
    ax.set_yticks(y); ax.set_yticklabels([c[1] for c in comp])
    ax.tick_params(axis="y", colors=INK2)
    ax.set_ylim(-0.6, len(comp) - 0.25)
    ax.set_xlabel("milliseconds per call (median)")
    style(ax, xgrid=True, ygrid=False)
    head(ax, "Where the extra pixels do cost something",
         "the design map — three orders of magnitude below one solve")
    save(fig, "fig11_s4_3_cost")


def fig12():
    """Coarsen a delivered mask, then read it at the reference order again."""
    trips = [(5, "10", "5 nm design, coarsened to 10 nm"),
             (5, "20", "5 nm design, coarsened to 20 nm"),
             (10, "20", "10 nm design, coarsened to 20 nm")]
    fig, axes = plt.subplots(3, 1, figsize=(7.4, 6.4), sharex=True,
                             gridspec_kw=dict(hspace=0.42))
    for ax, (p, to, lab) in zip(axes, trips):
        keys = ["all"] + TGT
        for row, t in enumerate(keys):
            ts = TGT if t == "all" else [t]
            d = np.array([u3(tt, p, s)["roundtrip"][to]["delta_eta"]
                          for tt in ts for s in S3SEED[tt]])
            lo, hi = boot_med_ci(d)
            m = np.median(d)
            big = t == "all"
            ax.scatter(d, np.full(d.size, row) + RNG.uniform(-.10, .10, d.size), s=13,
                       color=PIX_C[p], alpha=0.28, edgecolor="none", zorder=2)
            ax.plot([lo, hi], [row, row], color=PIX_C[p], lw=2.6 if big else 1.5, zorder=3)
            ax.scatter([m], [row], s=46 if big else 26, color=PIX_C[p], edgecolor=SURF,
                       linewidth=1.0, zorder=4)
            npos = int((d > 0).sum())
            ax.annotate("%+.3f    %d↑ / %d↓" % (m, npos, d.size - npos), (0.208, row),
                        fontsize=7.3, color=INK2 if big else MUTED, va="center")
        ax.axvline(0, color=INK, lw=1.0, zorder=1)
        ax.set_yticks(range(4))
        ax.set_yticklabels(["pooled, n = 24"] + ["    " + TGTLAB[t] for t in TGT])
        ax.tick_params(axis="y", colors=INK2)
        ax.invert_yaxis(); ax.set_ylim(3.7, -0.7)
        ax.set_xlim(-0.17, 0.29)
        style(ax, xgrid=True, ygrid=False)
        ax.text(0, 1.06, lab, transform=ax.transAxes, color=PIX_C[p], fontsize=8.8,
                fontweight="bold")
    axes[0].annotate("median    sign split", (0.208, -0.72), fontsize=7.3, color=MUTED,
                     va="center", annotation_clip=False)
    axes[-1].set_xlabel("$\\Delta\\eta$ @ (40,10) after the round trip")
    fighead(fig, "Coarsening a delivered mask moves the reference reading — and the sign follows the source pixel",
            "dot = median, line = bootstrap 95% CI of the median, faint dots = the 8 or 24 designs; the round trip changes only 1.4–3.0% of the 5 nm pixels",
            x=0.10, y=1.045)
    save(fig, "fig12_s4_3_roundtrip")


def fig13():
    """Interface length tracks the self-report bias."""
    fig, axes = plt.subplots(1, 2, figsize=(8.8, 3.8), gridspec_kw=dict(wspace=0.30))
    L = np.array([u3(t, p, s)["geometry"]["interface_len_nm"] / 1000
                  for p in PIX for t in TGT for s in S3SEED[t]])
    B = np.array([u3(t, p, s)["self_bias_rel"] * 100
                  for p in PIX for t in TGT for s in S3SEED[t]])
    E = np.array([u3(t, p, s)["eta_ref"] for p in PIX for t in TGT for s in S3SEED[t]])
    C = [PIX_C[p] for p in PIX for t in TGT for s in S3SEED[t]]
    for ax, yv, ylab in ((axes[0], B, "self-report bias  ($\\eta_{\\rm self}-\\eta_{\\rm ref}$)/$\\eta_{\\rm ref}$"),
                         (axes[1], E, "delivered $\\eta$ @ (40,10)")):
        ax.scatter(L, yv, s=30, c=C, edgecolor=SURF, linewidth=0.7, zorder=3)
        ax.set_xlabel("delivered interface length (µm)")
        ax.set_ylabel(ylab)
        ax.set_xlim(2.5, 18.5)
        style(ax, xgrid=True)
    axes[0].axhline(0, color=INK, lw=1.0, zorder=2)
    axes[0].yaxis.set_major_formatter(lambda v, p: "%+.0f%%" % v)
    axes[0].set_ylim(-25, 260)
    axes[0].text(3.0, 235, "Spearman %.2f" % stats.spearmanr(L, B).statistic,
                 color=INK, fontsize=9)
    axes[1].set_ylim(0.05, 0.72)
    axes[1].text(3.0, 0.665, "Spearman %.2f" % stats.spearmanr(L, E).statistic,
                 color=INK, fontsize=9)
    h = [Line2D([], [], marker="o", ls="", color=PIX_C[p], ms=6, label="%d nm" % p)
         for p in PIX]
    axes[1].legend(handles=h, title="design pixel", loc="lower left",
                   handletextpad=0.3, borderpad=0.3)
    head(axes[0], "More boundary, more over-reporting",
         "n = 72 delivered designs (3 pixels × 3 targets × 8 seeds); association only, no mechanism claimed")
    head(axes[1], "…and lower delivered efficiency", " ")
    save(fig, "fig13_s4_3_interface_vs_bias")


def fig14():
    """What survives the 60 nm filter, and what the hard threshold puts back."""
    fig, ax = plt.subplots(figsize=(6.8, 4.0))
    x = np.arange(len(PIX))
    fl = np.array([np.median([u3(t, p, s)["spectrum"]["filtered_latent_ref"]["frac_beyond_nyq20"]
                              for t in TGT for s in S3SEED[t]]) for p in PIX])
    db = np.array([np.median([u3(t, p, s)["spectrum"]["delivered_binary_ref"]["frac_beyond_nyq20"]
                              for t in TGT for s in S3SEED[t]]) for p in PIX])
    H = D3["1-0|5|20-5|7101"]["spectrum"]["filter_transfer_ref"]["max_transfer_beyond_nyq20"]
    for xi, a, b in zip(x, fl, db):
        ax.plot([xi, xi], [a, b], color=GRID, lw=2.2, zorder=2, solid_capstyle="round")
    ax.scatter(x, fl, s=62, color=RAMP[1], edgecolor=SURF, linewidth=1.2, zorder=4,
               label="continuous field, after the 60 nm filter")
    ax.scatter(x, db, s=62, color=RAMP[8], edgecolor=SURF, linewidth=1.2, zorder=4,
               label="delivered binary mask, after the hard threshold")
    ax.axhline(H, color=RED, lw=1.2, ls=(0, (4, 3)), zorder=3)
    ax.text(2.42, H * 3.5, "ceiling imposed by the filter itself,  $|H|^2$ = 1.2×10$^{-20}$",
            color=RED, fontsize=7.6, ha="right")
    for xi, v in zip(x, db):
        ax.annotate("%.2f%%" % (v * 100), (xi, v), textcoords="offset points",
                    xytext=(0, 11), ha="center", fontsize=8, color=INK)
    ax.text(1.0, fl.min() / 90, "all three at 10$^{-27}$ — below the float64 FFT noise floor",
            fontsize=7.8, color=INK2, ha="center", va="center")
    ax.set_yscale("log"); ax.set_ylim(1e-30, 1e3)
    ax.set_yticks([1e-27, 1e-21, 1e-15, 1e-9, 1e-3])
    ax.set_xticks(x); ax.set_xticklabels(["%d nm design pixel" % p for p in PIX])
    ax.set_xlim(-0.45, 2.55)
    ax.set_ylabel("energy fraction beyond the 20 nm Nyquist limit")
    ax.legend(loc="center left", handletextpad=0.4, borderpad=0.3)
    style(ax)
    head(ax, "The filter removes every sub-20 nm feature; the hard threshold puts steps back",
         "measured on the common 5 nm evaluation grid (140×480); median of 24 delivered designs per pixel")
    save(fig, "fig14_s4_3_spectrum")


def fig15():
    """What the fabrication filter's radius decides (theory, no solves)."""
    ny, nx, Lx, Ly = 140, 480, 2400.0, 700.0
    dy, dx = Ly / ny, Lx / nx
    yy, xx = np.meshgrid((np.arange(ny) - (ny - 1) / 2) * dy,
                         (np.arange(nx) - (nx - 1) / 2) * dx, indexing="ij")

    def transfer(R):                       # exactly periodic_gaussian_filter's kernel
        k = np.exp(-(xx ** 2 + yy ** 2) / R ** 2)
        k /= k.sum()
        return np.abs(np.fft.fft2(np.fft.ifftshift(k)))[0, :]      # along x, n = 0

    fig, ax = plt.subplots(figsize=(7.4, 4.6))
    m = np.arange(0, 66)
    for mo, lab in ((12, "(12,3)"), (24, "(24,6)"), (40, "(40,10)\nreference order")):
        ax.axvline(mo, color=GRID, lw=1.0, zorder=1)
        ax.annotate(lab, (mo, 2.5e-11), ha="center", va="bottom", fontsize=7.4,
                    color=INK2 if mo == 40 else MUTED)
    ax.axvline(60, color=RED, lw=1.1, ls=(0, (4, 3)), zorder=2)
    ax.annotate("Nyquist of the\n20 nm design grid", (61.2, 1.5e-2), ha="left",
                va="center", fontsize=7.4, color=RED)
    for R, c, lx, ly in ((60.0, RAMP[8], 33, 4e-4), (40.0, RAMP[4], 48, 2.5e-2),
                         (20.0, RAMP[0], 40, 1.6)):
        H = transfer(R)
        ax.plot(m, H[m], color=c, lw=2.0, zorder=4)
        ax.text(lx, ly, "%d nm filter" % R, color=c, fontsize=8.6, fontweight="bold",
                ha="center", va="center")
        ax.scatter([40], [H[40]], s=42, color=c, edgecolor=SURF, linewidth=1.1, zorder=6)
        ax.annotate("%.0e" % H[40] if H[40] < 0.01 else "%.2f" % H[40],
                    (40, H[40]), textcoords="offset points", xytext=(-8, -9),
                    fontsize=7.8, color=c, va="center", ha="right")
    ax.set_yscale("log"); ax.set_ylim(1e-11, 6)
    ax.set_xlim(0, 70)
    ax.set_xlabel("Fourier order $m$ along the 2400 nm period   "
                  "(half-period $=$ 1200 nm / $m$)")
    ax.set_ylabel("filter transmission  |H|")
    style(ax, xgrid=False)
    ax.axhline(1e-4, color=MUTED, lw=0.8, zorder=1)
    ax.text(0.6, 1.5e-4, "10$^{-4}$: past this the filter has erased the feature",
            fontsize=7.4, color=MUTED)
    head(ax, "The filter radius, not the design pixel, sets how much structure can exist",
         "kernel exp($-r^2/R^2$), exactly as used in the design map; dots give the transmission at the reference order")
    save(fig, "fig15_filter_transfer")


for f in (fig01, fig02, fig03, fig04, fig05, fig06, fig07, fig08, fig09,
          fig10, fig11, fig12, fig13, fig14, fig15):
    print(f.__name__, "-", (f.__doc__ or "").strip().splitlines()[0])
    f()
print("done")
