"""S4 shared wiring: truncation order and design-pixel experiments (CPC section 4).

This module is descriptive infrastructure only.  It produces numbers and writes
them to disk; it makes no claim about what the numbers mean.  Every qualitative
statement belongs in ``S4_实验记录.md``, written by a later session from the
JSON this module's consumers emit.

What is frozen here (do not edit without re-running everything):
  physics  660 nm, lattice (2400,700) nm, 800 nm patterned film
           (air background / n=3.2 feature), semi-infinite n=1.46 substrate on
           the incidence side and semi-infinite air on the exit side,
           x-polarized normal incidence.
  design   latent -> y-mirror symmetrization -> periodic Gaussian filter
           (60 nm radius) -> tanh(beta) projection.  Delivered mask is the
           beta-independent hard 0.5 threshold of the FILTERED field.
  protocol Adam ascent (0.9/0.999/1e-8), cosine lr 0.02 -> 0, beta 1 -> 64
           exponential, 219 steps, hard-mask audit every 6 steps on the audit
           level, delivered = audit-best.
  numerics GPU / complex64 everywhere (D-011), VECTORIZED_CONV +
           FAST_DIAGNOSTICS + MEMORY_EFFICIENT on, CHECKPOINT_SMATRIX off,
           torch.set_num_threads(3).

The two independent variables of the S4 round are (a) the truncation order used
for DESCENT versus the order used for the AUDIT -- passed separately to
``run_descent`` -- and (b) the design pixel (20 / 10 / 5 nm), selected through
``PIX``.

Grid / 4M+1 constraint.  The convolution matrices reach difference indices
+-2Mx, +-2My, so a level (Mx,My) needs ``nx >= 4*Mx+1`` and ``ny >= 4*My+1``.
  20 nm -> (35,120)  native ceiling (29,8)
  10 nm -> (70,240)  native ceiling (59,17)
   5 nm -> (140,480) native ceiling (119,34)
(40,10) is ILLEGAL on the 20 nm native grid (needs nx>=161, has 120).  The way
to evaluate a coarse mask at (40,10) is ``eta_ref``/``to_ref_grid``: block
replication of a BINARY mask is pointwise exact -- the same physical structure,
only the DFT aliasing terms change.  ``check_level`` refuses illegal pairs
loudly rather than letting the solver produce a silently wrong number.
"""
import argparse
import json
import math
import os
import sys
import time
from typing import Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
import torch

# --------------------------------------------------------------- switches
# Environment first (so anything imported below that reads os.environ at import
# time sees the intended state), module attributes second (authoritative: they
# also override a module that was already imported by someone else).
os.environ.setdefault("TFMM_VECTORIZED_CONV", "1")
os.environ.setdefault("TFMM_FAST_DIAGNOSTICS", "1")
os.environ.setdefault("TFMM_MEMORY_EFFICIENT", "1")
os.environ.setdefault("TFMM_CHECKPOINT_SMATRIX", "0")

THREADS = int(os.environ.get("P0_THREADS", "3"))
torch.set_num_threads(THREADS)

_HERE = os.path.dirname(os.path.abspath(__file__))
_E16_SCRIPTS = os.path.abspath(os.path.join(
    _HERE, "..", "..", "E16_inherited_baseline", "scripts"))
if _E16_SCRIPTS not in sys.path:
    sys.path.insert(0, _E16_SCRIPTS)

import e10_common as C  # noqa: E402  (adds ../../../src to sys.path itself)
import trustworthy_fmm.fourier.convolution as _conv  # noqa: E402
import trustworthy_fmm.solvers.vector_2d as _v2d  # noqa: E402
from trustworthy_fmm.fabrication.process import (  # noqa: E402
    periodic_gaussian_filter,
)

_conv.VECTORIZED_CONV = True
_v2d.FAST_DIAGNOSTICS = True
_v2d.MEMORY_EFFICIENT = True          # exact algebraic rearrangement (A2)
_v2d.CHECKPOINT_SMATRIX = False       # no level in this round needs it

# ------------------------------------------------------------------- paths
ROOT = os.path.abspath(os.path.join(_HERE, ".."))
DATA = os.path.join(ROOT, "data")
os.makedirs(DATA, exist_ok=True)


def _gpu_name() -> str:
    try:
        if torch.cuda.is_available():
            return torch.cuda.get_device_name(0)
    except Exception:                                    # pragma: no cover
        pass
    return "none"


ENV: Dict[str, object] = {
    "torch": torch.__version__,
    "torch_cuda": torch.version.cuda,
    "gpu": _gpu_name(),
    "cuda_available": bool(torch.cuda.is_available()),
    "threads": THREADS,
    "VECTORIZED_CONV": bool(_conv.VECTORIZED_CONV),
    "FAST_DIAGNOSTICS": bool(_v2d.FAST_DIAGNOSTICS),
    "MEMORY_EFFICIENT": bool(_v2d.MEMORY_EFFICIENT),
    "CHECKPOINT_SMATRIX": bool(_v2d.CHECKPOINT_SMATRIX),
    "python": sys.version.split()[0],
    "numpy": np.__version__,
}


def meta(script: str, params: Optional[Dict] = None) -> Dict[str, object]:
    """Metadata block every S4 JSON must carry.  ``params`` is the parsed CLI."""
    return {
        "script": script,
        "params": dict(params or {}),
        "env": dict(ENV),
        "argv": list(sys.argv),
        "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "protocol": {
            "n_steps": N_STEPS, "audit_every": AUDIT_EVERY,
            "lr0": C.DEFAULT.adam_lr0, "beta": [C.DEFAULT.beta_ladder[0],
                                                C.DEFAULT.beta_ladder[-1]],
            "filter_nm": C.DEFAULT.filter_nm, "threshold": C.DEFAULT.threshold,
            "ref_level": list(REF_LEVEL), "ref_pix_nm": REF_PIX,
        },
    }


# ------------------------------------------------------------------ config
PIX: Dict[int, "C.ProblemConfig"] = {
    20: C.DEFAULT.variant(ny=35,  nx=120, dtype=torch.complex64, device="cuda"),
    10: C.DEFAULT.variant(ny=70,  nx=240, dtype=torch.complex64, device="cuda"),
    5:  C.DEFAULT.variant(ny=140, nx=480, dtype=torch.complex64, device="cuda"),
}
PIXELS: List[int] = [20, 10, 5]
REF_LEVEL: Tuple[int, int] = (40, 10)
REF_PIX: int = 5                       # common evaluation grid = (140,480)
REF_CFG = PIX[REF_PIX]
REF_SHAPE: Tuple[int, int] = REF_CFG.shape           # (140, 480)

TARGETS: List[Tuple[int, int]] = [(1, 0), (2, 0), (3, 0)]
SEED_BASE: Dict[int, int] = {1: 7101, 2: 7201, 3: 7301}
SEED_BLOCK = 40                        # 7101-7140 / 7201-7240 / 7301-7340

N_STEPS = 219
AUDIT_EVERY = 6

# --dry-run scale: same code path, negligible cost.
DRY = {"n_steps": 7, "audit_every": 3, "n_seeds": 1}


def seeds_for(target: Sequence[int], n: int) -> List[int]:
    """First ``n`` seeds of ``target``'s reserved block.

    Blocks are 7101-7140 / 7201-7240 / 7301-7340.  7000-7099 is EXCLUDED: E22's
    noise stream used 7000+100r+k there, and reusing it would silently couple
    this round to that one.
    """
    m = int(target[0]) if isinstance(target, (tuple, list)) else int(target)
    if m not in SEED_BASE:
        raise ValueError("no seed block for target order %r" % (m,))
    if n < 1 or n > SEED_BLOCK:
        raise ValueError("n must be in 1..%d, got %r" % (SEED_BLOCK, n))
    base = SEED_BASE[m]
    seeds = list(range(base, base + n))
    for s in seeds:
        if 7000 <= s <= 7099:
            raise AssertionError("seed %d collides with the E22 7000+ block" % s)
    return seeds


def pix_of(cfg) -> int:
    """Design pixel (nm) of a config, by shape lookup.  Raises if unknown."""
    for px, c in PIX.items():
        if cfg.shape == c.shape:
            return px
    raise ValueError("config shape %r is not one of the S4 grids %r"
                     % (cfg.shape, {p: c.shape for p, c in PIX.items()}))


def check_level(level: Sequence[int], cfg, what: str = "level") -> Tuple[int, int]:
    """Assert (Mx,My) is representable on cfg's grid (nx>=4Mx+1, ny>=4My+1)."""
    lv = (int(level[0]), int(level[1]))
    if not cfg.supports(lv):
        ny_min, nx_min = cfg.min_grid_for(lv)
        raise ValueError(
            "%s %r is illegal on grid (ny,nx)=%r: needs (ny,nx)>=(%d,%d). "
            "Block-replicate the binary to the %d nm reference grid first "
            "(to_ref_grid / eta_ref)."
            % (what, lv, cfg.shape, ny_min, nx_min, REF_PIX))
    return lv


# --------------------------------------------------------- paired initials
def _area_downsample(field: torch.Tensor, ny: int, nx: int) -> torch.Tensor:
    """Exact block mean from ``field``'s grid down to (ny,nx)."""
    fy, fx = field.shape
    if fy % ny or fx % nx:
        raise AssertionError("grid %r does not divide evenly into (%d,%d)"
                             % ((fy, fx), ny, nx))
    ky, kx = fy // ny, fx // nx
    return field.reshape(ny, ky, nx, kx).mean(dim=(1, 3))


def paired_initial_latent(seed: int, cfg) -> torch.Tensor:
    """Standard initial latent, PAIRED across the 20/10/5 nm grids.

    DELIBERATE DEVIATION from ``C.initial_latent``.  ``C.initial_latent`` draws
    ``randn`` directly on each config's own grid, so the same seed gives three
    UNRELATED random fields at 20 / 10 / 5 nm and a pixel comparison built on it
    is unpaired -- the seed-to-seed spread would swamp the pixel effect.  Here
    the noise is drawn once on the finest grid (140,480) with a CPU generator
    (device-independent stream), filtered at the physical 60 nm radius, and then
    AREA-AVERAGED down to the target grid.  All three grids therefore carry the
    same physical initial field and the pixel comparison is paired.

    The downsampling is close to lossless: the field is already band-limited by
    the 60 nm filter, whose Gaussian is ~3 pixels wide even at 20 nm, so the
    (140,480) -> (35,120) block mean removes almost no content.  ``rel`` in
    ``init_field_agreement`` measures exactly how much it does remove.

    Everything after the downsample is the frozen protocol, unchanged:
    ``smooth/smooth.std()`` -> ``init_mean + init_scale*smooth`` ->
    ``clamp(init_clamp_lo, init_clamp_hi)`` -> ``symmetrize``.  Note the std
    normalization happens per grid, AFTER the downsample (the protocol's own
    order), so the three fields agree up to a scalar within a fraction of a
    percent of 1 rather than exactly; that factor is reported too.

    Returns a CPU float64 tensor, matching ``C.initial_latent``'s calling
    convention on the CPU side -- the caller moves it to the device.
    """
    g = torch.Generator().manual_seed(int(seed))
    noise = torch.randn(REF_SHAPE, generator=g, dtype=cfg.latent_dtype)
    smooth_fine = periodic_gaussian_filter(noise, cfg.lattice_nm, cfg.filter_nm)
    smooth = _area_downsample(smooth_fine, cfg.ny, cfg.nx)
    smooth = smooth / smooth.std()
    return C.symmetrize((cfg.init_mean + cfg.init_scale * smooth)
                        .clamp(cfg.init_clamp_lo, cfg.init_clamp_hi))


def init_field_agreement(seed: int) -> Dict[str, object]:
    """Self-check: how equal are the paired initials across the three grids?

    Each grid's latent is block-replicated up to (140,480), re-filtered at 60 nm
    on that common grid, and compared to the 5 nm one in relative L2.  Small
    numbers mean the pairing works.  Printed by the smoke test; never gates.
    """
    fine = paired_initial_latent(seed, PIX[REF_PIX])
    fine_f = periodic_gaussian_filter(fine, REF_CFG.lattice_nm, REF_CFG.filter_nm)
    denom = float(torch.linalg.vector_norm(fine_f))
    rel, std_ratio, ptp = {}, {}, {}
    for px in PIXELS:
        lat = paired_initial_latent(seed, PIX[px])
        up = upsample(lat, px // REF_PIX)
        up_f = periodic_gaussian_filter(up, REF_CFG.lattice_nm, REF_CFG.filter_nm)
        rel[px] = float(torch.linalg.vector_norm(up_f - fine_f) / denom)
        std_ratio[px] = float(lat.std() / fine.std())
        ptp[px] = [float(lat.min()), float(lat.max())]
    return {"seed": int(seed), "ref_shape": list(REF_SHAPE),
            "rel_l2_vs_5nm": rel, "std_ratio_vs_5nm": std_ratio,
            "latent_range": ptp}


# ---------------------------------------------------------- solve helpers
def upsample(t: torch.Tensor, k: int) -> torch.Tensor:
    """Block replication by k in both axes (pointwise exact on binaries)."""
    k = int(k)
    if k == 1:
        return t.clone()
    return torch.repeat_interleave(torch.repeat_interleave(t, k, 0), k, 1)


def to_ref_grid(binary: torch.Tensor, pix: int) -> torch.Tensor:
    """Lift a mask on the ``pix`` nm grid to the common (140,480) grid.

    Block replication of a BINARY mask is pointwise exact: identical physical
    structure, only the DFT aliasing terms differ.  Do not call this on a
    grayscale field and expect the same guarantee.
    """
    k = int(pix) // REF_PIX
    if k not in (1, 2, 4):
        raise AssertionError("pix %r gives replication factor %r, expected 1/2/4"
                             % (pix, k))
    out = upsample(binary, k)
    if tuple(out.shape) != tuple(REF_SHAPE):
        raise AssertionError("lifted shape %r != reference %r"
                             % (tuple(out.shape), tuple(REF_SHAPE)))
    return out


def eta(density: torch.Tensor, level: Sequence[int], target: Sequence[int],
        cfg) -> float:
    """Transmitted efficiency of order ``target``.  No gradient, GPU/c64."""
    lv = check_level(level, cfg, "eval level")
    return C.forward_density(density, lv, target, cfg, audit=False)


def eta_grad(rho_latent: torch.Tensor, level: Sequence[int],
             target: Sequence[int], beta: float, cfg):
    """(eta, d eta / d latent) through the frozen design map.  GPU/c64."""
    lv = check_level(level, cfg, "descent level")
    return C.value_grad_latent(rho_latent, lv, target, beta, cfg)


def eta_ref(binary: torch.Tensor, target: Sequence[int], pix: int) -> float:
    """Score a delivered mask on the common reference grid at ``REF_LEVEL``."""
    return eta(to_ref_grid(binary, pix), REF_LEVEL, target, REF_CFG)


# --------------------------------------------------------------- NaN guard
# Observed 2026-09-09, S4-2, target (1,0) seed 7105, descent (20,5), step 49,
# beta = 2.547: the FORWARD value was healthy (eta = 0.7866) while the returned
# gradient was non-finite in ALL 16800 entries.  The signature is the
# unregularised eigendecomposition adjoint: its 1/(lambda_j - lambda_i) factor
# divides by zero when two eigenvalues coincide to within complex64 rounding
# (see the manuscript's Sec. 2.4, Eq. 2.21 -- the "third error source").
# Feeding that gradient to Adam poisons the latent, and the NEXT step's forward
# solve then dies inside torch.linalg.eig.
#
# Policy, applied UNIFORMLY to every arm of every S4 experiment:
#   1. evaluate at beta as scheduled;
#   2. on a non-finite gradient (or a forward that raises), retry at
#      beta*(1 +- jitter) -- an exact degeneracy is a measure-zero coincidence
#      and an arbitrarily small change of the permittivity breaks it;
#   3. if every retry fails, return grad=None; the caller SKIPS the Adam update
#      but still consumes the step, so the step count stays at n_steps.
# Every occurrence is counted and logged, and the counts are reported.
GRAD_JITTERS = (1e-6, -1e-6, 1e-5, -1e-5)


def robust_value_grad(rho_latent: torch.Tensor, level: Sequence[int],
                      target: Sequence[int], beta: float, cfg):
    """``C.value_grad_latent`` guarded against non-finite adjoints.

    Returns ``(value, grad_or_None, event_or_None)``.  ``grad is None`` means
    every attempt failed and the caller must skip the parameter update.
    ``event`` is ``None`` on the clean path, otherwise a dict for the log.
    """
    first_exc = None
    val = None
    try:
        val, grad = C.value_grad_latent(rho_latent, level, target, beta, cfg)
        if bool(torch.isfinite(grad).all()):
            return float(val), grad, None
        del grad
    except RuntimeError as exc:                      # forward already poisoned
        first_exc = str(exc)[:200]

    for j in GRAD_JITTERS:
        b = float(beta) * (1.0 + j)
        try:
            v2, g2 = C.value_grad_latent(rho_latent, level, target, b, cfg)
        except RuntimeError:
            continue
        if bool(torch.isfinite(g2).all()):
            return float(v2), g2, {
                "event": "jitter_recovered", "level": list(level),
                "beta": float(beta), "beta_used": b, "jitter": j,
                "forward_exception": first_exc,
            }
        del g2

    return (float(val) if val is not None else float("nan")), None, {
        "event": "skipped_update", "level": list(level), "beta": float(beta),
        "jitters_tried": list(GRAD_JITTERS), "forward_exception": first_exc,
    }


# ------------------------------------------------------------------ timing
def _sync():
    if torch.cuda.is_available():
        torch.cuda.synchronize()


def _reset_peak():
    if torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats()


def _peak_bytes() -> int:
    if torch.cuda.is_available():
        return int(torch.cuda.max_memory_allocated())
    return 0


# ------------------------------------------------------------ cost anchors
# GPU/c64 seconds per call, measured on this box.  Used ONLY for the progress
# printout and the up-front estimate; never for any reported quantity.
COST_VG: Dict[Tuple[int, int], float] = {
    (8, 2): 0.040, (12, 3): 0.106, (16, 4): 0.312, (20, 5): 0.755,
    (24, 6): 1.78, (28, 7): 3.87, (32, 8): 5.4, (40, 10): 24.4,
}
COST_FWD: Dict[Tuple[int, int], float] = {
    (12, 3): 0.095, (16, 4): 0.273, (20, 5): 0.66, (24, 6): 1.49,
    (28, 7): 3.46, (32, 8): 5.4, (40, 10): 23.0,
}
# (20,5) and (32,8) are N^2.13 interpolations, not measurements.
COST_INTERPOLATED = {(20, 5), (32, 8)}
_COST_EXP = 2.13


def cost_s(level: Sequence[int], kind: str = "vg") -> float:
    """Estimated seconds for one call at ``level`` ("vg" or "fwd").

    Falls back to an N^2.13 scaling off the (16,4) anchor for unlisted levels.
    Grid size shifts these a little (the FFT/convolution part scales with the
    grid, the eigensolve does not); treat every number here as +-30%.
    """
    lv = (int(level[0]), int(level[1]))
    table = COST_VG if kind == "vg" else COST_FWD
    if lv in table:
        return table[lv]
    anchor_lv = (16, 4)
    ratio = (C.n_terms(lv) / C.n_terms(anchor_lv)) ** _COST_EXP
    return table[anchor_lv] * ratio


def estimate_run_s(descent_level, audit_level, n_steps: int = N_STEPS,
                   audit_every: int = AUDIT_EVERY) -> float:
    """Wall-clock estimate for one ``run_descent``."""
    n_aud = len(range(0, n_steps, audit_every)) + 1
    return n_steps * cost_s(descent_level, "vg") + n_aud * cost_s(audit_level, "fwd")


def fmt_s(seconds: float) -> str:
    seconds = max(0.0, float(seconds))
    if seconds < 90:
        return "%.0f s" % seconds
    if seconds < 5400:
        return "%.1f min" % (seconds / 60.0)
    return "%.2f h" % (seconds / 3600.0)


# ------------------------------------------------------------- the descent
def run_descent(target: Sequence[int], seed: int, cfg,
                descent_level: Sequence[int], audit_level: Sequence[int],
                n_steps: int = N_STEPS, audit_every: int = AUDIT_EVERY,
                record_traj: bool = False, audit_on_ref: bool = False,
                progress_every: int = 0, label: str = "") -> Dict[str, object]:
    """One run of the frozen protocol.  Descent and audit orders are separate.

    ``descent_level``  order the gradient ascent is driven at (native grid).
    ``audit_level``    order the hard mask is scored at every ``audit_every``
                       steps.  Native grid unless ``audit_on_ref``.
    ``audit_on_ref``   score the hard mask on the common (140,480) reference
                       grid instead of the native one.  Needed whenever
                       ``audit_level`` exceeds what the native grid can carry
                       (e.g. (40,10) from a 20 nm grid); block replication of a
                       binary is exact, so this is the same structure.
    ``record_traj``    also return per-step wall clock.

    Delivered = the hard mask with the best AUDIT eta seen (running best,
    including step 0 and one audit after the final update).  The returned
    ``best_audit_eta`` is that self-evaluated number, not an independent score.
    """
    if n_steps < 2:
        raise ValueError("n_steps must be >= 2 (progress = step/(n_steps-1))")
    if audit_every < 1:
        raise ValueError("audit_every must be >= 1")
    tgt = (int(target[0]), int(target[1]))
    dlv = check_level(descent_level, cfg, "descent level")
    px = pix_of(cfg)
    audit_cfg = REF_CFG if audit_on_ref else cfg
    alv = check_level(audit_level, audit_cfg, "audit level")

    rho = paired_initial_latent(seed, cfg).to(cfg.device)
    adam = C.Adam(rho.shape, cfg)

    def _audit(rho_now):
        b = C.hard_binary(rho_now, cfg)
        if audit_on_ref:
            return b, eta(to_ref_grid(b.cpu(), px).to(REF_CFG.device),
                          alv, tgt, REF_CFG)
        return b, eta(b, alv, tgt, cfg)

    best_eta, best_bin, best_rho, best_step = -float("inf"), None, None, -1
    traj: List[List[float]] = []
    per_step: List[float] = []
    grad_events: List[dict] = []          # NaN-guard log, see robust_value_grad
    n_audits = 0

    _reset_peak()
    _sync()
    t0 = time.perf_counter()
    for step in range(n_steps):
        progress = step / (n_steps - 1)
        beta = C.beta_at(progress, cfg=cfg)
        lr = C.cosine_lr(progress, cfg)
        s0 = time.perf_counter() if record_traj else 0.0
        _, grad, ev = robust_value_grad(rho, dlv, tgt, beta, cfg)
        if ev is not None:
            ev["step"] = step
            grad_events.append(ev)
        if step % audit_every == 0:
            b, a = _audit(rho)
            n_audits += 1
            traj.append([step, a])
            if a > best_eta:
                best_eta, best_bin, best_rho, best_step = a, b, rho.clone(), step
        if grad is not None:
            rho = adam.step(rho, grad, lr)
        if record_traj:
            _sync()
            per_step.append(time.perf_counter() - s0)
        if progress_every and (step + 1) % progress_every == 0:
            el = time.perf_counter() - t0
            print("    %s step %3d/%d  beta %5.1f  lr %.4f  best %.4f  "
                  "[%s elapsed, ~%s left]"
                  % (label or str(tgt), step + 1, n_steps, beta, lr, best_eta,
                     fmt_s(el), fmt_s(el * (n_steps - step - 1) / (step + 1))),
                  flush=True)
    # final audit, after the last update
    b, a = _audit(rho)
    n_audits += 1
    traj.append([n_steps, a])
    if a > best_eta:
        best_eta, best_bin, best_rho, best_step = a, b, rho.clone(), n_steps
    _sync()
    wall = time.perf_counter() - t0

    return {
        "target": list(tgt), "seed": int(seed), "pixel_nm": px,
        "grid": list(cfg.shape),
        "descent_level": list(dlv), "audit_level": list(alv),
        "audit_on_ref": bool(audit_on_ref),
        "n_steps": int(n_steps), "audit_every": int(audit_every),
        "n_audits": int(n_audits),
        "grad_events": grad_events,
        "n_grad_jitter_recovered": sum(
            1 for e in grad_events if e["event"] == "jitter_recovered"),
        "n_grad_skipped_updates": sum(
            1 for e in grad_events if e["event"] == "skipped_update"),
        "best_audit_eta": float(best_eta), "best_audit_step": int(best_step),
        "final_audit_eta": float(a),
        "audit_traj": traj,
        "wall_s": float(wall),
        "per_step_wall": per_step if record_traj else None,
        "peak_mem_bytes": _peak_bytes(),
        "delivered_binary": best_bin.detach().cpu(),
        "delivered_latent": best_rho.detach().cpu(),
    }


def split_arrays(row: Dict[str, object]) -> Tuple[Dict[str, object],
                                                  torch.Tensor, torch.Tensor]:
    """Peel the tensors off a ``run_descent`` row so the rest is JSON-safe."""
    r = dict(row)
    binary = r.pop("delivered_binary")
    latent = r.pop("delivered_latent")
    return r, binary, latent


def save_arrays(tag: str, binary: torch.Tensor, latent: torch.Tensor) -> Dict[str, str]:
    """np.save both tensors under traceable names; return the relative paths."""
    b_path = os.path.join(DATA, tag + "_binary.npy")
    l_path = os.path.join(DATA, tag + "_latent.npy")
    np.save(b_path, binary.detach().cpu().numpy())
    np.save(l_path, latent.detach().cpu().numpy())
    return {"binary": os.path.basename(b_path), "latent": os.path.basename(l_path)}


# ------------------------------------------------------------- persistence
def _sanitize_nonfinite(obj, path: str = "", found: Optional[List[str]] = None):
    """Replace NaN/Inf floats by None, recording where they were.

    ``json.dump`` writes ``NaN``/``Infinity`` by default, which is not legal
    JSON and silently produces a store that jq / JS / strict parsers reject.
    Refusing outright (``allow_nan=False``) would throw away a long run at
    flush time, so instead the offending values are replaced by ``null`` and
    the paths are reported loudly and recorded in the file itself.
    """
    found = [] if found is None else found
    if isinstance(obj, float):
        if math.isfinite(obj):
            return obj, found
        found.append("%s=%r" % (path or "<root>", obj))
        return None, found
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            out[k], found = _sanitize_nonfinite(v, "%s.%s" % (path, k), found)
        return out, found
    if isinstance(obj, (list, tuple)):
        out = []
        for i, v in enumerate(obj):
            w, found = _sanitize_nonfinite(v, "%s[%d]" % (path, i), found)
            out.append(w)
        return out, found
    return obj, found


REPLACE_RETRIES = 12          # ~7.8 s of backoff; see save_json


def save_json(path: str, obj) -> str:
    """Atomic write: full JSON to ``.tmp``, then replace.  Kill-safe.

    ``allow_nan=False``: a store with NaN/Inf in it is not valid JSON.  Rather
    than lose the run, a non-finite value is replaced by ``null`` on a second
    pass and the substitution is reported (console + ``meta.nonfinite_nulled``).

    WINDOWS.  ``os.replace`` onto a path that any other process has open without
    ``FILE_SHARE_DELETE`` raises ``PermissionError`` -- and Python's ``open()``
    does not pass that share mode.  A store is flushed after every unit, so over
    a multi-hour run the odds that someone (an editor, ``Get-Content``, a virus
    scanner, another session reading progress) holds the file for a moment are
    not small, and an unhandled failure there would end the run and leave a
    stale ``.tmp`` behind.  The replace is therefore retried with a linear
    backoff, and the ``.tmp`` is cleaned up if every attempt fails.
    """
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    tmp = path + ".tmp"
    try:
        try:
            payload = json.dumps(obj, indent=1, ensure_ascii=False,
                                 allow_nan=False, default=_json_default)
        except ValueError:
            clean, found = _sanitize_nonfinite(obj)
            if isinstance(clean, dict):
                clean.setdefault("meta", {})["nonfinite_nulled"] = found[:200]
            print("WARNING: %d non-finite value(s) in this store were written "
                  "as null (JSON has no NaN/Inf).  First few: %r"
                  % (len(found), found[:5]), flush=True)
            payload = json.dumps(clean, indent=1, ensure_ascii=False,
                                 allow_nan=False, default=_json_default)
        with open(tmp, "w", encoding="utf-8") as f:
            f.write(payload)
            f.flush()
            os.fsync(f.fileno())
    except BaseException:
        # A half-written .tmp must not survive: the next --resume would find a
        # stale file next to a good store and invite confusion.
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise
    last = None
    for attempt in range(REPLACE_RETRIES):
        try:
            os.replace(tmp, path)
            if attempt:
                print("note: %s was locked by another process; the atomic "
                      "replace succeeded on attempt %d"
                      % (os.path.basename(path), attempt + 1), flush=True)
            return path
        except PermissionError as exc:          # target held open elsewhere
            last = exc
            time.sleep(0.1 * (attempt + 1))
    try:
        os.remove(tmp)
    except OSError:
        pass
    raise last


def _json_default(o):
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, torch.Tensor):
        raise TypeError("refusing to JSON-encode a tensor; np.save it instead "
                        "(see save_arrays / split_arrays)")
    if isinstance(o, tuple):
        return list(o)
    raise TypeError("not JSON serializable: %r" % (type(o),))


def load_json(path: str, default=None):
    """Read a JSON store, tolerating absence and a truncated file."""
    if not os.path.exists(path):
        return default
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (ValueError, OSError) as exc:
        print("WARNING: %s unreadable (%s); starting a fresh store"
              % (path, exc), flush=True)
        return default


def new_store(script: str, params: Optional[Dict] = None) -> Dict[str, object]:
    return {"meta": meta(script, params), "units": {}}


def unit_key(*parts) -> str:
    """Stable key for one work unit, e.g. unit_key((1,0), 20, (16,4), 7101)."""
    out = []
    for p in parts:
        if isinstance(p, (tuple, list)):
            out.append("-".join(str(int(v)) for v in p))
        else:
            out.append(str(p))
    return "|".join(out)


def unit_done(store: Dict, key: str) -> bool:
    return bool(store) and key in store.get("units", {})


def record_unit(store: Dict, key: str, row, path: str) -> Dict:
    """Store one finished unit and flush the whole file (incremental, resumable)."""
    store.setdefault("units", {})[key] = row
    store.setdefault("meta", {})["updated_utc"] = time.strftime(
        "%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    save_json(path, store)
    return store


def resume_store(path: str, script: str, params: Optional[Dict],
                 resume: bool) -> Dict:
    """Load an existing store when --resume, else start a fresh one."""
    if resume:
        store = load_json(path, None)
        if store and "units" in store:
            store.setdefault("meta", {}).setdefault("resumes", []).append(
                meta(script, params))
            print("resuming %s: %d units already done"
                  % (os.path.basename(path), len(store["units"])), flush=True)
            return store
        print("resume requested but no usable store at %s; starting fresh"
              % path, flush=True)
    return new_store(script, params)


# ------------------------------------------------------------------- CLI
def add_common_args(parser: argparse.ArgumentParser,
                    default_seeds: int = 6,
                    dry_help: Optional[str] = None) -> argparse.ArgumentParser:
    """Flags every S4 script shares.

    ``dry_help`` lets a caller whose --dry-run schedule differs from ``DRY``
    state its own, instead of poking at ``parser._actions`` afterwards.
    """
    parser.add_argument("--n-seeds", type=int, default=default_seeds,
                        help="seeds per target, from that target's block")
    parser.add_argument("--targets", type=str, default="1,2,3",
                        help="comma-separated diffraction orders m, e.g. 1,3")
    parser.add_argument("--dry-run", action="store_true",
                        help=dry_help or
                             "tiny self-check: %d steps, audit every %d, "
                             "1 seed" % (DRY["n_steps"], DRY["audit_every"]))
    parser.add_argument("--resume", action="store_true",
                        help="skip units already present in the output JSON")
    parser.add_argument("--out", type=str, default=None,
                        help="output JSON path (default: ../data/<script>.json)")
    parser.add_argument("--progress-every", type=int, default=0,
                        help="print inside the descent every N steps (0=off)")
    return parser


def parse_targets(spec: str) -> List[Tuple[int, int]]:
    out = []
    for tok in str(spec).split(","):
        tok = tok.strip()
        if not tok:
            continue
        m = int(tok)
        if (m, 0) not in TARGETS:
            raise ValueError("target order %r is not one of %r" % (m, TARGETS))
        out.append((m, 0))
    if not out:
        raise ValueError("--targets selected nothing")
    return out


def out_path(args, script: str) -> str:
    """Where this run's JSON goes.  A --dry-run ALWAYS gets a ``_dry`` stem.

    Without that rule ``--dry-run --out <real store>`` would write 6-step rows
    into a production store, which no consumer can tell apart from real ones.
    """
    dry = bool(getattr(args, "dry_run", False))
    if getattr(args, "out", None):
        p = os.path.abspath(args.out)
        if dry:
            head, tail = os.path.split(p)
            stem, ext = os.path.splitext(tail)
            if not stem.endswith("_dry"):
                p = os.path.join(head, stem + "_dry" + (ext or ".json"))
                print("note: --dry-run redirected --out to %s (a dry store must "
                      "never share a file with a real one)" % p, flush=True)
        return p
    stem = os.path.splitext(os.path.basename(script))[0]
    if dry:
        stem += "_dry"
    return os.path.join(DATA, stem + ".json")


def dry_apply(args):
    """Shrink the schedule in place for --dry-run; returns (n_steps, audit_every)."""
    if getattr(args, "dry_run", False):
        args.n_seeds = min(args.n_seeds, DRY["n_seeds"])
        return DRY["n_steps"], DRY["audit_every"]
    return N_STEPS, AUDIT_EVERY


def banner(script: str, args, est_s: Optional[float] = None) -> None:
    print("=" * 72, flush=True)
    print("%s | torch %s | %s | threads %d | c64/GPU"
          % (script, ENV["torch"], ENV["gpu"], THREADS), flush=True)
    print("  switches: VEC_CONV=%s FAST_DIAG=%s MEM_EFF=%s CKPT=%s"
          % (ENV["VECTORIZED_CONV"], ENV["FAST_DIAGNOSTICS"],
             ENV["MEMORY_EFFICIENT"], ENV["CHECKPOINT_SMATRIX"]), flush=True)
    print("  args: %s" % (vars(args) if hasattr(args, "__dict__") else args,),
          flush=True)
    if est_s is not None:
        print("  estimated total: %s (cost anchors, +-30%%)" % fmt_s(est_s),
              flush=True)
    print("=" * 72, flush=True)


# ------------------------------------------------------------------- smoke
def _smoke(with_ref: bool = False) -> None:
    print("ENV: %s" % json.dumps(ENV, indent=1), flush=True)
    for m in (1, 2, 3):
        print("seeds m=%d: %s ..." % (m, seeds_for((m, 0), 4)), flush=True)
    ag = init_field_agreement(SEED_BASE[1])
    print("paired-init agreement (seed %d):" % ag["seed"], flush=True)
    for px in PIXELS:
        print("  %2d nm  rel_L2 vs 5 nm = %.3e   std ratio = %.6f   "
              "range [%.4f, %.4f]"
              % (px, ag["rel_l2_vs_5nm"][px], ag["std_ratio_vs_5nm"][px],
                 ag["latent_range"][px][0], ag["latent_range"][px][1]),
              flush=True)
    # legality guard must fire on the documented illegal pair
    try:
        check_level((40, 10), PIX[20])
        print("PROBLEM: (40,10) on the 20 nm grid did NOT raise", flush=True)
    except ValueError:
        print("check_level: (40,10) on 20 nm grid correctly refused", flush=True)

    cfg = PIX[20]
    r = run_descent((1, 0), SEED_BASE[1], cfg, (8, 2), (12, 3),
                    n_steps=DRY["n_steps"], audit_every=DRY["audit_every"],
                    record_traj=True)
    row, binary, latent = split_arrays(r)
    print("dry descent: best audit %.4f @step %d, %d audits, %.1f s, "
          "peak %.2f GiB" % (row["best_audit_eta"], row["best_audit_step"],
                             row["n_audits"], row["wall_s"],
                             row["peak_mem_bytes"] / 2 ** 30), flush=True)
    print("binary: shape %r, values %r, fill %.3f"
          % (tuple(binary.shape), sorted(set(binary.flatten().tolist()))[:3],
             float(binary.mean())), flush=True)
    lifted = to_ref_grid(binary, 20)
    print("to_ref_grid: %r -> %r, fill preserved %.6f -> %.6f"
          % (tuple(binary.shape), tuple(lifted.shape), float(binary.mean()),
             float(lifted.mean())), flush=True)
    print("eta(28,7) native = %.6f"
          % eta(binary.to(cfg.device), (28, 7), (1, 0), cfg), flush=True)
    if with_ref:
        t0 = time.perf_counter()
        print("eta_ref(40,10) = %.6f  [%s]"
              % (eta_ref(binary, (1, 0), 20), fmt_s(time.perf_counter() - t0)),
              flush=True)
    p = save_json(os.path.join(DATA, "s4_common_smoke.json"),
                  {"meta": meta("s4_common.py", {"smoke": True}),
                   "init_agreement": ag, "dry_descent": row})
    print("wrote %s" % p, flush=True)


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="s4_common smoke test")
    ap.add_argument("--with-ref", action="store_true",
                    help="also run one (40,10) reference solve (~25 s)")
    _smoke(ap.parse_args().with_ref)
