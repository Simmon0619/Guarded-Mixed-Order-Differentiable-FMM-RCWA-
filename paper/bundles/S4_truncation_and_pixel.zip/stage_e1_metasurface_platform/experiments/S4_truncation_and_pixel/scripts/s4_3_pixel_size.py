"""S4-3: what does the design pixel change?

Truncation order is FIXED at (20,5) for both descent and self-audit, so the
design pixel is the only variable.  Two arms are run here -- 20 nm (35,120)
and 5 nm (140,480) -- and the 10 nm arm is REUSED from S4-2's L20 arm, which
runs the identical protocol on the identical seeds.  Every delivered mask is
scored on the common reference grid (140,480) at (40,10) by block replication,
which is pointwise exact on a binary.

This script makes no claim.  It records numbers and writes them to disk; the
reading belongs in ``S4_实验记录.md``.

The user's question is "what does the pixel mainly affect", so three families
of quantity are recorded beyond the delivered efficiency:

  1. TIME, split.  Every step separates the solve (``value_grad_latent``, which
     also carries the design map's forward+backward) from the non-solve work
     (schedule, Adam update, clone), and every audit separates the design map
     (``hard_binary``) from the forward solve.  A standalone probe times the
     design map alone at each pixel.  Solve cost is set by the retained mode
     count N, so it should be pixel-independent; if it is not, the difference
     has to show up in one of these other buckets.

  2. BOUNDARY QUANTIZATION.  Fill fraction, boundary pixel count, interface
     length in nm (block-replication invariant, so comparable across pixels),
     and the ROUND TRIP: area-average the delivered binary down to 20 nm,
     re-threshold at 0.5, block-replicate back to the reference grid, re-score
     at (40,10), report delta-eta.  A 5 nm delivery also round-trips through
     10 nm, giving a three-point quantization ladder.  The 20 nm arm's own
     20 nm round trip is the identity and is recorded as an exact zero with no
     solve spent on it.

  3. SUB-FILTER TEXTURE.  For each delivered latent, the spatial power spectrum
     of ``C.filtered(rho)`` and the fraction of its energy beyond the 20 nm
     (and 10 nm) grid Nyquist -- the quantity S4-3 asks for.  Two companions are
     recorded with it, because on its own it is not readable: the same fractions
     for the delivered BINARY (a hard threshold is full-band, so this is where
     a finer pixel can actually reach the physics), and the 60 nm filter's own
     |H|^2 beyond those Nyquists, which is the ceiling the first number is
     measured against (the Gaussian's transfer at the 20 nm Nyquist is ~1e-10
     in amplitude, so a filtered field's beyond-Nyquist share is ~1e-20 whatever
     the optimizer did).

     EVERY spectral fraction is recorded TWICE: once on the arm's own native
     grid (``*_native``) and once on the common (140,480) reference grid
     (``*_ref``).  Only the ``_ref`` pair is comparable across arms, and it is
     the one ``summarize`` aggregates.  A field on the 20 nm grid has no bin
     above its own Nyquist, so its native ``frac_beyond_nyq20`` is 0 BY
     CONSTRUCTION and reading the native column across arms inverts the
     ordering: block-replicating the 20 nm mask to (140,480) -- the same
     physical structure the reference solve sees -- puts real staircase energy
     above 1/(2*20 nm).

Usage
    python s4_3_pixel_size.py                    # full run, ~3.8 GPU-h
    python s4_3_pixel_size.py --dry-run          # seconds; cheap orders
    python s4_3_pixel_size.py --resume           # continue an interrupted run
    python s4_3_pixel_size.py --targets 1 --pixels 5 --n-seeds 2
"""
import argparse
import fnmatch
import hashlib
import os
import statistics
import subprocess
import time
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import torch

import s4_common as s4c
from s4_common import C

SCRIPT = "s4_3_pixel_size.py"

# ---- frozen for this experiment -------------------------------------------
DESCENT_LEVEL: Tuple[int, int] = (20, 5)
AUDIT_LEVEL: Tuple[int, int] = (20, 5)
DEFAULT_RUN_PIXELS: Tuple[int, ...] = (20, 5)   # arms this script runs by default
ALLOWED_PIXELS: Tuple[int, ...] = (20, 10, 5)   # arms --pixels may name
REUSE_PIXEL = 10                           # arm read back from S4-2
S4_2_ARM = "L20"                           # the S4-2 arm that matches us
QUANTIZE_TO = (20, 10)                     # round-trip target grids (nm)
# The S4-2 rows we may reuse must have been produced under the frozen schedule.
N_STEPS_EXPECTED = s4c.N_STEPS
AUDIT_EVERY_EXPECTED = s4c.AUDIT_EVERY

DESIGNS = os.path.join(s4c.DATA, "designs")     # redirected in main() for --dry-run
S4_2_CANDIDATES = ("s4_2_descent_order.json", "s4_2_truncation_order.json",
                   "s4_2.json")
# --dry-run substitutes cheap orders everywhere so the self-check is seconds.
# The real orders are still legality-checked on every grid that would be used.
DRY_REF_LEVEL: Tuple[int, int] = (12, 3)
DRY_DESCENT_LEVEL: Tuple[int, int] = (8, 2)
DRY_AUDIT_LEVEL: Tuple[int, int] = (8, 2)
# A same-grid, low-order value+grad probe.  Legal on all three grids
# (needs ny>=9, nx>=33), so the (20,5)-minus-(8,2) difference isolates the cost
# of the retained modes from the cost that scales with the GRID.
PROBE_LEVEL: Tuple[int, int] = (8, 2)
PROBE_SEED = 12345678       # probe-only RNG; never a design seed


# ============================================================ small helpers
def _sync():
    if torch.cuda.is_available():
        torch.cuda.synchronize()


def _reset_peak():
    if torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats()


def _peak_bytes() -> int:
    return int(torch.cuda.max_memory_allocated()) if torch.cuda.is_available() else 0


def _free():
    if torch.cuda.is_available():
        torch.cuda.empty_cache()


def _stats(xs: Sequence[float]) -> Dict[str, object]:
    """Summary of a timing list.  Median first: step times are right-skewed."""
    xs = [float(x) for x in xs]
    if not xs:
        return {"n": 0, "median": None, "mean": None, "min": None,
                "max": None, "total": 0.0, "sd": None}
    return {"n": len(xs), "median": statistics.median(xs),
            "mean": sum(xs) / len(xs), "min": min(xs), "max": max(xs),
            "total": sum(xs),
            "sd": statistics.pstdev(xs) if len(xs) > 1 else 0.0}


def _round(xs: Sequence[float], nd: int = 6) -> List[float]:
    return [round(float(x), nd) for x in xs]


def mask_sha1(binary: torch.Tensor) -> str:
    """Content hash of a 0/1 mask.  Same construction as S4-2's, so the two
    stores' hashes are directly comparable and a reused mask can be verified
    against the hash S4-2 recorded for it."""
    a = np.ascontiguousarray(binary.detach().cpu().numpy().astype(np.uint8))
    return hashlib.sha1(a.tobytes()).hexdigest()


_NVSMI_QUERY = "clocks.sm,clocks.mem,temperature.gpu,utilization.gpu,power.draw"


def gpu_telemetry() -> Dict[str, object]:
    """SM clock / temperature / utilisation at this instant, via nvidia-smi.

    Recorded once per unit.  A single card running 3-4 h drifts its clocks by
    5-10%, which is the same size as the pixel effect being measured; the arm
    order is also alternated per seed so drift cannot alias onto the pixel axis,
    but these samples let a reader regress it out rather than trust the
    alternation.  Costs ~50 ms and never raises.
    """
    out: Dict[str, object] = {"utc": time.strftime("%Y-%m-%dT%H:%M:%SZ",
                                                   time.gmtime())}
    try:
        raw = subprocess.check_output(
            ["nvidia-smi", "--query-gpu=" + _NVSMI_QUERY,
             "--format=csv,noheader,nounits"],
            stderr=subprocess.DEVNULL, timeout=10)
        vals = [v.strip() for v in raw.decode("ascii", "replace").splitlines()[0].split(",")]
        for name, v in zip(_NVSMI_QUERY.split(","), vals):
            try:
                out[name.replace(".", "_")] = float(v)
            except ValueError:
                out[name.replace(".", "_")] = v
    except Exception as exc:                    # nvidia-smi absent / busy
        out["error"] = "%s: %s" % (type(exc).__name__, exc)
    if torch.cuda.is_available():
        try:
            free_b, total_b = torch.cuda.mem_get_info()
            out["mem_free_gib"] = free_b / 2 ** 30
            out["mem_total_gib"] = total_b / 2 ** 30
        except Exception:                       # pragma: no cover
            pass
    return out


def _area_downsample(field: torch.Tensor, ny: int, nx: int) -> torch.Tensor:
    """Exact block mean onto a coarser grid (local copy of the private helper
    in s4_common, so this script does not reach into another module's privates)."""
    fy, fx = field.shape
    if fy % ny or fx % nx:
        raise AssertionError("grid %r does not divide evenly into (%d,%d)"
                             % ((fy, fx), ny, nx))
    ky, kx = fy // ny, fx // nx
    return field.reshape(ny, ky, nx, kx).mean(dim=(1, 3))


def _eta_on_ref(binary: torch.Tensor, target, pix: int,
                level: Sequence[int]) -> float:
    """Score a mask on the common (140,480) grid at ``level``.

    Local variant of ``s4c.eta_ref`` only because the reference order has to be
    overridable for --dry-run; at ``level = s4c.REF_LEVEL`` the two are the
    same call.
    """
    lifted = s4c.to_ref_grid(binary, pix)
    return s4c.eta(lifted, level, target, s4c.REF_CFG)


# ============================================================== measurements
def geometry(binary: torch.Tensor, cfg) -> Dict[str, object]:
    """Fill fraction and boundary size of a delivered mask.

    Neighbourhoods wrap: the structure is periodic in both axes.  ``boundary_px``
    counts pixels with at least one unlike 4-neighbour.  ``interface_len_nm``
    counts unlike adjacent PAIRS weighted by the shared edge length, which is
    invariant under block replication and therefore the one boundary measure
    that compares directly across the three pixel sizes (a staircase still
    overestimates a smooth perimeter, identically for all three).
    """
    b = binary.detach().cpu().to(torch.bool)
    ny, nx = b.shape
    dy, dx = cfg.pixel_yx
    diff_x = b != torch.roll(b, -1, dims=1)     # pair (i,j)-(i,j+1), edge len dy
    diff_y = b != torch.roll(b, -1, dims=0)     # pair (i,j)-(i+1,j), edge len dx
    pairs_x, pairs_y = int(diff_x.sum()), int(diff_y.sum())
    unlike = (diff_x | diff_y
              | torch.roll(diff_x, 1, dims=1) | torch.roll(diff_y, 1, dims=0))
    n_px = ny * nx
    n_feat = int(b.sum())
    return {
        "grid": [ny, nx], "pixel_nm_yx": [float(dy), float(dx)],
        "n_pixels": n_px, "n_feature_px": n_feat,
        "fill_fraction": n_feat / float(n_px),
        "boundary_px": int(unlike.sum()),
        "boundary_fraction": float(unlike.sum()) / float(n_px),
        "interface_pairs_x": pairs_x, "interface_pairs_y": pairs_y,
        "interface_len_nm": pairs_x * float(dy) + pairs_y * float(dx),
        "all_one_phase": bool(n_feat == 0 or n_feat == n_px),
    }


def _nyq_masks(ny: int, nx: int, cfg, pix: int):
    """(beyond, at) boolean masks for the ``pix`` nm grid Nyquist, on this grid."""
    lx, ly = cfg.lattice_nm                      # (Lx, Ly); axis0 spans Ly
    ky = torch.fft.fftfreq(ny, d=float(ly) / ny).abs().view(-1, 1)
    kx = torch.fft.fftfreq(nx, d=float(lx) / nx).abs().view(1, -1)
    fn = 1.0 / (2.0 * pix)
    hi, lo = fn * (1.0 + 1e-9), fn * (1.0 - 1e-9)
    beyond = (kx > hi) | (ky > hi)
    at = ((kx >= lo) | (ky >= lo)) & ~beyond
    return beyond, at


def beyond_nyquist(field: torch.Tensor, cfg) -> Dict[str, object]:
    """Share of a field's power spectrum that a coarser grid could not hold.

    ``frac_beyond_nyqP`` is the share of |FFT|^2 with |fx| or |fy| strictly
    above 1/(2P) nm^-1.  The ``_ac`` variants drop the DC bin from numerator
    and denominator (DC is ~3/4 of these fields and would bury everything
    else).  ``frac_at_nyqP`` is the energy sitting exactly on the boundary
    bins, reported separately so the inclusive/exclusive convention cannot
    change a conclusion silently.

    A field on the 20 nm grid has no representable frequency beyond its own
    Nyquist, so its ``frac_beyond_nyq20`` must come out exactly 0 -- that is
    the self-check.
    """
    f = field.detach().cpu().to(torch.float64)
    ny, nx = f.shape
    F = torch.fft.fft2(f)
    P = (F.real ** 2 + F.imag ** 2)
    total = float(P.sum())
    dc = float(P[0, 0])
    ac = total - dc
    out = {"grid": [ny, nx], "total_energy": total,
           "dc_fraction": dc / total if total > 0 else None}
    for pix in (20, 10):
        beyond, at = _nyq_masks(ny, nx, cfg, pix)
        e_beyond, e_at = float(P[beyond].sum()), float(P[at].sum())
        out["frac_beyond_nyq%d" % pix] = e_beyond / total if total > 0 else None
        out["frac_at_nyq%d" % pix] = e_at / total if total > 0 else None
        out["frac_beyond_nyq%d_ac" % pix] = e_beyond / ac if ac > 0 else None
        out["frac_at_nyq%d_ac" % pix] = e_at / ac if ac > 0 else None
    return out


_TRANSFER_CACHE: Dict[Tuple[int, int], Dict[str, object]] = {}


def filter_transfer(cfg) -> Dict[str, object]:
    """Power transfer |H|^2 of the 60 nm filter itself, beyond the coarse Nyquists.

    Without this the spectrum numbers are unreadable.  The 60 nm Gaussian is
    exp(-r^2/R^2), whose transfer at the 20 nm Nyquist (0.025 nm^-1) is ~1e-10
    in amplitude, so ANY filtered field -- optimized or random -- has ~1e-20 of
    its power beyond that Nyquist.  ``frac_beyond_nyq20`` of a filtered latent
    is therefore bounded by the filter, not by the optimization, and the two
    must be reported together.  Measured on the impulse response of the actual
    operator (``periodic_gaussian_filter``), not from the analytic formula, so
    it is the transfer this code really applies.
    """
    key = tuple(cfg.shape)
    if key in _TRANSFER_CACHE:
        return dict(_TRANSFER_CACHE[key])
    ny, nx = cfg.shape
    delta = torch.zeros((ny, nx), dtype=torch.float64)
    delta[0, 0] = 1.0
    h = s4c.periodic_gaussian_filter(delta, cfg.lattice_nm, cfg.filter_nm)
    H = torch.fft.fft2(h)
    T = (H.real ** 2 + H.imag ** 2)
    T = T / float(T[0, 0])                      # H(0) = sum(kernel) = 1
    out = {"grid": [ny, nx], "filter_nm": cfg.filter_nm,
           "note": "|H|^2 of the fabrication filter; bounds any frac_beyond. "
                   "max_transfer_* is None when this grid HOLDS no bin beyond "
                   "that Nyquist (not the same as the filter zeroing one)"}
    for pix in (20, 10):
        beyond, at = _nyq_masks(ny, nx, cfg, pix)
        n_b, n_a = int(beyond.sum()), int(at.sum())
        out["n_bins_beyond_nyq%d" % pix] = n_b
        out["n_bins_at_nyq%d" % pix] = n_a
        out["max_transfer_beyond_nyq%d" % pix] = (
            float(T[beyond].max()) if n_b else None)
        out["max_transfer_at_nyq%d" % pix] = (
            float(T[at].max()) if n_a else None)
    _TRANSFER_CACHE[key] = dict(out)
    return out


def spectrum(latent: Optional[torch.Tensor], binary: Optional[torch.Tensor],
             cfg, pix: int) -> Dict[str, object]:
    """Sub-filter texture: does the finer parameterization reach the structure?

    Two families of block, because the spec's quantity alone is not readable:
      ``filtered_latent_*``   the quantity S4-3 asks for -- spectrum of
                              ``C.filtered(rho)``, the field the threshold acts
                              on.
      ``delivered_binary_*``  the same fractions for the delivered mask.  The
                              mask is a hard threshold and therefore full-band
                              by construction, so this is where any extra
                              freedom a finer pixel bought actually shows up in
                              the physics.
      ``filter_transfer_*``   the filter's own |H|^2 beyond those Nyquists, i.e.
                              the ceiling the first block is measured against.

    and each is measured on TWO grids:
      ``*_native``  on the arm's own grid.  NOT comparable across arms: the
                    20 nm grid holds no bin beyond 1/(2*20 nm), so its
                    ``frac_beyond_nyq20`` is identically 0 by construction.
                    Kept only as the self-check that this is so.
      ``*_ref``     on the common (140,480) grid, which is the grid the
                    reference solve actually sees.  The binary is block-
                    replicated (pointwise exact); the latent is block-
                    replicated and then re-filtered at the physical 60 nm
                    radius on that grid.  THIS is the comparable pair, and the
                    one ``summarize`` aggregates.
    """
    lat = None if latent is None else latent.detach().cpu().to(torch.float64)
    bin_ = None if binary is None else binary.detach().cpu().to(torch.float64)
    k = int(pix) // s4c.REF_PIX
    out: Dict[str, object] = {
        "pixel_nm": int(pix),
        "filter_transfer_native": filter_transfer(cfg),
        "filter_transfer_ref": filter_transfer(s4c.REF_CFG),
        "note": "read the *_ref block; *_native is grid-dependent and its "
                "frac_beyond_nyq20 is 0 by construction on the 20 nm grid",
    }
    out["filtered_latent_native"] = (
        None if lat is None else beyond_nyquist(C.filtered(lat, cfg), cfg))
    out["delivered_binary_native"] = (
        None if bin_ is None else beyond_nyquist(bin_, cfg))
    out["filtered_latent_ref"] = (
        None if lat is None
        else beyond_nyquist(C.filtered(s4c.upsample(lat, k), s4c.REF_CFG),
                            s4c.REF_CFG))
    out["delivered_binary_ref"] = (
        None if bin_ is None
        else beyond_nyquist(s4c.to_ref_grid(bin_, pix), s4c.REF_CFG))
    return out


def _fill_matched_threshold(frac: torch.Tensor, target_fill: float):
    """Threshold on the block-mean field whose mask fill is closest to ``target_fill``.

    Candidates are the distinct block-mean values (the only thresholds that can
    change the mask) plus one above the maximum; ties in |fill error| break
    toward 0.5, so a mask that is already fill-matched keeps the protocol's own
    threshold.
    """
    vals = sorted(set(float(v) for v in frac.flatten().tolist()))
    n = float(frac.numel())
    best_t, best_err, best_fill = None, None, None
    for t in vals:
        fill = float((frac >= t).sum()) / n
        err = abs(fill - target_fill)
        key = (err, abs(t - 0.5))
        if best_err is None or key < best_err:
            best_t, best_err, best_fill = t, key, fill
    return best_t, best_fill


def roundtrip(binary: torch.Tensor, pix_from: int, pix_to: int, target,
              ref_level: Sequence[int], eta_ref: float,
              fill_matched: bool = False) -> Dict[str, object]:
    """Quantize a delivered mask onto a ``pix_to`` nm grid and re-score it.

    Area-average down, re-threshold at 0.5 with ``>=`` (the protocol's own
    comparison in ``hard_binary``), block-replicate back to the reference grid,
    solve at ``ref_level``.  ``delta_eta`` is (round-tripped - as-delivered), so
    a negative number is efficiency lost to coarser boundary quantization.

    ``pix_to == pix_from`` is the identity: recorded as an exact zero, no solve.

    FILL-MATCHED CONTROL (``fill_matched``).  A block whose mean is exactly 0.5
    is resolved to feature by ``>=``, so the plain round trip systematically
    RAISES the fill fraction -- a positive CD bias riding on top of the boundary
    quantization the measurement is after.  With ``fill_matched`` the same
    coarse field is thresholded instead at the value that brings the coarse
    fill closest to the delivered fill, and scored with a second solve.  The
    difference between the two deltas separates the bias from the quantization;
    without it the two are inseparable and cannot be recovered later without
    re-solving.  Costs one extra reference solve.
    """
    if pix_to == pix_from:
        return {"pix_to": pix_to, "identity": True, "eta_ref": eta_ref,
                "delta_eta": 0.0, "tie_blocks": 0, "tie_fraction": 0.0,
                "changed_ref_px": 0, "changed_ref_fraction": 0.0,
                "fill_before": float(binary.mean()),
                "fill_after": float(binary.mean()), "wall_s": 0.0,
                "fill_matched": None}
    if pix_to < pix_from:
        raise ValueError("round trip must go to a COARSER grid (%d -> %d)"
                         % (pix_from, pix_to))
    k = pix_to // pix_from
    if pix_to % pix_from or k not in (2, 4):
        raise ValueError("unsupported round trip %d nm -> %d nm" % (pix_from, pix_to))
    b = binary.detach().cpu().to(torch.float64)
    ny, nx = b.shape
    frac = _area_downsample(b, ny // k, nx // k)
    ties = int((frac == 0.5).sum())
    coarse = (frac >= 0.5).to(b.dtype)
    lifted_rt = s4c.to_ref_grid(coarse, pix_to)
    lifted_in = s4c.to_ref_grid(b, pix_from)
    changed = int((lifted_rt != lifted_in).sum())
    fill_before = float(b.mean())
    t0 = time.perf_counter()
    e = s4c.eta(lifted_rt, ref_level, target, s4c.REF_CFG)
    wall = time.perf_counter() - t0
    out = {"pix_to": pix_to, "identity": False, "eta_ref": e,
           "delta_eta": e - eta_ref,
           "threshold": 0.5,
           "tie_blocks": ties, "tie_fraction": ties / float(frac.numel()),
           "changed_ref_px": changed,
           "changed_ref_fraction": changed / float(lifted_in.numel()),
           "fill_before": fill_before,
           "fill_after": float(coarse.mean()),
           "fill_shift": float(coarse.mean()) - fill_before,
           "wall_s": wall, "fill_matched": None}
    if fill_matched:
        t_fm, fill_fm = _fill_matched_threshold(frac, fill_before)
        coarse_fm = (frac >= t_fm).to(b.dtype)
        same = bool(torch.equal(coarse_fm, coarse))
        fm = {"threshold": float(t_fm), "fill_after": float(fill_fm),
              "fill_shift": float(fill_fm) - fill_before,
              "same_mask_as_plain": same,
              "note": "threshold chosen to match the delivered fill; "
                      "delta_eta minus the plain delta_eta is the CD-bias term"}
        if same:
            fm.update({"eta_ref": e, "delta_eta": e - eta_ref,
                       "changed_ref_px": changed, "wall_s": 0.0})
        else:
            lifted_fm = s4c.to_ref_grid(coarse_fm, pix_to)
            t1 = time.perf_counter()
            e_fm = s4c.eta(lifted_fm, ref_level, target, s4c.REF_CFG)
            fm["wall_s"] = time.perf_counter() - t1
            fm["eta_ref"] = e_fm
            fm["delta_eta"] = e_fm - eta_ref
            fm["changed_ref_px"] = int((lifted_fm != lifted_in).sum())
        fm["delta_eta_vs_plain"] = fm["delta_eta"] - out["delta_eta"]
        out["fill_matched"] = fm
    return out


_PROBE_CACHE: Dict[Tuple[int, int], Dict[str, object]] = {}


def design_map_probe(cfg, target=(1, 0), reps: int = 10,
                     use_cache: bool = True) -> Dict[str, object]:
    """Attribute the pixel-dependent part of a step, in isolation.

    ``value_grad_latent`` is atomic -- inside it the design map's FORWARD
    (symmetrize, 60 nm filter, tanh) and BACKWARD both run, plus the eps build
    and the density FFT, and only then the eigen-solve.  The in-loop ``solve``
    bucket therefore is NOT a pure solver time and its pixel dependence cannot
    be attributed from the loop alone.  Four probe families close that:

      filtered / projected / hard_binary / adam_step
          the map's forward pieces and the update, on a real latent.
      map_value_grad
          ``projected(x).sum().backward()`` -- the map's BACKWARD, which is
          where the parameter count (4200 -> 67200) enters the autograd graph.
      value_grad_at_<PROBE_LEVEL>
          a full value+grad at a very low order that is legal on every grid.
          Its pixel dependence is grid-driven (eps build, density FFT, map);
          the gap up to the in-loop (20,5) time is what the retained modes cost.

    Cached per grid shape: the probe is identical for every (target, seed) at a
    given pixel, so it runs once per arm rather than 24 times.
    """
    key = tuple(cfg.shape)
    if use_cache and key in _PROBE_CACHE:
        out = dict(_PROBE_CACHE[key])
        out["cached"] = True
        return out
    rho = s4c.paired_initial_latent(s4c.SEED_BASE[1], cfg).to(cfg.device)
    adam = C.Adam(rho.shape, cfg)
    # Seeded on the CPU: torch.randn_like(rho) would draw from the UNSEEDED
    # cuda generator, making the probe irreproducible and advancing the cuda
    # RNG state under the rest of the run.
    g = torch.Generator().manual_seed(PROBE_SEED)
    grad = torch.randn(tuple(rho.shape), generator=g,
                       dtype=cfg.latent_dtype).to(cfg.device)

    def _map_vg():
        x = rho.detach().clone().requires_grad_(True)
        C.projected(x, 32.0, cfg).sum().backward()
        return x.grad

    plv = s4c.check_level(PROBE_LEVEL, cfg, "probe level")

    def _cheap_vg():
        return C.value_grad_latent(rho, plv, tuple(target), 32.0, cfg)

    out: Dict[str, object] = {"grid": list(cfg.shape), "reps": int(reps),
                              "probe_level": list(plv), "cached": False}
    probes = (("filtered", lambda: C.filtered(rho, cfg)),
              ("projected", lambda: C.projected(rho, 32.0, cfg)),
              ("hard_binary", lambda: C.hard_binary(rho, cfg)),
              ("adam_step", lambda: adam.step(rho, grad, 0.01)),
              ("map_value_grad", _map_vg),
              ("value_grad_at_%d_%d" % plv, _cheap_vg))
    for name, fn in probes:
        n = reps if not name.startswith("value_grad_at_") else max(3, reps // 3)
        fn()                                    # warm up / allocate
        _sync()
        ts = []
        for _ in range(n):
            t0 = time.perf_counter()
            fn()
            _sync()
            ts.append(time.perf_counter() - t0)
        out[name] = _stats(ts)
    out["note"] = ("map_value_grad is the design map's backward alone; "
                   "value_grad_at_%d_%d is a full value+grad at a low order "
                   "legal on every grid, so its pixel dependence is "
                   "grid-driven rather than mode-count-driven" % plv)
    # No del/empty_cache here: the closures in ``probes`` still reference rho /
    # adam / grad, so nothing is released until this frame returns.  The caller
    # calls _free() after it does.
    if use_cache:
        _PROBE_CACHE[key] = dict(out)
    return out


# ============================================================== the descent
def run_descent_timed(target, seed, cfg, n_steps: int, audit_every: int,
                      descent_level=DESCENT_LEVEL, audit_level=AUDIT_LEVEL,
                      progress_every: int = 0, label: str = "") -> Dict[str, object]:
    """The frozen 219-step protocol with the wall clock broken out per phase.

    TRAJECTORY-IDENTICAL to both loops it has to match: ``s4_common.run_descent``
    and -- the one that actually matters, because it is what produced the reused
    10 nm arm -- ``s4_2_descent_order.run_multi_audit``.  Same paired initial,
    same ``progress = step/(n_steps-1)`` schedule, same order of operations
    (value+grad, then audit of the PRE-update rho on every ``audit_every``-th
    step, then the Adam update), same running-best delivery with a strict ``>``,
    same extra audit after the final update.  Only ``perf_counter`` calls and
    ``cuda.synchronize`` barriers are added, and neither touches the numerics.
    ``--dry-run`` asserts BOTH pairings by running the loops and comparing the
    delivered masks (``parity_check``).

    Bucket definitions (the split is by call site, not by the spec's words):
      ``solve``       ``value_grad_latent`` -- eps build, density FFT, the
                      design map's FORWARD and BACKWARD, and the eigen-solve.
                      NOT a pure solver time; ``probe`` attributes the rest.
      ``overhead``    schedule (beta, lr) plus the Adam update and clone ONLY.
                      The spec's "overhead" also names filter/projection/hard
                      threshold, but those live inside ``value_grad_latent``
                      and ``audit_map``; see ``timing.notes``.
      ``audit_map``   ``hard_binary`` of the pre-update latent.
      ``audit_solve`` the audit forward at ``audit_level``.  Same order on
                      every arm, so this pair is the clean test of whether a
                      solve at fixed order depends on the design grid.

    Both arms carry identical instrumentation, so the pixel comparison is
    unaffected by the barriers; ``wall_s`` is end to end and must only be
    compared against another end-to-end wall (S4-2's ``run_wall_s``, never its
    attributed ``wall_s``).
    """
    if n_steps < 2:
        raise ValueError("n_steps must be >= 2 (progress = step/(n_steps-1))")
    tgt = (int(target[0]), int(target[1]))
    dlv = s4c.check_level(descent_level, cfg, "descent level")
    alv = s4c.check_level(audit_level, cfg, "audit level")
    px = s4c.pix_of(cfg)

    rho = s4c.paired_initial_latent(seed, cfg).to(cfg.device)
    adam = C.Adam(rho.shape, cfg)

    solve_t: List[float] = []
    overhead_t: List[float] = []
    audit_map_t: List[float] = []
    audit_solve_t: List[float] = []
    obj_traj: List[float] = []
    traj: List[List[float]] = []
    best_eta, best_bin, best_rho, best_step = -float("inf"), None, None, -1
    n_audits = 0

    _reset_peak()
    _sync()
    t_start = time.perf_counter()
    grad_events = []      # NaN-guard log (s4_common.robust_value_grad)
    for step in range(n_steps):
        t_loop = time.perf_counter()
        progress = step / (n_steps - 1)
        beta = C.beta_at(progress, cfg=cfg)
        lr = C.cosine_lr(progress, cfg)
        _sync()
        t0 = time.perf_counter()
        obj, grad, _gev = s4c.robust_value_grad(rho, dlv, tgt, beta, cfg)
        if _gev is not None:
            _gev['step'] = step
            grad_events.append(_gev)
            print('      !! non-finite adjoint at step %d beta %.3f -> %s'
                  % (step, beta, _gev['event']), flush=True)
        _sync()
        t1 = time.perf_counter()
        solve_t.append(t1 - t0)
        obj_traj.append(float(obj))
        if step % audit_every == 0:
            b = C.hard_binary(rho, cfg)
            _sync()
            t2 = time.perf_counter()
            a = s4c.eta(b, alv, tgt, cfg)
            _sync()
            t3 = time.perf_counter()
            audit_map_t.append(t2 - t1)
            audit_solve_t.append(t3 - t2)
            n_audits += 1
            traj.append([step, a])
            if a > best_eta:
                best_eta, best_bin, best_rho, best_step = a, b, rho.clone(), step
        else:
            t3 = t1
        if grad is not None:      # skipped_update keeps the step count
            rho = adam.step(rho, grad, lr)
        _sync()
        t4 = time.perf_counter()
        overhead_t.append((t0 - t_loop) + (t4 - t3))
        if progress_every and (step + 1) % progress_every == 0:
            el = time.perf_counter() - t_start
            print("      %s step %3d/%d  beta %5.1f  lr %.4f  best %.4f  "
                  "[%s elapsed, ~%s left]"
                  % (label or str(tgt), step + 1, n_steps, beta, lr, best_eta,
                     s4c.fmt_s(el),
                     s4c.fmt_s(el * (n_steps - step - 1) / (step + 1))),
                  flush=True)
    # final audit, after the last update
    _sync()
    tf0 = time.perf_counter()
    b = C.hard_binary(rho, cfg)
    _sync()
    tf1 = time.perf_counter()
    a = s4c.eta(b, alv, tgt, cfg)
    _sync()
    tf2 = time.perf_counter()
    audit_map_t.append(tf1 - tf0)
    audit_solve_t.append(tf2 - tf1)
    n_audits += 1
    traj.append([n_steps, a])
    if a > best_eta:
        best_eta, best_bin, best_rho, best_step = a, b, rho.clone(), n_steps
    wall = time.perf_counter() - t_start

    timing = {
        "wall_s": wall,
        "wall_s_kind": "end_to_end",
        "solve": _stats(solve_t),
        "overhead": _stats(overhead_t),
        "audit_map": _stats(audit_map_t),
        "audit_solve": _stats(audit_solve_t),
        "notes": {
            "wall_s": "end-to-end loop wall, barriers included; compare only "
                      "with another end-to-end wall",
            "solve": "value_grad_latent: eps build + density FFT + design-map "
                     "forward AND backward + eigen-solve; see probe",
            "overhead": "schedule + Adam update ONLY (filter/projection are "
                        "inside solve, hard_binary is audit_map)",
            "audit_solve": "pure forward at the SAME order on both grids -- "
                           "the controlled test of solve-cost vs design grid",
        },
        "accounted_s": (sum(solve_t) + sum(overhead_t) + sum(audit_map_t)
                        + sum(audit_solve_t)),
        "per_step_solve_s": _round(solve_t),
        "per_step_overhead_s": _round(overhead_t),
        "per_audit_map_s": _round(audit_map_t),
        "per_audit_solve_s": _round(audit_solve_t),
    }
    timing["unaccounted_s"] = wall - timing["accounted_s"]
    return {
        "target": list(tgt), "seed": int(seed), "pixel_nm": px,
        "grid": list(cfg.shape),
        "descent_level": list(dlv), "audit_level": list(alv),
        "audit_on_ref": False,
        "n_steps": int(n_steps), "audit_every": int(audit_every),
        "n_audits": int(n_audits),
        "best_audit_eta": float(best_eta), "best_audit_step": int(best_step),
        "final_audit_eta": float(a),
        "audit_traj": traj, "objective_traj": _round(obj_traj),
        "timing": timing,
        "peak_mem_bytes": _peak_bytes(),
        "delivered_binary": best_bin.detach().cpu(),
        "delivered_latent": best_rho.detach().cpu(),
    }


def parity_check(target, seed, cfg, n_steps, audit_every,
                 descent_level=DESCENT_LEVEL,
                 audit_level=AUDIT_LEVEL) -> Dict[str, object]:
    """Confirm the instrumented loop is trajectory-identical to BOTH originals.

    The pairing with the reused 10 nm arm rests on this.  The loop that actually
    produced that arm is ``s4_2_descent_order.run_multi_audit`` -- S4-2 does NOT
    call ``s4_common.run_descent`` -- so that is the comparison that has to be
    made; ``run_descent`` is checked too, because ``run_descent_timed``'s
    docstring claims equality with it and a claim in a docstring is worth
    exactly as much as its test.  Cheap at dry scale; runs under --dry-run.
    """
    out: Dict[str, object] = {"n_steps": n_steps, "audit_every": audit_every,
                              "descent_level": list(descent_level),
                              "audit_level": list(audit_level)}
    mine = run_descent_timed(target, seed, cfg, n_steps, audit_every,
                             descent_level=descent_level,
                             audit_level=audit_level)

    def _compare(theirs_bin, theirs_lat, theirs_traj, n_aud, best_step):
        d = max([abs(x[1] - y[1]) for x, y in
                 zip(mine["audit_traj"], theirs_traj)] or [0.0])
        return {"binary_equal": bool(torch.equal(mine["delivered_binary"],
                                                 theirs_bin)),
                "latent_equal": bool(torch.equal(mine["delivered_latent"],
                                                 theirs_lat)),
                "max_abs_audit_diff": d,
                "n_audits_equal": mine["n_audits"] == n_aud,
                "best_step_equal": mine["best_audit_step"] == best_step}

    theirs = s4c.run_descent(target, seed, cfg, descent_level, audit_level,
                             n_steps=n_steps, audit_every=audit_every)
    out["vs_s4_common_run_descent"] = _compare(
        theirs["delivered_binary"], theirs["delivered_latent"],
        theirs["audit_traj"], theirs["n_audits"], theirs["best_audit_step"])
    del theirs
    _free()

    # The one that matters: the loop that produced the reused 10 nm arm.
    try:
        import s4_2_descent_order as s2                     # noqa: E402
        alv = (int(audit_level[0]), int(audit_level[1]))
        run = s2.run_multi_audit(target, seed, cfg, descent_level, [alv],
                                 n_steps, audit_every)
        b = run["best"][alv]
        out["vs_s4_2_run_multi_audit"] = _compare(
            b["bin"].detach().cpu(), b["lat"].detach().cpu(),
            run["traj"][alv], run["n_audits"], b["step"])
        del run, b
        _free()
    except Exception as exc:
        out["vs_s4_2_run_multi_audit"] = {
            "error": "%s: %s" % (type(exc).__name__, exc)}

    # flat aliases so the console line and any old reader still work
    prim = out.get("vs_s4_2_run_multi_audit")
    if not isinstance(prim, dict) or "binary_equal" not in prim:
        prim = out["vs_s4_common_run_descent"]
    out.update({k: prim[k] for k in ("binary_equal", "latent_equal",
                                     "max_abs_audit_diff", "n_audits_equal",
                                     "best_step_equal")})
    out["all_equal"] = all(
        bool(v.get("binary_equal")) and bool(v.get("latent_equal"))
        for v in (out["vs_s4_common_run_descent"],
                  out["vs_s4_2_run_multi_audit"])
        if isinstance(v, dict) and "binary_equal" in v)
    del mine
    _free()
    return out


# ======================================================== S4-2 (10 nm) ingest
def _find_s4_2(explicit: Optional[str]) -> Optional[str]:
    if explicit:
        # An explicit path is an instruction, not a hint: a typo must not
        # degrade silently into "no S4-2 store found, 10 nm arm omitted" three
        # hours after the operator walked away.
        p = os.path.abspath(explicit)
        if not os.path.exists(p):
            raise SystemExit("--s4-2-json %s does not exist" % p)
        return p
    for name in S4_2_CANDIDATES:
        p = os.path.join(s4c.DATA, name)
        if os.path.exists(p):
            return p
    hits = sorted(fnmatch.filter(os.listdir(s4c.DATA), "s4_2*.json")) \
        if os.path.isdir(s4c.DATA) else []
    hits = [h for h in hits if not h.endswith("_dry.json")]
    return os.path.join(s4c.DATA, hits[0]) if hits else None


_ETA_REF_KEYS = ("eta_ref", "ref_eta", "eta_ref_40_10", "eta_40_10",
                 "eta_reference", "ref_eta_40_10")


def _pick_eta_ref(row: Dict) -> Tuple[Optional[float], Optional[str]]:
    """Find S4-2's reference-order efficiency, from a WHITELIST of field names.

    There used to be a fuzzy fallback over any key containing "ref" and "eta".
    It is gone: it would happily return a DELTA (``delta_eta_vs_ref``) or, since
    ``isinstance(True, int)`` is True in Python, a boolean flag as if it were an
    absolute efficiency.  S4-2 writes ``eta_ref`` deliberately for this
    consumer, and when the field is genuinely absent the right answer is to
    record a problem and recompute -- which this script does by default at zero
    extra cost.
    """
    for k in _ETA_REF_KEYS:
        v = row.get(k)
        if isinstance(v, (int, float)) and not isinstance(v, bool):
            return float(v), k
    return None, None


def _row_files(row: Dict) -> Dict[str, Optional[str]]:
    f = row.get("files")
    out = {"binary": None, "latent": None}
    if isinstance(f, dict):
        for k in ("binary", "latent"):
            v = f.get(k)
            if isinstance(v, str):
                out[k] = v
    elif isinstance(f, str):
        out["binary"] = f + "_binary.npy"
        out["latent"] = f + "_latent.npy"
    return out


def _load_npy(rel: Optional[str], want_shape) -> Tuple[Optional[torch.Tensor],
                                                       Optional[str]]:
    """Resolve a recorded file name against data/ and data/designs/.

    Returns (tensor, problem).  A truncated .npy -- what a kill during S4-2's
    ``np.save`` leaves behind -- is reported, not raised, so the glob fallback
    still gets its turn.
    """
    if not rel:
        return None, None
    for base in (s4c.DATA, DESIGNS):
        p = os.path.join(base, rel)
        if os.path.exists(p):
            try:
                a = np.load(p)
            except (ValueError, OSError, EOFError) as exc:
                return None, "%s unreadable (%s)" % (rel, exc)
            if tuple(a.shape) != tuple(want_shape):
                return None, ("%s has shape %r, expected %r"
                              % (rel, tuple(a.shape), tuple(want_shape)))
            return torch.from_numpy(np.asarray(a, dtype=np.float64)), None
    return None, "%s not found under data/ or data/designs/" % rel


_ARM_TOKENS = ("L20", "20-5", "20_5")


def _glob_npy(target, seed, want_shape) -> Tuple[Optional[torch.Tensor],
                                                 Optional[str], Optional[str]]:
    """Last resort: look for an S4-2 L20 mask by file name, shape-checked.

    Returns (tensor, name, problem).  The arm filter is NOT optional: every S4-2
    arm at 10 nm delivers a (70,240) mask, so an L16 or CERT file passes the
    shape check and would be silently loaded as the L20 delivery.  If no
    candidate names this arm, the answer is "nothing", not "the other arm".
    """
    pats = ["*s4_2*%d_%d*seed%d*binary.npy" % (target[0], target[1], seed),
            "*s4_2*seed%d*%d_%d*binary.npy" % (seed, target[0], target[1])]
    cands = []
    for base in (DESIGNS, s4c.DATA):
        if not os.path.isdir(base):
            continue
        for name in sorted(os.listdir(base)):
            if any(fnmatch.fnmatch(name, p) for p in pats):
                cands.append((base, name))
    n_all = len(cands)
    cands = [c for c in cands if any(tok in c[1] for tok in _ARM_TOKENS)]
    if len(cands) != 1:
        return None, None, (
            "glob found %d file(s) for target %s seed %d, %d of them naming "
            "arm %s (need exactly 1)" % (n_all, tuple(target), seed,
                                         len(cands), S4_2_ARM))
    base, name = cands[0]
    try:
        a = np.load(os.path.join(base, name))
    except (ValueError, OSError, EOFError) as exc:
        return None, None, "%s unreadable (%s)" % (name, exc)
    if tuple(a.shape) != tuple(want_shape):
        return None, None, "%s: shape %r != %r" % (name, tuple(a.shape),
                                                   tuple(want_shape))
    return torch.from_numpy(np.asarray(a, dtype=np.float64)), name, None


def load_s4_2(path: Optional[str], targets, seeds_by_target,
              n_steps: int = N_STEPS_EXPECTED,
              audit_every: int = AUDIT_EVERY_EXPECTED) -> Dict[str, object]:
    """Pull the L20 / 10 nm arm out of S4-2's store.

    The match is made on the CONTENT of each row -- pixel 10, descent (20,5),
    audit (20,5), native audit, unfused, the frozen step count and audit
    cadence, matching target and seed -- and every choice this function makes
    (which key matched, which field the reference eta came from, which .npy was
    used, whether its hash matched S4-2's) is recorded so a reader can audit
    the reuse.

    The schedule conditions matter: without them a 6-step ``--dry-run`` row that
    reached a real store through ``--out`` would be ingested as a 219-step
    delivery, and nothing downstream would contradict it.

    TIMING.  S4-2 measures the same phase split this script does, so all of it
    is carried over under matched names.  Note in particular that S4-2's
    ``wall_s`` is an ALIAS for ``wall_s_attributed`` (descent + this arm's
    audits) -- NOT an end-to-end wall.  Pouring it into the same ``wall_s`` key
    as ``run_descent_timed``'s end-to-end number would make the 10 nm arm look
    ~25% faster than the 20 nm arm for no reason but the definition, which is
    exactly the axis the user asked about.  ``run_wall_s`` is the comparable
    one and is what lands in ``timing.wall_s``.
    """
    info = {"path": path, "arm": S4_2_ARM, "available": False, "rows": {},
            "problems": [], "n_expected": sum(len(seeds_by_target[t])
                                              for t in targets),
            "match": {"pixel_nm": REUSE_PIXEL,
                      "descent_level": list(DESCENT_LEVEL),
                      "audit_level": list(AUDIT_LEVEL),
                      "n_steps": int(n_steps), "audit_every": int(audit_every)}}
    if not path:
        info["problems"].append("no S4-2 store found; 10 nm arm omitted")
        return info
    store = s4c.load_json(path, None)
    if not store or "units" not in store:
        info["problems"].append("S4-2 store at %s has no 'units'" % path)
        return info
    info["available"] = True
    info["s4_2_meta"] = store.get("meta", {}).get("script")
    units = store["units"]
    shape = s4c.PIX[REUSE_PIXEL].shape
    for tgt in targets:
        for seed in seeds_by_target[tgt]:
            hits, near = [], 0
            for key, row in units.items():
                if not isinstance(row, dict):
                    continue
                if list(row.get("target", [])) != list(tgt):
                    continue
                if int(row.get("seed", -1)) != int(seed):
                    continue
                if int(row.get("pixel_nm", -1)) != REUSE_PIXEL:
                    continue
                if (list(row.get("descent_level", [])) != list(DESCENT_LEVEL)
                        or list(row.get("audit_level", [])) != list(AUDIT_LEVEL)):
                    continue
                near += 1
                if int(row.get("n_steps", -1)) != int(n_steps):
                    continue
                if int(row.get("audit_every", -1)) != int(audit_every):
                    continue
                if row.get("audit_on_ref") is not False:
                    continue
                if row.get("fused"):
                    continue
                hits.append((key, row))
            if len(hits) > 1:
                pref = [h for h in hits
                        if str(h[1].get("arm", "")) == S4_2_ARM or S4_2_ARM in h[0]]
                hits = pref or hits
            if len(hits) != 1:
                info["problems"].append(
                    "target %s seed %d: %d S4-2 rows match content+schedule "
                    "(%d matched content but not n_steps=%d / audit_every=%d / "
                    "native unfused audit)"
                    % (tgt, seed, len(hits), near, n_steps, audit_every))
                continue
            key, row = hits[0]
            eta_ref, eta_key = _pick_eta_ref(row)
            files = _row_files(row)
            binary, prob = _load_npy(files["binary"], shape)
            latent, prob_l = _load_npy(files["latent"], shape)
            src, src_problem = files["binary"], prob
            if binary is None:
                binary, globbed, prob2 = _glob_npy(tgt, seed, shape)
                if binary is not None:
                    src = globbed
                    src_problem = ("recorded path unusable (%s); fell back to "
                                   "glob match %s" % (prob, globbed))
                else:
                    src, src_problem = None, "; ".join(
                        p for p in (prob, prob2) if p)
            # Integrity anchor: S4-2 records a sha1 of every delivered mask, so
            # a mask silently overwritten (or a wrong-arm file that slipped past
            # the name filter) is detectable rather than merely unlikely.
            their_sha = row.get("mask_sha1")
            our_sha = mask_sha1(binary) if binary is not None else None
            sha_match = (None if (their_sha is None or our_sha is None)
                         else bool(str(their_sha) == our_sha))
            if sha_match is False:
                info["problems"].append(
                    "target %s seed %d: mask sha1 MISMATCH (S4-2 recorded %s, "
                    "file %s is %s); refusing this mask"
                    % (tgt, seed, their_sha, src, our_sha))
                binary, latent = None, None
            info["rows"]["%s|%d" % (s4c.unit_key(tgt), seed)] = {
                "s4_2_key": key, "s4_2_arm": row.get("arm"),
                "eta_ref": eta_ref, "eta_ref_field": eta_key,
                "best_audit_eta": row.get("best_audit_eta"),
                "best_audit_step": row.get("best_audit_step"),
                "n_audits": row.get("n_audits"),
                "n_steps": row.get("n_steps"),
                "audit_every": row.get("audit_every"),
                # timing, under S4-2's own names; unit_row_reuse maps them
                "run_wall_s": row.get("run_wall_s"),
                "wall_s_attributed": row.get("wall_s_attributed"),
                "descent_wall_s": row.get("descent_wall_s"),
                "audit_wall_s": row.get("audit_wall_s"),
                "mask_wall_s": row.get("mask_wall_s"),
                "overhead_wall_s": row.get("overhead_wall_s"),
                "per_step_grad_median": row.get("per_step_grad_median"),
                "per_step_wall_median": row.get("per_step_wall_median"),
                "per_step_wall_mean": row.get("per_step_wall_mean"),
                "audit_wall_median": row.get("audit_wall_median"),
                "ref_wall_s": row.get("ref_wall_s"),
                "peak_mem_bytes": row.get("peak_mem_bytes"),
                "s4_2_ref_level": row.get("ref_level"),
                "s4_2_ref_grid": row.get("ref_grid"),
                "mask_sha1_s4_2": their_sha, "mask_sha1_loaded": our_sha,
                "mask_sha1_match": sha_match,
                "files": files, "binary_source": src,
                "binary_source_problem": src_problem,
                "latent_source_problem": prob_l,
                "_binary": binary, "_latent": latent,
            }
            if eta_ref is None:
                info["problems"].append(
                    "target %s seed %d: no whitelisted reference-eta field in "
                    "S4-2 row %s (it will be recomputed here)" % (tgt, seed, key))
    return info


# ==================================================================== driver
def unit_row_new(target, seed, pix, n_steps, audit_every, ref_level,
                 quantize_to, progress_every,
                 descent_level=DESCENT_LEVEL, audit_level=AUDIT_LEVEL,
                 fill_matched_to=()) -> Dict[str, object]:
    """Run one (pixel, target, seed) arm end to end and return its JSON row."""
    cfg = s4c.PIX[pix]
    label = "%s p%dnm s%d" % (target, pix, seed)
    r = run_descent_timed(target, seed, cfg, n_steps, audit_every,
                          descent_level=descent_level, audit_level=audit_level,
                          progress_every=progress_every, label=label)
    row, binary, latent = s4c.split_arrays(r)
    row["arm"] = "run"
    row["mask_sha1"] = mask_sha1(binary)
    row["files"] = save_design(pix, target, seed, binary, latent)

    _reset_peak()
    t0 = time.perf_counter()
    eta_ref = _eta_on_ref(binary, target, pix, ref_level)
    row["eta_ref"] = eta_ref
    row["ref_level"] = list(ref_level)
    row["ref_grid"] = list(s4c.REF_SHAPE)
    row["timing"]["eta_ref_s"] = time.perf_counter() - t0
    self_eta = row["best_audit_eta"]
    # Names aligned with S4-2's (self_bias_rel / self_bias_abs); the older
    # S4-3-only spellings are kept as aliases so nothing that already reads
    # them breaks.
    row["self_bias_rel"] = (self_eta - eta_ref) / eta_ref if eta_ref else None
    row["self_bias_abs"] = self_eta - eta_ref
    row["self_bias"] = row["self_bias_rel"]
    row["self_minus_ref"] = row["self_bias_abs"]

    row["geometry"] = geometry(binary, cfg)
    row["spectrum"] = spectrum(latent, binary, cfg, pix)
    row["roundtrip"] = {}
    for pix_to in quantize_to:
        if pix_to < pix:
            continue
        row["roundtrip"][str(pix_to)] = roundtrip(
            binary, pix, pix_to, target, ref_level, eta_ref,
            fill_matched=(pix_to in fill_matched_to))
    # AFTER the reference and round-trip solves, so their (40,10) peaks -- the
    # largest in the unit -- are inside the window.
    row["peak_mem_ref_bytes"] = _peak_bytes()
    row["probe"] = design_map_probe(cfg, target=target)
    _free()
    return row


def _reuse_timing(s4_2_row: Dict) -> Dict[str, object]:
    """Map S4-2's phase split onto this script's timing vocabulary.

    S4-2 measures exactly the comparable phases (it synchronizes around each
    segment, same as ``run_descent_timed``), so the middle of measurement 1 is
    available for the 10 nm arm and does not have to be dropped.  Only the
    ``median``/``total`` slots S4-2 actually recorded are filled; the rest of a
    ``_stats`` block stays None so nothing invents a spread S4-2 did not report.
    """
    def _blk(total=None, median=None):
        return {"n": None, "median": median, "mean": None, "min": None,
                "max": None, "total": total, "sd": None}

    aud = s4_2_row.get("audit_wall_s")
    if isinstance(aud, dict):                    # defensive: S4-2 flattens it
        aud = next(iter(aud.values()), None)
    return {
        # END-TO-END, the only wall comparable with the run arms'.
        "wall_s": s4_2_row.get("run_wall_s"),
        "wall_s_kind": "end_to_end",
        "wall_s_attributed": s4_2_row.get("wall_s_attributed"),
        "solve": _blk(s4_2_row.get("descent_wall_s"),
                      s4_2_row.get("per_step_grad_median")),
        "audit_solve": _blk(aud, s4_2_row.get("audit_wall_median")),
        "audit_map": _blk(s4_2_row.get("mask_wall_s")),
        "overhead": _blk(s4_2_row.get("overhead_wall_s")),
        "per_step_wall_median": s4_2_row.get("per_step_wall_median"),
        "per_step_wall_mean": s4_2_row.get("per_step_wall_mean"),
        "source": "s4_2",
        "notes": {
            "wall_s": "S4-2 run_wall_s: the measured end-to-end descent loop, "
                      "same definition as the run arms' wall_s",
            "wall_s_attributed": "S4-2's own 'wall_s' alias = descent + this "
                                 "arm's audits; NOT end to end, do not compare "
                                 "it with the run arms' wall_s",
            "overhead": "S4-2's residual (run - descent - audits - mask), so it "
                        "also absorbs anything the run arms leave unaccounted",
            "spread": "S4-2 reports totals and medians, not full per-call "
                      "lists, so min/max/sd are null here",
        },
    }


def unit_row_reuse(target, seed, s4_2_row, ref_level, quantize_to,
                   recheck_ref: bool, fill_matched_to=()) -> Dict[str, object]:
    """Build the 10 nm row from S4-2, adding what S4-2 did not measure.

    The descent itself is never re-run -- that is the point of the reuse -- but
    the reference score IS re-solved by default (``recheck_ref``), for two
    reasons: it puts the round-trip delta's two terms on provably the same
    footing, and the difference from S4-2's own number
    (``eta_ref_recheck_delta``) is a free cross-check that the two scripts
    score a delivered mask identically.  ~20 s per seed.
    """
    pix = REUSE_PIXEL
    cfg = s4c.PIX[pix]
    binary = s4_2_row.get("_binary")
    latent = s4_2_row.get("_latent")
    missing = []
    row = {
        "arm": "s4_2_reuse", "target": list(target), "seed": int(seed),
        "pixel_nm": pix, "grid": list(cfg.shape),
        "descent_level": list(DESCENT_LEVEL), "audit_level": list(AUDIT_LEVEL),
        "audit_on_ref": False,
        "source": {k: v for k, v in s4_2_row.items() if not k.startswith("_")},
        "best_audit_eta": s4_2_row.get("best_audit_eta"),
        "best_audit_step": s4_2_row.get("best_audit_step"),
        "n_audits": s4_2_row.get("n_audits"),
        "peak_mem_bytes": s4_2_row.get("peak_mem_bytes"),
        "n_steps": s4_2_row.get("n_steps"),
        "audit_every": s4_2_row.get("audit_every"),
        "mask_sha1": s4_2_row.get("mask_sha1_loaded"),
        "mask_sha1_s4_2": s4_2_row.get("mask_sha1_s4_2"),
        "mask_sha1_match": s4_2_row.get("mask_sha1_match"),
        "ref_level": list(ref_level), "ref_grid": list(s4c.REF_SHAPE),
        "timing": _reuse_timing(s4_2_row),
    }
    eta_ref = s4_2_row.get("eta_ref")
    # The round trip's delta is (our re-solve) - (this baseline), so the two
    # MUST be at the same order.  Reusing S4-2's number is only safe when we
    # are scoring at the frozen reference and S4-2 says it did too; otherwise
    # (a --dry-run substitute order, or an S4-2 row that recorded a different
    # ref_level) recompute rather than subtract two different quantities.
    their_lv = s4_2_row.get("s4_2_ref_level")
    level_mismatch = (list(ref_level) != list(s4c.REF_LEVEL)
                      or (their_lv is not None
                          and list(their_lv) != list(ref_level)))
    if binary is None:
        missing.append("delivered_binary")
        row["eta_ref"] = eta_ref
        row["eta_ref_source"] = "s4_2_json" if eta_ref is not None else None
        row["eta_ref_level_mismatch"] = bool(level_mismatch)
        row["geometry"] = None
        row["roundtrip"] = None
    else:
        row["eta_ref_level_mismatch"] = bool(level_mismatch)
        _reset_peak()            # so peak_mem_ref_bytes covers THIS unit only
        if recheck_ref or eta_ref is None or level_mismatch:
            t0 = time.perf_counter()
            e_new = _eta_on_ref(binary, target, pix, ref_level)
            row["timing"]["eta_ref_s"] = time.perf_counter() - t0
            row["eta_ref_s4_2"] = eta_ref
            row["eta_ref_recheck_delta"] = (
                e_new - eta_ref if eta_ref is not None else None)
            eta_ref = e_new
            row["eta_ref_source"] = "recomputed"
        else:
            row["eta_ref_source"] = "s4_2_json"
        row["eta_ref"] = eta_ref
        row["geometry"] = geometry(binary, cfg)
        row["roundtrip"] = {}
        for pix_to in quantize_to:
            if pix_to < pix:
                continue
            row["roundtrip"][str(pix_to)] = roundtrip(
                binary, pix, pix_to, target, ref_level, eta_ref,
                fill_matched=(pix_to in fill_matched_to))
        row["peak_mem_ref_bytes"] = _peak_bytes()
    if latent is None:
        missing.append("delivered_latent")
    if binary is None and latent is None:
        row["spectrum"] = None
    else:
        row["spectrum"] = spectrum(latent, binary, cfg, pix)
    if row.get("best_audit_eta") is not None and eta_ref:
        row["self_bias_rel"] = (row["best_audit_eta"] - eta_ref) / eta_ref
        row["self_bias_abs"] = row["best_audit_eta"] - eta_ref
        row["self_bias"] = row["self_bias_rel"]
        row["self_minus_ref"] = row["self_bias_abs"]
    row["missing"] = missing
    _free()
    return row


def save_design(pix, target, seed, binary, latent) -> Dict[str, str]:
    """np.save under data/designs/ with the name fixed by the S4-3 spec.

    ``s4_common.save_arrays`` writes into data/ root and returns basenames; the
    S4-3 spec puts designs in data/designs/, so this is a local copy that keeps
    the path relative to data/ in the JSON (traceable either way).
    """
    os.makedirs(DESIGNS, exist_ok=True)
    tag = "s4_3_p%dnm_%d_%d_seed%d" % (pix, target[0], target[1], seed)
    np.save(os.path.join(DESIGNS, tag + "_binary.npy"),
            binary.detach().cpu().numpy())
    np.save(os.path.join(DESIGNS, tag + "_latent.npy"),
            latent.detach().cpu().numpy())
    # The prefix follows the ACTUAL directory: --dry-run redirects DESIGNS to
    # designs_dry/, and a recorded path that still said designs/ would point a
    # reader at the real deliverable of the same name.
    rel = os.path.basename(DESIGNS.rstrip("\\/")) + "/"
    return {"binary": rel + tag + "_binary.npy",
            "latent": rel + tag + "_latent.npy"}

def _parse_pixels(spec: str) -> List[int]:
    """--pixels tokens -> a deduplicated, order-preserving list of legal arms."""
    out: List[int] = []
    for tok in str(spec).split(","):
        tok = tok.strip()
        if not tok:
            continue
        try:
            p = int(tok)
        except ValueError:
            raise SystemExit("--pixels: %r is not an integer (expected a "
                             "comma-separated subset of %r)"
                             % (tok, list(ALLOWED_PIXELS)))
        if p not in ALLOWED_PIXELS:
            raise SystemExit("--pixels may only contain %r, got %r"
                             % (list(ALLOWED_PIXELS), p))
        if p not in out:
            out.append(p)
    if not out:
        raise SystemExit("--pixels selected nothing")
    return out


def _parse_fill_matched(spec: str) -> Tuple[int, ...]:
    if str(spec).strip().lower() in ("none", "off", ""):
        return ()
    out = []
    for tok in str(spec).split(","):
        tok = tok.strip()
        if not tok:
            continue
        try:
            p = int(tok)
        except ValueError:
            raise SystemExit("--fill-matched-to: %r is not an integer" % tok)
        if p not in QUANTIZE_TO:
            raise SystemExit("--fill-matched-to may only name round-trip "
                             "targets %r, got %r" % (list(QUANTIZE_TO), p))
        if p not in out:
            out.append(p)
    return tuple(out)


def _gpu_precheck(args) -> Optional[Dict[str, object]]:
    """Refuse to start on a card someone else is already using.

    The S4 brief requires the three scripts to run SERIALLY: a sibling job both
    inflates every wall clock (the whole point of measurement 1) and can push
    the (40,10) reference solve, which peaks at ~2.9 GiB, into an OOM two hours
    into the queue.  Checked once, up front, before any GPU work.
    """
    if not torch.cuda.is_available():
        return None
    free_b, total_b = torch.cuda.mem_get_info()
    tel = gpu_telemetry()
    print("  GPU memory free %.2f / %.2f GiB%s"
          % (free_b / 2 ** 30, total_b / 2 ** 30,
             ("   [SM %.0f MHz, %.0f C, util %.0f%%]"
              % (tel.get("clocks_sm", float("nan")),
                 tel.get("temperature_gpu", float("nan")),
                 tel.get("utilization_gpu", float("nan"))))
             if isinstance(tel.get("clocks_sm"), float) else ""), flush=True)
    need = 4 * 2 ** 30
    if free_b < need and not args.ignore_gpu_check:
        raise SystemExit(
            "only %.2f GiB free on the card; the (40,10) reference solve peaks "
            "at ~2.9 GiB and S4 is specified to run serially.  Something else "
            "is resident -- stop it, or pass --ignore-gpu-check to override."
            % (free_b / 2 ** 30))
    return tel


def _backup_existing(path: str, resume: bool) -> Optional[str]:
    """Never silently discard a finished store when --resume was forgotten.

    ``resume_store(resume=False)`` hands back an empty store and the first
    ``save_json`` overwrites the file -- before a single unit has been redone.
    Losing that costs every timing, geometry, spectrum and round-trip number in
    it, none of which is reconstructible from the saved ``.npy`` masks.
    """
    if resume or not os.path.exists(path):
        return None
    old = s4c.load_json(path, None) or {}
    if not old.get("units"):
        return None
    bak = "%s.bak-%s" % (path, time.strftime("%Y%m%dT%H%M%SZ", time.gmtime()))
    os.replace(path, bak)
    print("NOTE: %s already held %d finished unit(s) and --resume was NOT "
          "given.  It has been moved to %s rather than overwritten; re-run "
          "with --resume to continue it instead."
          % (os.path.basename(path), len(old["units"]),
             os.path.basename(bak)), flush=True)
    return bak


GUARDED_CONFIG = ("descent_level", "audit_level", "ref_level", "n_steps",
                  "audit_every", "quantize_to_nm", "ref_level_is_frozen",
                  "fill_matched_to_nm")


def _merge_config(store: Dict, new_cfg: Dict) -> Dict:
    """Append-only config on --resume; abort on a protocol change.

    A store's ``config`` is what a reader uses to interpret every row in it.
    Overwriting it on resume would relabel rows produced under different
    settings -- and, with ``--out`` bypassing the ``_dry`` stem rule, could
    stamp ``ref_level_is_frozen: true`` over 7-step dry rows.
    """
    old = store.get("config")
    if not old:
        store["config"] = new_cfg
        return new_cfg
    diff = {k: [old.get(k), new_cfg.get(k)] for k in GUARDED_CONFIG
            if old.get(k) != new_cfg.get(k)}
    if diff:
        raise SystemExit(
            "--resume against a store built under a DIFFERENT protocol: %r.\n"
            "Units already in it were produced under the old settings and "
            "cannot be merged with the new ones.  Use a different --out."
            % (diff,))
    merged = dict(new_cfg)
    merged["pixels_run"] = sorted(set(old.get("pixels_run", []))
                                  | set(new_cfg.get("pixels_run", [])),
                                  reverse=True)
    store.setdefault("config_history", []).append(old)
    store["config"] = merged
    return merged


def main(argv=None) -> int:
    global DESIGNS
    ap = argparse.ArgumentParser(
        description="S4-3: design pixel at fixed truncation order (20,5)")
    s4c.add_common_args(ap, default_seeds=8)
    ap.add_argument("--pixels", type=str,
                    default=",".join(str(p) for p in DEFAULT_RUN_PIXELS),
                    help="arms to RUN, subset of %r.  10 nm is normally REUSED "
                         "from S4-2 rather than run; naming it here runs it "
                         "natively instead (+~1.3 h, three same-instrument "
                         "points on the time axis) and disables the reuse arm"
                         % (list(ALLOWED_PIXELS),))
    ap.add_argument("--s4-2-json", type=str, default=None,
                    help="path to S4-2's store (default: auto-detect in data/)")
    ap.add_argument("--skip-s4-2", action="store_true",
                    help="do not read the 10 nm arm at all")
    ap.add_argument("--reuse-10nm-ref", action="store_true",
                    help="trust S4-2's reference value for the 10 nm arm "
                         "instead of re-solving it here (saves ~8 min, but the "
                         "round-trip delta then subtracts two numbers this "
                         "script did not both produce)")
    ap.add_argument("--no-roundtrip-10", action="store_true",
                    help="skip the extra 5nm->10nm round trip (saves ~9 min)")
    ap.add_argument("--fill-matched-to", type=str, default="20",
                    help="round-trip targets (nm) that also get a FILL-MATCHED "
                         "re-threshold, which separates the CD bias of the "
                         "0.5 tie rule from the boundary quantization "
                         "(~+18 min for '20'); 'none' to skip")
    ap.add_argument("--ignore-init-check", action="store_true",
                    help="run even if the paired-initial agreement exceeds 5%%")
    ap.add_argument("--ignore-gpu-check", action="store_true",
                    help="start even if another job holds the card")
    ap.add_argument("--dry-full-ref", action="store_true",
                    help="in --dry-run, still use the real (40,10) reference")
    ap.add_argument("--dry-real-levels", action="store_true",
                    help="in --dry-run, descend at the real (20,5) instead of "
                         "the cheap substitute order (slower self-check)")
    args = ap.parse_args(argv)

    n_steps, audit_every = s4c.dry_apply(args)
    targets = s4c.parse_targets(args.targets)
    pixels = _parse_pixels(args.pixels)
    fill_matched_to = _parse_fill_matched(args.fill_matched_to)
    ref_level = s4c.REF_LEVEL
    desc_lv, aud_lv = DESCENT_LEVEL, AUDIT_LEVEL
    if args.dry_run:
        targets = targets[:1]
        if not args.dry_full_ref:
            ref_level = DRY_REF_LEVEL
        if not args.dry_real_levels:
            desc_lv, aud_lv = DRY_DESCENT_LEVEL, DRY_AUDIT_LEVEL
            # The cheap substitute must not hide an illegality in the real
            # thing: the frozen orders are still checked on every grid an arm
            # would use, they are just not solved at.
            for p in pixels:
                s4c.check_level(DESCENT_LEVEL, s4c.PIX[p], "frozen descent level")
                s4c.check_level(AUDIT_LEVEL, s4c.PIX[p], "frozen audit level")
            s4c.check_level(s4c.REF_LEVEL, s4c.REF_CFG, "frozen reference level")
    quantize_to = tuple(p for p in QUANTIZE_TO
                        if not (p == 10 and args.no_roundtrip_10))
    fill_matched_to = tuple(p for p in fill_matched_to if p in quantize_to)
    DESIGNS = os.path.join(s4c.DATA,
                           "designs_dry" if args.dry_run else "designs")
    # 10 nm can be a RUN arm or a REUSE arm, never both: they would collide on
    # the same unit key and the second would silently overwrite the first.
    run_ten = REUSE_PIXEL in pixels
    if run_ten and not args.skip_s4_2:
        print("note: --pixels names %d nm, so it is RUN natively here and the "
              "S4-2 reuse arm is disabled (one unit key per pixel)."
              % REUSE_PIXEL, flush=True)
    use_s4_2 = not (args.skip_s4_2 or run_ten)

    seeds_by_target = {t: s4c.seeds_for(t, args.n_seeds) for t in targets}
    n_new = len(targets) * len(pixels) * args.n_seeds
    per_unit = s4c.estimate_run_s(desc_lv, aud_lv, n_steps, audit_every)
    ref_cost = s4c.cost_s(ref_level, "fwd")
    if args.dry_run and ref_level != s4c.REF_LEVEL:
        # the anchors are for the 20 nm grid; a dry ref solves on (140,480)
        ref_cost *= 3.0
    def _n_ref_solves(p: int, is_reuse: bool = False) -> int:
        """Reference-order solves one unit at pixel ``p`` costs."""
        rts = [q for q in quantize_to if q > p]
        n = len(rts) + len([q for q in rts if q in fill_matched_to])
        if not is_reuse or not args.reuse_10nm_ref:
            n += 1                              # the delivered mask's own score
        return n

    est_unit = {p: per_unit + _n_ref_solves(p) * ref_cost for p in pixels}
    est = sum(len(targets) * args.n_seeds * est_unit[p] for p in pixels)
    # the reuse arm's share is added once the ingest says how many rows it
    # actually matched (S4-2 fills its arms in order, so it is often partial)
    est_reuse_per_unit = _n_ref_solves(REUSE_PIXEL, is_reuse=True) * ref_cost
    if use_s4_2:
        est += len(targets) * args.n_seeds * est_reuse_per_unit

    params = dict(vars(args))
    params.update({"n_steps": n_steps, "audit_every": audit_every,
                   "targets_resolved": [list(t) for t in targets],
                   "pixels_run": pixels, "ref_level": list(ref_level),
                   "descent_level": list(desc_lv), "audit_level": list(aud_lv),
                   "quantize_to": list(quantize_to),
                   "fill_matched_to": list(fill_matched_to),
                   "designs_dir": os.path.basename(DESIGNS)})
    path = s4c.out_path(args, SCRIPT)
    s4c.banner(SCRIPT, args, est)
    if not torch.cuda.is_available():
        print("FATAL: no CUDA device.  S4 runs GPU/complex64 by decision "
              "D-011; refusing to fall back to CPU.", flush=True)
        return 2
    print("  descent/audit order %r/%r%s; %d new units (+%d reused)"
          % (desc_lv, aud_lv,
             "   [DRY SUBSTITUTE -- frozen order is %r]" % (DESCENT_LEVEL,)
             if desc_lv != DESCENT_LEVEL else "",
             n_new, len(targets) * args.n_seeds if use_s4_2 else 0), flush=True)
    print("  reference: %r on grid %r%s"
          % (ref_level, list(s4c.REF_SHAPE),
             "   [DRY-RUN SUBSTITUTE -- not (40,10)]"
             if ref_level != s4c.REF_LEVEL else ""), flush=True)
    print("  round trips to %r nm, fill-matched control at %r nm"
          % (list(quantize_to), list(fill_matched_to) or "none"), flush=True)
    print("  designs: %s" % DESIGNS, flush=True)
    print("  out: %s" % path, flush=True)
    tel0 = _gpu_precheck(args)

    _backup_existing(path, args.resume)
    store = s4c.resume_store(path, SCRIPT, params, args.resume)
    new_cfg = {
        "descent_level": list(desc_lv), "audit_level": list(aud_lv),
        "frozen_descent_level": list(DESCENT_LEVEL),
        "pixels_run": sorted(pixels, reverse=True),
        "pixel_reused": None if not use_s4_2 else REUSE_PIXEL,
        "ten_nm_run_natively": bool(run_ten),
        "s4_2_arm": S4_2_ARM,
        "ref_level": list(ref_level), "ref_level_is_frozen":
            list(ref_level) == list(s4c.REF_LEVEL),
        "ref_grid": list(s4c.REF_SHAPE),
        "n_steps": n_steps, "audit_every": audit_every,
        "quantize_to_nm": list(quantize_to),
        "fill_matched_to_nm": list(fill_matched_to),
        "seeds": {str(list(t)): seeds_by_target[t] for t in targets},
        "paired_initials": True,
        "reading_notes": [
            "SPECTRUM: read spectrum.*_ref, never spectrum.*_native.  The "
            "native fractions are measured on each arm's own grid, where the "
            "20 nm arm has no bin beyond its own Nyquist and so scores an "
            "identical 0 by construction; on the common (140,480) grid -- the "
            "one the reference solve sees -- the same masks order the other "
            "way round.  summarize aggregates the _ref variants.",
            "SPECTRUM: filtered_latent is bounded by the filter's own |H|^2 "
            "beyond the coarse Nyquist (~1e-20), i.e. below the float64 FFT "
            "noise floor.  It is not a measurable physical quantity; report "
            "delivered_binary_ref and cite filter_transfer_ref as the ceiling.",
            "TIME: timing.audit_solve is a pure forward at the SAME order "
            "(%r) on two different grids, so IT -- not wall_s -- is the "
            "controlled test of whether solve cost depends on the design "
            "pixel.  timing.solve also contains the design map's forward and "
            "backward and the eps/FFT build; probe.map_value_grad and "
            "probe.value_grad_at_%d_%d attribute those."
            % (list(aud_lv), PROBE_LEVEL[0], PROBE_LEVEL[1]),
            "TIME: every arm's timing.wall_s is end to end (the 10 nm arm uses "
            "S4-2's run_wall_s, not its attributed wall_s).  Arm order is "
            "alternated per seed and gpu telemetry is sampled per unit, so "
            "clock drift can be checked rather than assumed.",
            "GEOMETRY: boundary_px is NOT comparable across pixels (a block "
            "replication multiplies it); interface_len_nm is invariant and is "
            "the one the summary aggregates.",
        ],
        "deviations": [
            "descent loop is a locally timed copy; --dry-run verifies it is "
            "trajectory-identical to BOTH s4_common.run_descent and "
            "s4_2_descent_order.run_multi_audit (the latter is what actually "
            "produced the reused 10 nm arm)",
            "designs go to data/designs/ (not save_arrays' data/ root)",
            "the 5nm->10nm round trip is an addition beyond the S4-3 spec, "
            "off with --no-roundtrip-10",
            "the fill-matched round-trip control is an addition beyond the "
            "S4-3 spec, off with --fill-matched-to none",
            "the reused 10 nm arm's reference score is re-solved here by "
            "default (cross-check in eta_ref_recheck_delta); --reuse-10nm-ref "
            "trusts S4-2's number instead",
        ],
    }
    _merge_config(store, new_cfg)
    store.setdefault("gpu_telemetry", {})["start"] = tel0

    # ---- paired-initial self-check (prereg kill criterion: rel > 5%)
    print("paired-initial agreement across 20/10/5 nm:", flush=True)
    agree, worst = {}, 0.0
    for t in targets:
        for seed in seeds_by_target[t]:
            a = s4c.init_field_agreement(seed)
            agree[str(seed)] = a
            worst = max(worst, max(a["rel_l2_vs_5nm"].values()))
    print("  worst relative L2 vs 5 nm over %d seeds: %.3e"
          % (len(agree), worst), flush=True)
    # merge, so a resume with a different --targets/--n-seeds does not drop the
    # agreement records of the seeds it is not running this time
    store.setdefault("init_agreement", {}).update(agree)
    store["init_agreement_worst_rel"] = max(
        worst, float(store.get("init_agreement_worst_rel") or 0.0))
    store["init_agreement_pass"] = bool(store["init_agreement_worst_rel"] <= 0.05)
    s4c.save_json(path, store)
    if worst > 0.05 and not args.ignore_init_check:
        print("ABORT: paired-initial disagreement %.3e exceeds the 5%% kill "
              "criterion in the prereg; the pairing premise does not hold. "
              "Re-run with --ignore-init-check only after deciding why."
              % worst, flush=True)
        return 2

    # ---- dry-run only: prove the timed loop matches both originals
    if args.dry_run:
        print("parity check vs s4_common.run_descent AND "
              "s4_2_descent_order.run_multi_audit ...", flush=True)
        pc = parity_check(targets[0], seeds_by_target[targets[0]][0],
                          s4c.PIX[pixels[0]], n_steps, audit_every,
                          descent_level=desc_lv, audit_level=aud_lv)
        store["parity_check"] = pc
        for name in ("vs_s4_common_run_descent", "vs_s4_2_run_multi_audit"):
            v = pc.get(name) or {}
            if "binary_equal" in v:
                print("  %-28s binary_equal=%s latent_equal=%s max|d audit|=%.3e"
                      % (name, v["binary_equal"], v["latent_equal"],
                         v["max_abs_audit_diff"]), flush=True)
            else:
                print("  %-28s NOT CHECKED: %s"
                      % (name, v.get("error")), flush=True)
        s4c.save_json(path, store)

    # ---- the 10 nm arm, read back from S4-2
    s4_2 = {"available": False, "rows": {},
            "problems": ["10 nm arm run natively (--pixels)" if run_ten
                         else "skipped by --skip-s4-2"]}
    s4_2_path = None
    if use_s4_2:
        s4_2_path = _find_s4_2(args.s4_2_json)
        s4_2 = load_s4_2(s4_2_path, targets, seeds_by_target,
                         n_steps=n_steps, audit_every=audit_every)
        n_have, n_want = len(s4_2["rows"]), len(targets) * args.n_seeds
        print("S4-2 (%s arm, %d nm): %s"
              % (S4_2_ARM, REUSE_PIXEL,
                 ("%d/%d rows from %s" % (n_have, n_want,
                                          os.path.basename(s4_2_path or "-")))
                 if s4_2["available"] else "NOT AVAILABLE"), flush=True)
        if s4_2["available"] and n_have < n_want:
            print("  WARNING: %d of %d 10 nm rows are missing -- S4-2 fills its "
                  "arms in order, so L20 may simply not have run yet.  This "
                  "store will be short those units; --resume later to add them."
                  % (n_want - n_have, n_want), flush=True)
        for p in s4_2["problems"][:6]:
            print("    note: %s" % p, flush=True)
    n_rows = len(s4_2.get("rows", {}))
    n_expected = len(targets) * args.n_seeds
    store["s4_2_ingest"] = {
        "path": s4_2.get("path"), "available": s4_2.get("available"),
        "arm": S4_2_ARM, "n_rows": n_rows, "n_expected": n_expected,
        "match": s4_2.get("match"),
        "problems": s4_2.get("problems", []),
        # "available" only means the file parsed; what matters is whether any
        # row actually MATCHED.  S4-2 completes its arms in order, so an L20
        # that has not been reached yet is the DEFAULT state early on, not an
        # edge case.
        "ten_nm_missing": bool(use_s4_2 and n_rows == 0),
        "ten_nm_partial": bool(use_s4_2 and 0 < n_rows < n_expected),
        "ten_nm_run_natively": bool(run_ten),
        "sha1_verified": sum(1 for r in s4_2.get("rows", {}).values()
                             if r.get("mask_sha1_match") is True),
    }
    if use_s4_2:
        # revise the budget now that the actual number of reusable rows is known
        est = (sum(len(targets) * args.n_seeds * est_unit[p] for p in pixels)
               + n_rows * est_reuse_per_unit)
        print("  revised estimate with %d reusable 10 nm row(s): %s"
              % (n_rows, s4c.fmt_s(est)), flush=True)
    store["estimate_s"] = est
    s4c.save_json(path, store)

    # ---- work list.  Alternating the arm order per seed keeps any position
    # effect (thermal drift over a 4 h queue, cache warmth) from aliasing onto
    # the pixel axis: a fixed order would put 20 nm first in all 24 pairs.
    work = []
    for t in targets:
        for seed in seeds_by_target[t]:
            order = list(pixels) if (seed % 2 == 0) else list(reversed(pixels))
            for p in order:
                work.append(("run", t, seed, p))
            if s4_2.get("available"):
                rk = "%s|%d" % (s4c.unit_key(t), seed)
                if rk in s4_2["rows"]:
                    work.append(("reuse", t, seed, REUSE_PIXEL))

    def _key(kind, t, seed, p):
        # the reuse arm always carries the frozen order in its key: it really
        # was descended at (20,5), whatever this invocation is descending at
        return s4c.unit_key(t, p, desc_lv if kind == "run" else DESCENT_LEVEL,
                            seed)

    # One discarded low-order solve so the first unit of the first arm does not
    # absorb the cuFFT plan / cuSOLVER workspace setup for a new shape.
    print("warm-up solve at %r ..." % (PROBE_LEVEL,), flush=True)
    t_warm = time.perf_counter()
    for p in pixels:
        s4c.eta(torch.zeros(s4c.PIX[p].shape, dtype=torch.float64),
                PROBE_LEVEL, targets[0], s4c.PIX[p])
    store["warmup_s"] = time.perf_counter() - t_warm
    print("  %s (discarded)" % s4c.fmt_s(store["warmup_s"]), flush=True)
    _free()

    t_start = time.perf_counter()
    done = 0
    for kind, t, seed, p in work:
        key = _key(kind, t, seed, p)
        if args.resume and s4c.unit_done(store, key):
            print("[skip] %s (already done)" % key, flush=True)
            continue
        t0 = time.perf_counter()
        tel = gpu_telemetry()
        try:
            if kind == "run":
                print("[run ] %s  (est %s)"
                      % (key, s4c.fmt_s(est_unit[p])), flush=True)
                row = unit_row_new(t, seed, p, n_steps, audit_every, ref_level,
                                   quantize_to, args.progress_every,
                                   descent_level=desc_lv, audit_level=aud_lv,
                                   fill_matched_to=fill_matched_to)
            else:
                print("[10nm] %s  (reuse from S4-2)" % key, flush=True)
                row = unit_row_reuse(t, seed,
                                     s4_2["rows"]["%s|%d" % (s4c.unit_key(t), seed)],
                                     ref_level, quantize_to,
                                     not args.reuse_10nm_ref,
                                     fill_matched_to=fill_matched_to)
        except Exception as exc:
            # One unit must not take the queue with it.  The most likely cause
            # is a transient OOM (another process grabbing memory); the failed
            # unit stays OUT of "units", so a later --resume simply redoes it.
            _free()
            store.setdefault("failures", []).append(
                {"key": key, "kind": kind, "target": list(t), "seed": int(seed),
                 "pixel_nm": int(p),
                 "error": "%s: %s" % (type(exc).__name__, exc),
                 "gpu": tel,
                 "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())})
            s4c.save_json(path, store)
            print("       FAILED (%s: %s) -- recorded in store['failures'] and "
                  "skipped; --resume will retry it"
                  % (type(exc).__name__, exc), flush=True)
            continue
        row["unit_wall_s"] = time.perf_counter() - t0
        row["gpu_at_start"] = tel
        row["work_order_index"] = len(store.get("units", {}))
        s4c.record_unit(store, key, row, path)
        done += 1
        rt = row.get("roundtrip") or {}
        rt20 = (rt.get("20") or {}).get("delta_eta")
        print("       eta_ref %s | self %s | d_eta(->20nm) %s | %s"
              % (_f(row.get("eta_ref")), _f(row.get("best_audit_eta")),
                 _f(rt20, "%+.4f"), s4c.fmt_s(row["unit_wall_s"])), flush=True)
        # keep the summary current, so a killed run still leaves a readable one
        store["summary"] = summarize(store)
        s4c.save_json(path, store)
        el = time.perf_counter() - t_start
        left = len([w for w in work if not s4c.unit_done(store, _key(*w))])
        print("       %d done this session, %d left, %s elapsed, ~%s left"
              % (done, left, s4c.fmt_s(el), s4c.fmt_s(el / done * left)),
              flush=True)

    store.setdefault("meta", {})["finished_utc"] = time.strftime(
        "%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    store.setdefault("gpu_telemetry", {})["end"] = gpu_telemetry()
    store["summary"] = summarize(store)
    s4c.save_json(path, store)
    print("=" * 72, flush=True)
    print("wrote %s (%d units, %d failure(s), %s total)"
          % (path, len(store.get("units", {})), len(store.get("failures", [])),
             s4c.fmt_s(time.perf_counter() - t_start)), flush=True)
    for line in _summary_lines(store["summary"]):
        print("  " + line, flush=True)
    if store.get("failures"):
        print("  %d unit(s) failed and were skipped; re-run with --resume"
              % len(store["failures"]), flush=True)
    return 0


def _f(v, fmt="%.4f"):
    return "n/a" if v is None else fmt % v


_SUMMARY_FIELDS = (
    "eta_ref", "self", "delta_rt20", "delta_rt20_fill_matched",
    "delta_rt20_cd_bias", "delta_rt10",
    "wall_s", "wall_s_attributed", "solve_median_s", "overhead_median_s",
    "audit_solve_median_s", "audit_map_median_s",
    "fill", "interface_len_nm", "tie_fraction_rt20", "fill_shift_rt20",
    # comparable, common-grid spectrum (the ones to report)
    "binary_frac_beyond_nyq20_ac_ref", "binary_frac_beyond_nyq10_ac_ref",
    "filtered_frac_beyond_nyq20_ac_ref",
    # native-grid companions, kept only as the self-check
    "binary_frac_beyond_nyq20_ac_native", "filtered_frac_beyond_nyq20_ac_native",
)


def summarize(store: Dict) -> Dict[str, object]:
    """Per-(pixel,target) descriptive aggregates.  Numbers only, no reading.

    The spectrum aggregates are the ``_ref`` (common (140,480) grid) ones.  The
    ``_native`` variants are carried alongside them only so a reader can see
    that the 20 nm arm's native beyond-Nyquist share is 0 by construction --
    aggregating THAT across arms would report the ordering backwards.
    """
    out: Dict[str, object] = {}

    def _num(v):
        return isinstance(v, (int, float)) and not isinstance(v, bool)

    for key, row in store.get("units", {}).items():
        if not isinstance(row, dict):
            continue
        k = "p%dnm|%s" % (row.get("pixel_nm", -1),
                          "-".join(str(v) for v in row.get("target", [])))
        b = out.setdefault(k, dict({"n": 0, "arms": []},
                                   **{f: [] for f in _SUMMARY_FIELDS}))
        b["n"] += 1
        if row.get("arm") not in b["arms"]:
            b["arms"].append(row.get("arm"))
        for src, dst in (("eta_ref", "eta_ref"), ("best_audit_eta", "self")):
            v = row.get(src)
            if _num(v):
                b[dst].append(v)
        rt_all = row.get("roundtrip") or {}
        rt = rt_all.get("20") or {}
        if _num(rt.get("delta_eta")):
            b["delta_rt20"].append(rt["delta_eta"])
        for src, dst in (("tie_fraction", "tie_fraction_rt20"),
                         ("fill_shift", "fill_shift_rt20")):
            if _num(rt.get(src)):
                b[dst].append(rt[src])
        fm = rt.get("fill_matched") or {}
        if _num(fm.get("delta_eta")):
            b["delta_rt20_fill_matched"].append(fm["delta_eta"])
        if _num(fm.get("delta_eta_vs_plain")):
            b["delta_rt20_cd_bias"].append(fm["delta_eta_vs_plain"])
        rt10 = rt_all.get("10") or {}
        if _num(rt10.get("delta_eta")):
            b["delta_rt10"].append(rt10["delta_eta"])
        tm = row.get("timing") or {}
        for src, dst in (("wall_s", "wall_s"),
                         ("wall_s_attributed", "wall_s_attributed")):
            if _num(tm.get(src)):
                b[dst].append(tm[src])
        for src, dst in (("solve", "solve_median_s"),
                         ("overhead", "overhead_median_s"),
                         ("audit_solve", "audit_solve_median_s"),
                         ("audit_map", "audit_map_median_s")):
            blk = tm.get(src)
            v = blk.get("median") if isinstance(blk, dict) else None
            if _num(v):
                b[dst].append(v)
        g = row.get("geometry") or {}
        for src, dst in (("fill_fraction", "fill"),
                         ("interface_len_nm", "interface_len_nm")):
            if _num(g.get(src)):
                b[dst].append(g[src])
        sp = row.get("spectrum") or {}
        for src, frac, dst in (
                ("delivered_binary_ref", "frac_beyond_nyq20_ac",
                 "binary_frac_beyond_nyq20_ac_ref"),
                ("delivered_binary_ref", "frac_beyond_nyq10_ac",
                 "binary_frac_beyond_nyq10_ac_ref"),
                ("filtered_latent_ref", "frac_beyond_nyq20_ac",
                 "filtered_frac_beyond_nyq20_ac_ref"),
                ("delivered_binary_native", "frac_beyond_nyq20_ac",
                 "binary_frac_beyond_nyq20_ac_native"),
                ("filtered_latent_native", "frac_beyond_nyq20_ac",
                 "filtered_frac_beyond_nyq20_ac_native")):
            v = (sp.get(src) or {}).get(frac)
            if _num(v):
                b[dst].append(v)
    for k, b in out.items():
        agg = {"n": b["n"], "arms": b["arms"]}
        for field, xs in b.items():
            if field in ("n", "arms"):
                continue
            agg[field] = _stats(xs)
        agg["note"] = ("spectrum aggregates ending _ref are the comparable "
                       "ones; _native is grid-dependent (0 by construction at "
                       "20 nm)")
        out[k] = agg
    return out


def _summary_lines(summary: Dict) -> List[str]:
    """One line per (pixel,target).  Comparable quantities only.

    ``self`` (each arm's own (20,5) audit) is deliberately NOT printed side by
    side: it is taken on a different grid in every arm, so a reader scanning
    the column would be comparing three different measurements.  ``eta_ref``
    and ``audit_solve`` are the controlled ones.
    """
    lines = ["(eta_ref and audit_solve are the cross-arm comparable columns; "
             "each arm's own audit is in the JSON, not here)"]
    for k in sorted(summary):
        a = summary[k]
        lines.append(
            "%-14s n=%-3d eta_ref med %s | d(->20nm) med %s | CD-bias med %s | "
            "solve med %s s | audit_solve med %s s | wall med %s"
            % (k, a.get("n", 0),
               _f((a.get("eta_ref") or {}).get("median")),
               _f((a.get("delta_rt20") or {}).get("median"), "%+.4f"),
               _f((a.get("delta_rt20_cd_bias") or {}).get("median"), "%+.4f"),
               _f((a.get("solve_median_s") or {}).get("median"), "%.3f"),
               _f((a.get("audit_solve_median_s") or {}).get("median"), "%.3f"),
               s4c.fmt_s((a.get("wall_s") or {}).get("median") or 0.0)
               + ("  [S4-2 run_wall_s]"
                  if a.get("arms") == ["s4_2_reuse"] else "")))
    return lines


if __name__ == "__main__":
    raise SystemExit(main())
