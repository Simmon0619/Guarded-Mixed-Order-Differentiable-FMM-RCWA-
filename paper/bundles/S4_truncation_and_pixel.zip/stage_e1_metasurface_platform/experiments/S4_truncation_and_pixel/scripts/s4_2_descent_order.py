"""S4-2: what the truncation order does during optimization (CPC section 4).

Descriptive only.  This script produces numbers and writes them to disk.  It
makes no claim about what they mean; every qualitative statement belongs in
``S4_实验记录.md``, written later from this JSON.

Design pixel is FIXED at 10 nm (grid 70x240).  The budget is EQUAL STEPS (219),
so the descent order is the only independent variable; wall clock is recorded
as a result, never used as a control.  Five arms:

    arm    descent    audit/selection   note
    L12    (12,3)     (12,3)            fixed order, self-selected
    L16    (16,4)     (16,4)            fixed order, self-selected
    L20    (20,5)     (20,5)            fixed order, self-selected
    L24    (24,6)     (24,6)            fixed order, self-selected
    CERT   (16,4)     (24,6)            certification arm: cheap descent,
                                        high-order verification + selection

L16 and CERT are run as ONE descent that carries two running bests (one scored
at (16,4), one at (24,6)).  Their trajectories are therefore bitwise identical
by construction, not merely nominally paired -- this is stated in every row
(``fused``/``fused_with``/``trajectory_id``/``wall_is_shared``) so no reader
mistakes them for two independent runs.  ``--no-fuse`` runs them as two
separate descents instead (that is the mode to use if a per-arm wall clock for
L16 alone is ever needed).

Every delivered hard mask is then block-replicated to the common 5 nm grid
(140,480) and scored at the reference order (40,10).  That number, ``eta_ref``,
is what the protocol treats as the truth; ``self_eta`` is the arm's own
running-best.  The self-report bias is recorded in three pieces because it is
NOT a pure truncation effect:

    self_bias_rel        (self_eta - eta_ref) / eta_ref
                         truncation AND grid representation mixed together
    self_bias_rel_trunc  (self_eta - eta_ref_native) / eta_ref_native
                         pure truncation: both numbers on the arm's own
                         (70,240) grid
    ref_grid_shift_rel   (eta_ref_native - eta_ref) / eta_ref
                         pure grid: the same order (40,10) evaluated on
                         (70,240) versus the lifted (140,480)

``eta_ref_native`` therefore runs BY DEFAULT (``--no-ref-native`` turns it off,
saving roughly 45 min of the ~7 h total).  Reviewers measured the grid term at
1e-2 relative on delivered masks and 1e-1 on unoptimized ones, i.e. the same
order as the quantity being measured, so it is not optional bookkeeping.

    python s4_2_descent_order.py                  # full run, ~7 h
    python s4_2_descent_order.py --dry-run        # ~1 min self-check
    python s4_2_descent_order.py --resume         # continue an interrupted run
    python s4_2_descent_order.py --skip-ref       # descents now, refs later
    python s4_2_descent_order.py --resume         # ... fills the pending refs

A store that already holds rows is never overwritten: re-running without
``--resume`` refuses and says so (``--force`` to discard deliberately).  A
``.lock`` file next to the store refuses a second concurrent run, because S4
wall clock is a RESULT and two processes on one GPU contaminate it.

Output: ../data/s4_2_descent_order.json  (../data/s4_2_descent_order_dry.json
for --dry-run), masks and latents under ../data/designs/.
"""
import argparse
import hashlib
import json
import math
import os
import statistics
import sys
import time
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

import s4_common as S                                    # noqa: E402
from s4_common import C                                  # noqa: E402

SCRIPT = "s4_2_descent_order.py"

# ------------------------------------------------------------------- design
PIXEL_NM = 10
CFG = S.PIX[PIXEL_NM]                                    # (70, 240), GPU/c64

# (name, descent level, audit/selection level)
ARMS: Tuple[Tuple[str, Tuple[int, int], Tuple[int, int]], ...] = (
    ("L12",  (12, 3), (12, 3)),
    ("L16",  (16, 4), (16, 4)),
    ("L20",  (20, 5), (20, 5)),
    ("L24",  (24, 6), (24, 6)),
    ("CERT", (16, 4), (24, 6)),
)
ARM_ORDER = [n for n, _, _ in ARMS]
ARM_SPEC = {n: (d, a) for n, d, a in ARMS}
FUSE_PAIR = ("L16", "CERT")          # identical descent level -> one trajectory

# --dry-run: 1 target, 1 seed, 6 steps, only the two lowest descent orders.
# CERT survives because its DESCENT order is (16,4); dropping it would leave
# the one arm whose audit path differs from its descent path untested.
DRY_STEPS = 6
DRY_AUDIT_EVERY = 3
DRY_ARMS = ("L12", "L16", "CERT")
DRY_MAX_REFS = 1        # a (40,10) reference solve is ~25 s; do ONE in a dry
                        # run so the path is exercised, leave the rest pending
WARMUP_SEED = 1         # not in any experiment block; warm-up structures only

DESIGNS = os.path.join(S.DATA, "designs")                # reset in main()


# ------------------------------------------------------------------ helpers
def _sync():
    if torch.cuda.is_available():
        torch.cuda.synchronize()


def _reset_peak():
    if torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats()


def _peak_bytes() -> int:
    return int(torch.cuda.max_memory_allocated()) if torch.cuda.is_available() else 0


def _peak_reserved_bytes() -> int:
    return int(torch.cuda.max_memory_reserved()) if torch.cuda.is_available() else 0


def _gib(b) -> float:
    return float(b) / 2 ** 30


def _utc() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _lv_key(level) -> str:
    return "%d-%d" % (int(level[0]), int(level[1]))


def mask_sha1(binary: torch.Tensor) -> str:
    """Content hash of a 0/1 mask; lets a reader verify arm-to-arm identity."""
    a = np.ascontiguousarray(binary.detach().cpu().numpy().astype(np.uint8))
    return hashlib.sha1(a.tobytes()).hexdigest()


def save_design(tag: str, binary: torch.Tensor, latent: torch.Tensor,
                latent_final: Optional[torch.Tensor] = None) -> Dict[str, str]:
    """np.save mask + latents under ../data/designs/; returns DATA-relative paths.

    ``latent`` is the latent AT THE DELIVERED AUDIT STEP (the running best), not
    the endpoint of the 219-step schedule.  ``latent_final`` is that endpoint,
    saved alongside because the two answer different questions (where the arm
    delivered from, versus where the schedule actually ended up).

    Local rather than ``S.save_arrays`` only because S4-2's deliverables go in
    a ``designs/`` subdirectory (120 masks would otherwise bury the JSONs).
    """
    os.makedirs(DESIGNS, exist_ok=True)
    b_path = os.path.join(DESIGNS, tag + "_binary.npy")
    l_path = os.path.join(DESIGNS, tag + "_latent.npy")
    np.save(b_path, binary.detach().cpu().numpy())
    np.save(l_path, latent.detach().cpu().numpy())
    out = {"binary": os.path.relpath(b_path, S.DATA).replace("\\", "/"),
           "latent": os.path.relpath(l_path, S.DATA).replace("\\", "/")}
    if latent_final is not None:
        f_path = os.path.join(DESIGNS, tag + "_latent_final.npy")
        np.save(f_path, latent_final.detach().cpu().numpy())
        out["latent_final"] = os.path.relpath(f_path, S.DATA).replace("\\", "/")
    return out


def load_design_binary(row: Dict) -> Optional[torch.Tensor]:
    rel = (row.get("files") or {}).get("binary")
    if not rel:
        return None
    path = os.path.join(S.DATA, rel)
    if not os.path.exists(path):
        return None
    return torch.from_numpy(np.load(path))


def design_tag(arm: str, target: Sequence[int], seed: int) -> str:
    return "s4_2_%s_%d_%d_seed%d" % (arm, int(target[0]), int(target[1]), int(seed))


def parse_arms(spec: str) -> List[str]:
    out = []
    for tok in str(spec).split(","):
        tok = tok.strip()
        if not tok:
            continue
        if tok not in ARM_SPEC:
            raise ValueError("unknown arm %r; known arms are %r" % (tok, ARM_ORDER))
        if tok not in out:
            out.append(tok)
    if not out:
        raise ValueError("--arms selected nothing")
    return sorted(out, key=ARM_ORDER.index)


def build_groups(arm_names: Sequence[str], fuse: bool) -> List[Dict]:
    """Group arms into descents.  L16+CERT share one unless ``fuse`` is off."""
    names = list(arm_names)
    groups: List[Dict] = []
    if fuse and all(n in names for n in FUSE_PAIR):
        groups.append({"names": list(FUSE_PAIR),
                       "descent": ARM_SPEC[FUSE_PAIR[0]][0],
                       "audits": [ARM_SPEC[n][1] for n in FUSE_PAIR],
                       "fused": True})
        names = [n for n in names if n not in FUSE_PAIR]
    for n in names:
        d, a = ARM_SPEC[n]
        groups.append({"names": [n], "descent": d, "audits": [a], "fused": False})
    for g in groups:                      # invariant: names[i] <-> audits[i]
        for i, n in enumerate(g["names"]):
            assert ARM_SPEC[n] == (g["descent"], tuple(g["audits"][i])), \
                "group %r contradicts the frozen arm table" % (g["names"],)
    groups.sort(key=lambda g: ARM_ORDER.index(g["names"][0]))
    return groups


def trajectory_id(target, seed, descent_level, group_names) -> str:
    """Two rows with the same id came out of the SAME descent trajectory.

    The group tag is part of the id: under ``--no-fuse`` L16 and CERT share a
    descent LEVEL but are two independent runs, and they must not claim to be
    one trajectory.
    """
    return "%s|%s" % (S.unit_key(target, PIXEL_NM, descent_level, seed),
                      "+".join(group_names))


# ------------------------------------------------------------------- warm-up
def warm_up(groups, do_ref: bool, do_native: bool) -> Dict[str, object]:
    """Pay CUDA's one-off costs BEFORE anything timed, and measure peaks.

    Two problems this solves at once.

    (1) cuFFT plans, cuBLAS/cuSOLVER handles and lazy module loading all land
        on the first heavy call of the process (~+2 s measured at (12,3)).
        Groups run in a fixed order, so without this the first arm reached --
        always L12, and after a --resume whichever arm happens to be first --
        silently carries that cost inside its ``descent_wall_s``.

    (2) ``torch.cuda.max_memory_allocated`` over a fused group is the MAX over
        both arms, so L16's recorded peak would really be CERT's.  Peak memory
        is a function of (grid, level), not of seed, so it is measured once
        here per level and attributed per arm afterwards.

    Returns a dict with the cold call times and ``peak_by_level``; both go into
    ``meta`` so the cost is visible rather than hidden.
    """
    t_all = time.perf_counter()
    lat = S.paired_initial_latent(WARMUP_SEED, CFG).to(CFG.device)
    binary = C.hard_binary(lat, CFG)
    peaks: Dict[str, Dict[str, object]] = {}
    cold: List[Dict[str, object]] = []

    def _one(kind: str, level, fn) -> None:
        key = _lv_key(level)
        _reset_peak()
        _sync()
        t0 = time.perf_counter()
        val = fn()
        _sync()
        dt = time.perf_counter() - t0
        slot = peaks.setdefault(key, {"level": [int(level[0]), int(level[1])]})
        slot[kind + "_peak_bytes"] = _peak_bytes()
        slot[kind + "_peak_reserved_bytes"] = _peak_reserved_bytes()
        slot[kind + "_cold_s"] = float(dt)
        cold.append({"kind": kind, "level": key, "s": float(dt),
                     "eta": (float(val) if isinstance(val, float) else None)})
        print("  warm-up %-3s %-6s %7.3f s  peak %.2f GiB"
              % (kind, key, dt, _gib(slot[kind + "_peak_bytes"])), flush=True)

    dlvs, alvs = [], []
    for g in groups:
        d = tuple(int(v) for v in g["descent"])
        if d not in dlvs:
            dlvs.append(d)
        for a in g["audits"]:
            a = tuple(int(v) for v in a)
            if a not in alvs:
                alvs.append(a)
    print("warm-up pass (one call per level; keeps CUDA start-up cost out of "
          "the measured descents and gives a per-level peak)", flush=True)
    for d in dlvs:
        _one("vg", d, lambda d=d: C.value_grad_latent(lat, d, (1, 0), 1.0, CFG)[0])
    for a in alvs:
        _one("fwd", a, lambda a=a: S.eta(binary, a, (1, 0), CFG))
    if do_ref:
        _one("ref", S.REF_LEVEL, lambda: S.eta_ref(binary, (1, 0), PIXEL_NM))
    if do_native:
        _one("ref_native", S.REF_LEVEL,
             lambda: S.eta(binary, S.REF_LEVEL, (1, 0), CFG))
    del lat, binary
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
    total = time.perf_counter() - t_all
    print("  warm-up done in %s" % S.fmt_s(total), flush=True)
    return {"seed": WARMUP_SEED, "target_used": [1, 0], "total_s": float(total),
            "calls": cold, "peak_by_level": peaks,
            "note": "single isolated call per level; peak_by_level is what a "
                    "row's peak_mem_bytes is attributed from, because a fused "
                    "group's measured peak is the max over BOTH arms"}


# ---------------------------------------------------------------- the descent
def run_multi_audit(target: Sequence[int], seed: int, cfg,
                    descent_level: Sequence[int],
                    audit_levels: Sequence[Sequence[int]],
                    n_steps: int, audit_every: int,
                    progress_every: int = 0, label: str = "",
                    record_per_step: bool = False) -> Dict[str, object]:
    """One frozen-protocol descent carrying ONE running best per audit level.

    Local extension of ``S.run_descent``, which supports a single audit level
    and does not split the wall clock.  Everything else is identical to it, on
    purpose: same paired initial latent, same beta/lr schedule, same audit
    placement (hard mask of ``rho`` BEFORE the Adam update whenever
    ``step % audit_every == 0``, plus one audit after the final update), same
    running-best delivery.  The hard mask is built once per audit step and
    scored at every requested level, so the levels see bitwise the same mask.

    Also kept, at no cost, is the value the gradient call already computed:
    ``soft_eta_each[step]`` is eta of the PROJECTED structure at the descent
    order, i.e. the thing the optimizer is actually climbing.  Without it a
    stalled arm cannot be told from an oscillating one after the fact, and the
    only way to recover it is a full re-run.

    Timing is attributed by synchronizing around each measured segment:
      descent_wall_s  sum of the value+gradient calls
      audit_wall_s    per audit level, sum of its forward solves
      mask_wall_s     sum of the hard_binary calls (shared by all levels)
      run_wall_s      the whole loop, measured end to end
    """
    if n_steps < 2:
        raise ValueError("n_steps must be >= 2 (progress = step/(n_steps-1))")
    if audit_every < 1:
        raise ValueError("audit_every must be >= 1")
    tgt = (int(target[0]), int(target[1]))
    dlv = S.check_level(descent_level, cfg, "descent level")
    alvs = [S.check_level(a, cfg, "audit level") for a in audit_levels]
    if len(set(alvs)) != len(alvs):
        # best/traj/audit_wall are keyed by level; duplicates would silently
        # merge two arms into one row.
        raise ValueError("audit levels must be distinct within a group, got %r"
                         % (alvs,))

    rho = S.paired_initial_latent(seed, cfg).to(cfg.device)
    adam = C.Adam(rho.shape, cfg)

    best = {a: {"eta": -float("inf"), "step": -1, "bin": None, "lat": None}
            for a in alvs}
    traj: Dict[Tuple[int, int], List[List[float]]] = {a: [] for a in alvs}
    audit_wall = {a: 0.0 for a in alvs}
    audit_calls: Dict[Tuple[int, int], List[float]] = {a: [] for a in alvs}
    last_eta = {a: float("nan") for a in alvs}
    n_nonfinite_audit = {a: 0 for a in alvs}
    soft_eta_each: List[float] = []
    per_step: List[float] = []
    grad_wall_each: List[float] = []
    descent_wall = 0.0
    mask_wall = 0.0
    n_audits = 0
    n_nonfinite_grad = 0
    grad_events = []          # NaN-guard log (s4_common.robust_value_grad)

    def _audit(step_index: int) -> None:
        nonlocal mask_wall, n_audits
        tm = time.perf_counter()
        b = C.hard_binary(rho, cfg)
        _sync()
        mask_wall += time.perf_counter() - tm
        n_audits += 1
        for a in alvs:
            ta = time.perf_counter()
            val = S.eta(b, a, tgt, cfg)
            _sync()
            da = time.perf_counter() - ta
            audit_wall[a] += da
            audit_calls[a].append(da)
            traj[a].append([int(step_index), float(val)])
            last_eta[a] = float(val)
            if not math.isfinite(val):
                # A NaN must never win the running best (and must never leave
                # the delivery empty either -- that surfaces at row-build time
                # as an explicit error, not an AttributeError).
                n_nonfinite_audit[a] += 1
                print("      WARNING: audit %r step %d returned %r"
                      % (a, step_index, val), flush=True)
                continue
            if val > best[a]["eta"]:
                best[a] = {"eta": float(val), "step": int(step_index),
                           "bin": b.clone(), "lat": rho.clone()}

    started = _utc()
    _reset_peak()
    _sync()
    t0 = time.perf_counter()
    for step in range(n_steps):
        progress = step / (n_steps - 1)
        beta = C.beta_at(progress, cfg=cfg)
        lr = C.cosine_lr(progress, cfg)
        s0 = time.perf_counter()
        tg = time.perf_counter()
        val, grad, ev = S.robust_value_grad(rho, dlv, tgt, beta, cfg)
        _sync()
        dt = time.perf_counter() - tg
        descent_wall += dt
        grad_wall_each.append(dt)
        soft_eta_each.append(float(val))
        if ev is not None:
            n_nonfinite_grad += 1
            ev["step"] = step
            grad_events.append(ev)
            print("      !! non-finite adjoint at step %d beta %.3f -> %s"
                  % (step, beta, ev["event"]), flush=True)
        if step % audit_every == 0:
            _audit(step)
        if grad is not None:                 # skipped_update keeps the step count
            rho = adam.step(rho, grad, lr)
        _sync()
        per_step.append(time.perf_counter() - s0)
        if progress_every and (step + 1) % progress_every == 0:
            el = time.perf_counter() - t0
            bests = " ".join("%d-%d %.4f" % (a[0], a[1], best[a]["eta"])
                             for a in alvs)
            print("      %s step %3d/%d beta %5.1f lr %.4f soft %.4f best[%s] "
                  "[%s elapsed, ~%s left]"
                  % (label, step + 1, n_steps, beta, lr, val, bests, S.fmt_s(el),
                     S.fmt_s(el * (n_steps - step - 1) / (step + 1))),
                  flush=True)
    _audit(n_steps)                       # final audit, after the last update
    _sync()
    run_wall = time.perf_counter() - t0
    peak = _peak_bytes()
    peak_res = _peak_reserved_bytes()

    return {
        "target": list(tgt), "seed": int(seed), "pixel_nm": S.pix_of(cfg),
        "grid": list(cfg.shape), "descent_level": list(dlv),
        "audit_levels": [list(a) for a in alvs],
        "n_steps": int(n_steps), "audit_every": int(audit_every),
        "n_audits": int(n_audits),
        "best": {a: dict(best[a]) for a in alvs},
        "last_eta": dict(last_eta),
        "traj": traj,
        "soft_eta_each": [float(x) for x in soft_eta_each],
        "n_nonfinite_grad_steps": int(n_nonfinite_grad),
        "grad_events": grad_events,
        "n_nonfinite_audit": dict(n_nonfinite_audit),
        "final_latent": rho.detach().clone(),
        "run_wall_s": float(run_wall),
        "descent_wall_s": float(descent_wall),
        "audit_wall_s": {a: float(audit_wall[a]) for a in alvs},
        "audit_calls": {a: list(audit_calls[a]) for a in alvs},
        "mask_wall_s": float(mask_wall),
        "per_step_wall": [float(x) for x in per_step],
        "grad_wall_each": [float(x) for x in grad_wall_each],
        "peak_mem_bytes": int(peak),
        "peak_mem_reserved_bytes": int(peak_res),
        "started_utc": started, "finished_utc": _utc(),
    }


# ------------------------------------------------------- reference-order eval
def ref_eval(binary: torch.Tensor, target: Sequence[int],
             cache: Optional[Dict[Tuple, Dict]], native: bool = False) -> Dict:
    """Score a delivered mask at (40,10) on the common (140,480) grid.

    ``cache`` skips a repeat solve when two arms deliver the SAME mask -- the
    solver is deterministic, so the repeat would return the same float.  The
    key is (target, mask sha1), NEVER the hash alone: eta depends on the
    diffraction order, and a hash-only key silently hands one target's value to
    another the moment two rows share a mask.  (That is reachable: a degenerate
    all-empty or all-solid delivery collides across targets.)  Every row records
    the hash and whether it was a cache hit, so the identity is auditable
    rather than implied.

    With ``native``, the same order is ALSO evaluated on the mask's own
    (70,240) grid -- legal there, since (40,10) needs only (41,161) -- which is
    what separates the truncation part of the self-report bias from the grid
    part.
    """
    h = mask_sha1(binary)
    ck = (int(target[0]), int(target[1]), h)
    if cache is not None and ck in cache:
        hit = dict(cache[ck])
        hit.update({"ref_cache_hit": True, "ref_wall_s": 0.0,
                    "ref_peak_mem_bytes": 0})
        if "eta_ref_native" in hit:
            hit["ref_native_wall_s"] = 0.0
        return hit
    _reset_peak()
    _sync()
    t0 = time.perf_counter()
    val = S.eta_ref(binary, target, PIXEL_NM)
    _sync()
    wall = time.perf_counter() - t0
    out = {"eta_ref": float(val), "mask_sha1": h,
           "ref_cache_hit": False, "ref_wall_s": float(wall),
           "ref_peak_mem_bytes": _peak_bytes(), "ref_same_mask_as": None}
    if native:
        _sync()
        t1 = time.perf_counter()
        out["eta_ref_native"] = float(
            S.eta(binary.to(CFG.device), S.REF_LEVEL, target, CFG))
        _sync()
        out["ref_native_wall_s"] = float(time.perf_counter() - t1)
    if cache is not None:
        keep = ["eta_ref", "mask_sha1"]
        if "eta_ref_native" in out:
            keep.append("eta_ref_native")
        cache[ck] = {k: out[k] for k in keep}
        cache[ck]["ref_same_mask_as"] = None
    return out


def _rel(a: Optional[float], b: Optional[float]) -> Optional[float]:
    """(a - b) / b, or None when b is missing or zero."""
    if a is None or b is None or b == 0.0:
        return None
    return float((a - b) / b)


def attach_ref(row: Dict, ref: Dict) -> Dict:
    """Fold a ref_eval result into an arm row and derive the self-report bias.

    Called with an empty ``ref`` under --skip-ref, so every row carries the same
    keys whether or not the reference solve has happened yet.

    Three bias numbers, deliberately kept apart (see the module docstring):
    ``self_bias_rel`` mixes truncation with the grid representation change;
    ``self_bias_rel_trunc`` is pure truncation on one grid; and
    ``ref_grid_shift_rel`` is the grid term on its own.  The last two exist
    only when the run carried ``eta_ref_native``.
    """
    for k in ("eta_ref", "ref_cache_hit", "ref_wall_s", "ref_peak_mem_bytes",
              "ref_same_mask_as", "eta_ref_native", "ref_native_wall_s"):
        row.setdefault(k, None)
    row.update(ref)
    row["ref_level"] = list(S.REF_LEVEL)
    row["ref_grid"] = list(S.REF_SHAPE)
    row["ref_pixel_nm"] = S.REF_PIX
    row["ref_native_grid"] = list(CFG.shape)
    e_ref = row.get("eta_ref")
    e_self = row.get("self_eta")
    e_nat = row.get("eta_ref_native")
    row["self_bias_abs"] = (None if (e_ref is None or e_self is None)
                            else float(e_self - e_ref))
    row["self_bias_rel"] = _rel(e_self, e_ref)
    row["self_bias_abs_trunc"] = (None if (e_nat is None or e_self is None)
                                  else float(e_self - e_nat))
    row["self_bias_rel_trunc"] = _rel(e_self, e_nat)
    row["ref_grid_shift_abs"] = (None if (e_nat is None or e_ref is None)
                                 else float(e_nat - e_ref))
    row["ref_grid_shift_rel"] = _rel(e_nat, e_ref)
    row["bias_decomposition_note"] = (
        "self_bias_rel mixes truncation with the 10 nm -> 5 nm grid change; "
        "self_bias_rel_trunc is truncation alone (both terms on 70x240) and "
        "ref_grid_shift_rel is the grid alone"
        if e_nat is not None else
        "eta_ref_native absent (--no-ref-native): self_bias_rel CANNOT be "
        "separated into a truncation part and a grid part")
    row["ref_pending"] = row.get("eta_ref") is None
    return row


# --------------------------------------------------------------- row builder
def rows_from_run(run: Dict, group: Dict, args,
                  peak_by_level: Optional[Dict] = None
                  ) -> "List[Tuple[str, Dict, torch.Tensor, torch.Tensor, torch.Tensor]]":
    """Split one (possibly fused) descent into one row per arm."""
    alvs = [tuple(a) for a in run["audit_levels"]]
    total_audit = sum(run["audit_wall_s"][a] for a in alvs)
    overhead = (run["run_wall_s"] - run["descent_wall_s"] - total_audit
                - run["mask_wall_s"])
    per_step = run["per_step_wall"]
    grads = run["grad_wall_each"]
    peak_by_level = peak_by_level or {}
    dkey = _lv_key(run["descent_level"])
    out = []
    for i, name in enumerate(group["names"]):
        alv = alvs[i]
        b = run["best"][alv]
        if b["bin"] is None:
            raise RuntimeError(
                "arm %s (target %r seed %r, audit level %r) delivered nothing: "
                "all %d audits were non-finite.  Nothing is written for this "
                "group; investigate before re-running."
                % (name, run["target"], run["seed"], alv, run["n_audits"]))
        calls = run["audit_calls"][alv]
        # Peak memory is a property of (grid, level), measured once in the
        # warm-up pass.  The group's own max_memory_allocated is ALSO recorded,
        # but for a fused pair it is the max over both arms -- i.e. L16's would
        # really be CERT's -- so it is named as the group quantity it is.
        akey = _lv_key(alv)
        pk = max(int((peak_by_level.get(dkey) or {}).get("vg_peak_bytes", 0)),
                 int((peak_by_level.get(akey) or {}).get("fwd_peak_bytes", 0)))
        attributed_peak = pk if pk > 0 else int(run["peak_mem_bytes"])
        row = {
            "arm": name,
            "target": list(run["target"]), "seed": int(run["seed"]),
            "pixel_nm": run["pixel_nm"], "grid": list(run["grid"]),
            "descent_level": list(run["descent_level"]),
            "audit_level": list(alv),
            "n_steps": run["n_steps"], "audit_every": run["audit_every"],
            "n_audits": run["n_audits"],
            "self_eta": float(b["eta"]), "self_best_step": int(b["step"]),
            "self_final_eta": float(run["last_eta"][alv]),
            "audit_traj": run["traj"][alv],
            "n_nonfinite_audits": int(run["n_nonfinite_audit"][alv]),
            # the value the gradient call already computed, at the DESCENT
            # order: what the optimizer was climbing, step by step.  Identical
            # for both arms of a fused group (same trajectory, same order).
            "soft_eta_traj": run["soft_eta_each"],
            "soft_eta_final": float(run["soft_eta_each"][-1]),
            "soft_eta_max": float(max(run["soft_eta_each"])),
            "soft_eta_level": list(run["descent_level"]),
            "n_nonfinite_grad_steps": int(run["n_nonfinite_grad_steps"]),
            "grad_events": run.get("grad_events", []),
            "fused": bool(group["fused"]),
            "fused_with": [n for n in group["names"] if n != name] or None,
            "trajectory_id": trajectory_id(run["target"], run["seed"],
                                           run["descent_level"],
                                           group["names"]),
            # wall clock.  run_wall_s is the measured wall of the WHOLE descent
            # and is shared by every arm of a fused group (it therefore also
            # contains the other arm's audits).  wall_s_attributed charges this
            # arm only for the descent plus its own audits.
            "run_wall_s": float(run["run_wall_s"]),
            "descent_wall_s": float(run["descent_wall_s"]),
            "audit_wall_s": float(run["audit_wall_s"][alv]),
            "mask_wall_s": float(run["mask_wall_s"]),
            "overhead_wall_s": float(overhead),
            "wall_s_attributed": float(run["descent_wall_s"]
                                       + run["audit_wall_s"][alv]),
            "wall_is_shared": bool(group["fused"]),
            "wall_note": ("descent_wall_s and run_wall_s were measured with "
                          "the other fused arm's audits interleaved; they are "
                          "NOT a standalone measurement of this arm.  Use "
                          "--no-fuse for a standalone per-arm wall clock."
                          if group["fused"] else
                          "standalone descent: this arm was the only one on "
                          "the trajectory"),
            "wall_s_definition": ("wall_s = wall_s_attributed = descent + this "
                                  "arm's own audits; it excludes the hard-mask "
                                  "builds and loop overhead, and it is NOT "
                                  "s4_common.run_descent's wall_s (which is "
                                  "end-to-end).  Compare run_wall_s for that."),
            "per_step_wall_median": float(statistics.median(per_step)),
            "per_step_wall_mean": float(sum(per_step) / len(per_step)),
            "per_step_wall_min": float(min(per_step)),
            "per_step_wall_max": float(max(per_step)),
            "per_step_wall_note": ("per_step_wall includes, on audit steps, "
                                   "EVERY audit level of the group; only the "
                                   "median is close to a pure gradient step. "
                                   "per_step_grad_* is the clean quantity."),
            "per_step_grad_median": float(statistics.median(grads)),
            "per_step_grad_mean": float(sum(grads) / len(grads)),
            "per_step_grad_min": float(min(grads)),
            "per_step_grad_max": float(max(grads)),
            "audit_wall_median": (float(statistics.median(calls))
                                  if calls else None),
            "peak_mem_bytes": int(attributed_peak),
            "peak_mem_gib": _gib(attributed_peak),
            "peak_mem_source": ("warm-up peak_by_level max(vg@descent, "
                                "fwd@audit)" if pk > 0 else
                                "group max_memory_allocated (no warm-up table)"),
            "peak_mem_bytes_group": int(run["peak_mem_bytes"]),
            "peak_mem_reserved_bytes_group": int(run["peak_mem_reserved_bytes"]),
            "peak_mem_gib_group": _gib(run["peak_mem_bytes"]),
            "mask_fill": float(b["bin"].mean()),
            "latent_saved": ("audit-best (the latent at step self_best_step, "
                             "i.e. the one the delivered mask came from); the "
                             "endpoint of the %d-step schedule is saved "
                             "separately as files.latent_final"
                             % run["n_steps"]),
            "started_utc": run["started_utc"], "finished_utc": run["finished_utc"],
            "eta_ref": None,
        }
        # Aliases under s4_common.run_descent's field names.  S4-3 reads this
        # store for its 10 nm arm; keeping the shared vocabulary means no
        # consumer has to know S4-2's local names.  wall_s is the PER-ARM
        # attributed cost (descent + this arm's audits); run_wall_s is the
        # measured end-to-end wall of the descent, shared by a fused pair.
        row["best_audit_eta"] = row["self_eta"]
        row["best_audit_step"] = row["self_best_step"]
        row["final_audit_eta"] = row["self_final_eta"]
        row["wall_s"] = row["wall_s_attributed"]
        row["audit_on_ref"] = False
        row["same_delivery_as"] = None      # filled by link_same_delivery()
        if args.record_per_step:
            row["per_step_wall_list"] = per_step
            row["grad_wall_list"] = grads
            row["audit_wall_list"] = calls
        out.append((name, row, b["bin"], b["lat"], run["final_latent"]))
    return out


def link_same_delivery(store: Dict, keys: Dict[str, str], path: str) -> int:
    """Cross-link rows of one unit that delivered a bitwise identical mask.

    By ``mask_sha1``, over the WHOLE unit rather than only inside a fused pair:
    under ``--no-fuse`` L16 and CERT are separate runs that can still deliver
    the same mask, and ``self_best_step`` cannot see that.
    """
    rows = {a: store.get("units", {}).get(k) for a, k in keys.items()}
    rows = {a: r for a, r in rows.items() if isinstance(r, dict)
            and r.get("mask_sha1")}
    changed = 0
    for arm, row in rows.items():
        same = sorted(a for a, r in rows.items()
                      if a != arm and r.get("mask_sha1") == row.get("mask_sha1"))
        new = same or None
        if "same_delivery_as" not in row or row["same_delivery_as"] != new:
            changed += 1
        row["same_delivery_as"] = new           # always present, never implied
    if changed:
        S.save_json(path, store)
    return changed


def same_mask_arm(store: Dict, sha: str, target, seed,
                  exclude: Optional[str] = None) -> Optional[str]:
    """Which already-stored arm of this unit carries mask ``sha``, if any."""
    for key, r in store.get("units", {}).items():
        if key == exclude or not isinstance(r, dict):
            continue
        if (r.get("mask_sha1") == sha and r.get("seed") == seed
                and list(r.get("target", [])) == list(target)):
            return r.get("arm")
    return None


# ------------------------------------------------------------------ estimate
def estimate_unit_s(groups, n_steps, audit_every, n_arms, do_ref, do_native) -> float:
    """Rough seconds per (target, seed) unit, for the banner only.

    The reference term counts DISTINCT masks, not arms: a fused pair usually
    delivers one mask and the second lookup is a cache hit.  It is still an
    estimate off +-30% anchors, and the anchors were measured at (35,120), so
    on this 10 nm grid the reference term in particular runs a little high.
    """
    n_aud = len(range(0, n_steps, audit_every)) + 1
    total = 0.0
    for g in groups:
        total += n_steps * S.cost_s(g["descent"], "vg")
        for a in g["audits"]:
            total += n_aud * S.cost_s(a, "fwd")
    if do_ref:
        n_ref = n_arms - sum(len(g["names"]) - 1 for g in groups if g["fused"])
        total += n_ref * S.cost_s(S.REF_LEVEL, "fwd") * (2 if do_native else 1)
    return total


def drop_foreign_units(store: Dict) -> int:
    """Quarantine rows this script did not write (wrong key shape or arm).

    A resumed run must not inherit rows from some other producer that happened
    to use this file name -- S4-3 keeps a mock ``s4_2_descent_order.json`` as a
    reader fixture, for instance.  Foreign rows are moved to
    ``meta.foreign_units_dropped`` (kept, not deleted) and reported.
    """
    units = store.get("units", {})
    bad = {}
    for key in list(units):
        parts = str(key).split("|")
        row = units[key]
        ok = (len(parts) == 4 and parts[1] == str(PIXEL_NM)
              and parts[2] in ARM_SPEC and isinstance(row, dict)
              and row.get("arm") in ARM_SPEC)
        if not ok:
            bad[key] = units.pop(key)
    if bad:
        store.setdefault("meta", {}).setdefault(
            "foreign_units_dropped", {}).update(bad)
        print("WARNING: %d unit row(s) in this store were not written by %s "
              "(keys %r); moved to meta.foreign_units_dropped"
              % (len(bad), SCRIPT, sorted(bad)), flush=True)
    return len(bad)


# ------------------------------------------------------------ pending refills
def fill_pending_refs(store, path, targets, seeds_by_m, arm_names, args,
                      do_native: bool) -> int:
    """Fill in eta_ref for rows written under --skip-ref, from the saved masks."""
    pend = []
    for key, row in store.get("units", {}).items():
        if not row.get("ref_pending"):
            continue
        tgt = tuple(row.get("target", ()))
        if tgt not in targets or row.get("arm") not in arm_names:
            continue
        if row.get("seed") not in seeds_by_m.get(tgt[0], []):
            continue
        pend.append((key, row))
    if not pend:
        return 0
    print("filling %d pending reference audits at %r ..."
          % (len(pend), S.REF_LEVEL), flush=True)
    # One cache for the whole refill, keyed by (target, mask sha1) inside
    # ref_eval -- this loop is the ONLY path that crosses targets, so a
    # hash-only key would hand one order's eta to another.
    cache = None if args.no_ref_cache else {}
    done = 0
    for key, row in sorted(pend):
        binary = load_design_binary(row)
        if binary is None:
            print("  WARNING: %s has no saved mask on disk; still pending" % key,
                  flush=True)
            continue
        tgt = tuple(row["target"])
        ref = ref_eval(binary, tgt, cache, do_native)
        if ref.get("ref_cache_hit"):
            ref["ref_same_mask_as"] = same_mask_arm(
                store, ref["mask_sha1"], tgt, row.get("seed"), exclude=key)
        attach_ref(row, ref)
        S.record_unit(store, key, row, path)
        done += 1
        print("  %s  eta_ref %.6f  self %.6f  bias %s  [%s]%s"
              % (key, row["eta_ref"], row["self_eta"],
                 ("%+.3e" % row["self_bias_rel"])
                 if row["self_bias_rel"] is not None else "n/a",
                 S.fmt_s(ref["ref_wall_s"]),
                 ("  (cache hit%s)" % (
                     ", same mask as %s" % ref["ref_same_mask_as"]
                     if ref.get("ref_same_mask_as") else ""))
                 if ref.get("ref_cache_hit") else ""), flush=True)
    return done


# ---------------------------------------------------------------- console sum
def print_summary(store, targets, seeds_by_m, arm_names) -> None:
    """Arithmetic on the measurements only.  No interpretation here."""
    print("-" * 72, flush=True)
    print("console summary (descriptive; means over completed seeds)", flush=True)
    for tgt in targets:
        print("  target %r" % (tgt,), flush=True)
        for arm in arm_names:
            rows = []
            for seed in seeds_by_m.get(tgt[0], []):
                r = store.get("units", {}).get(S.unit_key(tgt, PIXEL_NM, arm, seed))
                if r is not None:
                    rows.append(r)
            if not rows:
                continue
            selfs = [r["self_eta"] for r in rows if r.get("self_eta") is not None]
            refs = [r["eta_ref"] for r in rows if r.get("eta_ref") is not None]
            bias = [r["self_bias_rel"] for r in rows
                    if r.get("self_bias_rel") is not None]
            trunc = [r["self_bias_rel_trunc"] for r in rows
                     if r.get("self_bias_rel_trunc") is not None]
            walls = [r["wall_s_attributed"] for r in rows
                     if r.get("wall_s_attributed") is not None]
            print("    %-5s n=%d  self %s (n=%d)  eta_ref %s (n=%d)  "
                  "bias_rel %s  bias_trunc %s (n=%d)  wall %s/run"
                  % (arm, len(rows),
                     ("%.4f" % statistics.mean(selfs)) if selfs else "n/a",
                     len(selfs),
                     ("%.4f" % statistics.mean(refs)) if refs else "n/a",
                     len(refs),
                     ("%+.3e" % statistics.mean(bias)) if bias else "n/a",
                     ("%+.3e" % statistics.mean(trunc)) if trunc else "n/a",
                     len(trunc),
                     S.fmt_s(statistics.mean(walls)) if walls else "n/a"),
                  flush=True)
    print("-" * 72, flush=True)


# ------------------------------------------------------------------ run lock
def _pid_alive(pid: int) -> bool:
    """Is ``pid`` still running?  (Never os.kill on Windows: signal 0 there
    goes through TerminateProcess and would KILL the process.)"""
    if pid <= 0:
        return False
    if os.name == "nt":
        try:
            import ctypes
            k = ctypes.windll.kernel32
            h = k.OpenProcess(0x1000, False, int(pid))   # QUERY_LIMITED_INFO
            if not h:
                return False
            code = ctypes.c_ulong()
            ok = k.GetExitCodeProcess(h, ctypes.byref(code))
            k.CloseHandle(h)
            return bool(ok) and code.value == 259        # STILL_ACTIVE
        except Exception:
            return True          # cannot tell -> assume alive, refuse to run
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def acquire_lock(path: str) -> Tuple[Optional[str], Optional[str]]:
    """Take ``<store>.lock``.  Returns (lock_path, error_message)."""
    lock = path + ".lock"
    if os.path.exists(lock):
        try:
            with open(lock, "r", encoding="utf-8") as f:
                info = json.load(f)
        except Exception:
            info = {}
        pid = int(info.get("pid", -1) or -1)
        if pid > 0 and pid != os.getpid() and _pid_alive(pid):
            return None, ("%s is locked by pid %d (started %s).  S4 wall clock "
                          "is a RESULT: two processes on one GPU contaminate "
                          "every timing in both stores.  Wait for it, or pass "
                          "--no-lock if you are certain that pid is not this "
                          "experiment." % (lock, pid, info.get("started_utc")))
        print("note: removing a stale lock from pid %r" % (pid,), flush=True)
    try:
        with open(lock, "w", encoding="utf-8") as f:
            json.dump({"pid": os.getpid(), "started_utc": _utc(),
                       "argv": list(sys.argv)}, f)
    except OSError as exc:
        print("WARNING: could not write %s (%s); continuing without a lock"
              % (lock, exc), flush=True)
        return None, None
    return lock, None


def release_lock(lock: Optional[str]) -> None:
    if not lock:
        return
    try:
        os.remove(lock)
    except OSError:
        pass


# ------------------------------------------------------------------- main
def main(argv=None) -> int:
    global DESIGNS
    ap = argparse.ArgumentParser(
        description="S4-2: descent truncation order vs the (40,10) reference")
    S.add_common_args(
        ap, default_seeds=8,
        dry_help=("tiny self-check: 1 target, 1 seed, %d steps, audit every "
                  "%d, arms %s, at most %d real (40,10) reference solve(s)"
                  % (DRY_STEPS, DRY_AUDIT_EVERY, "+".join(DRY_ARMS),
                     DRY_MAX_REFS)))
    ap.add_argument("--arms", type=str, default=",".join(ARM_ORDER),
                    help="comma-separated subset of %s" % (ARM_ORDER,))
    ap.add_argument("--no-fuse", action="store_true",
                    help="run L16 and CERT as two separate descents instead of "
                         "one shared trajectory (costs one extra descent per "
                         "seed; trajectories then only nominally paired, but "
                         "each arm gets a standalone wall clock)")
    ap.add_argument("--skip-ref", action="store_true",
                    help="do the descents only; leave eta_ref pending (a later "
                         "--resume without this flag fills it from the masks)")
    ap.add_argument("--ref-native", action="store_true",
                    help="force the NATIVE 70x240 (40,10) score on (it is ON "
                         "by default except in --dry-run)")
    ap.add_argument("--no-ref-native", action="store_true",
                    help="skip the native (40,10) score.  Saves ~45 min, but "
                         "then self_bias_rel cannot be split into a truncation "
                         "part and a grid part -- the grid term is the same "
                         "order of magnitude as the bias itself")
    ap.add_argument("--dry-ref-all", action="store_true",
                    help="in --dry-run, do every reference solve instead of "
                         "the first %d" % DRY_MAX_REFS)
    ap.add_argument("--no-ref-cache", action="store_true",
                    help="re-solve the reference even when two arms delivered "
                         "a bitwise identical mask")
    ap.add_argument("--record-per-step", action="store_true",
                    help="store the full per-step wall-clock lists in the JSON")
    ap.add_argument("--no-warmup", action="store_true",
                    help="skip the warm-up pass (CUDA start-up then lands "
                         "inside the first measured descent; peaks fall back "
                         "to the group maximum)")
    ap.add_argument("--force", action="store_true",
                    help="discard an existing non-empty store instead of "
                         "refusing to overwrite it")
    ap.add_argument("--no-lock", action="store_true",
                    help="do not take/honour the <store>.lock file")
    args = ap.parse_args(argv)

    if args.ref_native and args.no_ref_native:
        print("FATAL: --ref-native and --no-ref-native contradict each other",
              flush=True)
        return 2
    if not torch.cuda.is_available():
        print("FATAL: no CUDA device.  S4 runs GPU/complex64 by decision "
              "D-011; refusing to fall back to CPU.", flush=True)
        return 2

    targets = S.parse_targets(args.targets)
    n_steps, audit_every = S.dry_apply(args)
    arm_names = parse_arms(args.arms)
    if args.dry_run:
        n_steps, audit_every = DRY_STEPS, DRY_AUDIT_EVERY
        targets = targets[:1]
        arm_names = [n for n in arm_names if n in DRY_ARMS]
        if not arm_names:
            print("FATAL: --dry-run only runs arms %r, and --arms selected "
                  "none of them.  Nothing would be measured." % (DRY_ARMS,),
                  flush=True)
            return 2
    # native reference: on for a real run, off for a dry one (it is the single
    # most expensive call in the script), either way overridable.
    do_native = args.ref_native or not (args.no_ref_native or args.dry_run)

    groups = build_groups(arm_names, fuse=not args.no_fuse)
    seeds_by_m = {t[0]: S.seeds_for(t, args.n_seeds) for t in targets}
    n_units = len(targets) * args.n_seeds
    unit_est = estimate_unit_s(groups, n_steps, audit_every, len(arm_names),
                               not args.skip_ref, do_native)

    path = S.out_path(args, SCRIPT)
    # designs live next to the store, so a second --out never fights the first
    # one over the same .npy names
    DESIGNS = os.path.join(os.path.dirname(os.path.abspath(path)),
                           "designs_dry" if args.dry_run else "designs")
    # created lazily by save_design, so a run that refuses to start (guard,
    # lock, bad flags) leaves no empty directory behind

    params = dict(vars(args))
    params.update({"pixel_nm": PIXEL_NM, "n_steps": n_steps,
                   "audit_every": audit_every,
                   "arms_selected": arm_names,
                   "targets_selected": [list(t) for t in targets],
                   "seeds": {str(k): v for k, v in seeds_by_m.items()},
                   "ref_native_effective": bool(do_native),
                   "designs_dir": os.path.basename(DESIGNS)})

    S.banner(SCRIPT, args, unit_est * n_units)
    print("  pixel %d nm, grid %r, EQUAL-STEP budget: %d steps, audit every %d"
          % (PIXEL_NM, CFG.shape, n_steps, audit_every), flush=True)
    for g in groups:
        print("    descent %r -> audits %r  (%s)%s"
              % (tuple(g["descent"]), [tuple(a) for a in g["audits"]],
                 "+".join(g["names"]),
                 "  [ONE shared trajectory]" if g["fused"] else ""), flush=True)
    print("  reference: %r on the %d nm grid %r, %s%s"
          % (S.REF_LEVEL, S.REF_PIX, S.REF_SHAPE,
             "SKIPPED (--skip-ref)" if args.skip_ref
             else "%d masks/unit" % len(arm_names),
             "" if args.skip_ref else
             ("  + native %r score" % (tuple(CFG.shape),) if do_native
              else "  (no native score: bias not decomposable)")), flush=True)
    print("  %d units (%d targets x %d seeds), ~%s each"
          % (n_units, len(targets), args.n_seeds, S.fmt_s(unit_est)), flush=True)
    print("  output: %s" % path, flush=True)
    print("  designs: %s" % DESIGNS, flush=True)

    # ---- the GPU had better be ours alone: wall clock is a reported result
    try:
        free_b, total_b = torch.cuda.mem_get_info()
        print("  VRAM: %.2f / %.2f GiB free" % (_gib(free_b), _gib(total_b)),
              flush=True)
        if free_b < 6 * 2 ** 30:
            print("WARNING: only %.2f GiB free -- something else is on this "
                  "GPU.  S4 assumes SERIAL execution; wall-clock numbers "
                  "measured now are contaminated and the (40,10) reference "
                  "may page (WDDM)." % _gib(free_b), flush=True)
        vram = {"free_bytes": int(free_b), "total_bytes": int(total_b)}
    except Exception as exc:                                # pragma: no cover
        print("  VRAM: unavailable (%s)" % exc, flush=True)
        vram = {"error": str(exc)}

    # ---- refuse to clobber a store that already holds results
    existing = S.load_json(path, None)
    n_existing = len((existing or {}).get("units", {}) or {})
    if n_existing and not args.resume and not args.force and not args.dry_run:
        print("FATAL: %s already holds %d unit row(s).  Re-run with --resume "
              "to continue it, or --force to discard it deliberately.  "
              "(Refusing silently costs nothing; overwriting costs hours.)"
              % (path, n_existing), flush=True)
        return 3

    lock = None
    if not args.no_lock:
        lock, err = acquire_lock(path)
        if err:
            print("FATAL: %s" % err, flush=True)
            return 4

    try:
        store = S.resume_store(path, SCRIPT, params, args.resume)
        drop_foreign_units(store)
        design_meta = {
            "pixel_nm": PIXEL_NM, "grid": list(CFG.shape),
            "budget": "equal steps (%d); wall clock is a recorded result, not "
                      "a control variable" % n_steps,
            "n_audits_per_run": len(range(0, n_steps, audit_every)) + 1,
            "arms": [{"name": n, "descent_level": list(d), "audit_level": list(a)}
                     for n, d, a in ARMS if n in arm_names],
            "fused_pairs": [g["names"] for g in groups if g["fused"]],
            "fusion_note": ("L16 and CERT come from ONE descent carrying two "
                            "running bests, so their trajectories are bitwise "
                            "identical (fully paired) and run_wall_s AND "
                            "descent_wall_s are shared by both rows -- they "
                            "include BOTH arms' audits.  Rows say so in "
                            "wall_is_shared/wall_note.  peak_mem_bytes is "
                            "attributed per level from the warm-up table, not "
                            "taken from the shared group maximum (that one is "
                            "kept as peak_mem_bytes_group)."
                            if any(g["fused"] for g in groups) else
                            "--no-fuse: L16 and CERT were run as separate "
                            "descents, so every wall clock is standalone."),
            "reference": {
                "level": list(S.REF_LEVEL), "grid": list(S.REF_SHAPE),
                "pixel_nm": S.REF_PIX,
                "native_also_scored": bool(do_native),
                "note": "delivered mask block-replicated 10 nm -> 5 nm "
                        "(pointwise exact for a binary) and scored at (40,10); "
                        "treated as the truth by the protocol.  (40,10) is ALSO "
                        "legal on the native 70x240 grid (needs 41x161), and "
                        "the two differ by the DFT sampling alone -- that "
                        "difference is eta_ref_native/ref_grid_shift_rel, and "
                        "it is the same order as self_bias_rel itself, so "
                        "self_bias_rel is NOT a pure truncation number."},
            "selection_note": "self_eta is a MAXIMUM over %d correlated audits "
                              "of one trajectory, so it is biased upward as an "
                              "estimate of the delivered structure's quality.  "
                              "Every arm takes the same %d audits at the same "
                              "step indices, so the bias is equal across arms.  "
                              "self_best_step == %d means the final audit, "
                              "taken AFTER the last Adam update (real step "
                              "indices only run to %d)."
                              % (len(range(0, n_steps, audit_every)) + 1,
                                 len(range(0, n_steps, audit_every)) + 1,
                                 n_steps, n_steps - 1),
            "latent_files": "files.latent is the latent AT THE DELIVERED AUDIT "
                            "STEP (self_best_step); files.latent_final is the "
                            "endpoint of the %d-step schedule" % n_steps,
            "initial_latent": "s4_common.paired_initial_latent (NOT "
                              "C.initial_latent): noise drawn on (140,480) and "
                              "area-averaged down, so S4 seeds are not "
                              "comparable to E-series runs at the same seed "
                              "numbers",
            "timing": "segments measured with cuda synchronize around each "
                      "call; run_wall_s is the end-to-end loop.  A warm-up pass "
                      "absorbs CUDA start-up before anything is timed (see "
                      "meta.warmup).  per_step_wall includes the audits of "
                      "every arm in the group; per_step_grad_* does not.",
            "claims": "none; this store is descriptive",
        }
        meta_blk = store.setdefault("meta", {})
        old = meta_blk.get("design")
        if old:
            # Do not let a partial re-run (one arm, one target) rewrite the
            # design block into a lie about what is in the file.
            if (old.get("pixel_nm") != design_meta["pixel_nm"]
                    or "%d" % n_steps not in str(old.get("budget"))):
                print("WARNING: the store on disk was written with a DIFFERENT "
                      "design block (steps/pixel).  Mixed settings in one file.",
                      flush=True)
            names = ({a.get("name") for a in (old.get("arms") or [])}
                     | set(arm_names))
            design_meta["arms"] = [
                {"name": n, "descent_level": list(d), "audit_level": list(a)}
                for n, d, a in ARMS if n in names]
            design_meta["arms_this_invocation"] = list(arm_names)
        hist = meta_blk.setdefault("design_history", [])
        if not hist or hist[-1].get("design") != design_meta:
            hist.append({"utc": _utc(), "argv": list(sys.argv),
                         "design": design_meta})
        meta_blk["design"] = design_meta
        meta_blk["vram_at_start"] = vram
        S.save_json(path, store)

        # ---- warm-up: CUDA start-up out of the timed region, peaks per level
        warm = None
        if not args.no_warmup:
            # the reference level is the single most expensive call in the
            # script (~25 s); warming it is worth it for a 7 h run and absurd
            # for a --dry-run, whose one reference solve may stay cold
            warm = warm_up(groups,
                           do_ref=(not args.skip_ref) and not args.dry_run,
                           do_native=do_native and not args.dry_run)
            meta_blk["warmup"] = warm
            meta_blk["peak_by_level"] = warm["peak_by_level"]
            S.save_json(path, store)
        peak_by_level = (warm or {}).get("peak_by_level", {})

        if args.resume and not args.skip_ref:
            fill_pending_refs(store, path, targets, seeds_by_m, arm_names, args,
                              do_native)

        def _row_done(key: str) -> bool:
            if not S.unit_done(store, key):
                return False
            if args.skip_ref:
                return True               # the reference is deliberately absent
            return not store["units"][key].get("ref_pending")

        # reference budget: a dry run does at most DRY_MAX_REFS real solves
        ref_budget = [DRY_MAX_REFS if (args.dry_run and not args.dry_ref_all)
                      else None]

        pending_units = []
        for tgt in targets:
            for seed in seeds_by_m[tgt[0]]:
                keys = {n: S.unit_key(tgt, PIXEL_NM, n, seed) for n in arm_names}
                if not all(_row_done(k) for k in keys.values()):
                    pending_units.append((tgt, seed))
        n_todo = len(pending_units)
        print("%d of %d unit(s) still to do (~%s)"
              % (n_todo, n_units, S.fmt_s(unit_est * n_todo)), flush=True)

        t_start = time.perf_counter()
        done_units = 0
        for tgt in targets:
            for seed in seeds_by_m[tgt[0]]:
                keys = {n: S.unit_key(tgt, PIXEL_NM, n, seed) for n in arm_names}
                if all(_row_done(k) for k in keys.values()):
                    print("[--/%d] %r seed %d: already done, skipping"
                          % (n_units, tgt, seed), flush=True)
                    continue
                done_units += 1
                el = time.perf_counter() - t_start
                print("=" * 72, flush=True)
                print("[%d/%d] target %r seed %d  (elapsed %s, ~%s left)"
                      % (done_units, n_todo, tgt, seed, S.fmt_s(el),
                         S.fmt_s(unit_est * (n_todo - done_units + 1))),
                      flush=True)
                cache = None if args.no_ref_cache else {}
                for g in groups:
                    gkeys = [keys[n] for n in g["names"]]
                    if all(_row_done(k) for k in gkeys):
                        print("  %s: done, skipping" % "+".join(g["names"]),
                              flush=True)
                        continue
                    label = "%s %r s%d" % ("+".join(g["names"]), tgt, seed)
                    g_est = (n_steps * S.cost_s(g["descent"], "vg")
                             + (len(range(0, n_steps, audit_every)) + 1)
                             * sum(S.cost_s(a, "fwd") for a in g["audits"]))
                    print("  %s: descent %r audits %r  (~%s)"
                          % ("+".join(g["names"]), tuple(g["descent"]),
                             [tuple(a) for a in g["audits"]], S.fmt_s(g_est)),
                          flush=True)
                    # free the allocator BEFORE the timed region, never after:
                    # an empty_cache between groups makes the NEXT group pay
                    # for re-cudaMalloc inside its own measurement
                    if torch.cuda.is_available():
                        torch.cuda.empty_cache()
                    run = run_multi_audit(
                        tgt, seed, CFG, g["descent"], g["audits"],
                        n_steps=n_steps, audit_every=audit_every,
                        progress_every=args.progress_every, label=label,
                        record_per_step=args.record_per_step)
                    for name, row, binary, latent, lat_fin in rows_from_run(
                            run, g, args, peak_by_level):
                        row["files"] = save_design(design_tag(name, tgt, seed),
                                                   binary, latent, lat_fin)
                        row["mask_sha1"] = mask_sha1(binary)
                        capped = (ref_budget[0] is not None
                                  and ref_budget[0] <= 0)
                        if args.skip_ref or capped:
                            attach_ref(row, {})
                            if capped:
                                row["ref_skipped_reason"] = (
                                    "--dry-run reference budget of %d solve(s) "
                                    "spent" % DRY_MAX_REFS)
                        else:
                            ref = ref_eval(binary, tgt, cache, do_native)
                            if ref.get("ref_cache_hit"):
                                ref["ref_same_mask_as"] = same_mask_arm(
                                    store, ref["mask_sha1"], tgt, seed,
                                    exclude=keys[name])
                            elif ref_budget[0] is not None:
                                ref_budget[0] -= 1
                            attach_ref(row, ref)
                        S.record_unit(store, keys[name], row, path)
                        print("    %-5s self(%d,%d) %.6f @step %-3d | "
                              "eta_ref %s%s | bias %s | %s desc + %s aud | "
                              "peak %.2f GiB"
                              % (name, row["audit_level"][0], row["audit_level"][1],
                                 row["self_eta"], row["self_best_step"],
                                 ("%.6f" % row["eta_ref"])
                                 if row["eta_ref"] is not None else "pending",
                                 (" (native %.6f)" % row["eta_ref_native"])
                                 if row.get("eta_ref_native") is not None else "",
                                 ("%+.3e" % row["self_bias_rel"])
                                 if row["self_bias_rel"] is not None else "n/a",
                                 S.fmt_s(row["descent_wall_s"]),
                                 S.fmt_s(row["audit_wall_s"]),
                                 row["peak_mem_gib"]), flush=True)
                    del run
                link_same_delivery(store, keys, path)
    except BaseException as exc:
        kind = type(exc).__name__
        print("\n%s after %d unit(s) touched; store flushed to %s"
              % (kind, locals().get("done_units", 0), path), flush=True)
        rest = [a for a in sys.argv[1:] if a != "--resume"]
        print("resume with: python %s --resume %s"
              % (SCRIPT, " ".join(rest)), flush=True)
        release_lock(lock)
        if isinstance(exc, KeyboardInterrupt):
            return 130
        raise
    release_lock(lock)

    print("=" * 72, flush=True)
    print("all requested units done in %s" % S.fmt_s(time.perf_counter() - t_start),
          flush=True)
    print_summary(store, targets, seeds_by_m, arm_names)
    n_pending = sum(1 for r in store.get("units", {}).values()
                    if r.get("ref_pending"))
    if n_pending:
        print("%d row(s) still have eta_ref pending; fill them with: "
              "python %s --resume" % (n_pending, SCRIPT), flush=True)
    store["meta"]["finished_utc"] = _utc()
    store["meta"]["total_wall_s"] = float(time.perf_counter() - t_start)
    S.save_json(path, store)
    print("wrote %s (%d unit rows)" % (path, len(store.get("units", {}))),
          flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
