"""S4-1: value and gradient across the truncation ladder, at fixed structure.

DESCRIPTIVE ONLY.  This script produces numbers; it asserts nothing about what
they mean.  Every interpretation belongs in ``S4_实验记录.md``, written later
from the JSON emitted here.

What varies: the truncation order M only.  The structure, the design pixel
(10 nm, native (70,240) grid -- every ladder rung is legal there, so no block
replication is used anywhere in this script), the physics and the design map
are all held fixed.

Structure set (12 by default, canonical order):
  (a) 6 random initials      ``paired_initial_latent(seed, PIX[10])`` for the
      first ``--n-seeds`` (default 2) seeds of each target's block:
      7101,7102 / 7201,7202 / 7301,7302.
  (b) 3 optimized structures  E26's 10 nm chain incumbents
      ``E26_fine_pixels/data/{1_0,2_0,3_0}_w10nm_latent.npy``.  A missing file
      is recorded in ``meta.passes[].missing_sources`` and skipped, not fatal.
  (c) 3 mid-descent structures  the latent after ``--mid-steps`` (60) steps of
      the frozen protocol at (16,4), seeds 7103/7203/7303.

Each structure belongs to exactly ONE target (its seed block, or its filename);
it is never evaluated against the other two.

Per (structure, beta) with beta in {1, 8, 64}, and per structure once more on
the beta-independent hard binary (``beta="hard"``, values only), the ladder
  (8,2) (12,3) (16,4) (20,5) (24,6) (28,7) (32,8) (40,10)
is walked and, for every rung, the value and (for the beta units) the gradient
w.r.t. the latent are recorded, together with

  vs. the top rung (40,10):  rel/abs value error, cos(g_M, g_ref), 1-cos,
                             the angle in radians, |g_M|/|g_ref| and
                             |g_M - g_ref|/|g_ref|
  adjacent rungs:            (eta_{i+1}-eta_i)/|eta_i| and 1-cos(g_{i+1}, g_i)
                             -- no assumption that (40,10) is the truth
  noise floor:               the same quantity computed twice along two paths
                             that are exact algebraic rearrangements of each
                             other (MEMORY_EFFICIENT on / off).  Their
                             disagreement is the empirical complex64 floor for
                             that configuration, so "is this ladder difference
                             above the arithmetic noise?" can be decided
                             pointwise without ever running complex128.

THE FLOOR IS MEASURED AT EVERY RUNG AND ON EVERY STRUCTURE BY DEFAULT.  It is
not monotone in M and it is strongly structure- and beta-dependent (measured:
1.3e-6 at (20,5) and 1.3e-3 at (32,8) on the same structure and beta), so it
cannot be interpolated across rungs or carried from one structure to another.
Every gradient number in this file must be read against the floor recorded at
the SAME (structure, beta, M) -- never against a single global floor, and never
against a floor measured on a different structure family.  ``--noise-structures``
/ ``--noise-levels`` exist only to trade coverage for wall clock; narrowing
either one leaves the affected rows without a yardstick.

Usage (cwd = this directory):
    python s4_1_value_grad_convergence.py                 # full, ~70 min
    python s4_1_value_grad_convergence.py --dry-run       # seconds
    python s4_1_value_grad_convergence.py --resume        # continue a kill

Output: ../data/s4_1_value_grad.json (the name the S4 spec asks for; the
script's own filename is longer).  Masks, latents, mid-descent caches and the
raw gradient archives go to ../data/designs/ (../data/designs_dry/ for a dry
run), always in the same directory as the JSON, so ``--out`` relocates the
whole unit and two runs cannot overwrite each other's arrays.

DEVIATIONS from the S4-1 spec, all deliberate, all recorded in the store:
 1. Noise floor at EVERY rung and on EVERY structure, not the spec's 5-of-8
    rungs / 6-of-12 structures.  Measured: the floor is non-monotone in M
    (1.3e-6 at (20,5) vs 1.3e-3 at (32,8), same structure and beta) and
    differs by ~300x between the init and E26 families, so a subset leaves
    most rows without a comparable yardstick.  Adds ~35 min; --noise-levels
    and --noise-structures can put the subset back.
 3. Path A is COMPUTED ONCE per rung and reused as the noise-floor reference
    instead of being re-run.  Justified by measurement (the solve is bitwise
    deterministic run-to-run) and controlled for: REPEAT_LEVELS re-runs path A
    on the cheap rungs of every noisy unit, and one --no-top-determinism-able
    check re-runs it at the TOP rung once per invocation.
 4. Mid-descent seeds are 7103 / 7203 / 7303, one per target block, not the
    spec's literal "7103 for all three".  The block convention wins; the cost
    is that the three midpoints no longer share an initial field, so an
    m-to-m difference among them confounds target with initial field.  If the
    pairing is wanted instead, pass the same seed explicitly and record the
    block exception.
 5. mid_latent records final_progress / beta_at_last_step / lr_at_last_step,
    and writes them to a sidecar ``*_info.json`` next to the cached .npy so a
    resumed run does not lose them.
 7. The mid structure id carries seed, step count, descent level AND schedule.
    Anything that changes the latent is in the id, so two schedules can never
    share a unit key or an .npy path.
 8. ``units`` is a LIST, not s4_common's dict, so a resume can replace a row
    in place when the stored row is narrower than what is now being asked for
    (see ``unit_stale``).  A resume that WIDENS the run redoes the affected
    units; one that narrows it skips.
 9. Store name is ``s4_1_value_grad.json`` (the spec's name), not the script's
    own longer filename.
"""
import argparse
import contextlib
import hashlib
import inspect
import json
import math
import os
import sys
import time
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
if _HERE not in sys.path:
    sys.path.insert(0, _HERE)

import s4_common as S                                   # noqa: E402
import trustworthy_fmm.solvers.vector_2d as _v2d        # noqa: E402

SCRIPT = "s4_1_value_grad_convergence.py"
# The S4 spec names the store ``s4_1_value_grad.json``; the script file is
# longer.  out_path() derives the stem from whatever name it is handed, so the
# store gets the spec's name while ``meta.script`` keeps the real filename.
OUT_STEM = "s4_1_value_grad"

# ------------------------------------------------------------------ schedule
PIXEL_NM = 10                       # every rung below is legal on (70,240)
CFG = S.PIX[PIXEL_NM]

LADDER: List[Tuple[int, int]] = [(8, 2), (12, 3), (16, 4), (20, 5),
                                 (24, 6), (28, 7), (32, 8), (40, 10)]
LADDER_DRY: List[Tuple[int, int]] = LADDER[:2]          # (8,2), (12,3)

BETAS: List[float] = [1.0, 8.0, 64.0]
HARD = "hard"                       # the beta-independent delivered binary

# Noise floor: two arithmetic paths.  DEFAULT = every rung, every structure.
# The spec's cost-control subset (5 of 8 rungs, 6 of 12 structures) was dropped
# after measurement: the floor is non-monotone in M and family-dependent, so a
# subset leaves most rows without a comparable yardstick.  --noise-levels and
# --noise-structures can restore a subset when wall clock matters more.
NOISE_LEVELS: List[Tuple[int, int]] = list(LADDER)
# A plain rerun of path A, to separate "arithmetic reordering" from "same code
# path, run twice".  Cheap rungs on every noisy unit; the top rung is checked
# once per run instead (see --no-top-determinism), because 2x25 s per unit is
# not affordable and the answer has never depended on the structure.
REPEAT_LEVELS: List[Tuple[int, int]] = [(12, 3), (16, 4), (24, 6)]
N_NOISE_STRUCTURES = -1             # -1 = all structures

MID_STEPS = 60
MID_LEVEL: Tuple[int, int] = (16, 4)
MID_SCHEDULE = "truncated"          # "truncated" | "compressed", see DEVIATIONS

E26_DATA = os.path.abspath(os.path.join(
    _HERE, "..", "..", "E26_fine_pixels", "data"))
E26_PATTERN = "%d_%d_w10nm_latent.npy"

# Path B (MEMORY_EFFICIENT off) wall clock relative to path A.  Measured on an
# IDLE box at 1.07-1.20 up to (32,8); the top rung allocates 6.3 GiB against
# path A's 5.0 GiB and has been seen to page under WDDM, so it gets a larger
# planning factor.  Used ONLY for the up-front estimate, never for anything
# reported.  Every cost number in this script is a planning number.
PATH_B_FACTOR = 1.15
PATH_B_FACTOR_BY_LEVEL: Dict[Tuple[int, int], float] = {(40, 10): 1.6}

# Where masks / latents / caches / gradient archives go.  Set in main() from
# the directory of the output JSON so --out relocates them too.
ARRAYS: str = os.path.join(S.DATA, "designs")
ARRAYS_REL: str = "designs"


def path_b_factor(level) -> float:
    return PATH_B_FACTOR_BY_LEVEL.get((int(level[0]), int(level[1])),
                                      PATH_B_FACTOR)


# ------------------------------------------------------------------ helpers
def _utc() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def _sync():
    if torch.cuda.is_available():
        torch.cuda.synchronize()


def _reset_peak():
    if torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats()


def _peak() -> int:
    return int(torch.cuda.max_memory_allocated()) if torch.cuda.is_available() else 0


def _empty_cache():
    if torch.cuda.is_available():
        torch.cuda.empty_cache()


def _lv_tag(level) -> str:
    return "%dx%d" % (int(level[0]), int(level[1]))


def _np_save_atomic(path: str, arr) -> str:
    """np.save through a temp file, then os.replace.

    A kill inside ``np.save`` otherwise leaves a truncated ``.npy`` that the
    next --resume loads and dies on, in ``build_structures``, before any skip
    logic runs -- with a reshape error that does not name the file.
    """
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    tmp = path + ".part"
    try:
        with open(tmp, "wb") as f:
            np.save(f, arr)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except BaseException:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise
    return path


def save_arrays(tag: str, binary: torch.Tensor, latent: torch.Tensor) -> Dict[str, str]:
    """np.save both tensors under ARRAYS; return paths relative to the store."""
    b = os.path.join(ARRAYS, tag + "_binary.npy")
    l = os.path.join(ARRAYS, tag + "_latent.npy")
    _np_save_atomic(b, binary.detach().cpu().numpy())
    _np_save_atomic(l, latent.detach().cpu().numpy())
    return {"binary": "%s/%s" % (ARRAYS_REL, os.path.basename(b)),
            "latent": "%s/%s" % (ARRAYS_REL, os.path.basename(l))}


@contextlib.contextmanager
def memory_efficient(flag: bool):
    """Temporarily select the MEMORY_EFFICIENT arithmetic path.

    ``vector_2d`` reads the module global at call time (no import-time capture,
    no memoization anywhere in the solve path), so flipping the attribute is
    sufficient.  The cache is emptied on both edges so the two paths do not
    inherit each other's allocator state, and the flag is restored even if the
    body raises.
    """
    old = _v2d.MEMORY_EFFICIENT
    _empty_cache()
    _v2d.MEMORY_EFFICIENT = bool(flag)
    try:
        yield
    finally:
        _v2d.MEMORY_EFFICIENT = old
        _empty_cache()


def cos_pair(a: torch.Tensor, b: torch.Tensor):
    """(cos, 1-cos) between two gradient tensors, both in float64 on the CPU.

    ``1-cos`` is NOT formed by subtracting: at cos ~ 1 that cancellation floors
    the answer at ~1e-16, which is above the noise floor this script is trying
    to measure.  It is computed as |a_hat - b_hat|^2 / 2, which is the same
    quantity and is accurate all the way down.  The raw ``cos`` is reported too
    and can read slightly above 1 (measured 1.0000000000000027); use
    ``one_minus_cos`` / ``angle_rad``, never ``arccos(cos)``.
    """
    a = a.detach().to("cpu", torch.float64).reshape(-1)
    b = b.detach().to("cpu", torch.float64).reshape(-1)
    na = float(torch.linalg.vector_norm(a))
    nb = float(torch.linalg.vector_norm(b))
    if na == 0.0 or nb == 0.0:
        return None, None
    ah, bh = a / na, b / nb
    omc = float(torch.linalg.vector_norm(ah - bh) ** 2) / 2.0
    return float(torch.dot(ah, bh)), omc


def angle_of(omc: Optional[float]) -> Optional[float]:
    """Angle in radians from ``1-cos``, NaN-free.

    ``arccos(cos)`` returns NaN whenever the reported cos rounds above 1, which
    it does at the ref rung.  ``2*asin(sqrt(omc/2))`` is exact and monotone.
    """
    if omc is None:
        return None
    x = min(max(float(omc), 0.0), 2.0) / 2.0
    return 2.0 * math.asin(math.sqrt(x))


def rel_l2(a: Optional[torch.Tensor], b: Optional[torch.Tensor]) -> Optional[float]:
    """|a - b| / |b|, computed from the tensors (no cancelling scalar formula).

    This is the one gradient statistic directly comparable to ``rel_value_err``.
    The naive scalar recovery sqrt(1 + r^2 - 2 r c) from the stored cos cancels
    catastrophically, so it is written out rather than left to the consumer.
    """
    if a is None or b is None:
        return None
    a = a.detach().to("cpu", torch.float64).reshape(-1)
    b = b.detach().to("cpu", torch.float64).reshape(-1)
    nb = float(torch.linalg.vector_norm(b))
    if nb == 0.0:
        return None
    return float(torch.linalg.vector_norm(a - b)) / nb


def rel(x: Optional[float], ref: Optional[float]) -> Optional[float]:
    """(x - ref)/|ref|, or None when ref is missing or zero."""
    if x is None or ref is None or ref == 0.0:
        return None
    return (x - ref) / abs(ref)


def sha16(t: torch.Tensor) -> str:
    a = np.ascontiguousarray(t.detach().cpu().to(torch.float64).numpy())
    return hashlib.sha1(a.tobytes()).hexdigest()[:16]


def timed_grad(rho, level, target, beta, cfg):
    """(eta, grad_cpu, wall_s, peak_bytes, err).

    The device->host copy of the gradient is deliberately OUTSIDE the timed
    window: it is ~13 us on this tensor, but it is not part of the solve.
    """
    _reset_peak()
    _sync()
    t0 = time.perf_counter()
    try:
        v, g = S.eta_grad(rho, level, target, float(beta), cfg)
        _sync()
        wall = time.perf_counter() - t0
        return v, g.detach().to("cpu", torch.float64), wall, _peak(), None
    except RuntimeError as exc:                      # OOM or solver failure
        _sync()
        wall = time.perf_counter() - t0
        _empty_cache()
        return None, None, wall, _peak(), str(exc)[:300]


def timed_eta(density, level, target, cfg):
    _reset_peak()
    _sync()
    t0 = time.perf_counter()
    try:
        v = S.eta(density, level, target, cfg)
        _sync()
        return v, time.perf_counter() - t0, _peak(), None
    except RuntimeError as exc:
        _sync()
        _empty_cache()
        return None, time.perf_counter() - t0, _peak(), str(exc)[:300]


def order_spectrum(density, level, target, cfg) -> Dict[str, object]:
    """Full transmitted/reflected order spectrum for one hard mask.

    Bit-identical to ``S.eta``'s solve: the same ``_eps`` (same dtype/device,
    audit=False) fed to the same ``_solve``, and the target number is read from
    the same ``power_t`` entry.  ``--spectrum`` checks that equality once, on
    the cheapest rung, and records the residual.  Off by default: it doubles
    the hard ladder's cost and nothing else in the file depends on it.
    """
    lv = S.check_level(level, cfg, "spectrum level")
    with torch.no_grad():
        r = S.C._solve(S.C._eps(density, cfg), lv, cfg)
        orders = [list(o) for o in r.orders]
        pt = r.power_t.detach().to("cpu", torch.float64)
        pr = r.power_r.detach().to("cpu", torch.float64)
        idx = list(r.orders).index(tuple(target))
        return {
            "orders": orders,
            "power_t": [float(x) for x in pt],
            "power_r": [float(x) for x in pr],
            "sum_power_t": float(pt.sum()), "sum_power_r": float(pr.sum()),
            "total_T": float(r.total_T), "total_R": float(r.total_R),
            "energy_residual": float(r.energy_residual),
            "eta_target": float(pt[idx]),
        }


def solver_settings() -> Dict[str, object]:
    """The solver defaults that shape the GRADIENT, recorded verbatim.

    ``e10_common._solve`` passes none of these, so the solve runs on the
    library defaults.  They are read off the signature rather than hard-coded
    so the record can never drift from the code.  ``eig_backward="default"``
    routes to plain ``torch.linalg.eig`` with PyTorch's own 1/(li-lj) backward
    and NO broadening -- ``eig_eps_*`` are consumed only by the Lorentzian
    paths, which are not selected.  In complex64 a near-degenerate mode pair
    therefore amplifies roundoff without limit, and FAST_DIAGNOSTICS
    short-circuits the minimum-gap diagnostic, so an outlying noise floor
    cannot be attributed to an eigenvalue gap after the fact.
    """
    keys = ("factorization", "normal_smoothing_sigma_px",
            "detach_tangent_field", "eig_backward", "eig_eps_relative",
            "eig_eps_absolute", "theta_deg", "phi_deg")
    out: Dict[str, object] = {}
    try:
        sig = inspect.signature(_v2d.solve_multilayer_vector_2d)
        for k in keys:
            p = sig.parameters.get(k)
            if p is not None and p.default is not inspect.Parameter.empty:
                out[k] = p.default
    except (TypeError, ValueError) as exc:              # pragma: no cover
        out["error"] = str(exc)
    out["overridden_by_e10_common_solve"] = []
    out["note"] = ("_solve passes only geometry/level/incident_jones, so every "
                   "key above is the library default and is what produced "
                   "every gradient in this file.  eig_backward='default' has "
                   "no degeneracy broadening; FAST_DIAGNOSTICS=True disables "
                   "the eigenvalue-gap diagnostic, so gaps are not recorded.")
    return out


# --------------------------------------------------------------- structures
class Struct(object):
    """One fixed structure: a latent on the 10 nm grid plus its provenance."""

    def __init__(self, sid, family, target, latent, info):
        self.sid = sid
        self.family = family
        self.target = (int(target[0]), int(target[1]))
        self.latent = latent.detach().cpu().to(torch.float64)
        self.info = dict(info)
        self.sha = sha16(self.latent)

    def on_device(self):
        return self.latent.to(CFG.device)

    def hard(self):
        return S.C.hard_binary(self.on_device(), CFG)

    def describe(self) -> Dict[str, object]:
        lat = self.latent
        sym = float((lat - torch.flip(lat, dims=(0,))).abs().max())
        b = self.hard().detach().cpu()
        return {
            "sid": self.sid, "family": self.family, "target": list(self.target),
            "pixel_nm": PIXEL_NM, "grid": list(CFG.shape),
            "latent_sha1_16": self.sha,
            "latent_min": float(lat.min()), "latent_max": float(lat.max()),
            "latent_mean": float(lat.mean()), "latent_std": float(lat.std()),
            "sym_residual_inf": sym,
            "hard_fill": float(b.mean()),
            "arrays": save_arrays("s4_1_" + self.sid, b, lat),
            "source": self.info,
        }


def mid_latent(target, seed, steps, level, schedule, progress_every=0):
    """The latent after ``steps`` steps of the frozen protocol at ``level``.

    ``schedule="truncated"`` (default) reads the spec's "first 60 steps of
    run_descent" literally: progress = step/(219-1), so the run stops partway
    up the beta ramp with the learning rate still high and the structure still
    grey -- a genuinely intermediate object.  ``schedule="compressed"`` instead
    runs a complete 60-step protocol (progress = step/(steps-1)), which ends at
    beta=64 and is therefore a converged endpoint, not a midpoint.
    """
    if int(steps) < 1:
        raise ValueError("--mid-steps must be >= 1 (got %r); a 0-step "
                         "'midpoint' is the initial latent under another name"
                         % (steps,))
    rho = S.paired_initial_latent(seed, CFG).to(CFG.device)
    adam = S.C.Adam(rho.shape, CFG)
    denom = (S.N_STEPS - 1) if schedule == "truncated" else max(steps - 1, 1)
    _reset_peak()
    _sync()
    t0 = time.perf_counter()
    beta = lr = 0.0
    for st in range(steps):
        prog = st / denom
        beta = S.C.beta_at(prog, cfg=CFG)
        lr = S.C.cosine_lr(prog, CFG)
        _, g = S.eta_grad(rho, level, target, beta, CFG)
        rho = adam.step(rho, g, lr)
        if progress_every and (st + 1) % progress_every == 0:
            print("      mid %s step %d/%d beta %.2f lr %.4f [%s]"
                  % (target, st + 1, steps, beta, lr,
                     S.fmt_s(time.perf_counter() - t0)), flush=True)
    _sync()
    info = {"kind": "mid_descent", "seed": int(seed), "steps": int(steps),
            "level": list(level), "schedule": schedule,
            "final_progress": (steps - 1) / denom,
            "beta_at_last_step": float(beta), "lr_at_last_step": float(lr),
            "wall_s": time.perf_counter() - t0, "peak_mem_bytes": _peak()}
    return rho.detach().cpu(), info


def mid_cache_path(target, seed, steps, level, schedule) -> str:
    return os.path.join(ARRAYS, "s4_1_midcache_%d_%d_s%d_n%d_%dx%d_%s.npy"
                        % (target[0], target[1], seed, steps, level[0],
                           level[1], schedule))


def mid_sid(target, seed, steps, level, schedule) -> str:
    """Structure id for a mid-descent latent.

    EVERYTHING that changes the latent is in the id: target, seed, step count,
    descent level and schedule.  Leaving the schedule out made a 'truncated'
    and a 'compressed' midpoint share a unit key AND an .npy path, so a resume
    with the other schedule silently overwrote the archived latent while
    keeping the old numbers.
    """
    return "mid_%d-%d_s%d_n%d_%dx%d_%s" % (target[0], target[1], seed, steps,
                                           level[0], level[1], schedule)


def build_structures(args, targets) -> Tuple[List["Struct"], List[Dict]]:
    """Canonical order: all (a) initials, then all (b) E26, then all (c) mid."""
    structures: List[Struct] = []
    missing: List[Dict] = []

    # (a) random initials -- the first --n-seeds seeds of each target's block
    if args.n_seeds > 0:
        for tgt in targets:
            for seed in S.seeds_for(tgt, args.n_seeds):
                lat = S.paired_initial_latent(seed, CFG)
                structures.append(Struct(
                    "init_%d-%d_s%d" % (tgt[0], tgt[1], seed), "init", tgt, lat,
                    {"kind": "paired_initial_latent", "seed": int(seed)}))

    # (b) E26 10 nm chain incumbents
    if not args.no_e26:
        for tgt in targets:
            path = os.path.join(E26_DATA, E26_PATTERN % tgt)
            if not os.path.exists(path):
                missing.append({"target": list(tgt), "path": path,
                                "reason": "file not found"})
                print("  NOTE: %s missing, skipping that structure" % path,
                      flush=True)
                continue
            arr = np.load(path).astype("float64")
            if tuple(arr.shape) != tuple(CFG.shape):
                missing.append({"target": list(tgt), "path": path,
                                "reason": "shape %r != %r"
                                          % (tuple(arr.shape), tuple(CFG.shape))})
                print("  NOTE: %s has shape %r, expected %r; skipping"
                      % (path, tuple(arr.shape), tuple(CFG.shape)), flush=True)
                continue
            with open(path, "rb") as fh:
                file_sha = hashlib.sha1(fh.read()).hexdigest()[:16]
            structures.append(Struct(
                "e26w10_%d-%d" % tgt, "e26_w10nm", tgt,
                torch.from_numpy(arr),
                {"kind": "e26_chain_incumbent", "path": path,
                 "file_sha1_16": file_sha}))

    # (c) mid-descent structures (cached on disk so --resume never recomputes)
    if not args.no_mid:
        for tgt in targets:
            seed = S.seeds_for(tgt, 3)[2]              # 7103 / 7203 / 7303
            cache = mid_cache_path(tgt, seed, args.mid_steps, MID_LEVEL,
                                   args.mid_schedule)
            side = cache[:-4] + "_info.json"
            info = None
            if os.path.exists(cache):
                try:
                    lat = torch.from_numpy(np.load(cache).astype("float64"))
                except (ValueError, OSError) as exc:
                    print("  NOTE: mid cache %s is unreadable (%s); "
                          "recomputing" % (os.path.basename(cache), exc),
                          flush=True)
                    lat = None
                else:
                    # provenance sidecar: without it a resumed store no longer
                    # says which beta the midpoint stopped at, which is the
                    # single most important fact about a mid-descent structure
                    info = S.load_json(side, None)
                    if not isinstance(info, dict):
                        info = {"kind": "mid_descent", "seed": int(seed),
                                "steps": int(args.mid_steps),
                                "level": list(MID_LEVEL),
                                "schedule": args.mid_schedule,
                                "provenance": "sidecar missing"}
                    info = dict(info)
                    info["loaded_from_cache"] = os.path.basename(cache)
                    print("  mid %s: reused %s (beta at last step %s)"
                          % (tgt, os.path.basename(cache),
                             info.get("beta_at_last_step", "?")), flush=True)
            else:
                lat = None
            if lat is None:
                print("  mid %s: %d steps at %s (%s) ..."
                      % (tgt, args.mid_steps, MID_LEVEL, args.mid_schedule),
                      flush=True)
                lat, info = mid_latent(tgt, seed, args.mid_steps, MID_LEVEL,
                                       args.mid_schedule, args.progress_every)
                _np_save_atomic(cache, lat.numpy())
                info["cache"] = os.path.basename(cache)
                S.save_json(side, info)
                print("    done in %s (beta %.2f at last step)"
                      % (S.fmt_s(info["wall_s"]), info["beta_at_last_step"]),
                      flush=True)
            structures.append(Struct(
                mid_sid(tgt, seed, args.mid_steps, MID_LEVEL,
                        args.mid_schedule), "mid", tgt, lat, info))

    return structures, missing


def noise_subset(structures: List["Struct"], n: int, spread: bool) -> List[str]:
    """Which structures get the two-path noise floor.  ``n < 0`` means all."""
    if n < 0 or n >= len(structures):
        return [s.sid for s in structures]
    n = max(0, int(n))
    if not spread:
        return [s.sid for s in structures[:n]]
    order: List[Struct] = []
    by_family: Dict[str, List[Struct]] = {}
    for s in structures:
        by_family.setdefault(s.family, []).append(s)
    fams = list(by_family)
    i = 0
    while len(order) < len(structures):
        f = fams[i % len(fams)]
        if by_family[f]:
            order.append(by_family[f].pop(0))
        i += 1
        if all(not v for v in by_family.values()):
            break
    return [s.sid for s in order[:n]]


# ------------------------------------------------------------------- ladder
def _noise_entry(level, path_a_desc: str) -> Dict[str, object]:
    """A noise row with EVERY key present, so the consumer can index it.

    Failure and success used to produce four different key sets; a missing
    ``noise_floor_one_minus_cos`` is a KeyError in analysis, not a None.
    """
    return {"level": list(level),
            "path_a": path_a_desc, "path_b": "MEMORY_EFFICIENT=False",
            "path_a_eta": None, "path_b_eta": None,
            "path_a_grad_norm": None, "path_b_grad_norm": None,
            "wall_s_b": None, "peak_mem_bytes_b": None, "error": None,
            "noise_floor_cos": None, "noise_floor_one_minus_cos": None,
            "noise_floor_angle_rad": None,
            "noise_floor_abs_value": None, "noise_floor_rel_value": None,
            "noise_floor_grad_rel_l2": None,
            "grad_norm_ratio_b_over_a": None,
            "repeat_a": None}


def run_ladder_beta(struct: "Struct", beta: float, ladder, noise_levels,
                    repeat_levels, progress_every: int,
                    keep_grads: Optional[Dict[str, object]] = None
                    ) -> Dict[str, object]:
    """Value + gradient at every rung, then the vs-ref, adjacent and noise blocks."""
    tgt = struct.target
    rho = struct.on_device()
    ref_lv = tuple(ladder[-1])

    rungs: List[Dict[str, object]] = []
    grads: Dict[Tuple[int, int], torch.Tensor] = {}
    etas: Dict[Tuple[int, int], float] = {}
    t_unit = time.perf_counter()
    peak_unit = 0
    n_err = 0

    for i, lv in enumerate(ladder):
        v, g, w, pk, err = timed_grad(rho, lv, tgt, beta, CFG)
        peak_unit = max(peak_unit, pk)
        if err is None:
            grads[tuple(lv)] = g
            etas[tuple(lv)] = v
            if keep_grads is not None:
                keep_grads["a_" + _lv_tag(lv)] = g.numpy()
        else:
            n_err += 1
            print("      !! %s beta=%s %-8s FAILED: %s"
                  % (struct.sid, beta, lv, err), flush=True)
        rungs.append({"level": list(lv), "n_terms": S.C.n_terms(lv),
                      "eta": v, "grad_norm": (None if g is None
                                              else float(torch.linalg.vector_norm(g))),
                      "wall_s": w, "peak_mem_bytes": pk, "error": err})
        if progress_every and (i + 1) % progress_every == 0:
            print("      %s beta=%s  %-8s eta=%s  [%s]"
                  % (struct.sid, beta, lv,
                     "FAILED" if v is None else "%.9f" % v, S.fmt_s(w)),
                  flush=True)

    # ---- versus the top rung
    eta_ref = etas.get(ref_lv)
    g_ref = grads.get(ref_lv)
    for row in rungs:
        lv = tuple(row["level"])
        row["ref_level"] = list(ref_lv)
        row["abs_value_err"] = (None if (row["eta"] is None or eta_ref is None)
                                else row["eta"] - eta_ref)
        row["rel_value_err"] = rel(row["eta"], eta_ref)
        c = omc = nr = rl2 = None
        if g_ref is not None and lv in grads:
            c, omc = cos_pair(grads[lv], g_ref)
            nr = float(torch.linalg.vector_norm(grads[lv])
                       / torch.linalg.vector_norm(g_ref))
            rl2 = rel_l2(grads[lv], g_ref)
        row["grad_cos_vs_ref"] = c
        row["one_minus_cos_vs_ref"] = omc
        row["grad_angle_rad_vs_ref"] = angle_of(omc)
        row["grad_norm_ratio"] = nr
        row["grad_rel_l2_vs_ref"] = rl2

    # ---- adjacent rungs (no "(40,10) is the truth" assumption)
    adjacent = []
    for lo, hi in zip(ladder[:-1], ladder[1:]):
        lo, hi = tuple(lo), tuple(hi)
        d_val = d_abs = d_cos = c = d_rl2 = None
        if lo in etas and hi in etas:
            d_abs = etas[hi] - etas[lo]
            d_val = None if etas[lo] == 0.0 else d_abs / abs(etas[lo])
        if lo in grads and hi in grads:
            c, d_cos = cos_pair(grads[hi], grads[lo])
            d_rl2 = rel_l2(grads[hi], grads[lo])
        adjacent.append({"from": list(lo), "to": list(hi), "d_value": d_val,
                         "d_value_abs": d_abs, "cos": c, "d_cos": d_cos,
                         "d_angle_rad": angle_of(d_cos),
                         "d_grad_rel_l2": d_rl2})

    # ---- noise floor: path A (reused from the ladder) vs path B
    noise = []
    for lv in noise_levels:
        lv = tuple(lv)
        entry = _noise_entry(lv, "MEMORY_EFFICIENT=True (reused)")
        if lv not in grads:
            entry["error"] = "path A unavailable"
            noise.append(entry)
            continue
        entry["path_a_eta"] = etas[lv]
        entry["path_a_grad_norm"] = float(torch.linalg.vector_norm(grads[lv]))
        with memory_efficient(False):
            vb, gb, wb, pkb, errb = timed_grad(rho, lv, tgt, beta, CFG)
        peak_unit = max(peak_unit, pkb)
        entry["path_b_eta"] = vb
        entry["path_b_grad_norm"] = (None if gb is None
                                     else float(torch.linalg.vector_norm(gb)))
        entry["wall_s_b"] = wb
        entry["peak_mem_bytes_b"] = pkb
        entry["error"] = errb
        if errb is None:
            c, omc = cos_pair(gb, grads[lv])
            entry["noise_floor_cos"] = c
            entry["noise_floor_one_minus_cos"] = omc
            entry["noise_floor_angle_rad"] = angle_of(omc)
            entry["noise_floor_abs_value"] = vb - etas[lv]
            entry["noise_floor_rel_value"] = rel(vb, etas[lv])
            entry["noise_floor_grad_rel_l2"] = rel_l2(gb, grads[lv])
            entry["grad_norm_ratio_b_over_a"] = float(
                torch.linalg.vector_norm(gb) / torch.linalg.vector_norm(grads[lv]))
            if keep_grads is not None:
                keep_grads["b_" + _lv_tag(lv)] = gb.numpy()
        else:
            n_err += 1
            print("      !! %s beta=%s %-8s path B FAILED: %s"
                  % (struct.sid, beta, lv, errb), flush=True)
        # plain rerun of path A: same code path twice, to separate arithmetic
        # reordering from run-to-run nondeterminism
        if lv in [tuple(x) for x in repeat_levels]:
            v2, g2, w2, _pk2, err2 = timed_grad(rho, lv, tgt, beta, CFG)
            if err2 is None:
                c2, omc2 = cos_pair(g2, grads[lv])
                entry["repeat_a"] = {"one_minus_cos": omc2, "cos": c2,
                                     "angle_rad": angle_of(omc2),
                                     "abs_value": v2 - etas[lv],
                                     "rel_value": rel(v2, etas[lv]),
                                     "grad_rel_l2": rel_l2(g2, grads[lv]),
                                     "wall_s": w2}
            else:
                entry["repeat_a"] = {"error": err2}
                n_err += 1
        noise.append(entry)

    return {"ladder": rungs, "adjacent": adjacent, "noise_floor": noise,
            "ref_level": list(ref_lv), "wall_s": time.perf_counter() - t_unit,
            "peak_mem_bytes": peak_unit, "n_errors": n_err}


def run_ladder_hard(struct: "Struct", ladder, noise_levels,
                    progress_every: int, spectrum: bool = False
                    ) -> Dict[str, object]:
    """Same ladder on the delivered (beta-independent) hard binary, values only."""
    tgt = struct.target
    dens = struct.hard()
    ref_lv = tuple(ladder[-1])

    rungs: List[Dict[str, object]] = []
    etas: Dict[Tuple[int, int], float] = {}
    t_unit = time.perf_counter()
    peak_unit = 0
    n_err = 0
    spec_check = None

    for i, lv in enumerate(ladder):
        v, w, pk, err = timed_eta(dens, lv, tgt, CFG)
        peak_unit = max(peak_unit, pk)
        if err is None:
            etas[tuple(lv)] = v
        else:
            n_err += 1
            print("      !! %s hard %-8s FAILED: %s" % (struct.sid, lv, err),
                  flush=True)
        row = {"level": list(lv), "n_terms": S.C.n_terms(lv), "eta": v,
               "grad_norm": None, "wall_s": w, "peak_mem_bytes": pk,
               "error": err, "spectrum": None}
        if spectrum and err is None:
            try:
                sp = order_spectrum(dens, lv, tgt, CFG)
                if spec_check is None:
                    spec_check = {"level": list(lv), "eta_via_S_eta": v,
                                  "eta_via_spectrum": sp["eta_target"],
                                  "abs_difference": sp["eta_target"] - v}
                sp.pop("eta_target", None)
                row["spectrum"] = sp
            except RuntimeError as exc:
                row["spectrum"] = {"error": str(exc)[:300]}
                n_err += 1
        rungs.append(row)
        if progress_every and (i + 1) % progress_every == 0:
            print("      %s hard      %-8s eta=%s  [%s]"
                  % (struct.sid, lv, "FAILED" if v is None else "%.9f" % v,
                     S.fmt_s(w)), flush=True)

    eta_ref = etas.get(ref_lv)
    for row in rungs:
        row["ref_level"] = list(ref_lv)
        row["abs_value_err"] = (None if (row["eta"] is None or eta_ref is None)
                                else row["eta"] - eta_ref)
        row["rel_value_err"] = rel(row["eta"], eta_ref)
        row["grad_cos_vs_ref"] = None
        row["one_minus_cos_vs_ref"] = None
        row["grad_angle_rad_vs_ref"] = None
        row["grad_norm_ratio"] = None
        row["grad_rel_l2_vs_ref"] = None

    adjacent = []
    for lo, hi in zip(ladder[:-1], ladder[1:]):
        lo, hi = tuple(lo), tuple(hi)
        d_val = d_abs = None
        if lo in etas and hi in etas:
            d_abs = etas[hi] - etas[lo]
            d_val = None if etas[lo] == 0.0 else d_abs / abs(etas[lo])
        adjacent.append({"from": list(lo), "to": list(hi), "d_value": d_val,
                         "d_value_abs": d_abs, "cos": None, "d_cos": None,
                         "d_angle_rad": None, "d_grad_rel_l2": None})

    noise = []
    for lv in noise_levels:
        lv = tuple(lv)
        entry = _noise_entry(lv, "MEMORY_EFFICIENT=True (reused)")
        if lv not in etas:
            entry["error"] = "path A unavailable"
            noise.append(entry)
            continue
        entry["path_a_eta"] = etas[lv]
        with memory_efficient(False):
            vb, wb, pkb, errb = timed_eta(dens, lv, tgt, CFG)
        peak_unit = max(peak_unit, pkb)
        entry["path_b_eta"] = vb
        entry["wall_s_b"] = wb
        entry["peak_mem_bytes_b"] = pkb
        entry["error"] = errb
        if errb is None:
            entry["noise_floor_abs_value"] = vb - etas[lv]
            entry["noise_floor_rel_value"] = rel(vb, etas[lv])
        else:
            n_err += 1
            print("      !! %s hard %-8s path B FAILED: %s"
                  % (struct.sid, lv, errb), flush=True)
        noise.append(entry)

    return {"ladder": rungs, "adjacent": adjacent, "noise_floor": noise,
            "ref_level": list(ref_lv), "wall_s": time.perf_counter() - t_unit,
            "peak_mem_bytes": peak_unit, "n_errors": n_err,
            "spectrum_consistency": spec_check}


# --------------------------------------------------------------- estimation
def unit_cost(kind: str, ladder, noise_levels, repeat_levels, noisy: bool,
              spectrum: bool = False) -> float:
    """Planning seconds for one unit.  ``kind`` is "vg" or "fwd"."""
    total = sum(S.cost_s(lv, kind) for lv in ladder)
    if kind == "fwd" and spectrum:
        total *= 2.0                       # one extra forward solve per rung
    if noisy:
        total += sum(S.cost_s(lv, kind) * path_b_factor(lv)
                     for lv in noise_levels)
        if kind == "vg":
            total += sum(S.cost_s(lv, "vg") for lv in repeat_levels
                         if tuple(lv) in {tuple(x) for x in noise_levels})
    return total


def estimate_counts(n_struct: int, n_noisy: int, betas, ladder, noise_levels,
                    repeat_levels, do_hard: bool, spectrum: bool) -> float:
    n_noisy = max(0, min(int(n_noisy), int(n_struct)))
    n_quiet = max(0, int(n_struct) - n_noisy)
    total = 0.0
    for noisy, count in ((True, n_noisy), (False, n_quiet)):
        total += count * len(betas) * unit_cost("vg", ladder, noise_levels,
                                                repeat_levels, noisy)
        if do_hard:
            total += count * unit_cost("fwd", ladder, noise_levels,
                                       repeat_levels, noisy, spectrum)
    return total


def estimate_build(args, targets) -> float:
    """Planning seconds for build_structures (the mid descents dominate)."""
    if args.no_mid:
        return 0.0
    per = args.mid_steps * S.cost_s(MID_LEVEL, "vg")
    todo = 0
    for tgt in targets:
        seed = S.seeds_for(tgt, 3)[2]
        if not os.path.exists(mid_cache_path(tgt, seed, args.mid_steps,
                                             MID_LEVEL, args.mid_schedule)):
            todo += 1
    return todo * per


def estimate_warmup(mode: str, ladder) -> float:
    if mode == "none":
        return 0.0
    rungs = ladder if mode == "full" else ladder[:1]
    return sum(S.cost_s(lv, "vg") * (1.0 + path_b_factor(lv)) for lv in rungs)


# -------------------------------------------------------------------- store
def as_list(store):
    """This script's on-disk ``units`` is a LIST (see DEVIATIONS)."""
    units = store.get("units", [])
    store["units"] = list(units.values()) if isinstance(units, dict) else list(units)
    return store


def index_units(store) -> Dict[str, int]:
    idx = {}
    for i, u in enumerate(store.get("units", [])):
        if isinstance(u, dict) and u.get("unit_key"):
            idx[u["unit_key"]] = i
    return idx


def merge_structures(store, structures) -> None:
    """Merge this pass's structure records into the store BY SID.

    Replacing the block wholesale orphaned every unit written by an earlier
    pass with a different --targets: the rows stayed, their provenance
    (latent hash, fill, symmetry residual, .npy pointers) vanished.
    """
    prev = {}
    for s in store.get("structures", []) or []:
        if isinstance(s, dict) and s.get("sid"):
            prev[s["sid"]] = s
    for s in structures:
        prev[s.sid] = s.describe()
    store["structures"] = list(prev.values())


def unit_stale(old, sha: str, ladder, want_noise, want_repeat,
               want_spectrum: bool, is_hard: bool):
    """Is a stored unit row too narrow / too old to stand for this request?

    The unit key is (structure, beta) only.  Without this check a resume that
    WIDENS the run -- more noise structures, more rungs, a different mid
    schedule -- skipped every unit and then wrote metadata claiming the wider
    coverage had been measured.  Comparison is by content, so a resume that
    NARROWS the request still skips (nothing would be gained by redoing it).
    """
    if old is None:
        return True, "not in store"
    if old.get("structure_latent_sha1_16") not in (None, sha):
        return True, "structure content changed"
    have_ladder = [tuple(r.get("level", ())) for r in old.get("ladder", []) or []]
    if have_ladder != [tuple(x) for x in ladder]:
        return True, "ladder differs (%s)" % (have_ladder,)
    have_noise = {tuple(n.get("level", ())) for n in old.get("noise_floor", []) or []}
    miss = [list(lv) for lv in want_noise if tuple(lv) not in have_noise]
    if miss:
        return True, "noise rungs missing %s" % (miss,)
    if want_noise and not old.get("noise_measured"):
        return True, "noise requested but not measured"
    if not is_hard:
        # the hard ladder has no gradients, so it never carries a repeat-A
        # block; demanding one there would redo it on every single resume
        have_rep = {tuple(n.get("level", ())) for n in old.get("noise_floor", []) or []
                    if isinstance(n.get("repeat_a"), dict)}
        failed = {tuple(n.get("level", ())) for n in old.get("noise_floor", []) or []
                  if n.get("error")}
        missr = [list(lv) for lv in want_repeat
                 if tuple(lv) not in have_rep and tuple(lv) not in failed]
        if missr:
            return True, "repeat-A rungs missing %s" % (missr,)
    if is_hard and want_spectrum and not any(
            isinstance(r.get("spectrum"), dict) for r in old.get("ladder", []) or []):
        return True, "spectrum requested but not present"
    return False, ""


def backup_existing(path: str, resume: bool, force: bool, dry: bool = False):
    """Never silently discard a finished store when --resume was forgotten.

    A ``--dry-run`` store is disposable by construction (its own ``_dry`` stem,
    6-step midpoints, 2-rung ladder), so it is overwritten without ceremony.
    """
    if resume or dry or not os.path.exists(path):
        return None, 0
    old = S.load_json(path, None) or {}
    units = old.get("units") or []
    n = len(units)
    if not n:
        return None, 0
    if not force:
        return None, n
    bak = "%s.bak-%s" % (path, time.strftime("%Y%m%dT%H%M%SZ", time.gmtime()))
    os.replace(path, bak)
    print("NOTE: %s held %d finished unit(s) and --force was given; it has "
          "been MOVED to %s, not deleted."
          % (os.path.basename(path), n, os.path.basename(bak)), flush=True)
    return bak, n


# --------------------------------------------------------------------- lock
def _pid_alive(pid: int) -> bool:
    """Is ``pid`` still running?  (Never os.kill on Windows: signal 0 there
    goes through TerminateProcess and would KILL the process.)"""
    if pid <= 0:
        return False
    if os.name == "nt":
        try:
            import ctypes
            k = ctypes.windll.kernel32
            h = k.OpenProcess(0x1000, False, int(pid))   # QUERY_LIMITED_INFO
            if not h:
                return False
            code = ctypes.c_ulong()
            ok = k.GetExitCodeProcess(h, ctypes.byref(code))
            k.CloseHandle(h)
            return bool(ok) and code.value == 259        # STILL_ACTIVE
        except Exception:
            return True          # cannot tell -> assume alive, refuse to run
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def acquire_lock(path: str):
    """Take ``<store>.lock``.  Returns (lock_path, error_message)."""
    lock = path + ".lock"
    if os.path.exists(lock):
        try:
            with open(lock, "r", encoding="utf-8") as f:
                info = json.load(f)
        except Exception:
            info = {}
        pid = int(info.get("pid", -1) or -1)
        if pid > 0 and pid != os.getpid() and _pid_alive(pid):
            return None, ("%s is locked by pid %d (started %s).  S4 wall clock "
                          "is a RESULT: two processes on one GPU contaminate "
                          "every timing in both stores (measured 3-5x "
                          "inflation).  Wait for it, or pass --no-lock if you "
                          "are certain that pid is not this experiment."
                          % (lock, pid, info.get("started_utc")))
        print("note: removing a stale lock from pid %r" % (pid,), flush=True)
    try:
        with open(lock, "w", encoding="utf-8") as f:
            json.dump({"pid": os.getpid(), "started_utc": _utc(),
                       "argv": list(sys.argv)}, f)
    except OSError as exc:
        print("WARNING: could not write %s (%s); continuing without a lock"
              % (lock, exc), flush=True)
        return None, None
    return lock, None


def release_lock(lock) -> None:
    if not lock:
        return
    try:
        os.remove(lock)
    except OSError:
        pass


# ----------------------------------------------------------------- CLI bits
def parse_levels(spec, ladder) -> List[Tuple[int, int]]:
    """"all" / "none" / "20x5,32x8" -> rungs, intersected with the ladder."""
    s = str(spec).strip().lower()
    if s in ("all", "*"):
        return [tuple(x) for x in ladder]
    if s in ("none", "-", ""):
        return []
    want: List[Tuple[int, int]] = []
    for tok in s.split(","):
        tok = tok.strip()
        if not tok:
            continue
        sep = next((c for c in ("x", ":", "/") if c in tok), None)
        if sep is None:
            raise ValueError("level %r must look like 20x5 (or 'all'/'none')"
                             % (tok,))
        a, b = tok.split(sep, 1)
        want.append((int(a), int(b)))
    lad = [tuple(x) for x in ladder]
    unknown = [lv for lv in want if lv not in lad]
    if unknown:
        print("note: --noise-levels %s are not on the ladder %s; ignored"
              % (unknown, lad), flush=True)
    return [lv for lv in lad if lv in want]           # ladder order


def parse_betas(spec) -> List[float]:
    out = []
    for tok in str(spec).split(","):
        tok = tok.strip()
        if not tok:
            continue
        v = float(tok)
        if not math.isfinite(v) or v <= 0.0:
            raise ValueError("beta %r is not a positive finite number; "
                             "tanh_projection would raise mid-run" % (tok,))
        out.append(v)
    if not out:
        raise ValueError("--betas selected nothing")
    return out


# --------------------------------------------------------------------- main
def main(argv=None) -> int:
    global ARRAYS, ARRAYS_REL

    ap = argparse.ArgumentParser(
        description="S4-1: value and gradient across the truncation ladder")
    S.add_common_args(
        ap, default_seeds=2,
        dry_help=("tiny self-check: first target only, 1 seed, ladder %s, "
                  "6 mid-descent steps, separate _dry store and designs_dry/"
                  % (LADDER_DRY,)))
    ap.add_argument("--betas", type=str, default="1,8,64",
                    help="projection betas for the gradient ladders")
    ap.add_argument("--mid-steps", type=int, default=MID_STEPS,
                    help="descent steps for the mid-descent structures (>=1)")
    ap.add_argument("--mid-schedule", choices=("truncated", "compressed"),
                    default=MID_SCHEDULE,
                    help="'truncated': first N steps of the 219-step schedule "
                         "(default); 'compressed': a complete N-step protocol")
    ap.add_argument("--noise-structures", type=int, default=N_NOISE_STRUCTURES,
                    help="how many structures get the two-path noise floor "
                         "(-1 = all, the default; narrowing it leaves the rest "
                         "of the file without a yardstick)")
    ap.add_argument("--noise-levels", type=str, default="all",
                    help="rungs for the two-path noise floor: 'all' (default), "
                         "'none', or e.g. 20x5,32x8")
    ap.add_argument("--noise-spread", action="store_true",
                    help="pick the noise subset round-robin across families "
                         "instead of the first N in canonical order")
    ap.add_argument("--skip-noise", action="store_true",
                    help="skip the noise-floor block entirely")
    ap.add_argument("--skip-hard", action="store_true",
                    help="skip the hard-binary (values-only) ladders")
    ap.add_argument("--spectrum", action="store_true",
                    help="also record the full order spectrum on the hard "
                         "ladder (doubles the hard ladder's cost)")
    ap.add_argument("--no-e26", action="store_true",
                    help="skip the E26 optimized structures")
    ap.add_argument("--no-mid", action="store_true",
                    help="skip the mid-descent structures")
    ap.add_argument("--no-save-grads", action="store_true",
                    help="do not archive the raw per-rung gradients "
                         "(~1 MB per unit; keeps every cross-rung and "
                         "cross-beta comparison recomputable without a re-run)")
    ap.add_argument("--warmup", choices=("none", "first", "full"),
                    default="full",
                    help="warm the CUDA/cuSOLVER/cuFFT plans on 'full' the "
                         "whole ladder (default; keeps per-rung wall_s free of "
                         "first-touch cost), 'first' only the lowest rung")
    ap.add_argument("--no-top-determinism", action="store_true",
                    help="skip the one-off path-A-twice check at the top rung")
    ap.add_argument("--no-lock", action="store_true",
                    help="do not take/honour the <store>.lock file")
    ap.add_argument("--ignore-gpu-check", action="store_true",
                    help="run even if another process appears to hold VRAM")
    ap.add_argument("--force", action="store_true",
                    help="with no --resume, move an existing store aside and "
                         "start fresh (it is never deleted)")
    args = ap.parse_args(argv)

    targets = S.parse_targets(args.targets)
    ladder = list(LADDER)
    S.dry_apply(args)                       # shrinks --n-seeds when --dry-run
    if args.dry_run:
        targets = targets[:1]
        ladder = list(LADDER_DRY)
        args.mid_steps = min(args.mid_steps, 6)
    for lv in ladder:
        S.check_level(lv, CFG, "ladder level")

    try:
        betas = parse_betas(args.betas)
        noise_levels = ([] if args.skip_noise
                        else parse_levels(args.noise_levels, ladder))
    except ValueError as exc:
        print("FATAL: %s" % exc, flush=True)
        return 2
    if args.n_seeds < 0:
        print("FATAL: --n-seeds must be >= 0", flush=True)
        return 2
    if not args.no_mid and args.mid_steps < 1:
        print("FATAL: --mid-steps must be >= 1 (or pass --no-mid)", flush=True)
        return 2
    repeat_levels = [lv for lv in REPEAT_LEVELS
                     if tuple(lv) in {tuple(x) for x in noise_levels}]

    path = S.out_path(args, OUT_STEM + ".py")
    # arrays live next to the store, so --out relocates the whole unit and two
    # runs can never overwrite each other's .npy files
    ARRAYS_REL = "designs_dry" if args.dry_run else "designs"
    ARRAYS = os.path.join(os.path.dirname(os.path.abspath(path)), ARRAYS_REL)
    os.makedirs(ARRAYS, exist_ok=True)

    params = dict(vars(args))
    params.update({"pixel_nm": PIXEL_NM, "ladder": [list(x) for x in ladder],
                   "betas": betas,
                   "targets_effective": [list(t) for t in targets],
                   "noise_levels_effective": [list(x) for x in noise_levels],
                   "repeat_levels": [list(x) for x in repeat_levels],
                   "mid_level": list(MID_LEVEL), "mid_sid_includes_schedule": True,
                   "e26_data": E26_DATA, "arrays_dir": ARRAYS,
                   "out_stem": OUT_STEM})
    S.banner(SCRIPT, args)

    # ---- estimate BEFORE the build: build_structures runs three descents
    n_pred = (len(targets) * max(args.n_seeds, 0)
              + (0 if args.no_e26 else len(targets))
              + (0 if args.no_mid else len(targets)))
    if args.skip_noise:
        n_noisy_pred = 0
    elif args.noise_structures < 0 or args.noise_structures >= n_pred:
        n_noisy_pred = n_pred
    else:
        n_noisy_pred = max(0, args.noise_structures)
    est_build = estimate_build(args, targets)
    est_warm = estimate_warmup(args.warmup, ladder)
    est_units = estimate_counts(n_pred, n_noisy_pred, betas, ladder,
                                noise_levels, repeat_levels,
                                not args.skip_hard, args.spectrum)
    print("-" * 72, flush=True)
    print("plan (before the build): %d structures, %d units, "
          "~%s build + ~%s warmup + ~%s units = ~%s"
          % (n_pred, n_pred * (len(betas) + (0 if args.skip_hard else 1)),
             S.fmt_s(est_build), S.fmt_s(est_warm), S.fmt_s(est_units),
             S.fmt_s(est_build + est_warm + est_units)), flush=True)
    print("  cost anchors are PLANNING numbers only (+-30%) and assume an "
          "IDLE GPU; path B at (40,10) peaks near 6.3 GiB.", flush=True)
    print("-" * 72, flush=True)

    # ---- the GPU had better be ours alone: wall clock is a reported result
    vram: Dict[str, object] = {}
    try:
        free_b, total_b = torch.cuda.mem_get_info()
        vram = {"free_bytes": int(free_b), "total_bytes": int(total_b)}
        print("VRAM: %.2f / %.2f GiB free"
              % (free_b / 2 ** 30, total_b / 2 ** 30), flush=True)
        if free_b < 8 * 2 ** 30 and not args.dry_run:
            msg = ("only %.2f GiB free -- something else is on this GPU.  S4 "
                   "assumes SERIAL execution; wall_s measured now is "
                   "contaminated (measured 3-5x inflation) and path B at "
                   "(40,10) may page under WDDM." % (free_b / 2 ** 30))
            if args.ignore_gpu_check:
                print("WARNING: %s (continuing: --ignore-gpu-check)" % msg,
                      flush=True)
                vram["warning"] = msg
            else:
                print("FATAL: %s  Stop it, or pass --ignore-gpu-check." % msg,
                      flush=True)
                return 5
    except Exception as exc:                                # pragma: no cover
        print("VRAM: unavailable (%s)" % exc, flush=True)
        vram = {"error": str(exc)}

    # ---- never silently discard a finished store
    bak, n_existing = backup_existing(path, args.resume, args.force,
                                      args.dry_run)
    if n_existing and not bak:
        print("FATAL: %s already holds %d finished unit row(s) and --resume "
              "was not given.  Re-run with --resume to continue it, or "
              "--force to move it aside deliberately.  (Refusing costs "
              "seconds; overwriting costs an hour.)" % (path, n_existing),
              flush=True)
        return 3

    lock = None
    if not args.no_lock:
        lock, err = acquire_lock(path)
        if err:
            print("FATAL: %s" % err, flush=True)
            return 4

    try:
        return _run(args, targets, ladder, betas, noise_levels, repeat_levels,
                    path, params, vram, bak, est_build, est_warm)
    finally:
        release_lock(lock)


def _run(args, targets, ladder, betas, noise_levels, repeat_levels,
         path, params, vram, bak, est_build, est_warm) -> int:
    print("building structures ...", flush=True)
    t_build = time.perf_counter()
    structures, missing = build_structures(args, targets)
    build_s = time.perf_counter() - t_build
    if not structures:
        print("no structures to run; nothing to do", flush=True)
        return 1
    noise_sids = ([] if args.skip_noise
                  else noise_subset(structures, args.noise_structures,
                                    args.noise_spread))

    est = estimate_counts(len(structures), len(noise_sids), betas, ladder,
                          noise_levels, repeat_levels, not args.skip_hard,
                          args.spectrum)
    n_units = len(structures) * (len(betas) + (0 if args.skip_hard else 1))
    print("-" * 72, flush=True)
    print("structures: %d  (%s)  [built in %s]" % (len(structures), ", ".join(
        "%s:%d" % (f, sum(1 for s in structures if s.family == f))
        for f in ["init", "e26_w10nm", "mid"]
        if any(s.family == f for s in structures)), S.fmt_s(build_s)),
        flush=True)
    print("ladder    : %s" % (ladder,), flush=True)
    print("betas     : %s  + hard binary: %s%s"
          % (betas, not args.skip_hard,
             " (+spectrum)" if args.spectrum else ""), flush=True)
    print("noise     : %d/%d structures, rungs %s, repeat %s"
          % (len(noise_sids), len(structures), noise_levels or "-",
             repeat_levels or "-"), flush=True)
    print("units     : %d   estimated %s (planning numbers, +-30%%)"
          % (n_units, S.fmt_s(est)), flush=True)
    print("output    : %s" % path, flush=True)
    print("arrays    : %s" % ARRAYS, flush=True)
    print("-" * 72, flush=True)

    store = as_list(S.resume_store(path, SCRIPT, params, args.resume))
    merge_structures(store, structures)
    meta = store.setdefault("meta", {})
    meta.setdefault("protocol", {})["s4_1_note"] = (
        "s4_1 runs entirely on the 10 nm native grid (70,240); every ladder "
        "rung is legal there and nothing is block-replicated.  ref_level / "
        "ref_pix_nm in this block are s4_common's cross-grid constants for "
        "the S4 ROUND and are unused here -- this script's reference rung is "
        "ladder[-1], recorded per unit as ref_level.")
    meta["solver"] = solver_settings()
    meta["reading_note"] = (
        "Unit rows are authoritative.  meta.passes[] records what each "
        "invocation asked for; a row's own ladder/beta/noise_measured/"
        "noise_floor[].level say what was actually measured for it.  Compare "
        "any gradient number only against the noise floor at the SAME "
        "(structure, beta, rung).  eta is float32-precision (a complex64 "
        "solve): ~6e-8 absolute near eta=0.9, so the 17 printed digits are "
        "not all significant.  Use one_minus_cos / angle_rad, never "
        "arccos(cos): the raw cos can round above 1.")
    meta["vram_at_start"] = vram
    if bak:
        meta.setdefault("backups", []).append(os.path.basename(bak))
    pass_rec: Dict[str, object] = {
        "started_utc": _utc(), "argv": list(sys.argv),
        "ladder": [list(x) for x in ladder], "betas": list(betas),
        "targets": [list(t) for t in targets],
        "noise_levels": [list(x) for x in noise_levels],
        "repeat_levels": [list(x) for x in repeat_levels],
        "noise_subset": list(noise_sids), "missing_sources": missing,
        "structure_sids": [s.sid for s in structures],
        "spectrum": bool(args.spectrum), "build_wall_s": build_s,
        "est_total_s": est + est_build + est_warm,
    }
    meta.setdefault("passes", []).append(pass_rec)
    idx = index_units(store)

    # ---- warm up so no rung pays for CUDA context / cuSOLVER / cuFFT setup
    warm: Dict[str, object] = {"mode": args.warmup}
    if args.warmup != "none":
        rho0 = structures[0].on_device()
        rungs = ladder if args.warmup == "full" else ladder[:1]
        t_w = time.perf_counter()
        for flag in (True, False):
            for lv in rungs:
                with memory_efficient(flag):
                    t0 = time.perf_counter()
                    try:
                        S.eta_grad(rho0, lv, structures[0].target, 1.0, CFG)
                        _sync()
                        warm["ME=%s|%s" % (flag, _lv_tag(lv))] = \
                            time.perf_counter() - t0
                    except RuntimeError as exc:
                        warm["ME=%s|%s" % (flag, _lv_tag(lv))] = str(exc)[:200]
        warm["total_s"] = time.perf_counter() - t_w
        _empty_cache()
        print("warmup (%s, %s): %s"
              % (args.warmup, S.fmt_s(warm["total_s"]),
                 {k: (("%.3f s" % v) if isinstance(v, float) else v)
                  for k, v in warm.items() if k.startswith("ME=")}), flush=True)
    else:
        warm["note"] = ("no warm-up: the FIRST unit's per-rung wall_s includes "
                        "cuSOLVER/cuFFT first-touch cost at every rung")
    pass_rec["warmup"] = warm
    S.save_json(path, store)

    # ---- one-off determinism control at the TOP rung (path A run twice).
    # REPEAT_LEVELS covers the cheap rungs on every noisy unit; the top rung is
    # where a workspace-dependent cuSOLVER path is most plausible and where a
    # per-unit repeat would be unaffordable, so it is checked once.
    if not args.no_top_determinism and not args.skip_noise:
        top = tuple(ladder[-1])
        st0 = structures[0]
        b0 = max(betas)
        print("top-rung determinism control: path A twice at %s, %s, beta %g "
              "(~%s) ..." % (top, st0.sid, b0,
                             S.fmt_s(2 * S.cost_s(top, "vg"))), flush=True)
        rho0 = st0.on_device()
        v1, g1, w1, _p1, e1 = timed_grad(rho0, top, st0.target, b0, CFG)
        v2, g2, w2, _p2, e2 = timed_grad(rho0, top, st0.target, b0, CFG)
        det: Dict[str, object] = {
            "level": list(top), "structure": st0.sid,
            "structure_latent_sha1_16": st0.sha, "beta": float(b0),
            "target": list(st0.target), "wall_s": [w1, w2],
            "error": e1 or e2}
        if e1 is None and e2 is None:
            c, omc = cos_pair(g2, g1)
            det.update({"cos": c, "one_minus_cos": omc,
                        "angle_rad": angle_of(omc),
                        "grad_rel_l2": rel_l2(g2, g1),
                        "abs_value": v2 - v1, "rel_value": rel(v2, v1),
                        "bitwise_equal": bool(torch.equal(g1, g2)
                                              and v1 == v2)})
            print("  1-cos(A,A') = %.3e   d_eta = %+.3e   bitwise equal: %s"
                  % (omc, v2 - v1, det["bitwise_equal"]), flush=True)
        else:
            print("  FAILED: %s" % det["error"], flush=True)
        pass_rec["top_determinism"] = det
        S.save_json(path, store)

    plan: List[Tuple[Struct, object]] = []
    for st in structures:
        for b in betas:
            plan.append((st, b))
        if not args.skip_hard:
            plan.append((st, HARD))

    t_start = time.perf_counter()
    est_left = est
    est_run = 0.0
    global_peak = 0
    n_done = n_skipped = n_redone = 0
    err_units: List[Dict[str, object]] = []
    n_errors = 0
    for i, (st, b) in enumerate(plan, 1):
        is_hard = (b == HARD)
        btag = HARD if is_hard else ("beta%g" % b)
        key = S.unit_key(st.sid, btag)
        noisy = st.sid in noise_sids
        nl = noise_levels if noisy else []
        rl = repeat_levels if noisy else []
        unit_est = unit_cost("fwd" if is_hard else "vg", ladder, nl, rl, noisy,
                             args.spectrum)
        old = store["units"][idx[key]] if key in idx else None
        stale, why = unit_stale(old, st.sha, ladder, nl, rl, args.spectrum,
                                is_hard)
        if args.resume and old is not None and not stale:
            n_skipped += 1
            est_left = max(0.0, est_left - unit_est)
            print("[%3d/%3d] %-34s %-6s SKIP (done)"
                  % (i, len(plan), st.sid, btag), flush=True)
            continue
        if args.resume and old is not None:
            n_redone += 1
            print("[%3d/%3d] %-34s %-6s REDO (%s)"
                  % (i, len(plan), st.sid, btag, why), flush=True)
        print("[%3d/%3d] %-34s %-6s target %s  (~%s for this unit, ~%s left)"
              % (i, len(plan), st.sid, btag, st.target, S.fmt_s(unit_est),
                 S.fmt_s(est_left)), flush=True)

        est_run += unit_est
        keep = ({} if (not is_hard and not args.no_save_grads) else None)
        if is_hard:
            res = run_ladder_hard(st, ladder, nl, args.progress_every,
                                  args.spectrum)
        else:
            res = run_ladder_beta(st, float(b), ladder, nl, rl,
                                  args.progress_every, keep)

        grad_file = None
        if keep:
            grad_file = "s4_1_grads_%s.npz" % key.replace("|", "_")
            gp = os.path.join(ARRAYS, grad_file)
            tmp = gp + ".part"
            try:
                with open(tmp, "wb") as fh:
                    np.savez_compressed(fh, **keep)
                os.replace(tmp, gp)
                grad_file = "%s/%s" % (ARRAYS_REL, grad_file)
            except OSError as exc:
                print("      WARNING: could not write %s (%s)"
                      % (grad_file, exc), flush=True)
                grad_file = None
                try:
                    os.remove(tmp)
                except OSError:
                    pass

        row = {"unit_key": key, "unit_index": i, "structure": st.sid,
               "structure_family": st.family, "structure_source": st.info,
               "structure_latent_sha1_16": st.sha,
               "target": list(st.target),
               "beta": (HARD if is_hard else float(b)),
               "pixel_nm": PIXEL_NM, "grid": list(CFG.shape),
               "block_replicated": False,
               "noise_measured": noisy,
               "noise_levels_requested": [list(x) for x in nl],
               "repeat_levels_requested": [list(x) for x in rl],
               "grad_archive": grad_file,
               "recorded_utc": _utc()}
        row.update(res)
        if key in idx:
            store["units"][idx[key]] = row
        else:
            store["units"].append(row)
            idx[key] = len(store["units"]) - 1
        n_errors += int(res.get("n_errors", 0) or 0)
        if res.get("n_errors"):
            bad = [r["level"] for r in res["ladder"] if r.get("error")]
            bad += [["noiseB"] + list(n["level"]) for n in res["noise_floor"]
                    if n.get("error")]
            err_units.append({"unit_key": key, "levels": bad,
                              "n_errors": int(res["n_errors"])})
        store["meta"]["updated_utc"] = _utc()
        S.save_json(path, store)
        n_done += 1
        global_peak = max(global_peak, int(res["peak_mem_bytes"]))
        est_left = max(0.0, est_left - unit_est)

        etas = [r["eta"] for r in res["ladder"]]
        lo = next((e for e in etas if e is not None), None)
        hi = res["ladder"][-1]["eta"]
        print("          eta %s -> %s over the ladder | %s | peak %.2f GiB%s"
              % ("%.6f" % lo if lo is not None else "n/a",
                 "%.6f" % hi if hi is not None else "n/a",
                 S.fmt_s(res["wall_s"]), res["peak_mem_bytes"] / 2 ** 30,
                 "" if not res.get("n_errors")
                 else "  !! %d error(s)" % res["n_errors"]), flush=True)

    total = time.perf_counter() - t_start
    pass_rec["units_written"] = n_done
    pass_rec["units_skipped"] = n_skipped
    pass_rec["units_redone"] = n_redone
    pass_rec["wall_s"] = total
    pass_rec["est_units_run_s"] = est_run
    pass_rec["peak_mem_bytes"] = global_peak
    pass_rec["n_errors"] = n_errors
    pass_rec["error_units"] = err_units
    pass_rec["finished_utc"] = _utc()
    # accumulate across passes rather than overwrite: an all-skipped resume
    # used to write total_wall_s ~ 0 and peak 0 over the real figures
    meta = store["meta"]
    meta["total_wall_s"] = float(meta.get("total_wall_s") or 0.0) + total
    meta["global_peak_mem_bytes"] = max(int(meta.get("global_peak_mem_bytes")
                                            or 0), global_peak)
    meta["n_errors_total"] = int(meta.get("n_errors_total") or 0) + n_errors
    meta["finished_utc"] = _utc()
    S.save_json(path, store)

    print("=" * 72, flush=True)
    print("%d units written (%d of them redone), %d skipped, %d total in the "
          "store" % (n_done, n_redone, n_skipped, len(store["units"])),
          flush=True)
    print("wall %s for the units run here (%s was estimated for the units "
          "actually run; %s for the whole plan), peak %.2f GiB"
          % (S.fmt_s(total), S.fmt_s(est_run), S.fmt_s(est),
             global_peak / 2 ** 30), flush=True)
    print("wrote %s" % path, flush=True)
    if err_units:
        print("!" * 72, flush=True)
        print("%d SOLVER/OOM ERROR(S) in %d unit(s) -- the affected rungs have "
              "eta/grad = null and are NOT usable:" % (n_errors, len(err_units)),
              flush=True)
        for e in err_units:
            print("   %-40s %s" % (e["unit_key"], e["levels"]), flush=True)
        print("!" * 72, flush=True)
    else:
        print("no solver/OOM errors", flush=True)
    if missing_of(store):
        print("missing sources (recorded, not fatal): %s"
              % missing_of(store), flush=True)
    return 0


def missing_of(store) -> List[str]:
    out = []
    for p in store.get("meta", {}).get("passes", []) or []:
        for m in p.get("missing_sources", []) or []:
            if m.get("path") not in out:
                out.append(m.get("path"))
    return out


if __name__ == "__main__":
    sys.exit(main())
