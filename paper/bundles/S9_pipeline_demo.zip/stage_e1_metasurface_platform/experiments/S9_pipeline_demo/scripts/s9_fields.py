"""S9 -- x-z field map of the delivered binary (P2, target (4,0)).

The solver returns the tangential E amplitudes of every transmitted order at
the output interface (z = d) and of every reflected order at the input
interface (z = 0); the incident wave is Ex = 1 at normal incidence from the
n = 1.46 side.  The field is reconstructed on the two half spaces
(convention as viz/app.fields_block: exp(+i k0 (kx x + ky y + kz z)), k in
units of k0):

    z < 0 :   E = E_inc e^{+i k0 kz_in z} + sum_o r_o e^{i k0 (kx_o x + ky_o y - kz_in,o z)}
    z > d :   E = sum_o t_o e^{i k0 (kx_o x + ky_o y + kz_out,o (z - d))}

with Ez from div E = 0.  Inside the layer the modal fields are not exposed,
so that band shows the structure's cross-section at the symmetry plane y0.
Evanescent orders are kept (they decay physically away from the interfaces).
Plots Re(Ex) (wavefronts) and |E|^2 at y = y0 over two periods.
"""
import json
import math
import os
import sys

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import s9_demo as D                                                   # noqa: E402
C = D.C
from workbench.app import k_vectors, solve_density                    # noqa: E402
from trustworthy_fmm.physics.channels import outgoing_sqrt            # noqa: E402

DATA, FIG = D.DATA, D.FIG


def main():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.colors import TwoSlopeNorm

    device = C.setup_runtime()
    D.S7.assert_eig_cpu()
    cfg = C.make_cfg(5)
    od = C.orders_for(D.M, cfg)
    ctx = C.make_ctx(cfg, (D.M, 0), od["descent"], od["gate"], device)
    R = json.load(open(os.path.join(DATA, "s9_demo.json"), encoding="utf-8"))
    b = torch.from_numpy(np.load(os.path.join(DATA, R["delivery"]["files"]["binary"]))["binary"].astype(np.float64))
    level = od["top"]
    with torch.no_grad():
        r = solve_density(b, tuple(level), cfg, ctx.theta, ctx.phi, ctx.dtype, ctx.device)
    orders, kx, ky = k_vectors(cfg, level, ctx.theta, ctx.phi)
    kz_in = outgoing_sqrt(torch.as_tensor(cfg.n_incident ** 2 - kx ** 2 - ky ** 2, dtype=torch.complex128)).numpy()
    kz_out = outgoing_sqrt(torch.as_tensor(cfg.n_output ** 2 - kx ** 2 - ky ** 2, dtype=torch.complex128)).numpy()
    tt = r.fields["tangential_t"].detach().cpu().numpy().astype(np.complex128)
    tr = r.fields["tangential_r"].detach().cpu().numpy().astype(np.complex128)
    i0 = orders.index((0, 0))
    k0 = 2.0 * math.pi / cfg.wavelength_nm
    lx, ly = cfg.lattice_nm
    d = cfg.thickness_nm
    y0 = ly / 2.0
    # grids (nm): two periods in x; z from -1.2 um to d + 2.4 um
    x = np.linspace(0.0, 2 * lx, 600)
    z_lo = np.linspace(-1200.0, 0.0, 120)
    z_hi = np.linspace(d, d + 2400.0, 240)

    def field(xg, zg, side):
        ex = np.zeros(xg.shape, np.complex128)
        ey = np.zeros(xg.shape, np.complex128)
        ez = np.zeros(xg.shape, np.complex128)
        if side == "in":
            # incident plane wave (Ex = 1, along +z) + reflected orders
            ex += np.exp(1j * k0 * kz_in[i0] * zg)
            amp, kz, sgn, zoff = tr, kz_in, -1.0, 0.0
        else:
            amp, kz, sgn, zoff = tt, kz_out, +1.0, d
        for i in range(len(orders)):
            a_x, a_y = amp[i, 0], amp[i, 1]
            if abs(a_x) + abs(a_y) < 1e-12:
                continue
            kzz = sgn * kz[i]
            ph = np.exp(1j * k0 * (kx[i] * xg + ky[i] * y0 + kzz * (zg - zoff)))
            kz_safe = kzz if abs(kzz) > 1e-9 else 1e-9
            a_z = -(kx[i] * a_x + ky[i] * a_y) / kz_safe
            ex += a_x * ph
            ey += a_y * ph
            ez += a_z * ph
        return ex, ey, ez

    XL, ZL = np.meshgrid(x, z_lo)
    XH, ZH = np.meshgrid(x, z_hi)
    exl, eyl, ezl = field(XL, ZL, "in")
    exh, eyh, ezh = field(XH, ZH, "out")
    Il = np.abs(exl) ** 2 + np.abs(eyl) ** 2 + np.abs(ezl) ** 2
    Ih = np.abs(exh) ** 2 + np.abs(eyh) ** 2 + np.abs(ezh) ** 2
    # the structure's cross-section at y0 (row of the binary), for the layer band
    row = b.numpy()[min(int(round(y0 / 5.0)), b.shape[0] - 1), :]
    cross = np.tile(row, 2)
    theta4 = math.degrees(math.asin(D.M * cfg.wavelength_nm / lx / cfg.n_output))
    # --- figure
    fig, axs = plt.subplots(2, 1, figsize=(12, 7.6), sharex=True)
    for ax, (Fl, Fh), title, kind in ((axs[0], (exl.real, exh.real), "Re(Ex)  (incident Ex = 1; wavefronts)", "div"),
                                      (axs[1], (Il, Ih), "|E|^2  (incident = 1)", "seq")):
        if kind == "div":
            lim = float(np.percentile(np.abs(np.concatenate([Fl.ravel(), Fh.ravel()])), 99))
            nrm = TwoSlopeNorm(vcenter=0.0, vmin=-lim, vmax=lim)
            cm = "RdBu_r"
        else:
            nrm = None
            cm = "magma"
        vmax = None if kind == "div" else float(np.percentile(np.concatenate([Fl.ravel(), Fh.ravel()]), 99))
        im = ax.pcolormesh(x / 1000, z_lo / 1000, Fl, cmap=cm, norm=nrm, vmin=None if nrm else 0, vmax=None if nrm else vmax, shading="auto")
        ax.pcolormesh(x / 1000, z_hi / 1000, Fh, cmap=cm, norm=nrm, vmin=None if nrm else 0, vmax=None if nrm else vmax, shading="auto")
        # layer band with the cross-section (black = n 3.2)
        ax.imshow(cross[None, :], cmap="gray_r", vmin=0, vmax=1, aspect="auto", extent=[0, 2 * lx / 1000, 0, d / 1000], interpolation="nearest")
        ax.axhline(0.0, color="0.3", lw=0.6)
        ax.axhline(d / 1000, color="0.3", lw=0.6)
        # expected (+4,0) direction in the output medium
        x0, z0 = 4.5, d / 1000 + 0.3
        L = 1.4
        ax.annotate("", xy=(x0 + L * math.sin(math.radians(theta4)), z0 + L * math.cos(math.radians(theta4))), xytext=(x0, z0),
                    arrowprops=dict(arrowstyle="->", color="k" if kind == "seq" else "0.1", lw=1.5))
        ax.text(x0 + 0.05, z0 + 0.05, "(+4,0): %.1f deg" % theta4, fontsize=8, color="k" if kind == "seq" else "0.1")
        ax.set_ylim(z_lo[0] / 1000, z_hi[-1] / 1000)
        ax.set_xlim(0, 2 * lx / 1000)
        ax.set_ylabel("z (um)   glass n=1.46 below 0 | layer 0-0.3 | air above", fontsize=8)
        ax.set_title(title, fontsize=10)
        fig.colorbar(im, ax=ax, shrink=0.9, pad=0.01)
    axs[1].set_xlabel("x (um), two periods of 3.0 um; y = %.0f nm (symmetry plane)" % y0)
    fig.suptitle("x-z field of the delivered binary, order (%d,%d), normal incidence from glass: T(+4,0) = %.3f, T_total %.3f, R_total %.3f"
                 % (level[0], level[1], float(r.power_t[orders.index((D.M, 0))]), float(r.total_T), float(r.total_R)), fontsize=10)
    fig.tight_layout()
    out = os.path.join(FIG, "s9_field_xz.png")
    fig.savefig(out, dpi=170)
    plt.close(fig)
    # --- numbers for the record: mean intensity far downstream, order angles
    zfar = slice(-40, None)
    print("T(+4,0) %.4f | mean |E|^2 at z=d+2.0..2.4 um: %.3f | incident side mean |E|^2: %.3f" % (float(r.power_t[orders.index((D.M, 0))]), Ih[zfar].mean(), Il.mean()))
    print("propagating transmitted orders and angles:", [("(%+d,%+d)" % o, round(math.degrees(math.asin(min(1, kx[i] / cfg.n_output))), 1), round(float(r.power_t[i]), 3))
                                                        for i, o in enumerate(orders) if kz_out[i].real > 1e-9 and float(r.power_t[i]) > 1e-3])
    print("figure:", out)


if __name__ == "__main__":
    main()
