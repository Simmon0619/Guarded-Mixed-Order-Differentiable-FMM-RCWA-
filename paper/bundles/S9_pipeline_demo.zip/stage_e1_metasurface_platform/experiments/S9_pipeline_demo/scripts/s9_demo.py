"""S9 -- one end-to-end run of the shipped pipeline (strategy v2, the parts that
are already validated) on P2, target (4,0):

  1. three MIX4 tickets (219 steps, README ramp 2 -> 2000, k = 4 from beta ~11,
     hard-binary gate checkpoints), each delivering its best gate checkpoint;
  2. select by gate reading; certify the winner at rung 1 (52,7) and the top
     rung (64,9); report (rung1, top, delta) and the gate optimism;
  3. conditional repair: only the DELIVERED ticket, only if rung1 is below the
     pool's running median minus 0.05 (S7 m=4 O pool median 0.733 -> bar 0.683)
     AND its gate optimism is < 0.05; chain at beta = max(beta*, 64), 15 hops,
     stop after 12 consecutive rejections, alpha cycling 0.1/0.25/0.5, 30-step
     mixed re-descent, hard-binary gate acceptance, rung-1 read on every accept;
  4. the delivered hard binary (image), its diffraction table at both
     certification rungs, and the ticket / chain curves.

Not in this demo (E3 not run yet): the gradient guards, the adaptive cadence,
the online order rise.  Descriptive; GPU / complex64, eig on CPU.
"""
import importlib
import json
import os
import sys
import time
from typing import Dict, List

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
_S7 = os.path.abspath(os.path.join(_HERE, "..", "..", "S7_headtohead", "scripts"))
sys.path.insert(0, _S7)
import s7_headtohead as S7                                            # noqa: E402
C = S7.C
from workbench.app import _sym, filtered_noise, app_hard_binary, solve_density   # noqa: E402

DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
FIG = os.path.abspath(os.path.join(_HERE, "..", "figures"))
M = 4
N_TICKETS = 3
STEPS, BETA_END = 219, 2000.0
SEED_BASE = 310000
NOISE_BASE = 320000
POOL_MEDIAN_RUNG1 = 0.733          # S7 m=4 O pool (12 tickets), s7_analysis_b2000.json
REPAIR_BAR = POOL_MEDIAN_RUNG1 - 0.05
OPTIMISM_MAX = 0.05
HOPS, STOP_AFTER = 15, 12


def log(msg, fh):
    line = time.strftime("%H:%M:%S ") + msg
    print(line, flush=True)
    fh.write(line + "\n")
    fh.flush()


def diffraction_table(binary, level, ctx):
    """All orders' transmitted / reflected power at ``level`` (forward only)."""
    with torch.no_grad():
        r = solve_density(binary, tuple(level), ctx.cfg, ctx.theta, ctx.phi, ctx.dtype, ctx.device)
    pt = r.power_t.detach().cpu().numpy().astype(float)
    pr = r.power_r.detach().cpu().numpy().astype(float)
    rows = []
    for (mm, nn), t, rr in zip(r.orders, pt, pr):
        if abs(t) > 1e-6 or abs(rr) > 1e-6:
            rows.append({"m": int(mm), "n": int(nn), "T": float(t), "R": float(rr)})
    rows.sort(key=lambda x: (x["n"], x["m"]))
    return {"level": list(level), "orders": rows, "T_total": float(pt.sum()), "R_total": float(pr.sum()),
            "target_T": float(pt[r.orders.index((M, 0))])}


def main():
    os.makedirs(DATA, exist_ok=True)
    os.makedirs(os.path.join(DATA, "designs"), exist_ok=True)
    os.makedirs(FIG, exist_ok=True)
    device = C.setup_runtime()
    S7.assert_eig_cpu()
    fh = open(os.path.join(DATA, "s9_demo.log"), "a", encoding="utf-8")
    cfg = C.make_cfg(5)
    od = C.orders_for(M, cfg)
    ctx = C.make_ctx(cfg, (M, 0), od["descent"], od["gate"], device)
    beta_fn = C.beta_geometric(2.0, BETA_END)
    mf = S7.mix_from_for(STEPS, BETA_END)
    ck = S7.o_ckpts(STEPS)
    gate_fwd = S7.PROBLEMS["P2"]["gate_fwd"][M]
    out_path = os.path.join(DATA, "s9_demo.json")
    R = json.load(open(out_path, encoding="utf-8")) if os.path.exists(out_path) else {"meta": {}, "tickets": [], "selection": {}, "repair": None, "delivery": {}}
    R["meta"] = {"problem": "P2 3000x500 nm, 300 nm, 5 nm pixels, lambda 660 nm, n_in 1.46 -> n_out 1.0, feature n 3.2", "target": [M, 0],
                 "orders": {k: list(v) for k, v in od.items()}, "steps": STEPS, "beta_end": BETA_END, "k": 4, "mix_from": mf,
                 "repair_rule": "delivered rung1 < %.3f (pool median %.3f - 0.05) and gate optimism < %.2f; beta_re = max(beta*, 64); %d hops, stop after %d rejections"
                                % (REPAIR_BAR, POOL_MEDIAN_RUNG1, OPTIMISM_MAX, HOPS, STOP_AFTER),
                 "eig_device": "cpu", "device": device}
    log("S9 demo start | m=%d | orders %s | mix_from %d" % (M, od, mf), fh)
    t_all = time.perf_counter()
    # ------------------------------------------------------------- 1. tickets
    for i in range(N_TICKETS):
        if any(t["index"] == i for t in R["tickets"]):
            continue
        seed = SEED_BASE + i
        ev: List[Dict] = []
        t0 = time.perf_counter()
        d = C.MixedDescent(ctx, seed, STEPS, beta_fn, ck, ev, beta_final=BETA_END, k=4, mix_from=mf)
        r = d.finish()
        best = r["best"]
        tc = time.perf_counter()
        e1 = C.eta(best["binary"], od["rung1"], ctx)
        t_cert = time.perf_counter() - tc
        tag = "s9_m%d_t%02d" % (M, i)
        np.savez_compressed(os.path.join(DATA, "designs", tag + "_best_binary.npz"), binary=best["binary"].numpy().astype(np.uint8))
        np.save(os.path.join(DATA, "designs", tag + "_best_latent.npy"), best["latent"].numpy())
        rec = {"index": i, "seed": seed, "best_step": best["step"], "beta_star": beta_fn(best["step"], STEPS),
               "eta_gate": best["eta_gate"], "eta_rung1": e1, "gate_optimism": best["eta_gate"] - e1,
               "final_step": r["final"]["step"], "final_eta_gate": r["final"]["eta_gate"],
               "reported_continuous": r["reported_continuous"], "collapse_step": r["collapse_step"],
               "checkpoints": r["checkpoints"], "trajectory": r["trajectory"],
               "n_high_order_steps": r["n_high_order_steps"], "wall_descent_s": r["wall_descent_s"], "wall_gate_s": r["wall_gate_s"],
               "ticket_cost_s": r["wall_descent_s"] + 12 * gate_fwd, "cert_rung1_s": t_cert, "unit_wall_s": time.perf_counter() - t0,
               "grad_events": ev, "files": {"binary": "designs/" + tag + "_best_binary.npz", "latent": "designs/" + tag + "_best_latent.npy"}}
        R["tickets"].append(rec)
        C.save_json(out_path, R)
        log("ticket %d | best@%d (beta* %.0f) gate %.4f rung1 %.4f optimism %+.4f | final gate %.4f | reported(cont) %.4f | high %d | cost %s"
            % (i, best["step"], rec["beta_star"], best["eta_gate"], e1, rec["gate_optimism"], r["final"]["eta_gate"], r["reported_continuous"],
               r["n_high_order_steps"], C.fmt_s(rec["ticket_cost_s"])), fh)
    # ----------------------------------------------------------- 2. selection
    tickets = sorted(R["tickets"], key=lambda t: t["index"])
    win = max(tickets, key=lambda t: t["eta_gate"])
    b = torch.from_numpy(np.load(os.path.join(DATA, win["files"]["binary"]))["binary"].astype(np.float64))
    lat = torch.from_numpy(np.load(os.path.join(DATA, win["files"]["latent"])).astype(np.float64))
    if "eta_top" not in R["selection"] or R["selection"].get("winner") != win["index"]:
        t0 = time.perf_counter()
        e_top = C.eta(b, od["top"], ctx)
        R["selection"] = {"winner": win["index"], "rule": "best gate reading of %d tickets" % len(tickets),
                          "eta_gate": win["eta_gate"], "eta_rung1": win["eta_rung1"], "eta_top": e_top,
                          "rung1_minus_top": win["eta_rung1"] - e_top, "gate_optimism": win["gate_optimism"], "top_read_s": time.perf_counter() - t0}
        C.save_json(out_path, R)
    sel = R["selection"]
    log("selected ticket %d | gate %.4f | rung1 %.4f | top %.4f (delta %+.4f) | optimism %+.4f" % (win["index"], sel["eta_gate"], sel["eta_rung1"], sel["eta_top"], sel["rung1_minus_top"], sel["gate_optimism"]), fh)
    # ------------------------------------------------------- 3. conditional repair
    trigger = (win["eta_rung1"] < REPAIR_BAR) and (win["gate_optimism"] < OPTIMISM_MAX)
    log("repair trigger: rung1 %.4f %s bar %.3f, optimism %.4f %s %.2f -> %s"
        % (win["eta_rung1"], "<" if win["eta_rung1"] < REPAIR_BAR else ">=", REPAIR_BAR, win["gate_optimism"],
           "<" if win["gate_optimism"] < OPTIMISM_MAX else ">=", OPTIMISM_MAX, "CHAIN" if trigger else "no repair"), fh)
    deliver_bin, deliver_r1, deliver_gate, deliver_src = b, win["eta_rung1"], win["eta_gate"], "ticket %d" % win["index"]
    if trigger and R.get("repair") is None:
        beta_re = max(float(win["beta_star"]), 64.0)
        inc_lat = lat.to(device) if device != "cpu" else lat
        inc_bin, inc_gate, inc_r1 = b, win["eta_gate"], win["eta_rung1"]
        ev: List[Dict] = []
        jumps, curve = [], [{"jump": -1, "eta_gate": inc_gate, "eta_rung1": inc_r1}]
        t0 = time.perf_counter()
        rejects, n_acc = 0, 0
        for j in range(HOPS):
            alpha = S7.ALPHAS[j % len(S7.ALPHAS)]
            noise = filtered_noise(NOISE_BASE + j, cfg)
            if device != "cpu":
                noise = noise.to(device)
            pert = _sym((inc_lat + alpha * cfg.init_scale * noise).clamp(0.0, 1.0), ctx.mode)
            rho, v_last, w = S7.redescend_mixed(pert, ctx, S7.RE_STEPS, beta_re, S7.RE_K, ev)
            cb = app_hard_binary(rho.detach().cpu(), cfg, ctx.mode)
            sc = C.eta(cb, od["gate"], ctx)
            acc = bool(sc > inc_gate)
            row = {"jump": j, "alpha": alpha, "cand_gate": sc, "cand_minus_inc": sc - inc_gate, "n_flipped": int((cb != inc_bin).sum()), "accepted": acc}
            if acc:
                r1 = C.eta(cb, od["rung1"], ctx)
                row.update({"cand_rung1": r1, "false_accept": bool(r1 < inc_r1)})
                inc_lat, inc_bin, inc_gate, inc_r1 = rho, cb, sc, r1
                n_acc += 1
                rejects = 0
            else:
                rejects += 1
            jumps.append(row)
            curve.append({"jump": j, "eta_gate": inc_gate, "eta_rung1": inc_r1})
            log("  hop %2d a=%.2f | cand gate %.4f (%+.4f) flips %d | %s" % (j, alpha, sc, sc - inc_gate, row["n_flipped"], "ACCEPT rung1 %.4f" % inc_r1 if acc else "reject"), fh)
            if rejects >= STOP_AFTER:
                log("  stop: %d consecutive rejections" % rejects, fh)
                break
        np.savez_compressed(os.path.join(DATA, "designs", "s9_m%d_chain_final_binary.npz" % M), binary=inc_bin.numpy().astype(np.uint8))
        R["repair"] = {"parent": win["index"], "beta_re": beta_re, "hops_run": len(jumps), "n_accept": n_acc,
                       "n_false_accept": int(sum(1 for x in jumps if x.get("false_accept"))),
                       "final_eta_gate": inc_gate, "final_eta_rung1": inc_r1, "gain_rung1": inc_r1 - win["eta_rung1"],
                       "jumps": jumps, "incumbent_curve": curve, "wall_s": time.perf_counter() - t0, "grad_events": ev,
                       "files": {"binary": "designs/s9_m%d_chain_final_binary.npz" % M}}
        C.save_json(out_path, R)
        log("chain done | accepts %d (false %d) | rung1 %.4f -> %.4f | %s" % (n_acc, R["repair"]["n_false_accept"], win["eta_rung1"], inc_r1, C.fmt_s(R["repair"]["wall_s"])), fh)
    elif not trigger:
        R["repair"] = {"triggered": False}
    if R.get("repair") and R["repair"].get("n_accept", 0) > 0 and R["repair"]["final_eta_gate"] > win["eta_gate"]:
        deliver_bin = torch.from_numpy(np.load(os.path.join(DATA, R["repair"]["files"]["binary"]))["binary"].astype(np.float64))
        deliver_r1, deliver_gate, deliver_src = R["repair"]["final_eta_rung1"], R["repair"]["final_eta_gate"], "chain on ticket %d" % win["index"]
    # ------------------------------------------------------------ 4. delivery
    if R["delivery"].get("source") != deliver_src:
        t0 = time.perf_counter()
        tab1 = diffraction_table(deliver_bin, od["rung1"], ctx)
        tabt = diffraction_table(deliver_bin, od["top"], ctx)
        R["delivery"] = {"source": deliver_src, "eta_gate": deliver_gate, "eta_rung1": deliver_r1, "eta_top": tabt["target_T"],
                         "sha1": C.sha1_of(deliver_bin), "fill_fraction": float(deliver_bin.mean()),
                         "diffraction_rung1": tab1, "diffraction_top": tabt, "reads_s": time.perf_counter() - t0}
        np.savez_compressed(os.path.join(DATA, "designs", "s9_m%d_delivered_binary.npz" % M), binary=deliver_bin.numpy().astype(np.uint8))
        R["delivery"]["files"] = {"binary": "designs/s9_m%d_delivered_binary.npz" % M}
        R["meta"]["total_wall_s"] = time.perf_counter() - t_all
        C.save_json(out_path, R)
    dl = R["delivery"]
    log("DELIVERED (%s): gate %.4f | rung1 (52,7) %.4f | top (64,9) %.4f | T_total %.4f R_total %.4f | fill %.3f | total wall %s"
        % (dl["source"], dl["eta_gate"], dl["eta_rung1"], dl["eta_top"], dl["diffraction_top"]["T_total"], dl["diffraction_top"]["R_total"], dl["fill_fraction"], C.fmt_s(R["meta"].get("total_wall_s", 0))), fh)
    log("orders (n=0 row, top rung): " + "  ".join("m=%+d:%.3f" % (o["m"], o["T"]) for o in dl["diffraction_top"]["orders"] if o["n"] == 0), fh)


if __name__ == "__main__":
    main()
