"""S9 -- figures from data/s9_demo.json (no solves): the delivered hard binary,
its diffraction efficiencies by order at both certification rungs, and the
ticket / chain curves."""
import json
import os

import numpy as np

_HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
FIG = os.path.abspath(os.path.join(_HERE, "..", "figures"))


def main():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    R = json.load(open(os.path.join(DATA, "s9_demo.json"), encoding="utf-8"))
    os.makedirs(FIG, exist_ok=True)
    dl = R["delivery"]
    m = R["meta"]["target"][0]
    b = np.load(os.path.join(DATA, dl["files"]["binary"]))["binary"].astype(float)
    ny, nx = b.shape                       # 100 x 600 at 5 nm: 500 x 3000 nm
    # --- the pattern: two periods in x, one in y, physical aspect
    fig, ax = plt.subplots(figsize=(12, 2.4))
    ax.imshow(np.tile(b, (1, 2)), cmap="gray_r", origin="lower", extent=[0, 2 * nx * 5 / 1000, 0, ny * 5 / 1000], interpolation="nearest")
    ax.axvline(nx * 5 / 1000, color="0.5", lw=0.8, ls="--")
    ax.set_xlabel("x (um)  -- two periods of 3.0 um")
    ax.set_ylabel("y (um)")
    ax.set_title("delivered hard binary, target (%d,0): gate %.3f | rung1 (52,7) %.3f | top (64,9) %.3f | fill %.2f  [%s]"
                 % (m, dl["eta_gate"], dl["eta_rung1"], dl["eta_top"], dl["fill_fraction"], dl["source"]), fontsize=9)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "s9_delivered_binary.png"), dpi=200)
    plt.close(fig)
    # --- diffraction efficiencies by order (n = 0 row), both rungs
    fig, axs = plt.subplots(1, 2, figsize=(12, 3.8), sharey=True)
    for ax, key, title in ((axs[0], "diffraction_rung1", "rung 1 (52,7)"), (axs[1], "diffraction_top", "top rung (64,9)")):
        tab = dl[key]
        rows = [o for o in tab["orders"] if o["n"] == 0]
        ms = [o["m"] for o in rows]
        T = [o["T"] for o in rows]
        Rr = [o["R"] for o in rows]
        x = np.arange(len(ms))
        cols = ["#1f4e79" if mm == m else "#9db7d5" for mm in ms]
        ax.bar(x - 0.2, T, 0.4, color=cols, label="transmitted")
        ax.bar(x + 0.2, Rr, 0.4, color="#bfbfbf", label="reflected")
        for xi, t in zip(x, T):
            if t > 0.02:
                ax.text(xi - 0.2, t + 0.01, "%.3f" % t, ha="center", fontsize=7)
        ax.set_xticks(x)
        ax.set_xticklabels(["(%+d,0)" % mm for mm in ms], fontsize=8)
        ax.set_title("%s: T_total %.3f, R_total %.3f, target %.3f" % (title, tab["T_total"], tab["R_total"], tab["target_T"]), fontsize=9)
        ax.set_ylim(0, 1.0)
        ax.grid(axis="y", alpha=0.3)
        ax.legend(fontsize=8, loc="upper left")
    axs[0].set_ylabel("efficiency")
    fig.suptitle("diffraction of the delivered binary (n = 0 row; orders with power > 1e-6)", fontsize=10)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "s9_diffraction.png"), dpi=170)
    plt.close(fig)
    # --- ticket curves (gate checkpoints) and the chain
    fig, axs = plt.subplots(1, 2, figsize=(12, 3.8))
    ax = axs[0]
    for t in sorted(R["tickets"], key=lambda t: t["index"]):
        st = [c["step"] for c in t["checkpoints"]]
        eg = [c["eta_gate"] for c in t["checkpoints"]]
        line, = ax.plot(st, eg, marker=".", ms=4, lw=1.3, label="ticket %d: best@%d gate %.3f, rung1 %.3f" % (t["index"], t["best_step"], t["eta_gate"], t["eta_rung1"]))
        ax.plot([t["best_step"]], [t["eta_gate"]], marker="o", ms=8, mfc="none", color=line.get_color())
    ax.axvline(R["meta"]["mix_from"], color="0.5", lw=0.8, ls=":")
    ax.set_xlabel("step (beta 2 -> 2000 geometric; dotted: mixing starts)")
    ax.set_ylabel("hard-binary gate reading (44,6)")
    ax.set_title("three MIX4 tickets; circle = delivered checkpoint", fontsize=9)
    ax.grid(alpha=0.3)
    ax.legend(fontsize=7)
    ax = axs[1]
    rep = R.get("repair") or {}
    if rep.get("incumbent_curve"):
        cv = rep["incumbent_curve"]
        ax.step([c["jump"] for c in cv], [c["eta_gate"] for c in cv], where="post", lw=1.5, label="incumbent gate")
        ax.step([c["jump"] for c in cv], [c["eta_rung1"] for c in cv], where="post", lw=1.5, ls="--", label="incumbent rung1")
        ax.plot([j["jump"] for j in rep["jumps"]], [j["cand_gate"] for j in rep["jumps"]], "x", ms=5, color="0.4", label="candidates (gate)")
        ax.set_title("repair chain on ticket %d at beta %.0f: %d accepts, rung1 %.3f -> %.3f" % (rep["parent"], rep["beta_re"], rep["n_accept"], R["tickets"][rep["parent"]]["eta_rung1"] if False else min(t["eta_rung1"] for t in R["tickets"] if t["index"] == rep["parent"]), rep["final_eta_rung1"]), fontsize=9)
        ax.set_xlabel("hop")
        ax.legend(fontsize=7)
        ax.grid(alpha=0.3)
    else:
        ax.text(0.5, 0.5, "repair not triggered\n(rung1 %.3f vs bar %.3f, optimism %.3f)" % (R["selection"]["eta_rung1"], 0.683, R["selection"]["gate_optimism"]),
                ha="center", va="center", transform=ax.transAxes)
        ax.set_axis_off()
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "s9_curves.png"), dpi=170)
    plt.close(fig)
    print("figures written to", FIG)


if __name__ == "__main__":
    main()
