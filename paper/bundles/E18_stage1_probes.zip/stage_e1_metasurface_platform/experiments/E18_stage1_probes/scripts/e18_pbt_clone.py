"""Probe 2 (docs/00 SS3.4): is a mid-trajectory clone perturbable at f=0.35?

Reproduce the (2,0)/seed-2030 torcwa_M12 run (budget 120, 219 steps) up to
35% of budget, snapshot the latent + Adam state, then branch:
  * 4 clones: latent + filtered noise scaled to that step's own Adam
    increment sd, Adam state copied, run to the end of the budget;
  * 1 control: the unperturbed parent continued (quantifies device drift).
Every branch delivers its best self-audited binary from the branch point on;
delivered binaries are blind-scored at (28,7)/c128/CPU.

Preregistered kill (docs/00 SS3.4): no clone beats the parent's 0.4895 AND
the clone spread is < 0.05  ->  the perturbation is inert at that beta and
PBT's exploit step has nothing to give.

    python e18_pbt_clone.py           # writes ../data/pbt_clone.json
"""
import json
import os
import time

import torch

from e18_common import (BUDGET, C, CPU, DATA, DESCENT, THREADS, USE_GPU,
                        audit28, filtered_noise)

TARGET = (2, 0)
SEED = 2030
LEVEL = (12, 3)
BRANCH_F = 0.35
N_CLONES = 4
PARENT_BLIND_28 = 0.4895        # frozen baseline, scores.json
AUDIT_EVERY = 6


def run_branch(rho, adam, units, step, budget, cfg, tag):
    """Continue the torcwa_M12 loop from a snapshot to the end of budget."""
    lv = LEVEL
    best_self, best_bin = -float("inf"), C.hard_binary(rho, cfg)
    while True:
        if units + C.cost_fwd(lv, cfg) + C.cost_bwd(lv, cfg) > budget:
            break
        progress = units / budget
        beta = C.beta_at(progress, cfg=cfg)
        lr = C.cosine_lr(progress, cfg)
        j, g = C.value_grad_latent(rho, lv, TARGET, beta, cfg)
        units += C.cost_fwd(lv, cfg) + C.cost_bwd(lv, cfg)
        if step % AUDIT_EVERY == 0 and units + C.cost_fwd(lv, cfg) <= budget:
            b = C.hard_binary(rho, cfg)
            s = C.forward_density(b, lv, TARGET, cfg)
            units += C.cost_fwd(lv, cfg)
            if s > best_self:
                best_self, best_bin = s, b
        rho = adam.step(rho, g, lr)
        step += 1
    b = C.hard_binary(rho, cfg)
    s = C.forward_density(b, lv, TARGET, cfg)
    if s > best_self:
        best_self, best_bin = s, b
    return {"tag": tag, "binary": best_bin.cpu(), "self": best_self,
            "steps_end": step}


def main():
    torch.set_num_threads(THREADS)
    cfg = DESCENT
    print("descent on %s; blind scoring c128/cpu; %d threads"
          % ("cuda/c64" if USE_GPU else "cpu/c128", THREADS))
    if USE_GPU:
        w = C.initial_latent(SEED, cfg)
        C.value_grad_latent(w, LEVEL, TARGET, 8.0, cfg)
        torch.cuda.synchronize()

    # ---- parent prefix to f=0.35 ------------------------------------------
    t0 = time.perf_counter()
    lv = LEVEL
    rho = C.initial_latent(SEED, cfg)
    adam = C.Adam(rho.shape, cfg)
    units, step = 0.0, 0
    prev = rho.clone()
    inc_sd = None
    while units / BUDGET < BRANCH_F:
        progress = units / BUDGET
        beta = C.beta_at(progress, cfg=cfg)
        lr = C.cosine_lr(progress, cfg)
        j, g = C.value_grad_latent(rho, lv, TARGET, beta, cfg)
        units += C.cost_fwd(lv, cfg) + C.cost_bwd(lv, cfg)
        if step % AUDIT_EVERY == 0:
            b = C.hard_binary(rho, cfg)
            C.forward_density(b, lv, TARGET, cfg)     # parity with parent loop
            units += C.cost_fwd(lv, cfg)
        prev = rho.clone()
        rho = adam.step(rho, g, lr)
        step += 1
    inc_sd = float((rho - prev).std())
    beta_here = C.beta_at(units / BUDGET, cfg=cfg)
    print("branch point: step %d, units %.1f (f=%.3f), beta %.1f, "
          "adam increment sd %.2e  [%.0f s]"
          % (step, units, units / BUDGET, beta_here, inc_sd,
             time.perf_counter() - t0))

    # ---- branches ----------------------------------------------------------
    branches = []
    snap_rho, snap_adam, snap_units, snap_step = \
        rho.clone(), adam.state(), units, step
    for k in range(N_CLONES):
        noise = filtered_noise(9000 + k).to(rho.device)
        pert = C.symmetrize((snap_rho + inc_sd * noise / 1.0)
                            .clamp(0.0, 1.0))
        a = C.Adam(rho.shape, cfg)
        a.load(snap_adam)
        branches.append(run_branch(pert, a, snap_units, snap_step, BUDGET,
                                   cfg, "clone_%d" % k))
        print("  clone %d done: self %.4f  [%.0f s]"
              % (k, branches[-1]["self"], time.perf_counter() - t0))
    a = C.Adam(rho.shape, cfg)
    a.load(snap_adam)
    branches.append(run_branch(snap_rho.clone(), a, snap_units, snap_step,
                               BUDGET, cfg, "control"))
    print("  control done: self %.4f  [%.0f s]"
          % (branches[-1]["self"], time.perf_counter() - t0))

    # ---- blind scoring -----------------------------------------------------
    rows = []
    for br in branches:
        blind = audit28(br["binary"], TARGET)
        rows.append({"tag": br["tag"], "self_12_3": br["self"],
                     "blind_28_7": blind, "steps_end": br["steps_end"]})
        print("  %s: self(12,3) %.4f   blind(28,7) %.4f"
              % (br["tag"], br["self"], blind))

    clones = [r["blind_28_7"] for r in rows if r["tag"].startswith("clone")]
    control = [r["blind_28_7"] for r in rows if r["tag"] == "control"][0]
    spread = max(clones) - min(clones)
    beat = max(clones) > PARENT_BLIND_28
    inert = (not beat) and spread < 0.05
    summary = {
        "target": list(TARGET), "seed": SEED, "branch_f": BRANCH_F,
        "branch_step": snap_step, "beta_at_branch": beta_here,
        "increment_sd": inc_sd,
        "clone_blind": clones, "control_blind": control,
        "parent_baseline_blind": PARENT_BLIND_28,
        "clone_max": max(clones), "clone_spread": spread,
        "any_clone_beats_parent": beat,
        "kill_inert": inert,
        "descent": "cuda/c64" if USE_GPU else "cpu/c128",
        "wall_s": time.perf_counter() - t0, "threads": THREADS,
    }
    path = os.path.join(DATA, "pbt_clone.json")
    with open(path, "w") as f:
        json.dump({"summary": summary, "rows": rows}, f, indent=1)
    print()
    print("clone max %.4f vs parent %.4f; spread %.4f  -> %s"
          % (max(clones), PARENT_BLIND_28, spread,
             "KILL: perturbation inert" if inert else "ALIVE"))
    print("wrote %s" % path)


if __name__ == "__main__":
    main()
