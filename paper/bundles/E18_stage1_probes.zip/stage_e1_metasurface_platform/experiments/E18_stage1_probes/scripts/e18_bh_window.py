"""Probe 1 (docs/00 SS3.3): does a basin-hopping perturbation window exist?

Take the best delivered latent of each target.  Apply filtered-noise
perturbations at four amplitudes, re-descend 30 steps at beta=64 fixed, and
certify at (24,6)/c128/CPU.  A usable window requires at least one
perturbation that BOTH escapes (>10% of pixels differ from the parent binary,
after quotienting out all 4200 cyclic shifts) AND survives (certified eta
within 20% of the parent's).  Preregistered kill: no (alpha, sample) gives
both -> the basin-hopping route dies today.

    python e18_bh_window.py           # writes ../data/bh_window.json
"""
import json
import os
import time

import torch

from e18_common import (BUDGET, C, CPU, DATA, DESCENT, THREADS, USE_GPU,
                        audit24, filtered_noise, load_latent,
                        min_hamming_over_shifts)

BASES = [
    # best delivered design per target, from data/main/scores.json
    {"target": (1, 0), "latent": "1_0_2031_certified_screened_latent.npy",
     "eta24": 0.3968},
    {"target": (2, 0), "latent": "2_0_2030_torcwa_M12_latent.npy",
     "eta24": 0.4837},
    {"target": (3, 0), "latent": "3_0_2029_torcwa_M12_latent.npy",
     "eta24": 0.3503},
]
ALPHAS = [0.1, 0.25, 0.5, 1.0]      # x init_scale (0.08)
NOISE_SEEDS = [11, 12, 13]
STEPS = 30
BETA = 64.0
LEVEL = (12, 3)
ESCAPE_FRAC = 0.10
SURVIVE_REL = 0.20


def redescend(rho0, target, cfg):
    """30 Adam steps at fixed beta=64, cosine lr 0.02 -> 0, level (12,3)."""
    rho = rho0.clone() if cfg.device == "cpu" else rho0.to(cfg.device)
    adam = C.Adam(rho.shape, cfg)
    for t in range(STEPS):
        lr = C.cosine_lr(t / STEPS, cfg)
        _, g = C.value_grad_latent(rho, LEVEL, target, BETA, cfg)
        rho = adam.step(rho, g, lr)
    return rho.cpu()


def main():
    torch.set_num_threads(THREADS)
    print("descent on %s; audits on c128/cpu; %d threads"
          % ("cuda/c64" if USE_GPU else "cpu/c128", THREADS))
    if USE_GPU:                                   # warmup, untimed
        w = load_latent(BASES[0]["latent"]).to("cuda")
        C.value_grad_latent(w, LEVEL, BASES[0]["target"], BETA, DESCENT)
        torch.cuda.synchronize()

    rows = []
    t0 = time.perf_counter()
    for base in BASES:
        lat = load_latent(base["latent"])
        tgt = tuple(base["target"])
        parent_bin = C.hard_binary(lat, CPU)
        parent_eta = audit24(parent_bin, tgt)     # re-certify, don't trust cache
        print("base %s %s: eta24 %.4f (recorded %.4f)"
              % (tgt, base["latent"], parent_eta, base["eta24"]))
        for ns in NOISE_SEEDS:
            noise = filtered_noise(1000 * ns + 7)
            for alpha in ALPHAS:
                pert = C.symmetrize(
                    (lat + alpha * C.DEFAULT.init_scale * noise)
                    .clamp(0.0, 1.0))
                pre_bin = C.hard_binary(pert, CPU)
                pre_ham = min_hamming_over_shifts(parent_bin.numpy(),
                                                  pre_bin.numpy())
                rho = redescend(pert, tgt, DESCENT)
                new_bin = C.hard_binary(rho, CPU)
                ham = min_hamming_over_shifts(parent_bin.numpy(),
                                              new_bin.numpy())
                eta = audit24(new_bin, tgt)
                escaped = ham / 4200.0 > ESCAPE_FRAC
                survived = abs(eta - parent_eta) <= SURVIVE_REL * parent_eta
                rows.append({
                    "target": list(tgt), "latent": base["latent"],
                    "noise_seed": ns, "alpha": alpha,
                    "parent_eta24": parent_eta,
                    "pre_hamming": pre_ham, "hamming": ham,
                    "hamming_frac": ham / 4200.0,
                    "eta24": eta, "rel_change": (eta - parent_eta) / parent_eta,
                    "escaped": escaped, "survived": survived,
                    "window": escaped and survived,
                    "improved": eta > parent_eta,
                })
                print("  %s ns%d a=%.2f: pre-ham %d -> ham %d (%.1f%%)  "
                      "eta24 %.4f (%+.1f%%)  %s%s"
                      % (tgt, ns, alpha, pre_ham, ham, 100 * ham / 4200.0,
                         eta, 100 * (eta - parent_eta) / parent_eta,
                         "ESCAPE" if escaped else "stay",
                         "+SURVIVE" if survived else ""))
        print("  [%.0f s elapsed]" % (time.perf_counter() - t0))

    windows = [r for r in rows if r["window"]]
    improved = [r for r in rows if r["improved"]]
    summary = {
        "n": len(rows),
        "n_escaped": sum(r["escaped"] for r in rows),
        "n_survived": sum(r["survived"] for r in rows),
        "n_window": len(windows),
        "n_improved": len(improved),
        "window_exists": len(windows) > 0,
        "windows": [{k: r[k] for k in ("target", "noise_seed", "alpha",
                                       "hamming_frac", "rel_change")}
                    for r in windows],
        "best_improvement": max((r["rel_change"] for r in rows), default=None),
        "descent": "cuda/c64" if USE_GPU else "cpu/c128",
        "steps": STEPS, "beta": BETA, "level": list(LEVEL),
        "wall_s": time.perf_counter() - t0,
        "threads": THREADS, "budget_reference": BUDGET,
    }
    path = os.path.join(DATA, "bh_window.json")
    with open(path, "w") as f:
        json.dump({"summary": summary, "rows": rows}, f, indent=1)
    print()
    print("windows (escape AND survive): %d / %d   -> %s"
          % (len(windows), len(rows),
             "WINDOW EXISTS" if windows else "KILL: window empty"))
    print("wrote %s" % path)


if __name__ == "__main__":
    main()
