"""Route-C gate (docs/00 SS3.6): filter radius x truncation order.

Claim under test: low-order RCWA error is dominated by the design's own
spatial-frequency content, so a coarser fabrication filter would make the
cheap orders *faithful*, multiplying everyone's budget by ~6.

30 delivered latents; rebuild the hard binary under filter_nm in {60,100,140};
forward-only at (8,2), (12,3), (24,6), all c128/CPU (this is an error-structure
measurement, not a descent).  Preregistered pass (BOTH required):
  (i)  MAD of the (12,3)-vs-(24,6) relative error drops below 8% at 140 nm
       (from 21.8% at 60 nm);
  (ii) the median (24,6) eta at 140 nm retains >= 60% of its 60 nm value.

    python e19_filter_gate.py         # writes ../data/filter_gate.json
"""
import glob
import json
import os
import time

import torch

from e18_common import C, CPU, DATA, DESIGNS, THREADS, load_latent

FILTERS = [60.0, 100.0, 140.0]
LEVELS = [(8, 2), (12, 3), (24, 6)]
N_DESIGNS = 30


def main():
    torch.set_num_threads(THREADS)
    names = sorted(os.path.basename(p) for p in
                   glob.glob(os.path.join(DESIGNS, "*_latent.npy")))
    step = max(1, len(names) // N_DESIGNS)
    picks = names[::step][:N_DESIGNS]
    print("%d designs x %d filters x %d levels, c128/cpu, %d threads"
          % (len(picks), len(FILTERS), len(LEVELS), THREADS))

    rows = []
    t0 = time.perf_counter()
    for i, name in enumerate(picks):
        lat = load_latent(name)
        tgt = (int(name.split("_")[0]), int(name.split("_")[1]))
        for f_nm in FILTERS:
            cfg = CPU.variant(filter_nm=f_nm)
            b = C.hard_binary(lat, cfg)
            etas = {}
            for lv in LEVELS:
                etas[str(lv)] = C.forward_density(b, lv, tgt, CPU, audit=True)
            rows.append({"latent": name, "target": list(tgt),
                         "filter_nm": f_nm, "etas": etas})
        if (i + 1) % 5 == 0:
            print("  %d/%d  (%.0f s)" % (i + 1, len(picks),
                                         time.perf_counter() - t0))

    summary = {"filters": {}}
    for f_nm in FILTERS:
        sub = [r for r in rows if r["filter_nm"] == f_nm]
        rel = [(r["etas"]["(12, 3)"] - r["etas"]["(24, 6)"])
               / max(abs(r["etas"]["(24, 6)"]), 1e-9) for r in sub]
        med = sorted(rel)[len(rel) // 2]
        mad = sorted(abs(x - med) for x in rel)[len(rel) // 2]
        e24 = sorted(r["etas"]["(24, 6)"] for r in sub)[len(sub) // 2]
        summary["filters"][str(f_nm)] = {
            "rel_err_median": med, "rel_err_mad": mad, "eta24_median": e24}
        print("filter %3.0f nm: (12,3)vs(24,6) rel err median %+.3f  MAD %.3f"
              "   eta24 median %.4f" % (f_nm, med, mad, e24))
    m60 = summary["filters"]["60.0"]["eta24_median"]
    m140 = summary["filters"]["140.0"]["eta24_median"]
    mad140 = summary["filters"]["140.0"]["rel_err_mad"]
    summary["pass_i_mad_lt_8pct"] = mad140 < 0.08
    summary["pass_ii_eta_retained"] = m140 >= 0.60 * m60
    summary["gate_pass"] = summary["pass_i_mad_lt_8pct"] and \
        summary["pass_ii_eta_retained"]
    summary["wall_s"] = time.perf_counter() - t0
    path = os.path.join(DATA, "filter_gate.json")
    with open(path, "w") as f:
        json.dump({"summary": summary, "rows": rows}, f, indent=1)
    print()
    print("(i) MAD@140 = %.3f (<0.08? %s)   (ii) eta retention %.2f (>=0.60? %s)"
          % (mad140, summary["pass_i_mad_lt_8pct"], m140 / max(m60, 1e-9),
             summary["pass_ii_eta_retained"]))
    print("gate -> %s" % ("PASS" if summary["gate_pass"] else "FAIL"))
    print("wrote %s" % path)


if __name__ == "__main__":
    main()
