"""E18 stage-1 probes: shared wiring.

Stage-0 verdict (notes/E17, D-007): GPU/c64 failed the preregistered parity
acceptance, so probe descent runs on CPU/c128 with the E17 fast paths
(vectorized conv: forward bitwise-identical, gradients to 1e-16; skipped
diagnostics: exactly neutral).  Certification and blind scoring are ALWAYS
c128/CPU at (24,6)/(28,7) -- discipline 3 -- and are bitwise-identical to the
frozen scorer under these flags (E17 fastpath_equiv.json).
"""
import os
import sys

import numpy as np
import torch

THREADS = int(os.environ.get("P0_THREADS", "3"))
torch.set_num_threads(THREADS)

_HERE = os.path.dirname(os.path.abspath(__file__))
_E16_SCRIPTS = os.path.abspath(os.path.join(
    _HERE, "..", "..", "E16_inherited_baseline", "scripts"))
if _E16_SCRIPTS not in sys.path:
    sys.path.insert(0, _E16_SCRIPTS)

import e10_common as C  # noqa: E402
import trustworthy_fmm.fourier.convolution as _conv  # noqa: E402
import trustworthy_fmm.solvers.vector_2d as _v2d  # noqa: E402

_conv.VECTORIZED_CONV = True     # E17: forward bitwise, grad 1e-16
_v2d.FAST_DIAGNOSTICS = True     # E17: exactly neutral (no probe reads them)

DESIGNS = os.path.abspath(os.path.join(
    _HERE, "..", "..", "E16_inherited_baseline", "data", "main", "designs"))
DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))

USE_GPU = os.environ.get("E18_DEVICE", "cpu") == "cuda" and torch.cuda.is_available()
DESCENT = (C.DEFAULT.variant(dtype=torch.complex64, device="cuda")
           if USE_GPU else C.DEFAULT)
CPU = C.DEFAULT

# The frozen campaign ran --budget 120 (219 steps at (12,3)), not the config
# default of 60.  Every reproduction here must use this number.
BUDGET = 120.0


def load_latent(name):
    return torch.from_numpy(
        np.load(os.path.join(DESIGNS, name)).astype("float64"))


def filtered_noise(seed, cfg=C.DEFAULT):
    """The same operator initial_latent uses: unit-std filtered white noise."""
    g = torch.Generator().manual_seed(int(seed))
    noise = torch.randn((cfg.ny, cfg.nx), generator=g, dtype=cfg.latent_dtype)
    smooth = C.periodic_gaussian_filter(noise, cfg.lattice_nm, cfg.filter_nm)
    return smooth / smooth.std()


def min_hamming_over_shifts(a, b):
    """Hamming distance between two binary masks, minimised over ALL cyclic
    shifts (both axes).  For (m,0) targets every x- and y-translation is an
    exact symmetry of the objective, so a pure translation must not read as an
    escape (docs/00 SS3.3)."""
    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    cc = np.fft.ifft2(np.fft.fft2(a) * np.conj(np.fft.fft2(b))).real
    overlap_max = cc.max()
    return int(round(a.sum() + b.sum() - 2.0 * overlap_max))


def audit24(binary_cpu, target):
    return C.forward_density(binary_cpu, (24, 6), target, CPU, audit=True)


def audit28(binary_cpu, target):
    return C.forward_density(binary_cpu, (28, 7), target, CPU, audit=True)
