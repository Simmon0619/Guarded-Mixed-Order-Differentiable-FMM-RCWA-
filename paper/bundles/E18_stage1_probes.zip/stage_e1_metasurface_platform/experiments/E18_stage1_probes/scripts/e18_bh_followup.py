"""Follow-up to probe 1: reproduce the winning perturbations, add the alpha=0
polish control, blind-score at (28,7), extra reference at (32,8) for each
target's champion, and run the held-out process audit on the champions.

Reproduction is deterministic (same process wiring as e18_bh_window: CPU/c128,
fast paths, 3 threads, same noise seeds), and each reproduced eta24 is checked
against the probe's recorded value before anything else is claimed.

    python e18_bh_followup.py         # writes ../data/bh_followup.json
                                      # and ../data/designs/*.npy
"""
import json
import os

import numpy as np
import torch

from e18_common import (C, CPU, DATA, THREADS, audit24, audit28,
                        filtered_noise, load_latent)
from trustworthy_fmm.fabrication.process import periodic_binary_morphology

BASES = {
    (1, 0): "1_0_2031_certified_screened_latent.npy",
    (2, 0): "2_0_2030_torcwa_M12_latent.npy",
    (3, 0): "3_0_2029_torcwa_M12_latent.npy",
}
# (target, noise_seed, alpha, eta24 recorded by the probe)
WINNERS = [
    ((1, 0), 12, 0.10, 0.4592),
    ((1, 0), 13, 0.50, 0.4808),
    ((2, 0), 11, 0.25, 0.5717),
    ((2, 0), 11, 0.50, 0.6479),
    ((2, 0), 12, 0.10, 0.5470),
    ((2, 0), 13, 0.25, 0.5444),
    ((2, 0), 13, 0.50, 0.6193),
    ((2, 0), 13, 1.00, 0.6358),
    ((3, 0), 13, 0.10, 0.3573),
]
STEPS = 30
BETA = 64.0
LEVEL = (12, 3)
CD_BIAS_NM = [-20.0, 20.0]
MORPH_RADIUS_NM = 40.0


def redescend(rho0, target):
    rho = rho0.clone()
    adam = C.Adam(rho.shape, CPU)
    for t in range(STEPS):
        lr = C.cosine_lr(t / STEPS, CPU)
        _, g = C.value_grad_latent(rho, LEVEL, target, BETA, CPU)
        rho = adam.step(rho, g, lr)
    return rho


def held_out(mask_t, target):
    """The e10_robustness protocol: +-20 nm CD, 40 nm opening/closing, (24,6)."""
    mask = mask_t.numpy().astype(bool)
    nominal = audit24(mask_t, target)
    held = {"nominal_24_6": nominal}
    for bias in CD_BIAS_NM:
        pert = torch.from_numpy(C.cd_bias_mask(mask, bias))
        held["cd_{:+.0f}nm".format(bias)] = audit24(pert, target)
    for op in ("opening", "closing"):
        pert = periodic_binary_morphology(mask, op, MORPH_RADIUS_NM,
                                          C.DEFAULT.pixel_yx)
        held["{}_{:.0f}nm".format(op, MORPH_RADIUS_NM)] = audit24(
            torch.from_numpy(np.asarray(pert, dtype=np.float64)), target)
    scen = {k: v for k, v in held.items() if k != "nominal_24_6"}
    held["worst_absolute"] = min(scen.values())
    held["worst_relative"] = min(scen.values()) / max(nominal, 1e-12)
    held["worst_scenario"] = min(scen, key=scen.get)
    return held


def main():
    torch.set_num_threads(THREADS)
    designs_dir = os.path.join(DATA, "designs")
    os.makedirs(designs_dir, exist_ok=True)
    out = {"winners": [], "polish_alpha0": [], "champions": {}}

    # ---- alpha=0 polish control (attribution: perturbation vs more steps) --
    for tgt, base_name in BASES.items():
        lat = load_latent(base_name)
        parent24 = audit24(C.hard_binary(lat, CPU), tgt)
        rho = redescend(lat, tgt)
        b = C.hard_binary(rho, CPU)
        eta24 = audit24(b, tgt)
        rec = {"target": list(tgt), "parent_eta24": parent24,
               "eta24": eta24, "rel_change": (eta24 - parent24) / parent24}
        out["polish_alpha0"].append(rec)
        print("alpha=0 polish %s: %.4f -> %.4f (%+.1f%%)"
              % (tgt, parent24, eta24, 100 * rec["rel_change"]))

    # ---- reproduce winners, blind-score --------------------------------
    best_per_target = {}
    for tgt, ns, alpha, recorded in WINNERS:
        lat = load_latent(BASES[tgt])
        noise = filtered_noise(1000 * ns + 7)
        pert = C.symmetrize(
            (lat + alpha * C.DEFAULT.init_scale * noise).clamp(0.0, 1.0))
        rho = redescend(pert, tgt)
        b = C.hard_binary(rho, CPU)
        eta24 = audit24(b, tgt)
        match = abs(eta24 - recorded) < 5e-4
        eta28 = audit28(b, tgt)
        tag = "%d_%d_ns%d_a%03d" % (tgt[0], tgt[1], ns, round(100 * alpha))
        np.save(os.path.join(designs_dir, tag + "_binary.npy"),
                b.numpy())
        np.save(os.path.join(designs_dir, tag + "_latent.npy"),
                rho.numpy())
        rec = {"target": list(tgt), "noise_seed": ns, "alpha": alpha,
               "eta24": eta24, "eta24_probe": recorded,
               "reproduced": bool(match), "eta28": eta28,
               "drift_24_28": (eta28 - eta24) / max(eta24, 1e-12),
               "files": tag}
        out["winners"].append(rec)
        print("%s ns%d a=%.2f: eta24 %.4f (probe %.4f, repro %s)  "
              "eta28 %.4f (drift %+.1f%%)"
              % (tgt, ns, alpha, eta24, recorded, match, eta28,
                 100 * rec["drift_24_28"]))
        if tgt not in best_per_target or eta28 > best_per_target[tgt][1]:
            best_per_target[tgt] = (rec, eta28, b)

    # ---- champions: held-out audit ----------------------------------------
    # (32,8) is unreachable on the frozen 35x120 grid (needs nx >= 4*32+1 =
    # 129), so (28,7) is the highest admissible reference order; recorded as a
    # protocol constraint, not a choice.
    for tgt, (rec, eta28, b) in best_per_target.items():
        held = held_out(b, tgt)
        out["champions"][str(tgt)] = {"winner": rec, "held_out": held}
        print("champion %s (%s): eta24 %.4f  eta28 %.4f | "
              "held-out worst %.4f (%.2f of nominal, %s)"
              % (tgt, rec["files"], rec["eta24"], rec["eta28"],
                 held["worst_absolute"], held["worst_relative"],
                 held["worst_scenario"]))

    # frozen-campaign references for the same targets (from scores.json blind)
    out["frozen_best_28"] = {"(1, 0)": 0.3976, "(2, 0)": 0.4895,
                             "(3, 0)": 0.3710}
    path = os.path.join(DATA, "bh_followup.json")
    with open(path, "w") as f:
        json.dump(out, f, indent=1)
    print("wrote %s" % path)


if __name__ == "__main__":
    main()
