"""Diagnostic: full power budget of the best delivered design per target."""
import glob, json, os, sys
import numpy as np, torch
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "scripts"))
import e10_common as C

sc = {}
for p in glob.glob(os.path.join(C._HERE, "..", "data", "main", "*scores.json")):
    for k, v in json.load(open(p)).items():
        if not k.startswith("_"):
            sc[k] = v

best = {}
for k, v in sc.items():
    t = tuple(v["target"])
    if t not in best or v["blind"]["28,7"] > best[t][1]["blind"]["28,7"]:
        best[t] = (k, v)

lam, (Lx, Ly), nout = C.WL, C.LATTICE, C.N_OUT
print("open orders in air: |m| <= %.2f along x, |n| <= %.2f along y"
      % (nout * Lx / lam, nout * Ly / lam))
print("open orders in substrate n=%.2f: |m| <= %.2f, |n| <= %.2f"
      % (C.N_IN, C.N_IN * Lx / lam, C.N_IN * Ly / lam))
print()

out = {}
for t in sorted(best):
    key, rec = best[t]
    t_, seed_, arm_ = rec["target"], rec["seed"], rec["arm"]
    name = "%d_%d_%d_%s_binary.npy" % (t_[0], t_[1], seed_, arm_)
    design = np.load(os.path.join(C._HERE, "..", "data", "main", "designs", name))
    eps = torch.tensor(np.where(design > 0.5, C.EPS_FEAT, C.EPS_BG), dtype=C.DT)
    res = C.solve_multilayer_vector_2d(
        [eps], [C.THICK], lam, (Lx, Ly), C.N_IN, nout, (28, 7),
        incident_jones=(1.0 + 0j, 0.0 + 0j))
    pt = res.power_t.real.numpy(); pr = res.power_r.real.numpy()
    orders = [tuple(o) for o in res.orders]
    T, R = float(res.total_T.real), float(res.total_R.real)
    tgt = pt[orders.index(t)]
    rows = sorted(zip(orders, pt, pr), key=lambda z: -z[1])
    print("target (%+d,%d)  %s  eta=%.4f" % (t[0], t[1], rec["arm"], tgt))
    print("   total T=%.4f  total R=%.4f  T+R=%.6f" % (T, R, T + R))
    print("   top transmitted channels:")
    for o, a, b in rows[:6]:
        if a > 1e-4:
            print("      T(%+d,%+d) = %.4f%s" % (o[0], o[1], a, "   <-- TARGET" if o == t else ""))
    ry = sorted(zip(orders, pr), key=lambda z: -z[1])[:3]
    print("   top reflected channels: " + ", ".join("R(%+d,%+d)=%.4f" % (o[0], o[1], v) for o, v in ry if v > 1e-4))
    ynz = sum(a for o, a, _ in rows if o[1] != 0)
    print("   transmitted into y!=0 orders: %.4f" % ynz)
    print("   share of transmitted power in target: %.1f%%" % (100 * tgt / max(T, 1e-12)))
    print()
    out["%+d,%d" % t] = dict(arm=rec["arm"], eta=float(tgt), total_T=T, total_R=R,
                             y_leak=float(ynz), target_share_of_T=float(tgt / max(T, 1e-12)),
                             channels={"%+d,%+d" % o: float(a) for o, a, _ in rows if a > 1e-4})
json.dump(out, open(os.path.join(C._HERE, "..", "data", "where_light_goes.json"), "w"), indent=1)
