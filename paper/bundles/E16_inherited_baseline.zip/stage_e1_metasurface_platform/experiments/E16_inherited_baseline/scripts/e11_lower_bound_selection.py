"""E12-lite: does selecting on a cheap DISAGREEMENT-penalised score beat selecting
on the cheap point estimate?

TORCWA's arm audits its hard binary every 6 steps at its own (12,3) and delivers
the argmax.  E10 showed that argmax inflates by +24% (winner's curse on a noisy
but unbiased model).  A constant error bar cannot fix this -- it does not change
the ranking.  A per-design error PROXY can.  The cheapest available proxy is the
disagreement between two cheap levels, eps(x) = |eta_L(x) - eta_H(x)|, which is
a Richardson-style truncation indicator costing one extra cheap solve.

Rules compared on the SAME candidate pool:
  A  argmax eta_L                         (what TORCWA does)
  B  argmax [eta_L - lam * eps]           (disagreement-penalised)
  C  argmax eta_H                         (just use the better cheap level)
Truth for all: eta at (24,6).
"""
import glob, json, os, sys
import numpy as np, torch
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import e10_common as C

L, H, TRUTH = (12, 3), (16, 4), (24, 6)
ARM = "torcwa_M12"
DES = os.path.join(C._HERE, "..", "data", "main", "designs")

runs = []
for t in C.TARGETS:
    for seed in C.SEEDS:
        pool = sorted(glob.glob(os.path.join(
            DES, "%d_%d_%d_%s_cp*_cur.npy" % (t[0], t[1], seed, ARM))))
        if pool:
            runs.append((t, seed, pool))

out = []
for t, seed, pool in runs:
    recs = []
    for f in pool:
        d = torch.tensor(np.load(f), dtype=torch.float64)
        eL = C.forward_density(d, L, t)
        eH = C.forward_density(d, H, t)
        eT = C.forward_density(d, TRUTH, t)
        recs.append(dict(f=os.path.basename(f), eL=eL, eH=eH, eT=eT, eps=abs(eL - eH)))
    out.append(dict(target=list(t), seed=seed, pool=recs))
    print("(%+d,%d) %d  pool=%d" % (t[0], t[1], seed, len(recs)), flush=True)
    json.dump(out, open(os.path.join(C._HERE, "..", "data", "lower_bound_selection.json"), "w"), indent=1)
print("done")
