"""E10 arms: the TORCWA Example-6 recipe vs the certified scheme.

Both arms share e10_common's physics, design map, Adam, cosine learning-rate
schedule and exponential beta continuation.  They differ only in what governs
the Fourier fidelity and what is allowed to be delivered.
"""
import time

from e10_common import (
    Adam, BETA_LADDER, BUDGET_UNITS, LEVELS, beta_at, cosine_lr, cost_bwd,
    cost_fwd, forward_density, forward_latent, hard_binary, initial_latent,
    value_grad_latent,
)

QUALIFY_TOL = 0.05      # relative |J_R - J_H| on the delivered binary
QUALIFY_FLOOR = 1e-3    # below this eta the qualification test is meaningless
PROMOTION = [(16, 4), (20, 5), (24, 6)]


def _snapshot(store, units, t0, binary, tag, current=None):
    """Record the arm's own delivered choice and, separately, the structure it
    is standing on.  The second one enables a post-hoc oracle-selection
    ablation: how much of any gap is trajectory, how much is selection."""
    store.append({
        "units": float(units),
        "wall_s": time.perf_counter() - t0,
        "binary": binary.clone(),
        "current": (binary if current is None else current).clone(),
        "tag": tag,
    })


# ------------------------------------------------------- arm A: TORCWA recipe
def run_torcwa_style(target, seed, level, budget=BUDGET_UNITS,
                     binary_audit_every=6, wall_budget_s=None):
    """Fixed Fourier order + Adam + beta continuation (TORCWA Example 6).

    Its own fixed level is the only judge available to it: the delivered
    structure is the hard binary that scored best under that same level.
    """
    lv = tuple(level)
    rho = initial_latent(seed)
    adam = Adam(rho.shape)
    units = 0.0
    t0 = time.perf_counter()
    best_bin = hard_binary(rho)
    best_self = -float("inf")
    history, checkpoints = [], []
    step = 0
    while True:
        elapsed = time.perf_counter() - t0
        if wall_budget_s:
            if elapsed >= wall_budget_s:
                break
            progress = min(elapsed / wall_budget_s, 1.0)
        else:
            if units + cost_fwd(lv) + cost_bwd(lv) > budget:
                break
            progress = units / budget
        beta = beta_at(progress)
        lr = cosine_lr(progress)
        j, g = value_grad_latent(rho, lv, target, beta)
        units += cost_fwd(lv) + cost_bwd(lv)
        if step % binary_audit_every == 0 and (
                wall_budget_s or units + cost_fwd(lv) <= budget):
            b = hard_binary(rho)
            self_score = forward_density(b, lv, target)
            units += cost_fwd(lv)
            if self_score > best_self:
                best_self, best_bin = self_score, b
            _snapshot(checkpoints, units, t0, best_bin, "audit", current=b)
        history.append({"step": step, "units": units, "soft": j, "beta": beta,
                        "lr": lr, "best_self_binary": best_self})
        rho = adam.step(rho, g, lr)
        step += 1
    b = hard_binary(rho)
    self_score = forward_density(b, lv, target)
    units += cost_fwd(lv)
    if self_score > best_self:
        best_self, best_bin = self_score, b
    _snapshot(checkpoints, units, t0, best_bin, "final", current=b)
    return {
        "delivered_binary": best_bin,
        "final_latent": rho,
        "units": units,
        "wall_s": time.perf_counter() - t0,
        "steps": step,
        "self_reported_binary": best_self,
        "self_reported_soft": history[-1]["soft"] if history else float("nan"),
        "final_beta": history[-1]["beta"] if history else float("nan"),
        "history": history,
        "checkpoints": checkpoints,
        "level": list(lv),
    }


# ------------------------------------------------- arm B: certified scheme
def run_certified(target, seed, budget=BUDGET_UNITS, inner=6, audit_every=2,
                  wall_budget_s=None):
    """Gradient-aware + representation-aware + delivery-certified ascent.

    * proposals at L are corrected to be first-order consistent with H;
    * every candidate must pass an *actual gain* test at H (no model ratio);
    * the delivered hard binary is certified at R and can only improve;
    * beta sharpening is gated: if the current H cannot reproduce R on the
      delivered binary, the level is promoted instead of sharpening further.
    """
    lv_l = LEVELS["L"]
    promo = 0
    lv_h = PROMOTION[promo]
    lv_r = PROMOTION[promo + 1]
    rho = initial_latent(seed)
    adam = Adam(rho.shape)
    units = 0.0
    t0 = time.perf_counter()

    cert_bin = hard_binary(rho)
    cert_score = forward_density(cert_bin, lv_r, target)
    units += cost_fwd(lv_r)
    cert_rho, cert_adam = rho.clone(), adam.state()

    beta_cap = BETA_LADDER[-1]
    alpha = 1.0
    accepts = rejects = rollbacks = promotions = gated = 0
    accepts_since_audit = 0
    events, checkpoints = [], []
    _snapshot(checkpoints, units, t0, cert_bin, "init")
    outer = 0
    while True:
        elapsed = time.perf_counter() - t0
        if wall_budget_s:
            if elapsed >= wall_budget_s:
                break
            progress = min(elapsed / wall_budget_s, 1.0)
        else:
            est = (cost_fwd(lv_l) + cost_bwd(lv_l)) * (1 + inner) \
                + cost_fwd(lv_h) + cost_bwd(lv_h) + cost_fwd(lv_h)
            if units + est > budget:
                break
            progress = min(units / budget, 1.0)
        beta = min(beta_at(progress), beta_cap)
        lr = cosine_lr(progress)

        j_l, g_l = value_grad_latent(rho, lv_l, target, beta)
        units += cost_fwd(lv_l) + cost_bwd(lv_l)
        j_h, g_h = value_grad_latent(rho, lv_h, target, beta)
        units += cost_fwd(lv_h) + cost_bwd(lv_h)
        correction = g_h - g_l

        saved_adam = adam.state()
        x = rho.clone()
        for _ in range(inner):
            _, g_lx = value_grad_latent(x, lv_l, target, beta)
            units += cost_fwd(lv_l) + cost_bwd(lv_l)
            x = adam.step(x, g_lx + correction, lr, scale=alpha)

        j_h_cand = forward_latent(x, lv_h, target, beta)      # mandatory
        units += cost_fwd(lv_h)
        event = {"outer": outer, "beta": beta, "level_h": list(lv_h),
                 "J_H": j_h, "J_H_cand": j_h_cand, "alpha": alpha,
                 "units": units}
        if j_h_cand >= j_h:
            accepts += 1
            accepts_since_audit += 1
            rho = x
            alpha = min(alpha * 1.3, 1.0)
            event["action"] = "accept"
        else:
            rejects += 1
            adam.load(saved_adam)
            alpha = max(alpha * 0.5, 0.05)
            event["action"] = "reject"

        due = accepts_since_audit >= audit_every or (
            event["action"] == "reject" and rejects % 3 == 0)
        if due:
            accepts_since_audit = 0
            if not wall_budget_s and                     units + cost_fwd(lv_r) + cost_fwd(lv_h) > budget:
                events.append(event)
                break
            b = hard_binary(rho)
            score_r = forward_density(b, lv_r, target)
            units += cost_fwd(lv_r)
            score_h = forward_density(b, lv_h, target)
            units += cost_fwd(lv_h)
            denom = max(abs(score_r), QUALIFY_FLOOR)
            qual = abs(score_r - score_h) / denom
            event["binary_R"] = score_r
            event["binary_H"] = score_h
            event["qualification"] = qual
            if qual <= QUALIFY_TOL:
                beta_cap = BETA_LADDER[-1]
            else:
                gated += 1
                beta_cap = min(beta_cap, beta)
                if promo + 2 < len(PROMOTION):
                    promo += 1
                    lv_h, lv_r = PROMOTION[promo], PROMOTION[promo + 1]
                    promotions += 1
                    event["promoted_to"] = list(lv_h)
            if score_r >= cert_score:
                cert_score, cert_bin = score_r, b
                cert_rho, cert_adam = rho.clone(), adam.state()
                event["certified"] = True
            else:
                rollbacks += 1
                rho = cert_rho.clone()
                adam.load(cert_adam)
                alpha = max(alpha * 0.5, 0.05)
                event["rollback"] = True
            _snapshot(checkpoints, units, t0, cert_bin, "audit", current=b)
        events.append(event)
        outer += 1

    _snapshot(checkpoints, units, t0, cert_bin, "final")
    return {
        "delivered_binary": cert_bin,
        "final_latent": cert_rho,
        "units": units,
        "wall_s": time.perf_counter() - t0,
        "outer": outer,
        "self_reported_binary": cert_score,
        "certified_level": list(lv_r),
        "stats": {"accepts": accepts, "rejects": rejects,
                  "rollbacks": rollbacks, "promotions": promotions,
                  "beta_gated": gated, "final_beta_cap": beta_cap,
                  "acceptance_rate": accepts / max(accepts + rejects, 1)},
        "events": events,
        "checkpoints": checkpoints,
        "level": list(lv_h),
    }


# ------------------------------ arm B': certified with dense cheap screening
def run_certified_screened(target, seed, budget=BUDGET_UNITS, inner=6,
                           audit_every=2, wall_budget_s=None):
    """POST-HOC VARIANT of run_certified -- registered after seeing E10.

    The measured E10 gap traced back to *sampling cadence*, not to the cost of
    certification: the plain certified arm evaluates a hard binary only at its
    R audits (4-6 per run), so the delivered design is a maximum over ~5
    samples, while the TORCWA arm audits its binary every 6 steps (37 samples,
    at its own low order).

    This variant separates search from delivery:
      * the trajectory is identical -- FOC-corrected L proposals with mandatory
        H actual-gain acceptance;
      * every inner iterate is screened as a hard binary at the CHEAP level L;
      * only when the cheap screen beats the certified design's own screen
        score is an expensive R certification spent on it;
      * certification and beta gating are unchanged, so delivery safety and
        the representation gate still hold.

    Because it was designed after seeing the result it is reported as a
    separate arm and never substituted for `certified`.
    """
    lv_l = LEVELS["L"]
    promo = 0
    lv_h = PROMOTION[promo]
    lv_r = PROMOTION[promo + 1]
    rho = initial_latent(seed)
    adam = Adam(rho.shape)
    units = 0.0
    t0 = time.perf_counter()

    cert_bin = hard_binary(rho)
    cert_score = forward_density(cert_bin, lv_r, target)
    units += cost_fwd(lv_r)
    cert_screen = forward_density(cert_bin, lv_l, target)
    units += cost_fwd(lv_l)
    cert_rho, cert_adam = rho.clone(), adam.state()

    beta_cap = BETA_LADDER[-1]
    alpha = 1.0
    accepts = rejects = rollbacks = promotions = gated = 0
    accepts_since_audit = 0
    screened = 0
    best_screen_score, best_screen_bin = -float("inf"), None
    events, checkpoints = [], []
    _snapshot(checkpoints, units, t0, cert_bin, "init")
    outer = 0
    while True:
        elapsed = time.perf_counter() - t0
        if wall_budget_s:
            if elapsed >= wall_budget_s:
                break
            progress = min(elapsed / wall_budget_s, 1.0)
        else:
            est = (cost_fwd(lv_l) + cost_bwd(lv_l)) * (1 + inner) \
                + cost_fwd(lv_h) + cost_bwd(lv_h) + cost_fwd(lv_h) \
                + inner * cost_fwd(lv_l)
            if units + est > budget:
                break
            progress = min(units / budget, 1.0)
        beta = min(beta_at(progress), beta_cap)
        lr = cosine_lr(progress)

        j_l, g_l = value_grad_latent(rho, lv_l, target, beta)
        units += cost_fwd(lv_l) + cost_bwd(lv_l)
        j_h, g_h = value_grad_latent(rho, lv_h, target, beta)
        units += cost_fwd(lv_h) + cost_bwd(lv_h)
        correction = g_h - g_l

        saved_adam = adam.state()
        x = rho.clone()
        for _ in range(inner):
            _, g_lx = value_grad_latent(x, lv_l, target, beta)
            units += cost_fwd(lv_l) + cost_bwd(lv_l)
            x = adam.step(x, g_lx + correction, lr, scale=alpha)
            candidate = hard_binary(x)
            screen = forward_density(candidate, lv_l, target)
            units += cost_fwd(lv_l)
            screened += 1
            if screen > best_screen_score:
                best_screen_score, best_screen_bin = screen, candidate

        j_h_cand = forward_latent(x, lv_h, target, beta)
        units += cost_fwd(lv_h)
        event = {"outer": outer, "beta": beta, "level_h": list(lv_h),
                 "J_H": j_h, "J_H_cand": j_h_cand, "alpha": alpha,
                 "screened": screened, "best_screen": best_screen_score,
                 "units": units}
        if j_h_cand >= j_h:
            accepts += 1
            accepts_since_audit += 1
            rho = x
            alpha = min(alpha * 1.3, 1.0)
            event["action"] = "accept"
        else:
            rejects += 1
            adam.load(saved_adam)
            alpha = max(alpha * 0.5, 0.05)
            event["action"] = "reject"

        due = (accepts_since_audit >= audit_every
               or (event["action"] == "reject" and rejects % 3 == 0))
        promising = best_screen_bin is not None and best_screen_score > cert_screen
        if due and promising:
            accepts_since_audit = 0
            if not wall_budget_s and \
                    units + cost_fwd(lv_r) + cost_fwd(lv_h) > budget:
                events.append(event)
                break
            score_r = forward_density(best_screen_bin, lv_r, target)
            units += cost_fwd(lv_r)
            score_h = forward_density(best_screen_bin, lv_h, target)
            units += cost_fwd(lv_h)
            denom = max(abs(score_r), QUALIFY_FLOOR)
            qual = abs(score_r - score_h) / denom
            event["binary_R"] = score_r
            event["binary_H"] = score_h
            event["qualification"] = qual
            if qual <= QUALIFY_TOL:
                beta_cap = BETA_LADDER[-1]
            else:
                gated += 1
                beta_cap = min(beta_cap, beta)
                if promo + 2 < len(PROMOTION):
                    promo += 1
                    lv_h, lv_r = PROMOTION[promo], PROMOTION[promo + 1]
                    promotions += 1
                    event["promoted_to"] = list(lv_h)
            if score_r >= cert_score:
                cert_score, cert_bin = score_r, best_screen_bin
                cert_screen = best_screen_score
                cert_rho, cert_adam = rho.clone(), adam.state()
                event["certified"] = True
            else:
                rollbacks += 1
                cert_screen = best_screen_score
                rho = cert_rho.clone()
                adam.load(cert_adam)
                alpha = max(alpha * 0.5, 0.05)
                event["rollback"] = True
            _snapshot(checkpoints, units, t0, cert_bin, "audit",
                      current=best_screen_bin)
        elif due:
            accepts_since_audit = 0
        events.append(event)
        outer += 1

    _snapshot(checkpoints, units, t0, cert_bin, "final")
    return {
        "delivered_binary": cert_bin,
        "final_latent": cert_rho,
        "units": units,
        "wall_s": time.perf_counter() - t0,
        "outer": outer,
        "self_reported_binary": cert_score,
        "certified_level": list(lv_r),
        "stats": {"accepts": accepts, "rejects": rejects,
                  "rollbacks": rollbacks, "promotions": promotions,
                  "beta_gated": gated, "final_beta_cap": beta_cap,
                  "screened_binaries": screened,
                  "acceptance_rate": accepts / max(accepts + rejects, 1)},
        "events": events,
        "checkpoints": checkpoints,
        "level": list(lv_h),
    }
