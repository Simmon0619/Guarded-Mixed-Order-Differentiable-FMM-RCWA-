"""E10 head-to-head: frozen physics, common design map, shared cost model.

Frozen protocol (2026-08-28):
  physics : E2/GateD main stack -- 660 nm, lattice (2400,700) nm, 800 nm
            patterned film (air background / n=3.2 feature) between a
            semi-infinite n=1.46 substrate (incidence side) and semi-infinite
            air.  x-polarized normal incidence, complex128, grid (Ny,Nx)=
            (35,120) = 20 nm square pixels.
  design  : IDENTICAL for every arm --
            latent rho -> y-mirror symmetrization -> periodic Gaussian filter
            (60 nm) -> tanh projection(beta) -> eps.  Delivered structure is
            the hard 0.5 threshold of the *filtered* latent (beta-independent),
            re-symmetrized.
  cost    : 1 unit = one (16,4) forward.  fwd(level) = (n_terms/297)^3,
            bwd = 1.5 x fwd.  Every solve any arm performs is charged,
            including its own binary audits.  Checkpoint scoring for the
            anytime curves is measurement, charged separately and never steers.
  scoring : delivered hard binary re-scored by the SAME solver at (24,6) and
            (28,7).  (28,7) is the reported truth; the (24,6)->(28,7) change is
            the residual reference uncertainty and is reported, not hidden.

P0 refactor (2026-08-30): the frozen protocol now lives on an immutable
``ProblemConfig`` rather than in module-level constants, so that a single
process can hold several problems at once -- required for the supercell size
sweep (E14) and for splitting descent precision from audit precision (P2/E13).

``DEFAULT`` reproduces the frozen protocol exactly.  Every function takes the
config as a trailing ``cfg`` argument defaulting to ``DEFAULT``, and the old
module-level names are retained as aliases bound to ``DEFAULT``, so existing
callers keep working unchanged.  Acceptance for this refactor is BITWISE
identity against ``p0_bitwise_baseline.py`` -- not tolerance agreement.

Two couplings that were previously implicit are now explicit, because the
refactor would otherwise let them drift apart silently:
  * ``projected`` relied on ``tanh_projection``'s default ``eta=0.5`` happening
    to equal ``THRESHOLD``; the threshold is now passed through.
  * ``N_H`` (the cost-model denominator) was evaluated at import time from
    ``LEVELS['H']``.  It is now an explicit, ABSOLUTE ``cost_unit_terms`` field:
    deriving it from each config's own ladder would let a supercell variant
    silently rescale the budget and destroy cross-scale comparability (E14).
"""
import math
import os
import sys
from dataclasses import dataclass
from typing import Dict, Sequence, Tuple

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.abspath(os.path.join(_HERE, "..", "..", ".."))
if os.path.join(_ROOT, "src") not in sys.path:
    sys.path.insert(0, os.path.join(_ROOT, "src"))

from trustworthy_fmm.fabrication.process import (  # noqa: E402
    periodic_gaussian_filter,
    periodic_signed_distance_nm,
    tanh_projection,
)
from trustworthy_fmm.solvers.vector_2d import solve_multilayer_vector_2d  # noqa: E402


# --------------------------------------------------------------- the protocol
@dataclass(frozen=True)
class ProblemConfig:
    """One frozen design problem.  Immutable; derive variants with ``variant``."""

    # -- physics
    wavelength_nm: float = 660.0
    lattice_nm: Tuple[float, float] = (2400.0, 700.0)   # (Lx, Ly)
    ny: int = 35
    nx: int = 120
    thickness_nm: float = 800.0
    n_incident: float = 1.46
    n_output: float = 1.0
    eps_background: float = 1.0
    eps_feature: float = 3.2 ** 2
    incident_jones: Tuple[complex, complex] = (1.0 + 0j, 0.0 + 0j)

    # -- design map
    filter_nm: float = 60.0
    threshold: float = 0.5
    beta_ladder: Tuple[float, ...] = (1.0, 2.0, 4.0, 8.0, 16.0, 32.0, 64.0)
    init_mean: float = 0.5
    init_scale: float = 0.08
    init_clamp_lo: float = 0.05
    init_clamp_hi: float = 0.95

    # -- fidelity ladder (tuple of pairs so the dataclass stays hashable)
    level_pairs: Tuple[Tuple[str, Tuple[int, int]], ...] = (
        ("L", (12, 3)), ("H", (16, 4)), ("R", (20, 5)), ("R2", (24, 6)),
    )
    score_levels: Tuple[Tuple[int, int], ...] = ((24, 6), (28, 7))
    checkpoint_level: Tuple[int, int] = (24, 6)
    promotion_levels: Tuple[Tuple[int, int], ...] = ((16, 4), (20, 5), (24, 6))

    # -- cost model.  The frozen protocol defines 1 unit as one ABSOLUTE (16,4)
    #    forward.  This must NOT be derived from this config's own levels['H']:
    #    a supercell variant with a different ladder would silently rescale the
    #    budget and destroy cross-scale comparability (E14).
    cost_unit_terms: int = 297          # n_terms((16, 4))

    # -- campaign
    targets: Tuple[Tuple[int, int], ...] = ((1, 0), (2, 0), (3, 0))
    seeds: Tuple[int, ...] = (2029, 2030, 2031)
    budget_units: float = 60.0

    # -- optimizer
    adam_lr0: float = 0.02
    adam_b1: float = 0.9
    adam_b2: float = 0.999
    adam_eps: float = 1e-8

    # -- numerics.  descent_* drives the optimization loop; audit_* drives
    #    certification and delivered scoring.  Identical by default, split by
    #    P2/E13 so descent can run complex64 on GPU while audits stay
    #    complex128 on CPU.
    dtype: torch.dtype = torch.complex128
    device: str = "cpu"
    audit_dtype: torch.dtype = torch.complex128
    audit_device: str = "cpu"
    latent_dtype: torch.dtype = torch.float64

    # -- perturbation families for the held-out audit.  Collected here because
    #    they are currently duplicated and INCONSISTENT across consumers:
    #    e10_score.py uses +-10 nm (a no-op on a 20 nm pixel) while
    #    e10_robustness.py uses the +-20 nm that the E10 report actually
    #    describes.  P0 only records the discrepancy; rewiring the consumers is
    #    deliberately left to P1 so this refactor stays bitwise-verifiable.
    cd_bias_nm: Tuple[float, ...] = (-20.0, 20.0)
    morph_radius_nm: float = 40.0
    morph_ops: Tuple[str, ...] = ("opening", "closing")

    def __post_init__(self):
        # Only invariants whose violation would be SILENT are asserted here.
        # Anisotropic pixels and even ny are legitimate, so neither is checked.
        if not (self.dtype.is_complex and self.audit_dtype.is_complex):
            raise ValueError("dtype and audit_dtype must be complex; the solver "
                             "infers its working precision from the layer dtype")
        if self.latent_dtype.is_complex or not self.latent_dtype.is_floating_point:
            raise ValueError("latent_dtype must be a real floating type")
        for name, level in self.level_pairs:
            if not all(isinstance(v, int) for v in level):
                raise ValueError("level %r must hold ints: n_terms() truncates "
                                 "silently via int()" % (name,))
        if min(self.lattice_nm) <= 0 or self.wavelength_nm <= 0 or self.thickness_nm < 0:
            raise ValueError("lattice periods and wavelength must be positive")
        if self.cost_unit_terms <= 0:
            raise ValueError("cost_unit_terms must be positive")

    # ---- derived
    @property
    def levels(self) -> Dict[str, Tuple[int, int]]:
        return {name: level for name, level in self.level_pairs}

    @property
    def pixel_yx(self) -> Tuple[float, float]:
        """(dy, dx) in nm.  Derived -- never stored, so it cannot go stale."""
        return (self.lattice_nm[1] / self.ny, self.lattice_nm[0] / self.nx)

    @property
    def n_h(self) -> int:
        """Legacy alias for the cost denominator.  Kept for the old module-level
        ``N_H``; new code should read ``cost_unit_terms``, which is absolute."""
        return self.cost_unit_terms

    @property
    def shape(self) -> Tuple[int, int]:
        return (self.ny, self.nx)

    def variant(self, **changes) -> "ProblemConfig":
        """A copy with fields replaced; the only supported way to make one."""
        from dataclasses import replace
        return replace(self, **changes)

    def min_grid_for(self, level: Sequence[int]) -> Tuple[int, int]:
        """Smallest (ny, nx) satisfying the convolution constraint n >= 4m+1."""
        return (4 * int(level[1]) + 1, 4 * int(level[0]) + 1)

    def supports(self, level: Sequence[int]) -> bool:
        ny_min, nx_min = self.min_grid_for(level)
        return self.ny >= ny_min and self.nx >= nx_min


def _assert_axis_conventions():
    """PIXEL_YX is (20.0, 20.0) at the frozen constants, so a (dy,dx)->(dx,dy)
    swap is bitwise invisible there.  Check on a deliberately anisotropic
    config, where the two orders differ."""
    probe = ProblemConfig(lattice_nm=(2400.0, 700.0), ny=35, nx=60)
    dy, dx = probe.pixel_yx
    assert (dy, dx) == (20.0, 40.0), "pixel_yx must be (Ly/ny, Lx/nx), got %r" % (probe.pixel_yx,)
    assert probe.shape == (35, 60), "shape must be (ny, nx)"
    assert ProblemConfig().cost_unit_terms == n_terms((16, 4)) == 297


DEFAULT = ProblemConfig()

# Legacy module-level aliases: the frozen E10 protocol, so that the thirteen
# consumer scripts keep working with no edits.  New code should pass ``cfg``.
DT = DEFAULT.dtype
WL = DEFAULT.wavelength_nm
LATTICE = DEFAULT.lattice_nm
NY, NX = DEFAULT.ny, DEFAULT.nx
THICK = DEFAULT.thickness_nm
N_IN, N_OUT = DEFAULT.n_incident, DEFAULT.n_output
EPS_BG, EPS_FEAT = DEFAULT.eps_background, DEFAULT.eps_feature
PIXEL_YX = DEFAULT.pixel_yx

FILTER_NM = DEFAULT.filter_nm
THRESHOLD = DEFAULT.threshold
BETA_LADDER = list(DEFAULT.beta_ladder)

LEVELS = DEFAULT.levels
SCORE_LEVELS = [tuple(lv) for lv in DEFAULT.score_levels]
CHECKPOINT_LEVEL = DEFAULT.checkpoint_level

TARGETS = [tuple(t) for t in DEFAULT.targets]
SEEDS = list(DEFAULT.seeds)
BUDGET_UNITS = DEFAULT.budget_units

ADAM_LR0 = DEFAULT.adam_lr0
ADAM_B1, ADAM_B2, ADAM_EPS = DEFAULT.adam_b1, DEFAULT.adam_b2, DEFAULT.adam_eps


def n_terms(level):
    return (2 * int(level[0]) + 1) * (2 * int(level[1]) + 1)


N_H = DEFAULT.n_h

_assert_axis_conventions()     # needs n_terms, so it runs after the definitions


def cost_fwd(level, cfg=DEFAULT):
    # Expression form is load-bearing: (n/N)**3, n**3/N**3 and (n/N)*(n/N)*(n/N)
    # disagree in the last ulp at some levels.  Do not "simplify" this.
    return (n_terms(level) / cfg.cost_unit_terms) ** 3


def cost_bwd(level, cfg=DEFAULT):
    return 1.5 * cost_fwd(level, cfg)


# ----------------------------------------------------------------- design map
def symmetrize(rho):
    return 0.5 * (rho + torch.flip(rho, dims=(0,)))


def filtered(rho, cfg=DEFAULT):
    """Common latent -> filtered density map (symmetry + fabrication filter)."""
    return symmetrize(
        periodic_gaussian_filter(symmetrize(rho), cfg.lattice_nm, cfg.filter_nm))


def projected(rho, beta, cfg=DEFAULT):
    # The threshold is passed explicitly: it used to ride on tanh_projection's
    # eta=0.5 default silently matching THRESHOLD.
    return tanh_projection(filtered(rho, cfg), float(beta), cfg.threshold)


def hard_binary(rho, cfg=DEFAULT):
    """Delivered manufacturing mask: beta-independent hard threshold."""
    with torch.no_grad():
        return (filtered(rho, cfg) >= cfg.threshold).to(cfg.latent_dtype)


def initial_latent(seed, cfg=DEFAULT):
    # The generator is always CPU so the random stream -- and therefore every
    # trajectory -- is identical no matter which device the solve runs on.
    g = torch.Generator().manual_seed(int(seed))
    noise = torch.randn((cfg.ny, cfg.nx), generator=g, dtype=cfg.latent_dtype)
    smooth = periodic_gaussian_filter(noise, cfg.lattice_nm, cfg.filter_nm)
    smooth = smooth / smooth.std()
    latent = symmetrize(
        (cfg.init_mean + cfg.init_scale * smooth).clamp(cfg.init_clamp_lo,
                                                        cfg.init_clamp_hi))
    return latent if cfg.device == "cpu" else latent.to(cfg.device)


# ------------------------------------------------------------------- solver
def _eps(density, cfg=DEFAULT, dtype=None, device=None):
    dtype = cfg.dtype if dtype is None else dtype
    device = cfg.device if device is None else device
    eps = (cfg.eps_background + (cfg.eps_feature - cfg.eps_background) * density)
    eps = eps.to(dtype)
    return eps if device == "cpu" and eps.device.type == "cpu" else eps.to(device)


def _solve(eps_layer, level, cfg):
    return solve_multilayer_vector_2d(
        [eps_layer], [cfg.thickness_nm], cfg.wavelength_nm, cfg.lattice_nm,
        cfg.n_incident, cfg.n_output, tuple(level),
        incident_jones=cfg.incident_jones,
    )


def forward_density(density, level, target, cfg=DEFAULT, audit=False):
    """eta of the target transmitted order for a fixed density (no gradient).

    ``audit=True`` forces the audit precision/device, which is what any
    certification or delivered-score call should use once P2 splits them.
    """
    dtype = cfg.audit_dtype if audit else cfg.dtype
    device = cfg.audit_device if audit else cfg.device
    with torch.no_grad():
        r = _solve(_eps(density, cfg, dtype, device), level, cfg)
        return float(r.power_t[r.orders.index(tuple(target))])


def value_grad_latent(rho, level, target, beta, cfg=DEFAULT):
    """eta and d(eta)/d(latent rho) through the common design map."""
    x = rho.detach().clone().requires_grad_(True)
    r = _solve(_eps(projected(x, beta, cfg), cfg), level, cfg)
    j = r.power_t[r.orders.index(tuple(target))]
    j.backward()
    return float(j.detach()), x.grad.detach().clone()


def forward_latent(rho, level, target, beta, cfg=DEFAULT):
    with torch.no_grad():
        return forward_density(projected(rho, beta, cfg), level, target, cfg)


# --------------------------------------------------------------------- Adam
class Adam:
    def __init__(self, shape, cfg=DEFAULT):
        self.cfg = cfg
        dev = None if cfg.device == "cpu" else cfg.device
        self.m = torch.zeros(shape, dtype=cfg.latent_dtype, device=dev)
        self.v = torch.zeros(shape, dtype=cfg.latent_dtype, device=dev)
        self.t = 0

    def step(self, rho, grad, lr, scale=1.0):
        c = self.cfg
        self.t += 1
        self.m = c.adam_b1 * self.m + (1 - c.adam_b1) * grad
        self.v = c.adam_b2 * self.v + (1 - c.adam_b2) * grad.square()
        mh = self.m / (1 - c.adam_b1 ** self.t)
        vh = self.v / (1 - c.adam_b2 ** self.t)
        return symmetrize(
            (rho + scale * lr * mh / (vh.sqrt() + c.adam_eps)).clamp(0.0, 1.0))

    def state(self):
        return (self.m.clone(), self.v.clone(), self.t)

    def load(self, s):
        self.m, self.v, self.t = s[0].clone(), s[1].clone(), s[2]


def cosine_lr(progress, cfg=DEFAULT):
    return cfg.adam_lr0 * 0.5 * (1.0 + math.cos(math.pi * min(max(progress, 0.0), 1.0)))


def beta_at(progress, ladder=None, cfg=DEFAULT):
    """Continuous exponential beta continuation, as in TORCWA Example 6."""
    ladder = cfg.beta_ladder if ladder is None else ladder
    lo, hi = ladder[0], ladder[-1]
    return lo * (hi / lo) ** min(max(progress, 0.0), 1.0)


# ------------------------------------------------------------- perturbations
def cd_bias_mask(mask_yx, bias_nm, cfg=DEFAULT):
    """Periodic uniform edge bias; positive grows the feature."""
    m = np.asarray(mask_yx, dtype=bool)
    if not m.any() or m.all():
        return m.astype(np.float64)
    sd = periodic_signed_distance_nm(m, cfg.pixel_yx)
    return (sd >= -float(bias_nm)).astype(np.float64)
