"""What survives statistically?  Test every claim we currently lean on."""
import glob, itertools, json, math, statistics as st

sc = {}
for p in glob.glob('data/main/*scores.json'):
    for k, v in json.load(open(p)).items():
        if not k.startswith('_'):
            sc[k] = v


def perm_p(d):
    obs = abs(st.mean(d)); hits = tot = 0
    for s in itertools.product((1, -1), repeat=len(d)):
        tot += 1
        if abs(sum(a * b for a, b in zip(s, d)) / len(d)) >= obs - 1e-15:
            hits += 1
    return hits / tot


def arm(name, field):
    out = {}
    for v in sc.values():
        if v['arm'] != name:
            continue
        k = (tuple(v['target']), v['seed'])
        if field == 'inflation':
            out[k] = (v['self_reported_binary'] - v['blind']['28,7']) / v['blind']['28,7']
        else:
            out[k] = v['blind']['28,7']
    return out


def paired_test(label, a, b):
    keys = sorted(set(a) & set(b))
    d = [a[k] - b[k] for k in keys]
    p = perm_p(d)
    print("  %-46s mean %+8.4f  n=%d  p=%.4f  %s"
          % (label, st.mean(d), len(d), p,
             "SIGNIFICANT" if p < 0.05 else ("marginal" if p < 0.10 else "not resolved")))
    return p


print("=" * 92)
print("1. HONESTY -- is the self-report inflation difference real?")
print("=" * 92)
paired_test("inflation: torcwa_M12 - certified",
            arm('torcwa_M12', 'inflation'), arm('certified', 'inflation'))
paired_test("inflation: torcwa_M12 - certified_screened",
            arm('torcwa_M12', 'inflation'), arm('certified_screened', 'inflation'))
paired_test("inflation: torcwa_M12 - torcwa_M24_wall410",
            arm('torcwa_M12', 'inflation'), arm('torcwa_M24_wall410', 'inflation'))
paired_test("inflation: torcwa_native_gpu_M12 - certified",
            arm('torcwa_native_gpu_M12', 'inflation'), arm('certified', 'inflation'))

print()
print("=" * 92)
print("2. EFFICIENCY -- does any arm beat any other on delivered eta?")
print("=" * 92)
names = ['torcwa_M12', 'torcwa_M16', 'torcwa_M24_wall410', 'certified',
         'certified_screened', 'certified_wall410']
for i in range(len(names)):
    for j in range(i + 1, len(names)):
        paired_test("eta: %s - %s" % (names[i], names[j]),
                    arm(names[i], 'eta'), arm(names[j], 'eta'))

print()
print("=" * 92)
print("3. WINNER'S CURSE -- do designs selected on (12,3) carry a positive error?")
print("=" * 92)
rows = json.load(open('data/truncation_vs_selection.json'))
sel = [(r['eta_12_3'] - r['eta_28_7']) / r['eta_28_7']
       for r in rows if r['arm'] in ('torcwa_M12', 'torcwa_native_gpu_M12')]
oth = [(r['eta_12_3'] - r['eta_28_7']) / r['eta_28_7']
       for r in rows if r['arm'] not in ('torcwa_M12', 'torcwa_native_gpu_M12')]
print("  selected-on-(12,3): n=%d median %+.1f%% mean %+.1f%%  positive %d/%d"
      % (len(sel), 100 * st.median(sel), 100 * st.mean(sel),
         sum(x > 0 for x in sel), len(sel)))
print("  all other arms    : n=%d median %+.1f%% mean %+.1f%%  positive %d/%d"
      % (len(oth), 100 * st.median(oth), 100 * st.mean(oth),
         sum(x > 0 for x in oth), len(oth)))
# unpaired permutation test on the difference of means
import random
pool = sel + oth
obs = st.mean(sel) - st.mean(oth)
rng = random.Random(4242); hits = N = 20000
cnt = 0
for _ in range(N):
    rng.shuffle(pool)
    if abs(st.mean(pool[:len(sel)]) - st.mean(pool[len(sel):])) >= abs(obs) - 1e-15:
        cnt += 1
print("  difference of means %+.1f%%   permutation p = %.4f  -> %s"
      % (100 * obs, cnt / N, "SIGNIFICANT" if cnt / N < 0.05 else "not resolved"))
# sign test on "is the selected design's error positive"
k, n = sum(x > 0 for x in sel), len(sel)
p_sign = 2 * sum(math.comb(n, i) for i in range(k, n + 1)) / 2 ** n
print("  sign test (selected errors positive %d/%d vs 50%%): p = %.4f -> %s"
      % (k, n, p_sign, "SIGNIFICANT" if p_sign < 0.05 else "not resolved"))

print()
print("=" * 92)
print("4. ORDER MONOTONICITY -- is eta(+1) > eta(+2) > eta(+3)?")
print("=" * 92)
for name in names:
    a = arm(name, 'eta')
    m = {t: st.mean([x for k, x in a.items() if k[0] == t])
         for t in sorted({k[0] for k in a})}
    vals = [m[t] for t in sorted(m)]
    print("  %-22s +1=%.4f  +2=%.4f  +3=%.4f   %s"
          % (name, vals[0], vals[1], vals[2],
             "monotone" if vals[0] > vals[1] > vals[2] else "NOT monotone"))
allm = {}
for t in ((1, 0), (2, 0), (3, 0)):
    allm[t] = [v['blind']['28,7'] for v in sc.values() if tuple(v['target']) == t]
print("  pooled over all arms/seeds:")
for t in sorted(allm):
    print("    (%+d,%d)  n=%d  mean %.4f  median %.4f  max %.4f"
          % (t[0], t[1], len(allm[t]), st.mean(allm[t]), st.median(allm[t]), max(allm[t])))
