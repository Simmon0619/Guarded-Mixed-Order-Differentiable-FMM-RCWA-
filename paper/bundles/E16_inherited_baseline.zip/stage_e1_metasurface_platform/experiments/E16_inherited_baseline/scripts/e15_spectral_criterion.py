"""Where does the design's own spectrum sit relative to the truncation?

The design map limits features to the filter radius R.  The Fourier basis at
half-order m resolves structures down to Lambda/(2m).  So the truncation is
adequate only when  m >= Lambda/(2R).  This script checks that criterion
against the measured error ladder, and separates the two things the solver
needs the spectrum for: the VALUE (one output coefficient) and the GRADIENT
(the whole retained field).
"""
import glob, json, sys, os
import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import e10_common as C

Lx, Ly = C.LATTICE
R = C.FILTER_NM
print("design map filter radius R = %.0f nm;  periods Lx=%.0f Ly=%.0f nm" % (R, Lx, Ly))
print("criterion  m* = Lambda / (2R):   m*_x = %.1f   m*_y = %.1f"
      % (Lx / (2 * R), Ly / (2 * R)))
print("i.e. the truncation only resolves the design map's own length scale at")
print("about (mx,my) = (%d,%d).\n" % (round(Lx / (2 * R)), round(Ly / (2 * R))))

# --- spectral energy captured, averaged over the delivered designs ----------
sc = {}
for p in glob.glob('data/main/*scores.json'):
    for k, v in json.load(open(p)).items():
        if not k.startswith('_'):
            sc[k] = v
files = []
for k, v in sorted(sc.items()):
    t, seed, arm = tuple(v['target']), v['seed'], v['arm']
    f = 'data/main/designs/%d_%d_%d_%s_binary.npy' % (t[0], t[1], seed, arm)
    if os.path.exists(f):
        files.append(f)
print("delivered designs found: %d" % len(files))

LEVELS = [(8, 2), (12, 3), (16, 4), (20, 5), (24, 6), (28, 7), (40, 10)]
capt_bin, capt_filt = {lv: [] for lv in LEVELS}, {lv: [] for lv in LEVELS}
for f in files:
    d = torch.tensor(np.load(f), dtype=torch.float64)
    for name, field, store in (("bin", d, capt_bin),
                               ("filt", C.filtered(d), capt_filt)):
        F = torch.fft.fft2(field)
        P = (F.abs() ** 2).numpy()
        tot = P.sum()
        ny, nx = P.shape
        for mx, my in LEVELS:
            ix = [i % nx for i in range(-mx, mx + 1)]
            iy = [i % ny for i in range(-my, my + 1)]
            store[(mx, my)].append(P[np.ix_(iy, ix)].sum() / tot)

print("\n%-9s %8s %14s %14s %14s" % ("level", "n_terms", "captured(bin)",
                                     "captured(filt)", "measured MAD"))
MAD = {(12, 3): 21.8, (16, 4): 11.8, (24, 6): 2.4}
for lv in LEVELS:
    m = MAD.get(lv)
    print("%-9s %8d %13.4f%% %13.4f%% %14s"
          % ("(%d,%d)" % lv, C.n_terms(lv), 100 * np.mean(capt_bin[lv]),
             100 * np.mean(capt_filt[lv]), ("%.1f%%" % m) if m else "-"))

# --- the value needs ONE coefficient; the gradient needs the whole field ----
print("\nWhy the value and the gradient see the truncation differently:")
print("  eta            = |<phi_target, u>|^2      -- ONE retained harmonic")
print("  d eta / d rho  = 2 Re <lambda, (dA/drho) u> -- a bilinear form in the")
print("                   forward and adjoint fields over EVERY retained harmonic")
print("  so a truncation that leaves the target coefficient accurate can still")
print("  corrupt the gradient, because the gradient integrates the error over")
print("  the whole spectrum instead of sampling it at one point.\n")

d = torch.tensor(np.load(files[0]), dtype=torch.float64)
tgt = (1, 0)
print("empirical check on one delivered design (%s):" % os.path.basename(files[0]))
prev_v = prev_g = None
for lv in [(12, 3), (16, 4), (20, 5), (24, 6)]:
    rho = d.clone().requires_grad_(True)
    r = C._solve(C._eps(rho, C.DEFAULT), lv, C.DEFAULT)
    j = r.power_t[r.orders.index(tgt)]
    j.backward()
    v = float(j.detach()); g = rho.grad.detach().clone()
    if prev_v is not None:
        dv = abs(v - prev_v) / max(abs(prev_v), 1e-30)
        cos = float(torch.sum(g * prev_g) / (g.norm() * prev_g.norm()))
        print("  %-8s value change vs previous level %8.2e   gradient 1-cos %8.2e"
              % ("(%d,%d)" % lv, dv, 1 - cos))
    prev_v, prev_g = v, g
