"""Decompose each arm's self-report inflation into truncation error vs selection bias.

For every DELIVERED hard binary we re-evaluate eta at the arm's own audit level
and at the blind reference.  The per-design gap is pure truncation error.  The
arm's reported inflation is the gap for the design it *selected* as best.  If
inflation >> typical truncation error, the arm is not mis-simulating -- it is
winning a max over noisy estimates (winner's curse).
"""
import glob, json, os, sys
import numpy as np, torch
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import e10_common as C

LEVELS = [(12, 3), (16, 4)]
sc = {}
for p in glob.glob(os.path.join(C._HERE, "..", "data", "main", "*scores.json")):
    for k, v in json.load(open(p)).items():
        if not k.startswith("_"):
            sc[k] = v

rows = []
for k, v in sorted(sc.items()):
    t, seed, arm = tuple(v["target"]), v["seed"], v["arm"]
    f = os.path.join(C._HERE, "..", "data", "main", "designs",
                     "%d_%d_%d_%s_binary.npy" % (t[0], t[1], seed, arm))
    if not os.path.exists(f):
        continue
    d = torch.tensor(np.load(f), dtype=torch.float64)
    rec = dict(target=list(t), seed=seed, arm=arm,
               eta_24_6=v["blind"]["24,6"], eta_28_7=v["blind"]["28,7"],
               self_reported=v["self_reported_binary"])
    for lv in LEVELS:
        rec["eta_%d_%d" % lv] = C.forward_density(d, lv, t)
    rows.append(rec)
    print("%-22s (%+d,%d) %d  L12=%.4f L16=%.4f  ref=%.4f  reported=%.4f"
          % (arm, t[0], t[1], seed, rec["eta_12_3"], rec["eta_16_4"],
             rec["eta_28_7"], rec["self_reported"]), flush=True)

json.dump(rows, open(os.path.join(C._HERE, "..", "data", "truncation_vs_selection.json"), "w"), indent=1)

import statistics as st
print("\n=== per-arm decomposition (median over 9 runs) ===")
print("%-30s %14s %14s %14s" % ("arm", "trunc err @own", "reported infl", "selection part"))
own = {"torcwa_M12": "eta_12_3", "torcwa_native_gpu_M12": "eta_12_3",
       "torcwa_M16": "eta_16_4", "certified": "eta_24_6",
       "certified_screened": "eta_24_6", "certified_wall410": "eta_24_6"}
for arm in sorted({r["arm"] for r in rows}):
    rs = [r for r in rows if r["arm"] == arm]
    key = own[arm]
    trunc = st.median([(r[key] - r["eta_28_7"]) / r["eta_28_7"] for r in rs])
    infl = st.median([(r["self_reported"] - r["eta_28_7"]) / r["eta_28_7"] for r in rs])
    print("%-30s %13.1f%% %13.1f%% %13.1f%%" % (arm, 100 * trunc, 100 * infl, 100 * (infl - trunc)))
