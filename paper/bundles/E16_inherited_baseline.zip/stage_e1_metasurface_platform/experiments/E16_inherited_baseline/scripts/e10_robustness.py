"""E10 held-out process audit of the delivered hard binaries.

The first scoring pass used a +/-10 nm CD bias, which is a no-op on a 20 nm
pixel grid: the periodic signed distance of a boundary pixel is exactly one
pixel, so a half-pixel threshold moves nothing.  This pass replaces it with
perturbations that actually change the mask:

  * uniform CD bias of +/- 20 nm (one pixel of edge movement);
  * hard periodic opening and closing at a 40 nm structuring radius -- the
    E7 morphology operators, which are NOT reachable by a soft CD proxy.

All four are held out: no arm optimized against any of them.  Everything is
scored at (24,6) with the same solver, and the results are merged back into
the shard score files under "robustness".
"""
import argparse
import glob
import hashlib
import json
import os
import sys
import time

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import e10_common as C  # noqa: E402
from trustworthy_fmm.fabrication.process import (  # noqa: E402
    periodic_binary_morphology,
)

CD_BIAS_NM = [-20.0, 20.0]
MORPH_RADIUS_NM = 40.0


def _hash(mask):
    return hashlib.sha256(
        np.ascontiguousarray(mask).astype(np.uint8).tobytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default=os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "..", "data", "main"))
    parser.add_argument("--targets", type=int, nargs="*", default=None)
    args = parser.parse_args()
    out = os.path.abspath(args.out)
    want = None
    if args.targets:
        want = {(args.targets[i], args.targets[i + 1])
                for i in range(0, len(args.targets), 2)}

    runs = {}
    for path in sorted(glob.glob(os.path.join(out, "*runs.json"))):
        for key, value in json.load(open(path)).items():
            if not key.startswith("_"):
                runs[key] = value
    native_path = os.path.join(out, "native.json")
    if os.path.exists(native_path):
        runs.update(json.load(open(native_path)))

    t0 = time.time()
    for score_path in sorted(glob.glob(os.path.join(out, "*scores.json"))):
        scores = json.load(open(score_path))
        cache = scores.setdefault("_cache", {})
        changed = False

        def score(mask, level, target):
            key = "{}|{}|{}".format(_hash(mask), tuple(level), tuple(target))
            if key not in cache:
                cache[key] = C.forward_density(
                    torch.as_tensor(np.asarray(mask), dtype=torch.float64),
                    level, target)
            return cache[key]

        for run_key, entry in scores.items():
            if run_key.startswith("_"):
                continue
            target = tuple(entry["target"])
            if want is not None and target not in want:
                continue
            if "held_out" in entry:
                continue
            mask = np.load(os.path.join(
                out, "designs", runs[run_key]["binary_file"])) > 0.5
            nominal = score(mask.astype(np.float64), C.CHECKPOINT_LEVEL, target)
            held = {"nominal_24_6": nominal}
            for bias in CD_BIAS_NM:
                held["cd_{:+.0f}nm".format(bias)] = score(
                    C.cd_bias_mask(mask, bias), C.CHECKPOINT_LEVEL, target)
            for operation in ("opening", "closing"):
                perturbed = periodic_binary_morphology(
                    mask, operation, MORPH_RADIUS_NM, C.PIXEL_YX)
                held["{}_{:.0f}nm".format(operation, MORPH_RADIUS_NM)] = score(
                    perturbed.astype(np.float64), C.CHECKPOINT_LEVEL, target)
                held["{}_pixel_change".format(operation)] = float(
                    np.mean(perturbed != mask))
            scenario = {k: v for k, v in held.items()
                        if k != "nominal_24_6" and not k.endswith("pixel_change")}
            held["worst_absolute"] = min(scenario.values())
            held["worst_relative"] = min(scenario.values()) / max(nominal, 1e-12)
            held["worst_scenario"] = min(scenario, key=scenario.get)
            entry["held_out"] = held
            changed = True
            print("{:34s} nominal={:.4f} worst={:.4f} ({:.2f}x, {})".format(
                run_key, nominal, held["worst_absolute"],
                held["worst_relative"], held["worst_scenario"]), flush=True)
        if changed:
            json.dump(scores, open(score_path, "w"), indent=1)
    print("held-out audit done in {:.0f}s".format(time.time() - t0))


if __name__ == "__main__":
    main()
