"""E12a: is the fixed-low-order vs conservative-high-order gap real, or seed noise?

Reports the per-target breakdown (the headline table pools all three diffraction
targets), a paired test, an exact permutation test, a bootstrap interval, a
variance decomposition, and the seed count that would be needed to resolve the
observed effect.  No tolerance games: the point is to state honestly how much
this design can and cannot support at n=9.
"""
import glob
import itertools
import json
import math
import statistics as st

sc = {}
for p in glob.glob('data/main/*scores.json'):
    for k, v in json.load(open(p)).items():
        if not k.startswith('_'):
            sc[k] = v


def arm(name):
    return {(tuple(v['target']), v['seed']): v['blind']['28,7']
            for v in sc.values() if v['arm'] == name}


def paired(a, b):
    keys = sorted(set(a) & set(b))
    return keys, [a[k] - b[k] for k in keys]


def perm_p(d):
    """Exact two-sided sign-flip permutation test on the paired differences."""
    obs = abs(sum(d) / len(d))
    hits = tot = 0
    for signs in itertools.product((1, -1), repeat=len(d)):
        tot += 1
        if abs(sum(s * x for s, x in zip(signs, d)) / len(d)) >= obs - 1e-15:
            hits += 1
    return hits / tot


def boot_ci(d, n=20000, seed=12345):
    """Percentile bootstrap on the mean paired difference (deterministic LCG)."""
    s, out, m = seed, [], len(d)
    for _ in range(n):
        acc = 0.0
        for _ in range(m):
            s = (1103515245 * s + 12345) % (2 ** 31)
            acc += d[s % m]
        out.append(acc / m)
    out.sort()
    return out[int(0.025 * n)], out[int(0.975 * n)]


def report(name_a, name_b):
    a, b = arm(name_a), arm(name_b)
    keys, d = paired(a, b)
    print("\n=== %s  minus  %s   (positive = %s better) ===" % (name_a, name_b, name_a))
    print("  per-target breakdown:")
    for t in sorted({k[0] for k in keys}):
        sub = [x for k, x in zip(keys, d) if k[0] == t]
        w = sum(1 for x in sub if x > 0)
        print("    (%+d,%d)  n=%d  wins=%d  median %+.4f  mean %+.4f   [%s]"
              % (t[0], t[1], len(sub), w, st.median(sub), st.mean(sub),
                 " ".join("%+.4f" % x for x in sub)))
    mean, med = st.mean(d), st.median(d)
    sd = st.stdev(d)
    se = sd / math.sqrt(len(d))
    t_stat = mean / se if se else float('nan')
    lo, hi = boot_ci(d)
    print("  pooled n=%d  wins=%d/%d" % (len(d), sum(1 for x in d if x > 0), len(d)))
    print("  mean %+.4f   median %+.4f   sd(diff) %.4f   SE %.4f" % (mean, med, sd, se))
    print("  paired t = %+.2f (df=%d)      exact permutation p = %.4f"
          % (t_stat, len(d) - 1, perm_p(d)))
    print("  bootstrap 95%% CI on the mean: [%+.4f, %+.4f]  -> %s"
          % (lo, hi, "excludes 0" if lo * hi > 0 else "INCLUDES 0 (not resolved)"))
    if abs(mean) > 1e-12:
        need = (2.9 * sd / abs(mean)) ** 2      # ~80% power, two-sided 0.05
        print("  seeds needed for ~80%% power at this effect size: n ~= %d "
              "(we have %d)" % (math.ceil(need), len(d)))
    return d


print("=" * 78)
print("Q: is the E12a gap real, or seed noise?   All arms share physics, design")
print("   map, optimizer and solver; only the Fourier-order policy differs.")
print("=" * 78)

report('torcwa_M12', 'torcwa_M24_wall410')
report('certified', 'torcwa_M24_wall410')
report('torcwa_M12', 'certified')

# --- how big is seed noise compared with the arm effect? ---------------------
print("\n=== variance decomposition (blind eta at (28,7)) ===")
print("%-26s %8s %8s %8s" % ("arm", "mean", "sd", "sd/mean"))
for name in ('torcwa_M12', 'torcwa_M24_wall410', 'certified', 'certified_wall410'):
    v = list(arm(name).values())
    if v:
        print("%-26s %8.4f %8.4f %8.2f" % (name, st.mean(v), st.stdev(v),
                                           st.stdev(v) / st.mean(v)))
print()
for name in ('torcwa_M12', 'torcwa_M24_wall410', 'certified'):
    a = arm(name)
    tm = {t: st.mean([x for k, x in a.items() if k[0] == t])
          for t in sorted({k[0] for k in a})}
    within = st.mean([st.stdev([x for k, x in a.items() if k[0] == t])
                      for t in tm])
    between = st.stdev(list(tm.values()))
    print("%-22s between-target sd %.4f   within-target (seed) sd %.4f   "
          "seed/target %.2f" % (name, between, within, within / between))
