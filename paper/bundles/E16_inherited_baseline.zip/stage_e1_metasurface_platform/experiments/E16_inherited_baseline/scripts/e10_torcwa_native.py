"""E10 supplement: TORCWA run in its own native configuration.

The paired campaign runs every arm on our solver in complex128 on the CPU so
that the *method* is the only difference.  This script answers the separate,
purely implementational question: how fast is the TORCWA Example-6 recipe when
a TORCWA user runs it the way TORCWA is meant to be run -- GPU, complex64?

Physics, design map, Adam, learning-rate and beta schedules are identical to
e10_common.  Only the Maxwell engine, device and dtype change.  The delivered
hard binary is written out and later re-scored by the same complex128
reference as every other arm, so the accuracy cost of complex64 is visible.
"""
import argparse
import json
import os
import sys
import time

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import e10_common as C  # noqa: E402


def torcwa_power(density_yx, level, target, dtype, device):
    import torcwa
    real_dtype = torch.float32 if dtype == torch.complex64 else torch.float64
    eps_xy = C.EPS_BG + (C.EPS_FEAT - C.EPS_BG) * density_yx.transpose(0, 1).to(
        device=device, dtype=real_dtype)
    sim = torcwa.rcwa(freq=1.0 / C.WL, order=[int(level[0]), int(level[1])],
                      L=list(C.LATTICE), dtype=dtype, device=device,
                      stable_eig_grad=True)
    sim.add_input_layer(eps=C.N_IN ** 2)
    sim.add_output_layer(eps=C.N_OUT ** 2)
    sim.set_incident_angle(inc_ang=0.0, azi_ang=0.0)
    sim.add_layer(C.THICK, eps_xy)
    sim.solve_global_smatrix()
    txx = sim.S_parameters(orders=list(target), direction="forward",
                           port="transmission", polarization="xx",
                           ref_order=[0, 0])
    tyx = sim.S_parameters(orders=list(target), direction="forward",
                           port="transmission", polarization="yx",
                           ref_order=[0, 0])
    return torch.sum(torch.abs(txx) ** 2 + torch.abs(tyx) ** 2)


def run_native(target, seed, level, steps, dtype, device, audit_every=6):
    real_dtype = torch.float32 if dtype == torch.complex64 else torch.float64
    rho = C.initial_latent(seed).to(device=device, dtype=real_dtype)
    m = torch.zeros_like(rho)
    v = torch.zeros_like(rho)
    best_bin, best_self = C.hard_binary(rho.double().cpu()), -float("inf")
    if device == "cuda":
        torch.cuda.synchronize()
    t0 = time.perf_counter()
    for step in range(steps):
        progress = step / max(steps - 1, 1)
        beta = C.beta_at(progress)
        lr = C.cosine_lr(progress)
        x = rho.detach().clone().requires_grad_(True)
        j = torcwa_power(C.projected(x, beta), level, target, dtype, device)
        g = torch.autograd.grad(j, x)[0]
        if not bool(torch.isfinite(g).all()):
            raise RuntimeError("non-finite TORCWA gradient at step %d" % step)
        if step % audit_every == 0:
            with torch.no_grad():
                b = C.hard_binary(x.detach().double().cpu())
                s = float(torcwa_power(b.to(device=device, dtype=real_dtype),
                                       level, target, dtype, device))
            if s > best_self:
                best_self, best_bin = s, b
        with torch.no_grad():
            m = C.ADAM_B1 * m + (1 - C.ADAM_B1) * g
            v = C.ADAM_B2 * v + (1 - C.ADAM_B2) * g.square()
            mh = m / (1 - C.ADAM_B1 ** (step + 1))
            vh = v / (1 - C.ADAM_B2 ** (step + 1))
            rho = ((x + lr * mh / (vh.sqrt() + C.ADAM_EPS)).clamp(0, 1))
            rho = 0.5 * (rho + torch.flip(rho, dims=(0,)))
    if device == "cuda":
        torch.cuda.synchronize()
    wall = time.perf_counter() - t0
    return best_bin.double().cpu(), best_self, wall


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--steps", type=int, required=True)
    parser.add_argument("--level", type=int, nargs=2, default=[12, 3])
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--dtype", default="complex64")
    parser.add_argument("--tag", default="torcwa_native_gpu_M12")
    parser.add_argument("--out", default=os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "..", "data", "main"))
    args = parser.parse_args()
    out = os.path.abspath(args.out)
    os.makedirs(os.path.join(out, "designs"), exist_ok=True)
    dtype = {"complex64": torch.complex64,
             "complex128": torch.complex128}[args.dtype]
    path = os.path.join(out, "native.json")
    store = json.load(open(path)) if os.path.exists(path) else {}
    for target in C.TARGETS:
        for seed in C.SEEDS:
            key = "{}|{}|{}".format(tuple(target), seed, args.tag)
            if key in store:
                continue
            mask, self_score, wall = run_native(
                target, seed, tuple(args.level), args.steps, dtype, args.device)
            stem = "{}_{}_{}_{}".format(target[0], target[1], seed, args.tag)
            np.save(os.path.join(out, "designs", stem + "_binary.npy"),
                    mask.numpy())
            store[key] = {
                "target": list(target), "seed": seed, "tag": args.tag,
                "level": list(args.level), "steps": args.steps,
                "device": args.device, "dtype": args.dtype,
                "wall_s": wall, "self_reported_binary": self_score,
                "binary_file": stem + "_binary.npy",
            }
            json.dump(store, open(path, "w"), indent=1)
            print("{:34s} wall={:6.2f}s self={:.4f}".format(key, wall,
                                                            self_score),
                  flush=True)
    print("native runs:", len(store), "->", path)


if __name__ == "__main__":
    main()
