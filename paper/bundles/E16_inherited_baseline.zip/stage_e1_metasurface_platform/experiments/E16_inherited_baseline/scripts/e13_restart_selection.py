"""Where does selection actually cost you: inside a run, or ACROSS restarts?

Inside one run the candidate pool is flat near the top, so the selection rule
barely moves the delivered design (measured: E12A_ANALYSIS section on rule A/B/C).
But practitioners take their max somewhere else -- over RESTARTS.  Across seeds
the spread is enormous (0.07 to 0.49), so a wrong pick there is not a reporting
error, it ships a materially worse device.
"""
import glob, itertools, json, random, statistics as st

sc = {}
for p in glob.glob('data/main/*scores.json'):
    for k, v in json.load(open(p)).items():
        if not k.startswith('_'):
            sc[k] = v

ARMS = ['torcwa_M12', 'torcwa_M16', 'torcwa_M24_wall410', 'certified',
        'certified_screened', 'certified_wall410']


def runs_of(arm):
    return [(v['self_reported_binary'], v['blind']['24,6'], v['blind']['28,7'])
            for v in sc.values() if v['arm'] == arm]


print("=" * 96)
print("SPREAD across restarts vs inside a run")
print("=" * 96)
pool = json.load(open('data/lower_bound_selection.json'))
inside = [max(d['eT'] for d in r['pool']) - st.median([d['eT'] for d in r['pool']])
          for r in pool]
print("  inside one run : median(best - median of pool) = %+.4f  (pool of ~38 checkpoints)"
      % st.median(inside))
for arm in ARMS:
    r = runs_of(arm)
    t = [x[2] for x in r]
    print("  across restarts: %-22s best %.4f  median %.4f  worst %.4f   best-median %+.4f"
          % (arm, max(t), st.median(t), min(t), max(t) - st.median(t)))

print()
print("=" * 96)
print("BEST-OF-k RESTARTS: pick by the arm's own cheap self-report, vs by an honest")
print("reference evaluation.  Reported value = what you would publish; true value =")
print("what you actually shipped, scored blind at (28,7).")
print("=" * 96)

rng = random.Random(20260831)
TRIALS = 40000
for arm in ARMS:
    r = runs_of(arm)
    if len(r) < 3:
        continue
    print("\n  %s  (n=%d restarts available)" % (arm, len(r)))
    print("    %-3s %11s %11s %11s %11s" % ("k", "pick-cheap", "pick-honest", "oracle", "cheap regret"))
    for k in (2, 3, 5, 9):
        if k > len(r):
            continue
        cheap_true, honest_true, oracle_true, cheap_report = [], [], [], []
        for _ in range(TRIALS):
            s = rng.sample(r, k)
            a = max(s, key=lambda x: x[0])       # select on self-report (cheap)
            b = max(s, key=lambda x: x[1])       # select on honest (24,6) audit
            cheap_true.append(a[2]); cheap_report.append(a[0])
            honest_true.append(b[2])
            oracle_true.append(max(x[2] for x in s))
        ct, ht, ot = st.mean(cheap_true), st.mean(honest_true), st.mean(oracle_true)
        print("    %-3d %11.4f %11.4f %11.4f %11.4f" % (k, ct, ht, ot, ot - ct))
    # reporting inflation of the best-of-9 pick
    a = max(r, key=lambda x: x[0])
    print("    best-of-%d by self-report: you publish %.4f, you shipped %.4f  (%+.1f%%)"
          % (len(r), a[0], a[2], 100 * (a[0] - a[2]) / a[2]))

print()
print("=" * 96)
print("PAIRED TEST: does picking restarts by the cheap self-report lose real")
print("performance compared with picking by an honest audit?  (all arms, k=3)")
print("=" * 96)


def perm_p(d):
    obs = abs(st.mean(d)); hits = tot = 0
    for s in itertools.product((1, -1), repeat=len(d)):
        tot += 1
        if abs(sum(x * y for x, y in zip(s, d)) / len(d)) >= obs - 1e-15:
            hits += 1
    return hits / tot


for k in (3, 5):
    diffs = []
    rng2 = random.Random(777)
    for arm in ARMS:
        r = runs_of(arm)
        if len(r) < k:
            continue
        c, h = [], []
        for _ in range(20000):
            s = rng2.sample(r, k)
            c.append(max(s, key=lambda x: x[0])[2])
            h.append(max(s, key=lambda x: x[1])[2])
        diffs.append(st.mean(h) - st.mean(c))
    print("  k=%d  per-arm (honest - cheap) delivered truth: %s"
          % (k, " ".join("%+.4f" % d for d in diffs)))
    print("       mean %+.4f over %d arms   exact permutation p = %.4f  -> %s"
          % (st.mean(diffs), len(diffs), perm_p(diffs),
             "SIGNIFICANT" if perm_p(diffs) < 0.05 else "not resolved"))
