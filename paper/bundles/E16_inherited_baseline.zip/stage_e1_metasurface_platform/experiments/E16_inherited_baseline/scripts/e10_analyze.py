"""E10 analysis: paired tables, statistics and the head-to-head verdict."""
import argparse
import json
import os
import statistics
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import e10_common as C  # noqa: E402

ARM_ORDER = ["torcwa_M12", "torcwa_M16", "torcwa_M24", "torcwa_M24_wall410",
             "certified", "certified_screened", "certified_wall410",
             "torcwa_native_gpu_M12"]
# the native arm changes engine, device and dtype at once, so it is
# reported but never entered into the paired method comparison.
PAIRED_ARMS = ["torcwa_M12", "torcwa_M16", "torcwa_M24", "torcwa_M24_wall410",
               "certified", "certified_screened", "certified_wall410"]
ARM_LABEL = {
    "torcwa_M12": "TORCWA recipe @ (12,3)",
    "torcwa_M16": "TORCWA recipe @ (16,4)",
    "torcwa_M24": "conservative fixed @ (24,6)",
    "torcwa_M24_wall410": "conservative fixed @ (24,6), equal wall 410 s",
    "certified": "ours (certified, gated)",
    "certified_screened": "ours + dense cheap screen",
    "certified_wall410": "ours (equal wall clock 410 s)",
    "torcwa_native_gpu_M12": "TORCWA native GPU/c64 @ (12,3)",
}


def load(out):
    import glob
    merged = {}
    for path in sorted(glob.glob(os.path.join(out, "*scores.json"))):
        for key, value in json.load(open(path)).items():
            if not key.startswith("_"):
                merged[key] = value
    return merged


def _counts(rows):
    out = {}
    for r in rows:
        key = worst_scenario(r)
        out[key] = out.get(key, 0) + 1
    return out


def worst(entry):
    """Held-out worst-case relative efficiency of the delivered binary."""
    block = entry.get("held_out") or entry["robustness"]
    return block["worst_relative"]


def worst_scenario(entry):
    block = entry.get("held_out")
    return block["worst_scenario"] if block else "cd_only"


def oracle(entry):
    """Best of {trajectory checkpoints, delivered design} chosen by blind
    (24,6).  A real user cannot do this; it bounds how much of a gap is
    selection rather than trajectory."""
    block = entry.get("oracle_selection") or {}
    cand_24 = block.get("eta_24_6", -1e18)
    if entry["blind"]["24,6"] >= cand_24:
        return entry["blind"]["28,7"]
    return block.get("eta_28_7", entry["blind"]["28,7"])


def by_arm(scores, arm):
    return {(tuple(v["target"]), v["seed"]): v
            for v in scores.values() if v["arm"] == arm}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default=os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "..", "data", "main"))
    args = parser.parse_args()
    out = os.path.abspath(args.out)
    scores = load(out)
    arms = [a for a in ARM_ORDER if any(v["arm"] == a for v in scores.values())]
    analysis = {"per_arm": {}, "paired": {}, "per_run": []}

    for arm in arms:
        rows = list(by_arm(scores, arm).values())
        eta = [r["blind"]["28,7"] for r in rows]
        analysis["per_arm"][arm] = {
            "n": len(rows),
            "eta_28_7_median": statistics.median(eta),
            "eta_28_7_mean": statistics.mean(eta),
            "eta_28_7_max": max(eta),
            "eta_28_7_min": min(eta),
            "wall_s_median": statistics.median([r["wall_s"] for r in rows]),
            "units_median": statistics.median([r["units"] for r in rows]),
            "self_report_inflation_median": statistics.median(
                [r["self_report_inflation"] for r in rows]),
            "reference_drift_median": statistics.median(
                [r["reference_drift"] for r in rows]),
            "worst_cd_relative_median": statistics.median(
                [worst(r) for r in rows]),
            "fill_fraction_median": statistics.median(
                [r["fill_fraction"] for r in rows]),
            "oracle_eta_28_7_median": statistics.median(
                [oracle(r) for r in rows]),
            "selection_loss_median": statistics.median(
                [oracle(r) - r["blind"]["28,7"] for r in rows]),
            "worst_scenario_counts": _counts(rows),
        }

    paired = [a for a in PAIRED_ARMS if a in arms]
    for i, a in enumerate(paired):
        for b in paired[i + 1:]:
            ra, rb = by_arm(scores, a), by_arm(scores, b)
            keys = sorted(set(ra) & set(rb))
            diff = [ra[k]["blind"]["28,7"] - rb[k]["blind"]["28,7"] for k in keys]
            analysis["paired"]["{}_vs_{}".format(a, b)] = {
                "n": len(keys),
                "wins": sum(1 for d in diff if d > 0),
                "losses": sum(1 for d in diff if d < 0),
                "median_delta_eta": statistics.median(diff) if diff else None,
                "mean_delta_eta": statistics.mean(diff) if diff else None,
            }

    for key in sorted(scores):
        v = scores[key]
        analysis["per_run"].append({
            "target": v["target"], "seed": v["seed"], "arm": v["arm"],
            "eta_28_7": v["blind"]["28,7"], "eta_24_6": v["blind"]["24,6"],
            "self_reported": v["self_reported_binary"],
            "inflation": v["self_report_inflation"],
            "drift": v["reference_drift"],
            "worst_cd": worst(v),
            "oracle_28_7": oracle(v),
            "worst_scenario": worst_scenario(v),
            "wall_s": v["wall_s"], "units": v["units"],
            "fill": v["fill_fraction"],
        })

    json.dump(analysis, open(os.path.join(out, "analysis.json"), "w"), indent=1)

    print("\n=== per-arm summary (blind eta at (28,7), n={}) ===".format(
        analysis["per_arm"][arms[0]]["n"]))
    head = "{:24s} {:>8s} {:>8s} {:>8s} {:>9s} {:>10s} {:>9s} {:>9s}"
    print(head.format("arm", "median", "mean", "max", "wall[s]",
                      "inflation", "drift", "worstCD"))
    for arm in arms:
        s = analysis["per_arm"][arm]
        print("{:24s} {:8.4f} {:8.4f} {:8.4f} {:9.1f} {:+9.1%} {:9.1%} "
              "{:9.2f}".format(
                  ARM_LABEL[arm], s["eta_28_7_median"], s["eta_28_7_mean"],
                  s["eta_28_7_max"], s["wall_s_median"],
                  s["self_report_inflation_median"],
                  s["reference_drift_median"],
                  s["worst_cd_relative_median"]))

    print("\n=== paired comparisons (positive = first arm better) ===")
    for name, p in analysis["paired"].items():
        print("{:34s} n={} wins/losses={}/{} median delta eta={:+.4f}".format(
            name, p["n"], p["wins"], p["losses"], p["median_delta_eta"]))

    print("\n=== per run ===")
    print("{:8s} {:6s} {:24s} {:>9s} {:>9s} {:>10s} {:>9s} {:>8s}".format(
        "target", "seed", "arm", "eta(28,7)", "eta(24,6)", "self", "wall[s]",
        "worstCD"))
    for r in analysis["per_run"]:
        print("{:8s} {:<6d} {:24s} {:9.4f} {:9.4f} {:10.4f} {:9.1f} "
              "{:8.2f}".format(
                  "({:+d},{:+d})".format(*r["target"]), r["seed"],
                  ARM_LABEL[r["arm"]], r["eta_28_7"], r["eta_24_6"],
                  r["self_reported"], r["wall_s"], r["worst_cd"]))
    print("\nwritten:", os.path.join(out, "analysis.json"))


if __name__ == "__main__":
    main()
