"""E10 supplement: split the native arm's self-report error into two causes.

The TORCWA native arm evaluates its delivered binary at (12,3) in complex64 on
the GPU.  Its reported number can be wrong for two independent reasons: the
truncation is too low, and the arithmetic is single precision.  Scoring the
same delivered mask three ways separates them:

    self  = (12,3), complex64, GPU      <- what the arm reported
    a     = (12,3), complex128, CPU     <- same truncation, exact arithmetic
    truth = (28,7), complex128, CPU     <- blind reference

    self - a      : precision component
    a    - truth  : truncation component
"""
import argparse
import json
import os
import sys

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import e10_common as C  # noqa: E402


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default=os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "..", "data", "main"))
    args = parser.parse_args()
    out = os.path.abspath(args.out)
    native = json.load(open(os.path.join(out, "native.json")))
    scores = {}
    import glob
    for path in sorted(glob.glob(os.path.join(out, "*scores.json"))):
        for key, value in json.load(open(path)).items():
            if not key.startswith("_"):
                scores[key] = value

    rows = []
    for key in sorted(native):
        record = native[key]
        target = tuple(record["target"])
        mask = torch.as_tensor(
            np.load(os.path.join(out, "designs", record["binary_file"])),
            dtype=torch.float64)
        low_exact = C.forward_density(mask, tuple(record["level"]), target)
        truth = scores[key]["blind"]["28,7"] if key in scores else float("nan")
        self_report = record["self_reported_binary"]
        rows.append({
            "key": key, "target": list(target), "seed": record["seed"],
            "self_c64_low": self_report,
            "exact_c128_low": low_exact,
            "blind_c128_high": truth,
            "precision_component": self_report - low_exact,
            "truncation_component": low_exact - truth,
            "total_error": self_report - truth,
        })
        print("{:38s} self(c64,{},{})={:.4f}  exact(c128,same)={:.4f}  "
              "blind(28,7)={:.4f}  | precision {:+.4f}  truncation {:+.4f}"
              .format(key, record["level"][0], record["level"][1],
                      self_report, low_exact, truth,
                      rows[-1]["precision_component"],
                      rows[-1]["truncation_component"]), flush=True)

    finite = [r for r in rows if np.isfinite(r["blind_c128_high"])]
    summary = {
        "rows": rows,
        "median_precision_component": float(np.median(
            [r["precision_component"] for r in rows])),
        "median_truncation_component": float(np.median(
            [r["truncation_component"] for r in finite])) if finite else None,
        "median_total_error": float(np.median(
            [r["total_error"] for r in finite])) if finite else None,
    }
    path = os.path.join(out, "precision_decomposition.json")
    json.dump(summary, open(path, "w"), indent=1)
    print("\nmedian precision component  {:+.4f}".format(
        summary["median_precision_component"]))
    print("median truncation component {:+.4f}".format(
        summary["median_truncation_component"]))
    print("written", path)


if __name__ == "__main__":
    main()
