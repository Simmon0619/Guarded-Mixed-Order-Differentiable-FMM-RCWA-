"""P0: bitwise gradient parity between the pre-refactor and post-refactor paths.

The bitwise baseline covers forward values and the design map but NOT
value_grad_latent, which is the function the arms call most and whose path
(_eps, projected, tanh_projection) the refactor actually touched.  Here the
PRE-refactor implementations are inlined verbatim and compared against the
current module, bitwise, on values AND gradients.
"""
import hashlib
import sys

import numpy as np
import torch

import e10_common as C
from trustworthy_fmm.fabrication.process import periodic_gaussian_filter, tanh_projection
from trustworthy_fmm.solvers.vector_2d import solve_multilayer_vector_2d


def h(t):
    a = t.detach().cpu().numpy()
    return hashlib.sha256(np.ascontiguousarray(a).tobytes()).hexdigest()[:32]


# ---- verbatim pre-refactor implementations (module constants still exported)
def old_symmetrize(rho):
    return 0.5 * (rho + torch.flip(rho, dims=(0,)))


def old_filtered(rho):
    return old_symmetrize(
        periodic_gaussian_filter(old_symmetrize(rho), C.LATTICE, C.FILTER_NM))


def old_projected(rho, beta):
    return tanh_projection(old_filtered(rho), float(beta))      # eta defaulted


def old_eps(density):
    return (C.EPS_BG + (C.EPS_FEAT - C.EPS_BG) * density).to(C.DT)


def old_value_grad_latent(rho, level, target, beta):
    x = rho.detach().clone().requires_grad_(True)
    r = solve_multilayer_vector_2d(
        [old_eps(old_projected(x, beta))], [C.THICK], C.WL, C.LATTICE,
        C.N_IN, C.N_OUT, tuple(level), incident_jones=(1.0, 0.0),
    )
    j = r.power_t[r.orders.index(tuple(target))]
    j.backward()
    return float(j.detach()), x.grad.detach().clone()


def old_forward_latent(rho, level, target, beta):
    with torch.no_grad():
        d = old_projected(rho, beta)
        r = solve_multilayer_vector_2d(
            [old_eps(d)], [C.THICK], C.WL, C.LATTICE, C.N_IN, C.N_OUT,
            tuple(level), incident_jones=(1.0, 0.0))
        return float(r.power_t[r.orders.index(tuple(target))])


LEVELS = [(12, 3), (16, 4)]
BETAS = [1.0, 8.0, 64.0]
fails = []
checks = 0

for seed in C.SEEDS:
    rho = C.initial_latent(seed)
    rho_old = old_symmetrize(
        (0.5 + 0.08 * (lambda s: s / s.std())(
            periodic_gaussian_filter(
                torch.randn((C.NY, C.NX),
                            generator=torch.Generator().manual_seed(int(seed)),
                            dtype=torch.float64),
                C.LATTICE, C.FILTER_NM))).clamp(0.05, 0.95))
    if h(rho) != h(rho_old):
        fails.append("initial_latent seed %d" % seed)
    for beta in BETAS:
        a, b = C.projected(rho, beta), old_projected(rho, beta)
        checks += 1
        if h(a) != h(b):
            fails.append("projected seed=%d beta=%g" % (seed, beta))
        for level in LEVELS:
            for target in C.TARGETS[:2]:
                vn, gn = C.value_grad_latent(rho, level, target, beta)
                vo, go = old_value_grad_latent(rho, level, target, beta)
                checks += 1
                tag = "seed=%d beta=%g lvl=%s tgt=%s" % (seed, beta, level, target)
                if vn.hex() != vo.hex():
                    fails.append("value %s: %s vs %s" % (tag, vn.hex(), vo.hex()))
                if h(gn) != h(go):
                    fails.append("GRADIENT %s" % tag)
                fn = C.forward_latent(rho, level, target, beta)
                fo = old_forward_latent(rho, level, target, beta)
                checks += 1
                if fn.hex() != fo.hex():
                    fails.append("forward_latent %s" % tag)
        print("  seed %d beta %g done" % (seed, beta), flush=True)

print()
if fails:
    print("FAIL -- %d mismatches out of %d checks:" % (len(fails), checks))
    for f in fails[:40]:
        print("  " + f)
    sys.exit(1)
print("PASS -- %d checks bitwise identical (values, GRADIENTS, forward_latent, "
      "projected, initial_latent) across %d seeds x %d betas x %d levels x 2 targets"
      % (checks, len(C.SEEDS), len(BETAS), len(LEVELS)))
