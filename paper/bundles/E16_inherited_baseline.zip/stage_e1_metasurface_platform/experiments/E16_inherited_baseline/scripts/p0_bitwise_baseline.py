"""P0 bitwise regression harness for the ProblemConfig refactor.

Captures a fingerprint of everything the refactor could silently perturb, using
exact representations only: sha256 over raw tensor bytes for arrays, and
float.hex() for scalars.  Nothing here uses a tolerance -- the acceptance
criterion for P0 is bitwise identity, so a tolerance would defeat the purpose.

    python p0_bitwise_baseline.py --write   # before the refactor
    python p0_bitwise_baseline.py --check   # after the refactor

IMPORTANT: bitwise identity is only well defined at a FIXED BLAS thread count.
Changing OMP_NUM_THREADS reorders reductions inside the eigensolve and moves the
last few ulps -- measured here as ~1e-12 relative drift on eta between 3 and 6
threads, which is enough to fail a bitwise check for reasons that have nothing
to do with the code under test.  The harness therefore pins the thread count
itself and records it in the fingerprint, refusing to compare across counts.
"""
import argparse
import glob
import hashlib
import json
import os
import sys

import numpy as np
import torch

# Pinned before any solve: reduction order, hence the last ulps, depends on it.
THREADS = int(os.environ.get("P0_THREADS", "3"))
torch.set_num_threads(THREADS)

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import e10_common as C

OUT = os.path.join(C._HERE, "..", "data", "p0_bitwise_baseline.json")

# Solver levels: (12,3) on every delivered design is cheap and is the level the
# arms actually optimise at; the higher levels are sampled because they cost
# ~4x and ~12x more and add little extra coverage of the design map.
LEVEL_ALL = (12, 3)
LEVEL_SAMPLED = [(16, 4), (24, 6)]
N_SAMPLED = 6


def h(tensor):
    """sha256 over the exact bytes of a tensor/array -- no rounding."""
    a = tensor.detach().cpu().numpy() if isinstance(tensor, torch.Tensor) else np.asarray(tensor)
    return hashlib.sha256(np.ascontiguousarray(a).tobytes()).hexdigest()[:32]


def fx(value):
    """Exact, round-trippable scalar representation."""
    return float(value).hex()


def collect():
    fp = {"environment": {"threads": THREADS, "torch": torch.__version__,
                          "numpy": np.__version__}}

    # --- frozen scalars -----------------------------------------------------
    fp["constants"] = {
        "WL": fx(C.WL),
        "LATTICE": [fx(v) for v in C.LATTICE],
        "NY": C.NY, "NX": C.NX,
        "THICK": fx(C.THICK),
        "N_IN": fx(C.N_IN), "N_OUT": fx(C.N_OUT),
        "EPS_BG": fx(C.EPS_BG), "EPS_FEAT": fx(C.EPS_FEAT),
        "PIXEL_YX": [fx(v) for v in C.PIXEL_YX],
        "FILTER_NM": fx(C.FILTER_NM),
        "THRESHOLD": fx(C.THRESHOLD),
        "BETA_LADDER": [fx(v) for v in C.BETA_LADDER],
        "LEVELS": {k: list(v) for k, v in C.LEVELS.items()},
        "SCORE_LEVELS": [list(v) for v in C.SCORE_LEVELS],
        "CHECKPOINT_LEVEL": list(C.CHECKPOINT_LEVEL),
        "TARGETS": [list(t) for t in C.TARGETS],
        "SEEDS": list(C.SEEDS),
        "BUDGET_UNITS": fx(C.BUDGET_UNITS),
        "ADAM_LR0": fx(C.ADAM_LR0),
        "ADAM_B1": fx(C.ADAM_B1), "ADAM_B2": fx(C.ADAM_B2), "ADAM_EPS": fx(C.ADAM_EPS),
        "DT": str(C.DT),
    }

    # --- cost model ---------------------------------------------------------
    levels = sorted({tuple(v) for v in C.LEVELS.values()} |
                    {tuple(v) for v in C.SCORE_LEVELS} | {(8, 2), (20, 5), (28, 7)})
    fp["cost"] = {"%d,%d" % lv: {"n_terms": C.n_terms(lv),
                                 "fwd": fx(C.cost_fwd(lv)),
                                 "bwd": fx(C.cost_bwd(lv))} for lv in levels}

    # --- design map: the highest-risk, cheapest surface ----------------------
    dm = {}
    for seed in C.SEEDS:
        rho = C.initial_latent(seed)
        entry = {"initial_latent": h(rho), "filtered": h(C.filtered(rho)),
                 "symmetrize": h(C.symmetrize(rho)), "hard_binary": h(C.hard_binary(rho))}
        for beta in C.BETA_LADDER:
            entry["projected_beta_%g" % beta] = h(C.projected(rho, beta))
        # beta_at / cosine_lr are pure functions of progress; sample the schedule
        entry["beta_at"] = [fx(C.beta_at(p / 8.0)) for p in range(9)]
        entry["cosine_lr"] = [fx(C.cosine_lr(p / 8.0)) for p in range(9)]
        dm["seed_%d" % seed] = entry
    fp["design_map"] = dm

    # --- Adam: verify the update rule is untouched --------------------------
    torch.manual_seed(0)
    rho = C.initial_latent(C.SEEDS[0])
    opt = C.Adam(rho.shape)
    g = torch.randn(rho.shape, generator=torch.Generator().manual_seed(7), dtype=torch.float64)
    trace = []
    for i in range(5):
        rho = opt.step(rho, g, C.cosine_lr(i / 4.0))
        trace.append(h(rho))
    fp["adam_trace"] = trace

    # --- perturbation operators --------------------------------------------
    mask = C.hard_binary(C.initial_latent(C.SEEDS[0])).numpy().astype(bool)
    fp["cd_bias"] = {"%+d" % b: h(C.cd_bias_mask(mask, b)) for b in (-20, -10, 0, 10, 20)}

    # --- solver values on the delivered designs -----------------------------
    scores = {}
    for p in sorted(glob.glob(os.path.join(C._HERE, "..", "data", "main", "*scores.json"))):
        for k, v in json.load(open(p)).items():
            if not k.startswith("_"):
                scores[k] = v
    designs = []
    for k, v in sorted(scores.items()):
        t, seed, arm = tuple(v["target"]), v["seed"], v["arm"]
        f = os.path.join(C._HERE, "..", "data", "main", "designs",
                         "%d_%d_%d_%s_binary.npy" % (t[0], t[1], seed, arm))
        if os.path.exists(f):
            designs.append((k, t, f))

    sol = {}
    for i, (key, target, f) in enumerate(designs):
        d = torch.tensor(np.load(f), dtype=torch.float64)
        rec = {"design_sha": h(d), "eta_12_3": fx(C.forward_density(d, LEVEL_ALL, target))}
        if i % max(len(designs) // N_SAMPLED, 1) == 0:
            for lv in LEVEL_SAMPLED:
                rec["eta_%d_%d" % lv] = fx(C.forward_density(d, lv, target))
        sol[key] = rec
        print("  %3d/%d  %s" % (i + 1, len(designs), key), flush=True)
    fp["solver"] = sol
    return fp


def diff(old, new, path=""):
    out = []
    if isinstance(old, dict) and isinstance(new, dict):
        for k in sorted(set(old) | set(new)):
            if k not in old:
                out.append("%s/%s: ADDED" % (path, k))
            elif k not in new:
                out.append("%s/%s: REMOVED" % (path, k))
            else:
                out += diff(old[k], new[k], "%s/%s" % (path, k))
    elif isinstance(old, list) and isinstance(new, list):
        if len(old) != len(new):
            out.append("%s: length %d -> %d" % (path, len(old), len(new)))
        else:
            for i, (a, b) in enumerate(zip(old, new)):
                out += diff(a, b, "%s[%d]" % (path, i))
    elif old != new:
        out.append("%s: %r -> %r" % (path, old, new))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--write", action="store_true")
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    if not (a.write or a.check):
        ap.error("pass --write (before refactor) or --check (after)")
    fp = collect()
    if a.write:
        json.dump(fp, open(OUT, "w"), indent=1, sort_keys=True)
        print("\nbaseline written: %s" % OUT)
        print("entries: %d solver, %d design-map seeds" % (len(fp["solver"]), len(fp["design_map"])))
        return
    ref = json.load(open(OUT))
    ref_env, new_env = ref.get("environment", {}), fp["environment"]
    if ref_env.get("threads") != new_env["threads"]:
        print("REFUSING to compare: baseline was captured with %s threads, this "
              "run uses %s.  Bitwise identity is undefined across thread counts "
              "(reduction order changes).  Re-run with P0_THREADS=%s."
              % (ref_env.get("threads"), new_env["threads"], ref_env.get("threads")))
        sys.exit(2)
    if ref_env.get("torch") != new_env["torch"] or ref_env.get("numpy") != new_env["numpy"]:
        print("WARNING: library versions differ from the baseline (%s / %s vs %s / %s); "
              "a bitwise difference below may be environmental rather than a regression."
              % (ref_env.get("torch"), ref_env.get("numpy"), new_env["torch"], new_env["numpy"]))
    d = diff(ref, fp)
    if not d:
        print("\nPASS -- bitwise identical across %d solver entries, design map, "
              "cost model, Adam trace and perturbation operators." % len(fp["solver"]))
        return
    print("\nFAIL -- %d differences:" % len(d))
    for line in d[:60]:
        print("  " + line)
    if len(d) > 60:
        print("  ... and %d more" % (len(d) - 60))
    sys.exit(1)


if __name__ == "__main__":
    main()
