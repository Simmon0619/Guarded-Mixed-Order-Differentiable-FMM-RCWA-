"""E10 figures: delivered hard-binary patterns, honesty gap, anytime curves."""
import argparse
import json
import os
import statistics
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import e10_common as C  # noqa: E402

ARM_ORDER = ["torcwa_M12", "torcwa_M16", "certified", "certified_screened"]
ALL_ARMS = ARM_ORDER + ["torcwa_native_gpu_M12"]
ARM_LABEL = {
    "torcwa_M12": "TORCWA recipe\nfixed (12,3)",
    "torcwa_M16": "TORCWA recipe\nfixed (16,4)",
    "certified": "ours\ncertified + $\\beta$-gated",
    "certified_screened": "ours + dense\ncheap screening",
    "certified_wall410": "ours\nequal wall clock",
}
ARM_COLOR = {"torcwa_M12": "#E57A2E", "torcwa_M16": "#B4531A",
             "certified": "#2457C5", "certified_screened": "#12A594",
             "certified_wall410": "#7B61C9",
             "torcwa_native_gpu_M12": "#8C8C8C"}
ARM_LABEL["torcwa_native_gpu_M12"] = "TORCWA native\nGPU / complex64"
SHORT_LABEL = {
    "torcwa_M12": "TORCWA\n(12,3)",
    "torcwa_M16": "TORCWA\n(16,4)",
    "certified": "ours\ncertified",
    "certified_screened": "ours\n+ screening",
    "certified_wall410": "ours\nequal wall",
    "torcwa_native_gpu_M12": "TORCWA\nGPU c64",
}


def save(fig, stem):
    for suffix in ("png", "pdf", "svg"):
        fig.savefig(stem + "." + suffix,
                    dpi=300 if suffix == "png" else None, bbox_inches="tight")
    plt.close(fig)
    return stem + ".png"


def figure_patterns(scores, runs, out, figdir):
    """Best delivered design per (target, arm), scored blind at (28,7)."""
    targets = sorted({tuple(v["target"]) for v in scores.values()})
    arms = [a for a in ARM_ORDER if any(v["arm"] == a for v in scores.values())]
    fig, axes = plt.subplots(len(targets), len(arms),
                             figsize=(3.05 * len(arms), 1.42 * len(targets) + 1.1),
                             squeeze=False)
    extent = (0.0, C.LATTICE[0] / 1000, 0.0, C.LATTICE[1] / 1000)
    for r, target in enumerate(targets):
        for c, arm in enumerate(arms):
            cand = [v for k, v in scores.items()
                    if tuple(v["target"]) == target and v["arm"] == arm]
            best = max(cand, key=lambda v: v["blind"]["28,7"])
            key = "{}|{}|{}".format(target, best["seed"], arm)
            mask = np.load(os.path.join(out, "designs",
                                        runs[key]["binary_file"]))
            ax = axes[r][c]
            ax.imshow(mask, origin="lower", extent=extent, vmin=0, vmax=1,
                      cmap="gray", interpolation="nearest", aspect="equal")
            ax.set_title(
                "$\\eta$={:.3f}   (self {:.3f})".format(
                    best["blind"]["28,7"], best["self_reported_binary"]),
                fontsize=8.5,
                color="#1a1a1a" if arm.startswith("certified") else "#7a2d00")
            ax.set_xticks([0, 1, 2])
            if r == len(targets) - 1:
                ax.set_xlabel("x [µm]", fontsize=8)
            else:
                ax.tick_params(labelbottom=False)
            if c == 0:
                ax.set_ylabel("({:+d},{:+d})\ny [µm]".format(*target),
                              fontsize=9)
            else:
                ax.tick_params(labelleft=False)
            ax.tick_params(labelsize=7)
    for c, arm in enumerate(arms):
        axes[0][c].text(0.5, 1.42, ARM_LABEL[arm], transform=axes[0][c].transAxes,
                        ha="center", va="bottom", fontsize=10,
                        color=ARM_COLOR[arm])
    fig.suptitle("Delivered hard-binary masks (white = n=3.2), best of 3 seeds\n"
                 "$\\eta$ = blind transmitted efficiency of the target order at "
                 "(28,7); 'self' = what the arm believed it delivered",
                 fontsize=10.5, y=1.16)
    fig.subplots_adjust(hspace=0.42, wspace=0.10)
    return save(fig, os.path.join(figdir, "E10_delivered_patterns"))


def figure_honesty(scores, figdir):
    targets = sorted({tuple(v["target"]) for v in scores.values()})
    arms = [a for a in ARM_ORDER if any(v["arm"] == a for v in scores.values())]
    fig, axes = plt.subplots(1, 2, figsize=(11.2, 4.0))
    width = 0.78 / max(len(arms), 1)
    x = np.arange(len(targets))
    ax = axes[0]
    for i, arm in enumerate(arms):
        med = [statistics.median([v["blind"]["28,7"] for v in scores.values()
                                  if tuple(v["target"]) == t and v["arm"] == arm])
               for t in targets]
        top = [max([v["blind"]["28,7"] for v in scores.values()
                    if tuple(v["target"]) == t and v["arm"] == arm])
               for t in targets]
        offset = (i - (len(arms) - 1) / 2) * width
        ax.bar(x + offset, med, width, color=ARM_COLOR[arm],
               label=ARM_LABEL[arm].replace("\n", " "))
        ax.scatter(x + offset, top, s=16, color="k", zorder=3, marker="_")
    ax.set_xticks(x, ["({:+d},{:+d})".format(*t) for t in targets])
    ax.set_ylabel("blind $\\eta$ at (28,7)")
    ax.set_title("True delivered efficiency\n(bar = median of 3 seeds, "
                 "dash = best seed)", fontsize=10)
    ax.grid(axis="y", alpha=0.25)
    ax.legend(fontsize=8)

    ax = axes[1]
    for i, arm in enumerate(arms):
        vals = [v["self_report_inflation"] for v in scores.values()
                if v["arm"] == arm]
        ax.scatter([i + 0.12 * (j % 3 - 1) for j in range(len(vals))], vals,
                   color=ARM_COLOR[arm], s=34, alpha=0.85, edgecolor="w",
                   linewidth=0.6)
        ax.plot([i - 0.22, i + 0.22], [statistics.median(vals)] * 2,
                color="k", lw=2)
    ax.axhline(0.0, color="#444", lw=1, ls="--")
    ax.set_xticks(range(len(arms)), [SHORT_LABEL[a] for a in arms], fontsize=8)
    ax.set_ylabel("(self-reported $-$ blind) / blind")
    ax.set_title("Self-report inflation of the delivered binary\n"
                 "(0 = the arm reported what it actually delivered)",
                 fontsize=10)
    ax.grid(axis="y", alpha=0.25)
    fig.subplots_adjust(wspace=0.28)
    return save(fig, os.path.join(figdir, "E10_efficiency_and_honesty"))


def figure_anytime(scores, figdir):
    targets = sorted({tuple(v["target"]) for v in scores.values()})
    arms = [a for a in ARM_ORDER if any(v["arm"] == a for v in scores.values())]
    fig, axes = plt.subplots(1, len(targets), figsize=(4.0 * len(targets), 3.5),
                             squeeze=False)
    for c, target in enumerate(targets):
        ax = axes[0][c]
        grid = np.linspace(0.0, 420.0, 240)
        for arm in arms:
            runs = [v for v in scores.values()
                    if tuple(v["target"]) == target and v["arm"] == arm]
            curves = []
            for v in runs:
                w = np.array([p["wall_s"] for p in v["anytime"]])
                e = np.maximum.accumulate(
                    [p["eta_24_6"] for p in v["anytime"]])
                ax.step(w, e, where="post", color=ARM_COLOR[arm], alpha=0.30,
                        lw=1.0)
                # last value at or before each grid time; NaN before the first
                idx = np.searchsorted(w, grid, side="right") - 1
                curve = np.where(idx >= 0, e[np.clip(idx, 0, None)], np.nan)
                curve = np.where(grid > w[-1], np.nan, curve)
                curves.append(curve)
            stacked = np.vstack(curves)
            # only plot where every seed of this arm is still running, so the
            # median never jumps because one run ended early
            complete = ~np.isnan(stacked).any(axis=0)
            ax.plot(grid[complete], np.median(stacked[:, complete], axis=0),
                    color=ARM_COLOR[arm], lw=2.6,
                    label=ARM_LABEL[arm].replace("\n", " "))
        ax.set_title("target ({:+d},{:+d})".format(*target), fontsize=10)
        ax.set_xlabel("wall-clock time [s]")
        if c == 0:
            ax.set_ylabel("best delivered $\\eta$ so far  (blind, (24,6))")
            ax.legend(fontsize=7.5, loc="lower right")
        ax.grid(alpha=0.25)
    fig.suptitle("Anytime true delivered efficiency vs wall-clock time  "
                 "(same machine, same solver, complex128 CPU)\n"
                 "thin = individual seeds, thick = median of 3",
                 fontsize=10.5)
    fig.subplots_adjust(wspace=0.22, top=0.82)
    return save(fig, os.path.join(figdir, "E10_anytime"))


def main():
    parser = argparse.ArgumentParser()
    here = os.path.dirname(os.path.abspath(__file__))
    parser.add_argument("--out", default=os.path.join(here, "..", "data", "main"))
    parser.add_argument("--figdir", default=os.path.join(here, "..", "figures"))
    args = parser.parse_args()
    out, figdir = os.path.abspath(args.out), os.path.abspath(args.figdir)
    os.makedirs(figdir, exist_ok=True)
    import glob
    scores = {}
    for path in sorted(glob.glob(os.path.join(out, "*scores.json"))):
        for key, value in json.load(open(path)).items():
            if not key.startswith("_"):
                scores[key] = value
    runs = {}
    for path in sorted(glob.glob(os.path.join(out, "*runs.json"))):
        for key, value in json.load(open(path)).items():
            if not key.startswith("_"):
                runs[key] = value
    native = os.path.join(out, "native.json")
    if os.path.exists(native):
        runs.update(json.load(open(native)))
    print(figure_patterns(scores, runs, out, figdir))
    print(figure_honesty(scores, figdir))
    print(figure_anytime(scores, figdir))


if __name__ == "__main__":
    main()
