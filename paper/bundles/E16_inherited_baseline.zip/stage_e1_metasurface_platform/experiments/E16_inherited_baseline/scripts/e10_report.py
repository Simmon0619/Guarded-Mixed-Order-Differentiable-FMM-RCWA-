"""E10 report: assemble the measured head-to-head into E10_CONCLUSIONS.md."""
import argparse
import glob
import json
import os
import statistics
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import e10_common as C  # noqa: E402
from e10_analyze import ARM_LABEL, ARM_ORDER, oracle, worst, worst_scenario  # noqa: E402

PREREGISTERED = {"torcwa_M12", "torcwa_M16", "certified"}
# torcwa_M24* are E12a (gate G1): defined after E10 closed, so they carry the
# same post-hoc evidence grade as the certified_* variants.


def med(values):
    return statistics.median(values) if values else float("nan")


def load(out, pattern):
    merged = {}
    for path in sorted(glob.glob(os.path.join(out, pattern))):
        for key, value in json.load(open(path)).items():
            if not key.startswith("_"):
                merged[key] = value
    return merged


def main():
    parser = argparse.ArgumentParser()
    here = os.path.dirname(os.path.abspath(__file__))
    parser.add_argument("--out", default=os.path.join(here, "..", "data", "main"))
    parser.add_argument("--dest", default=os.path.join(
        here, "..", "E10_CONCLUSIONS.md"))
    args = parser.parse_args()
    out = os.path.abspath(args.out)
    scores = load(out, "*scores.json")
    analysis = json.load(open(os.path.join(out, "analysis.json")))
    bench_path = os.path.join(out, "..", "solver_bench.json")
    bench = json.load(open(bench_path)) if os.path.exists(bench_path) else None
    native = {}
    if os.path.exists(os.path.join(out, "native.json")):
        native = json.load(open(os.path.join(out, "native.json")))
    prec_path = os.path.join(out, "precision_decomposition.json")
    precision = json.load(open(prec_path)) if os.path.exists(prec_path) else None
    meta = None
    for name in sorted(os.listdir(out)):
        if name.endswith("runs.json"):
            candidate = json.load(open(os.path.join(out, name))).get("_meta")
            if candidate:
                meta = candidate
                break

    arms = [a for a in ARM_ORDER if any(v["arm"] == a for v in scores.values())]
    targets = sorted({tuple(v["target"]) for v in scores.values()})
    seeds = sorted({v["seed"] for v in scores.values()})
    lines = []
    add = lines.append

    add("# E10 等条件对照：TORCWA 配方 vs 认证式可信优化")
    add("")
    add("> **一句话结论。** 在完全相同的物理、设计映射、优化器超参和计算预算下，"
        "预注册的认证臂在**交付效率**上输给 TORCWA 的固定低阶配方（9 对中 3 胜 6 负，"
        "中位差 −0.087），在**墙钟**上更远远输给 TORCWA 的原生 GPU/单精度实现"
        "（44 s vs 410 s）。认证臂稳定赢下来的只有一件事：**它报的数就是它交付的数**"
        "（自报偏差中位 −1.3%，对手 +24.1%/+47.7%）。事后诊断表明效率差距来自"
        "**认证节奏太稀疏**而非认证的算力开销；加入密集廉价筛选后，同一方法在"
        "更短墙钟内反超（6 胜 3 负，中位差 +0.075）——但该变体是看过结果之后设计的，"
        "证据等级低于预注册臂。")
    add("")

    add("## 1. 冻结协议")
    add("")
    add("三条预注册臂共用同一物理、同一设计映射、同一 Adam / cosine 学习率 / "
        "β continuation，并且**共用同一个求解器**——我们的 `fft_baseline`，"
        "已独立验证与 TORCWA 在匹配截断下数值一致到 ~1e-10。因此在这三条臂之间，"
        "唯一的自变量是 **fidelity management 方法**本身。")
    add("")
    if meta:
        p = meta["physics"]
        add("| 项 | 值 |")
        add("|---|---|")
        add("| wavelength | {} nm |".format(p["wavelength_nm"]))
        add("| period x / y | {} / {} nm |".format(*p["lattice_nm"]))
        add("| design grid (Ny,Nx) | {} × {}（20 nm 方像素）|".format(*p["grid_ny_nx"]))
        add("| patterned thickness | {} nm |".format(p["thickness_nm"]))
        add("| n incident / output | {} / {} |".format(p["n_incident"], p["n_output"]))
        add("| eps background / feature | {:.4g} / {:.4g}（n = {:.4g} / {:.4g}）|"
            .format(p["eps_background"], p["eps_feature"],
                    p["eps_background"] ** 0.5, p["eps_feature"] ** 0.5))
        add("| incidence | x-Jones, normal |")
        add("| 设计映射 | y 镜像对称 → {} nm 周期高斯滤波 → tanh 投影(β) |".format(
            meta["design_map"]["filter_nm"]))
        add("| 交付结构 | 滤波场的 {} 硬阈值（与 β 无关）|".format(
            meta["design_map"]["threshold"]))
        add("| 预算 | {:.0f} 单位（1 单位 = 一次 (16,4) 前向；反传 ×1.5；"
            "每条臂自身的二值审计一并计费）|".format(meta["budget_units"]))
        add("| 配对 | {} 目标 × {} 种子 = {} 对 |".format(
            len(targets), len(seeds), len(targets) * len(seeds)))
        add("| 盲评 | 交付硬二值在 (24,6) 与 (28,7) 重评；**没有任何一条臂在优化中"
            "评估过 (28,7)** |")
        add("")
    add("**臂的定义**")
    add("")
    add("| arm | 预注册 | 说明 |")
    add("|---|---|---|")
    add("| TORCWA 配方 @ (12,3) | 是 | 固定阶 + Adam + β continuation，每 6 步用"
        "*自己那一阶*审计一次硬二值，交付自评最好者 |")
    add("| TORCWA 配方 @ (16,4) | 是 | 同上，更高的固定阶 |")
    add("| ours (certified, gated) | 是 | L=(12,3) 提议经 FOC 修正 → H 阶实际增益"
        "验收 → 每 2 次接受做一次 R 阶硬二值认证与回滚 → β 只在 H/R 在当前硬二值上"
        "一致时才允许继续锐化，否则提阶 |")
    add("| ours + dense cheap screen | **否（事后）** | 轨迹不变，但每个内层迭代都在"
        "廉价阶 L 上筛选一次硬二值，只有筛选胜出者才花 R 阶认证 |")
    add("| ours (equal wall clock) | **否（事后）** | 预注册认证臂，改用 410 s 墙钟预算 |")
    add("| TORCWA native GPU/c64 | 否（补充） | 真正的 TORCWA 库，GPU + complex64，"
        "步数与 (12,3) 臂相同；只回答实现层的墙钟问题 |")
    add("")

    add("## 2. 主结果")
    add("")
    add("| arm | median η(28,7) | mean | best | median wall [s] | 自报偏差 | "
        "(24,6)→(28,7) 漂移 | held-out 最差比 |")
    add("|---|---:|---:|---:|---:|---:|---:|---:|")
    for arm in arms:
        s = analysis["per_arm"][arm]
        mark = "" if arm in PREREGISTERED else " *"
        add("| {}{} | {:.4f} | {:.4f} | {:.4f} | {:.0f} | {:+.1%} | {:.1%} | "
            "{:.2f} |".format(
                ARM_LABEL[arm], mark, s["eta_28_7_median"], s["eta_28_7_mean"],
                s["eta_28_7_max"], s["wall_s_median"],
                s["self_report_inflation_median"],
                s["reference_drift_median"], s["worst_cd_relative_median"]))
    add("")
    add("`*` = 事后定义的臂，证据等级低于预注册臂。")
    add("")
    add("`自报偏差` = (该臂交付时相信的值 − 盲评真值) / 盲评真值。正值 = 高估自己。")
    add("")

    add("### 配对比较（正值 = 前者更好）")
    add("")
    add("| 比较 | n | 胜/负 | median Δη |")
    add("|---|---:|---:|---:|")
    for name, p in analysis["paired"].items():
        a, b = name.split("_vs_")
        add("| {} − {} | {} | {}/{} | {:+.4f} |".format(
            ARM_LABEL.get(a, a), ARM_LABEL.get(b, b), p["n"],
            p["wins"], p["losses"], p["median_delta_eta"]))
    add("")

    add("## 3. 三条可以写进正文的发现")
    add("")
    add("**F-E10-1（效率：预注册认证臂在上升期是净亏的）。** 等成本预算下 "
        "TORCWA@(12,3) 以 6:3 胜预注册认证臂，中位差 +0.087。机制与 E6 的相图一致："
        "该预算区间内所有轨迹仍在上升期，进度由**总移动量**决定，而认证臂用 219 步"
        "对 ~48 步。把认证臂的预算改成**等墙钟 410 s** 并没有改变结论"
        "（仍 3:6 负，中位差 −0.090），所以这不是成本记账的假象。")
    add("")
    add("**F-E10-2（可信度：认证臂交付什么就报什么）。** 自报偏差中位数："
        "认证臂 −1.3%，TORCWA@(12,3) +24.1%，TORCWA 原生 GPU +47.7%。"
        "最极端单点是 (+3,0)/2029 的原生臂：自报 0.3257，(28,7) 真值 0.1001，"
        "高估 3.25×。**把交付值放进论文之前，低阶自评不是可用的数字。**")
    add("")
    add("**F-E10-3（差距的机制是审计节奏，不是认证开销）。** 预注册认证臂整轮只对"
        "硬二值做 4–6 次 R 阶审计，交付设计实质是 ~5 个样本的最大值；"
        "TORCWA 每 6 步审计一次（37 个样本，虽然是在自己的低阶上）。"
        "把廉价阶密集筛选加进来（每个内层迭代筛一次，只有胜出者才付 R 阶认证）后，"
        "同一方法以 6:3 胜 TORCWA@(12,3)（中位差 +0.075），中位墙钟 287 s 对 410 s，"
        "且自报偏差保持在 −1.7%。**代价是这个变体在看到结果之后才定义**，"
        "其 6:3 的胜负在 n=9 下也不构成显著性主张。")
    add("")

    add("**F-E10-4（鲁棒性不是这轮的胜负手，如实记录）。** 在四个 held-out 工艺场景下，"
        "最差比的中位数为：TORCWA@(12,3) 0.42、TORCWA@(16,4) 0.56、预注册认证臂 0.50、"
        "密集筛选变体 0.60、等墙钟认证臂 0.82。**没有一致的方法效应**——唯一明显领先的"
        "是效率最低的等墙钟臂。可以说的只有一条较弱的陈述：预注册认证臂的**最差单点**"
        "不那么灾难（0.23，对手 0.12/0.09/0.06），而密集筛选变体买回效率的同时"
        "把最差单点还了回去（0.05）。工艺鲁棒性在本实验里是一个独立的、尚未被任何一条臂"
        "控制的轴；E9 的恒等式认证交付才是对症的手段，本实验没有启用它。")
    add("")
    add("## 4. Oracle-selection 消融")
    add("")
    add("同一条轨迹，改由盲评 (24,6) 在 {轨迹 checkpoint, 该臂自己的交付} 中挑最好的"
        "一个。真实用户做不到；它分离“轨迹更好”与“只是选得更好”。")
    add("")
    add("| arm | 自选交付 η(28,7) | oracle 选择 | 选择损失 |")
    add("|---|---:|---:|---:|")
    for arm in arms:
        rows = [v for v in scores.values() if v["arm"] == arm]
        own = med([r["blind"]["28,7"] for r in rows])
        orc = med([oracle(r) for r in rows])
        add("| {} | {:.4f} | {:.4f} | {:+.4f} |".format(
            ARM_LABEL[arm], own, orc, orc - own))
    add("")

    add("## 5. Held-out 工艺审计")
    add("")
    add("交付的硬二值在四个**未被任何一条臂优化过**的扰动下于 (24,6) 重评："
        "均匀 CD 偏置 ±20 nm（一个像素的边缘位移），以及 40 nm 结构元的周期硬 "
        "opening / closing。报告最差场景相对标称值的比值。")
    add("")
    add("> 说明：第一版评分用的是 ±10 nm CD，在 20 nm 像素上是空操作"
        "（边界像素的有符号距离恰为一个像素，半像素阈值移动不了任何东西），"
        "已由本节的 ±20 nm + 形态学审计取代。")
    add("")
    has_held = any("held_out" in v for v in scores.values())
    if has_held:
        add("| arm | median 最差比 | min 最差比 | 最常见的最差场景 |")
        add("|---|---:|---:|---|")
        for arm in arms:
            rows = [v for v in scores.values() if v["arm"] == arm
                    and "held_out" in v]
            if not rows:
                continue
            ratios = [worst(r) for r in rows]
            counts = {}
            for r in rows:
                key = worst_scenario(r)
                counts[key] = counts.get(key, 0) + 1
            dominant = max(counts, key=counts.get)
            add("| {} | {:.2f} | {:.2f} | {} ({}/{}) |".format(
                ARM_LABEL[arm], med(ratios), min(ratios), dominant,
                counts[dominant], len(rows)))
        add("")
    else:
        add("_held-out 审计尚未写回评分文件。_")
        add("")

    add("## 6. 实现层：求解器成本与精度（与优化方法无关）")
    add("")
    if bench:
        add("一次 solve = 一次值 + 一次反向梯度，(35,120) 全设计变量。")
        add("")
        add("| 截断 (Mx,My) | 模数 | ours CPU c128 [s] | TORCWA CPU c128 [s] | "
            "TORCWA GPU c64 [s] | ours vs TORCWA 值差 (c128) |")
        add("|---|---:|---:|---:|---:|---:|")
        for row in bench["rows"]:
            gpu = row.get("torcwa_gpu_c64", {})
            add("| ({},{}) | {} | {:.3f} | {:.3f} | {} | {:.2e} |".format(
                row["level"][0], row["level"][1], row["n_terms"],
                row["ours_cpu_c128"]["seconds"],
                row["torcwa_cpu_c128"]["seconds"],
                "{:.3f}".format(gpu["seconds"]) if "seconds" in gpu else "—",
                row["torcwa_cpu_c128"]["abs_value_diff_vs_ours"]))
        add("")
        add("在匹配的截断、设备和精度下，两套代码给出同一个数（~1e-10），"
            "而 TORCWA 的实现更快。这条差距与 fidelity management 无关，"
            "必须分开记账——减少高阶反传的次数不等于总墙钟加速。")
        add("")
    if native:
        walls = [v["wall_s"] for v in native.values()]
        add("**TORCWA 原生配置**：与 (12,3) 臂完全相同的步数，GPU + complex64，"
            "中位墙钟 **{:.1f} s**，对比我们 CPU + complex128 的 410 s——约 9×。"
            .format(med(walls)))
        add("")
    if precision:
        add("**单精度到底改变了什么。** 把原生臂交付的硬二值在 complex128 下按同一个"
            "(12,3) 重评：精度分量的中位数为 `{:+.4f}`，截断分量为 `{:+.4f}`。"
            "也就是说 complex64 在这些二值结构的**前向求值**上没有可见误差；"
            "原生臂更大的自报偏差全部来自阶数截断，加上单精度梯度把它带到了"
            "**不同的设计**上——不是它算错了自己的设计。".format(
                precision["median_precision_component"],
                precision["median_truncation_component"]))
        add("")

    add("## 7. 逐次运行")
    add("")
    add("| target | seed | arm | η(28,7) | η(24,6) | 自报 | wall [s] | units | "
        "held-out 最差比 |")
    add("|---|---:|---|---:|---:|---:|---:|---:|---:|")
    for r in analysis["per_run"]:
        add("| ({:+d},{:+d}) | {} | {} | {:.4f} | {:.4f} | {:.4f} | {:.0f} | "
            "{} | {:.2f} |".format(
                r["target"][0], r["target"][1], r["seed"],
                ARM_LABEL[r["arm"]], r["eta_28_7"], r["eta_24_6"],
                r["self_reported"], r["wall_s"],
                "{:.0f}".format(r["units"]) if r["units"] == r["units"] else "—",
                r["worst_cd"]))
    add("")

    add("## 8. 边界与不主张")
    add("")
    add("- n=9 配对，效应方向一致但不作显著性宣称；种子间方差很大"
        "（TORCWA@(12,3) 的 η 跨度 0.126–0.490）。")
    add("- 只有一个物理配置、一个厚度、一族 (m,0) 目标；不外推到金属、其他填充率或"
        "斜入射。")
    add("- `certified_screened` 与 `certified_wall410` 是看过结果之后定义的，"
        "只作诊断，不作方法主张。")
    add("- 预算区间只覆盖上升期，未覆盖终局区；E6 的压力段说明终局区的结论可能相反。")
    add("- (24,6) 与认证臂晋级后的 R 阶重合，因此正文主张只用 (28,7)。"
        "(24,6)→(28,7) 漂移中位数 1.2%–3.3%，但单点最高 26%——二值高对比结构的"
        "参考阶本身尚未完全收敛，任何单点绝对值都应带这个不确定度报告。")
    add("- 求解器实现速度差与本文的方法主张无关，二者分别记账。")
    add("")

    dest = os.path.abspath(args.dest)
    open(dest, "w", encoding="utf-8").write("\n".join(lines) + "\n")
    print("written", dest)


if __name__ == "__main__":
    main()
