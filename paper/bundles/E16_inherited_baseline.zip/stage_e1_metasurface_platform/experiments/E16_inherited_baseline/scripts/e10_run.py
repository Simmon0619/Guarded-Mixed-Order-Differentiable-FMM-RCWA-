"""E10 driver: paired equal-budget campaign, resumable.

Usage:
    python e10_run.py --budget 60 --out ../data/main
    python e10_run.py --budget 12 --seeds 2029 --out ../data/smoke
"""
import argparse
import json
import os
import platform
import sys
import time

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import e10_common as C          # noqa: E402
from e10_arms import (  # noqa: E402
    run_certified, run_certified_screened, run_torcwa_style,
)

ARMS = {
    "torcwa_M12": lambda t, s, b, w: run_torcwa_style(
        t, s, (12, 3), budget=b, wall_budget_s=w),
    "torcwa_M16": lambda t, s, b, w: run_torcwa_style(
        t, s, (16, 4), budget=b, wall_budget_s=w),
    # E12a (gate G1): the conservative fixed-order practice -- what a designer
    # is forced into on a new structure whose adequate order is not yet known.
    # Quote the equal-WALL-CLOCK variant: the synthetic unit model is N**3 while
    # the measured scaling is N**2.13, so units overcharge (24,6) by ~3.2x
    # relative to (16,4) and would make this arm lose for bookkeeping reasons.
    "torcwa_M24": lambda t, s, b, w: run_torcwa_style(
        t, s, (24, 6), budget=b, wall_budget_s=w),
    "certified": lambda t, s, b, w: run_certified(
        t, s, budget=b, wall_budget_s=w),
    "certified_screened": lambda t, s, b, w: run_certified_screened(
        t, s, budget=b, wall_budget_s=w),
}


def _jsonable(value):
    if isinstance(value, dict):
        return {k: _jsonable(v) for k, v in value.items() if k != "binary"}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    if isinstance(value, (np.floating, np.integer)):
        return value.item()
    if isinstance(value, torch.Tensor):
        return None
    return value


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--budget", type=float, default=C.BUDGET_UNITS)
    parser.add_argument("--out", default=os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "..", "data", "main"))
    parser.add_argument("--seeds", type=int, nargs="*", default=C.SEEDS)
    parser.add_argument("--targets", type=int, nargs="*", default=None)
    parser.add_argument("--shard", default="")
    parser.add_argument("--arms", nargs="*", default=None)
    parser.add_argument("--wall-budget", dest="wall_budget", type=float,
                        default=None,
                        help="equal-wall-clock mode: seconds per run; the "
                             "unit budget is then only bookkeeping")
    parser.add_argument("--suffix", default="",
                        help="appended to the arm name in the run key")
    args = parser.parse_args()

    out = os.path.abspath(args.out)
    os.makedirs(os.path.join(out, "designs"), exist_ok=True)
    targets = C.TARGETS if args.targets is None else [
        (args.targets[i], args.targets[i + 1])
        for i in range(0, len(args.targets), 2)]

    runs_path = os.path.join(out, args.shard + "runs.json")
    runs = json.load(open(runs_path)) if os.path.exists(runs_path) else {}
    runs.setdefault("_meta", {
        "budget_units": args.budget,
        "physics": {
            "wavelength_nm": C.WL, "lattice_nm": list(C.LATTICE),
            "grid_ny_nx": [C.NY, C.NX], "thickness_nm": C.THICK,
            "n_incident": C.N_IN, "n_output": C.N_OUT,
            "eps_background": C.EPS_BG, "eps_feature": C.EPS_FEAT,
            "polarization": "x_jones_normal_incidence",
        },
        "design_map": {
            "filter_nm": C.FILTER_NM, "threshold": C.THRESHOLD,
            "beta_ladder": C.BETA_LADDER, "y_mirror_symmetry": True,
        },
        "levels": {k: list(v) for k, v in C.LEVELS.items()},
        "environment": {
            "python": platform.python_version(),
            "torch": torch.__version__,
            "platform": platform.platform(),
        },
    })

    for target in targets:
        for seed in args.seeds:
            for arm, fn in ARMS.items():
                if args.arms and arm not in args.arms:
                    continue
                name = arm + args.suffix
                key = "{}|{}|{}".format(tuple(target), seed, name)
                if key in runs:
                    continue
                t0 = time.time()
                result = fn(tuple(target), seed, args.budget, args.wall_budget)
                stem = "{}_{}_{}_{}".format(
                    target[0], target[1], seed, name)
                np.save(os.path.join(out, "designs", stem + "_binary.npy"),
                        result["delivered_binary"].numpy())
                np.save(os.path.join(out, "designs", stem + "_latent.npy"),
                        result["final_latent"].numpy())
                cps = []
                for i, cp in enumerate(result["checkpoints"]):
                    name = "{}_cp{:02d}.npy".format(stem, i)
                    cur = "{}_cp{:02d}_cur.npy".format(stem, i)
                    np.save(os.path.join(out, "designs", name),
                            cp["binary"].numpy())
                    np.save(os.path.join(out, "designs", cur),
                            cp["current"].numpy())
                    cps.append({"units": cp["units"], "wall_s": cp["wall_s"],
                                "tag": cp["tag"], "file": name,
                                "current_file": cur})
                record = _jsonable({k: v for k, v in result.items()
                                    if k not in ("delivered_binary",
                                                 "final_latent",
                                                 "checkpoints")})
                record["checkpoints"] = cps
                record["binary_file"] = stem + "_binary.npy"
                record["latent_file"] = stem + "_latent.npy"
                record["driver_wall_s"] = time.time() - t0
                runs[key] = record
                json.dump(runs, open(runs_path, "w"), indent=1)
                print("{:26s} units={:6.1f} wall={:6.1f}s self={:.4f}".format(
                    key, record["units"], record["wall_s"],
                    record["self_reported_binary"]), flush=True)
    print("E10 optimization complete:", len(runs) - 1, "runs ->", runs_path)


if __name__ == "__main__":
    main()
