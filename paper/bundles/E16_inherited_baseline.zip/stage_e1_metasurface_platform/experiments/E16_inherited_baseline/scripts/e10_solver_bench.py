"""E10 solver micro-benchmark: implementation cost and numerical agreement.

Separates the two questions that a wall-clock comparison otherwise conflates:
  1. per-solve implementation efficiency of the two codes at matched truncation
     and matched device/dtype;
  2. what TORCWA's native GPU/complex64 configuration buys, and what it costs
     in accuracy relative to the complex128 reference.

One "solve" = one value + one reverse-mode gradient of the target-order
transmitted efficiency with respect to the full (35,120) density.
"""
import argparse
import json
import os
import platform
import statistics
import sys
import time

import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import e10_common as C  # noqa: E402

LEVELS = [(8, 2), (12, 3), (16, 4), (20, 5), (24, 6)]
TARGET = (1, 0)


def ours(density, level, device, dtype):
    real = torch.float64 if dtype == torch.complex128 else torch.float32
    x = density.to(device=device, dtype=real).clone().requires_grad_(True)
    eps = (C.EPS_BG + (C.EPS_FEAT - C.EPS_BG) * x).to(dtype)
    from trustworthy_fmm.solvers.vector_2d import solve_multilayer_vector_2d
    r = solve_multilayer_vector_2d([eps], [C.THICK], C.WL, C.LATTICE,
                                   C.N_IN, C.N_OUT, tuple(level),
                                   incident_jones=(1.0, 0.0))
    j = r.power_t[r.orders.index(TARGET)]
    j.backward()
    return float(j.detach()), x.grad.detach().double().cpu()


def torcwa_solve(density, level, device, dtype):
    import torcwa
    real = torch.float64 if dtype == torch.complex128 else torch.float32
    x = density.transpose(0, 1).contiguous().to(
        device=device, dtype=real).clone().requires_grad_(True)
    eps = C.EPS_BG + (C.EPS_FEAT - C.EPS_BG) * x
    sim = torcwa.rcwa(freq=1.0 / C.WL, order=[int(level[0]), int(level[1])],
                      L=list(C.LATTICE), dtype=dtype, device=device,
                      stable_eig_grad=True)
    sim.add_input_layer(eps=C.N_IN ** 2)
    sim.add_output_layer(eps=C.N_OUT ** 2)
    sim.set_incident_angle(inc_ang=0.0, azi_ang=0.0)
    sim.add_layer(C.THICK, eps)
    sim.solve_global_smatrix()
    txx = sim.S_parameters(orders=list(TARGET), direction="forward",
                           port="transmission", polarization="xx",
                           ref_order=[0, 0])
    tyx = sim.S_parameters(orders=list(TARGET), direction="forward",
                           port="transmission", polarization="yx",
                           ref_order=[0, 0])
    j = torch.sum(torch.abs(txx) ** 2 + torch.abs(tyx) ** 2)
    g = torch.autograd.grad(j, x)[0]
    return float(j.detach()), g.transpose(0, 1).double().cpu()


def timed(fn, repeats):
    values, grads, times = [], [], []
    for _ in range(repeats):
        torch.cuda.synchronize() if torch.cuda.is_available() else None
        t0 = time.perf_counter()
        v, g = fn()
        torch.cuda.synchronize() if torch.cuda.is_available() else None
        times.append(time.perf_counter() - t0)
        values.append(v)
        grads.append(g)
    return statistics.median(times), values[-1], grads[-1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--out", default=os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "..", "data",
        "solver_bench.json"))
    args = parser.parse_args()
    density = C.initial_latent(2029)
    rows = []
    for level in LEVELS:
        row = {"level": list(level), "n_terms": C.n_terms(level)}
        t, v_ref, g_ref = timed(
            lambda: ours(density, level, "cpu", torch.complex128), args.repeats)
        row["ours_cpu_c128"] = {"seconds": t, "value": v_ref}
        t, v, g = timed(
            lambda: torcwa_solve(density, level, "cpu", torch.complex128),
            args.repeats)
        row["torcwa_cpu_c128"] = {
            "seconds": t, "value": v,
            "abs_value_diff_vs_ours": abs(v - v_ref),
            "gradient_cosine_vs_ours": float(
                torch.nn.functional.cosine_similarity(
                    g.flatten(), g_ref.flatten(), dim=0)),
        }
        if torch.cuda.is_available():
            for tag, dtype in (("torcwa_gpu_c64", torch.complex64),
                               ("torcwa_gpu_c128", torch.complex128)):
                try:
                    timed(lambda: torcwa_solve(density, level, "cuda", dtype), 1)
                    t, v, g = timed(
                        lambda: torcwa_solve(density, level, "cuda", dtype),
                        args.repeats)
                    row[tag] = {
                        "seconds": t, "value": v,
                        "relative_value_error_vs_c128_reference":
                            abs(v - v_ref) / max(abs(v_ref), 1e-12),
                        "gradient_cosine_vs_ours": float(
                            torch.nn.functional.cosine_similarity(
                                g.flatten(), g_ref.flatten(), dim=0)),
                    }
                except Exception as exc:  # pragma: no cover
                    row[tag] = {"error": "{}: {}".format(type(exc).__name__, exc)}
        rows.append(row)
        print(json.dumps(row, indent=1), flush=True)
    payload = {
        "environment": {
            "python": platform.python_version(), "torch": torch.__version__,
            "platform": platform.platform(),
            "gpu": torch.cuda.get_device_name(0)
            if torch.cuda.is_available() else None,
            "threads": torch.get_num_threads(),
        },
        "definition": "one solve = one value + one reverse-mode gradient",
        "rows": rows,
    }
    json.dump(payload, open(os.path.abspath(args.out), "w"), indent=1)
    print("written", os.path.abspath(args.out))


if __name__ == "__main__":
    main()
