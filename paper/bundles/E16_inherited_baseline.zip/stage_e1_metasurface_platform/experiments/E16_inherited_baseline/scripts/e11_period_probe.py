"""E11 probe: does the E10 benchmark's oversized period explain the low efficiency?

Everything except the x-period is held at the E10 frozen protocol: same
material, thickness, filter, projection, Adam schedule, beta continuation,
solver and delivered-hard-binary rule.  Only Lx (hence the number of open
diffraction channels) changes.  Each configuration deflects into its own +1
order, so the *task* is "send light into the first order" in every case; what
varies is how many competing channels are open.
"""
import json, math, os, sys
import numpy as np, torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import e10_common as C
from trustworthy_fmm.fabrication.process import periodic_gaussian_filter, tanh_projection
from trustworthy_fmm.solvers.vector_2d import solve_multilayer_vector_2d

STEPS = 200
SEEDS = [2029, 2030, 2031]
PIXEL = 20.0
LY = 700.0
# (name, Lx, target, opt level, score level).  Orders are chosen so the two
# configurations resolve a COMPARABLE PHYSICAL truncation |kx|/k0 = mx*lambda/Lx:
#   Lx2400: opt 12/3.64 = 3.30 k0, score 24/3.64 = 6.59 k0
#   Lx1000: opt  8/1.52 = 5.28 k0, score 12/1.52 = 7.92 k0   (stricter -- conservative)
CONFIGS = [
    ("Lx2400_m1", 2400.0, (1, 0), (12, 3), (24, 6)),   # E10 benchmark, control
    ("Lx1000_m1", 1000.0, (1, 0), (8, 3), (12, 6)),    # few-channel deflector
]


def channels(Lx, n):
    return [m for m in range(-20, 21) if abs(m) * C.WL / Lx <= n]


def make(Lx):
    nx = int(round(Lx / PIXEL)); ny = int(round(LY / PIXEL))
    lat = (Lx, LY)

    def sym(r):
        return 0.5 * (r + torch.flip(r, dims=[0]))

    def filt(r):
        return periodic_gaussian_filter(sym(r), lat, C.FILTER_NM)

    def proj(r, beta):
        return tanh_projection(filt(r), beta, C.THRESHOLD)

    def eps(d):
        return (C.EPS_BG + (C.EPS_FEAT - C.EPS_BG) * d).to(C.DT)

    def solve(d, level, target, grad_x=None):
        r = solve_multilayer_vector_2d([eps(d)], [C.THICK], C.WL, lat, C.N_IN,
                                       C.N_OUT, tuple(level), incident_jones=(1.0, 0.0))
        return r

    def init(seed):
        g = torch.Generator().manual_seed(int(seed))
        z = torch.randn((ny, nx), generator=g, dtype=torch.float64)
        z = periodic_gaussian_filter(z, lat, C.FILTER_NM); z = z / z.std()
        return sym((0.5 + 0.08 * z).clamp(0.05, 0.95))

    return dict(nx=nx, ny=ny, lat=lat, sym=sym, filt=filt, proj=proj, eps=eps,
                solve=solve, init=init)


def run(name, Lx, target, level, score_level, seed):
    M = make(Lx)
    rho = M["init"](seed)
    opt = C.Adam(rho.shape)
    best = (-1.0, None)
    for i in range(STEPS):
        p = i / max(STEPS - 1, 1)
        beta = C.beta_at(p)
        x = rho.detach().clone().requires_grad_(True)
        r = M["solve"](M["proj"](x, beta), level, target)
        j = r.power_t[r.orders.index(tuple(target))]
        j.backward()
        rho = opt.step(rho, x.grad.detach(), C.cosine_lr(p))
        if i % 6 == 0 or i == STEPS - 1:
            with torch.no_grad():
                hb = (M["filt"](rho) >= C.THRESHOLD).to(torch.float64)
                rb = M["solve"](hb, level, target)
                v = float(rb.power_t[rb.orders.index(tuple(target))])
            if v > best[0]:
                best = (v, hb.clone())
    with torch.no_grad():
        rs = M["solve"](best[1], score_level, target)
        idx = rs.orders.index(tuple(target))
        eta = float(rs.power_t[idx]); T = float(rs.total_T.real); R = float(rs.total_R.real)
    return dict(name=name, Lx=Lx, seed=seed, target=list(target),
                self_reported=best[0], eta=eta, total_T=T, total_R=R,
                target_share_of_T=eta / max(T, 1e-12),
                deflection_deg=math.degrees(math.asin(min(target[0] * C.WL / Lx, 1.0))),
                open_air=len(channels(Lx, C.N_OUT)), open_sub=len(channels(Lx, C.N_IN)))


import argparse
ap = argparse.ArgumentParser(); ap.add_argument("--only", default=None)
ARGS = ap.parse_args()
_dst = os.path.join(C._HERE, "..", "data", "period_probe.json")
out = json.load(open(_dst)) if os.path.exists(_dst) else []
out = [r for r in out if ARGS.only is None or r["name"] != ARGS.only]
for name, Lx, target, level, score in CONFIGS:
    if ARGS.only is not None and name != ARGS.only:
        continue
    for seed in SEEDS:
        rec = run(name, Lx, target, level, score, seed)
        out.append(rec)
        print("%-12s seed %d  eta=%.4f  T=%.3f R=%.3f  share=%.1f%%  %.1f deg  air-x-orders=%d"
              % (name, seed, rec["eta"], rec["total_T"], rec["total_R"],
                 100 * rec["target_share_of_T"], rec["deflection_deg"], rec["open_air"]), flush=True)
    json.dump(out, open(_dst, "w"), indent=1)
print("done")
