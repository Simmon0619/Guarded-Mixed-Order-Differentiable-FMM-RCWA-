"""Does an EARLY checkpoint predict the FINAL outcome of a restart?

This is the load-bearing assumption of successive halving / Hyperband: you can
kill most restarts after a small fraction of their budget because early rank
predicts final rank.  If it holds here, best-of-N becomes affordable at a small
multiple of one full run -- which attacks the factor our own data says dominates
(which local optimum you land in, 3.9x spread).  If it fails, that whole family
of methods is inapplicable and we should know before building anything.

Uses the anytime curves already recorded for every run; costs no new solves.
"""
import glob, json, statistics as st

sc = {}
for p in glob.glob('data/main/*scores.json'):
    for k, v in json.load(open(p)).items():
        if not k.startswith('_'):
            sc[k] = v


def spearman(x, y):
    def rank(v):
        order = sorted(range(len(v)), key=lambda i: v[i])
        r = [0.0] * len(v)
        i = 0
        while i < len(order):
            j = i
            while j + 1 < len(order) and v[order[j + 1]] == v[order[i]]:
                j += 1
            avg = (i + j) / 2.0 + 1
            for k in range(i, j + 1):
                r[order[k]] = avg
            i = j + 1
        return r
    rx, ry = rank(x), rank(y)
    n = len(x)
    mx, my = st.mean(rx), st.mean(ry)
    num = sum((a - mx) * (b - my) for a, b in zip(rx, ry))
    den = (sum((a - mx) ** 2 for a in rx) * sum((b - my) ** 2 for b in ry)) ** 0.5
    return num / den if den else float('nan')


FRACTIONS = [0.10, 0.25, 0.50, 0.75]
print("=" * 100)
print("Spearman rank correlation between the running-best eta at a FRACTION of the")
print("budget and the final delivered eta(28,7), across the 9 restarts of each arm.")
print("Successive halving needs this to be high at small fractions.")
print("=" * 100)
print("%-24s %6s %8s %8s %8s %8s  %s" % ("arm", "n", "10%", "25%", "50%", "75%", "top-1 kept at 25%?"))

for armn in ('torcwa_M12', 'torcwa_M16', 'torcwa_M24_wall410', 'certified',
             'certified_screened', 'certified_wall410'):
    rows = [v for v in sc.values() if v['arm'] == armn and v.get('anytime')]
    if len(rows) < 4:
        continue
    finals = [r['blind']['28,7'] for r in rows]
    line, keeps = [], None
    for frac in FRACTIONS:
        early = []
        for r in rows:
            a = r['anytime']
            umax = max(p['units'] for p in a) or 1.0
            cand = [p for p in a if p['units'] <= frac * umax]
            early.append(max((p['eta_24_6'] for p in cand), default=0.0))
        rho = spearman(early, finals)
        line.append(rho)
        if abs(frac - 0.25) < 1e-9:
            k = max(1, len(rows) // 3)
            keep = sorted(range(len(rows)), key=lambda i: -early[i])[:k]
            best = max(range(len(finals)), key=lambda i: finals[i])
            keeps = "YES" if best in keep else "NO  (best restart killed)"
    print("%-24s %6d %8.2f %8.2f %8.2f %8.2f  %s"
          % (armn, len(rows), line[0], line[1], line[2], line[3], keeps))

print()
print("=" * 100)
print("What successive halving would have delivered, pooled over ALL arms' restarts")
print("(54 restarts treated as one population -- the realistic 'many random starts' setting)")
print("=" * 100)
rows = [v for v in sc.values() if v.get('anytime')]
finals = [r['blind']['28,7'] for r in rows]
print("  population: %d restarts   best %.4f   median %.4f" % (len(rows), max(finals), st.median(finals)))
for frac in FRACTIONS:
    early = []
    for r in rows:
        a = r['anytime']
        umax = max(p['units'] for p in a) or 1.0
        cand = [p for p in a if p['units'] <= frac * umax]
        early.append(max((p['eta_24_6'] for p in cand), default=0.0))
    rho = spearman(early, finals)
    for keep_frac in (1 / 3.,):
        k = max(1, int(len(rows) * keep_frac))
        kept = sorted(range(len(rows)), key=lambda i: -early[i])[:k]
        got = max(finals[i] for i in kept)
        cost = frac * len(rows) + (1 - frac) * k          # in units of one full run
        print("    screen at %3.0f%% budget, keep top %d: best kept = %.4f "
              "(oracle %.4f)   cost = %.1f full runs vs %d for exhaustive"
              % (100 * frac, k, got, max(finals), cost, len(rows)))
    print("      rank correlation at this fraction: rho = %.2f" % rho)
