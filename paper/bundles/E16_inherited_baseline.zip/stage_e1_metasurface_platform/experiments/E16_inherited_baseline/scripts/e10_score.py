"""E10 blind scoring.

Every delivered hard binary is re-scored by the SAME solver at (24,6) and
(28,7), regardless of the level its arm optimized at.  (28,7) is the headline
reference: no arm ever evaluates there, so it is blind for all of them.

Also computed:
  * anytime curves -- the best structure each arm could deliver so far,
    scored at (24,6) on a subsampled checkpoint grid;
  * an oracle-selection ablation -- the best checkpoint of the SAME trajectory
    picked by the blind (24,6) score.  A real user cannot do this; it bounds
    how much of any gap is selection rather than trajectory;
  * a held-out uniform CD-bias process pair at +/-10 nm.

Identical masks are scored once and cached by SHA-256.
"""
import argparse
import glob
import hashlib
import json
import os
import sys
import time

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import e10_common as C  # noqa: E402

CD_BIAS_NM = [-10.0, 10.0]
MAX_CHECKPOINTS = 10


def _hash(mask):
    return hashlib.sha256(
        np.ascontiguousarray(mask).astype(np.uint8).tobytes()).hexdigest()


def load_runs(out, include_native=True):
    runs = {}
    for path in sorted(glob.glob(os.path.join(out, "*runs.json"))):
        for key, value in json.load(open(path)).items():
            if not key.startswith("_"):
                runs[key] = value
    native_path = os.path.join(out, "native.json")
    if include_native and os.path.exists(native_path):
        for key, value in json.load(open(native_path)).items():
            value.setdefault("units", float("nan"))
            value.setdefault("checkpoints", [])
            runs[key] = value
    return runs


def subsample(items, limit):
    if len(items) <= limit:
        return list(range(len(items)))
    idx = np.unique(np.linspace(0, len(items) - 1, limit).round().astype(int))
    return list(idx)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", default=os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "..", "data", "main"))
    parser.add_argument("--shard", default="")
    parser.add_argument("--targets", type=int, nargs="*", default=None)
    args = parser.parse_args()
    out = os.path.abspath(args.out)
    runs = load_runs(out)
    want = None
    if args.targets:
        want = {(args.targets[i], args.targets[i + 1])
                for i in range(0, len(args.targets), 2)}

    scores_path = os.path.join(out, args.shard + "scores.json")
    scores = json.load(open(scores_path)) if os.path.exists(scores_path) else {}
    cache = scores.setdefault("_cache", {})

    def score(mask, level, target):
        key = "{}|{}|{}".format(_hash(mask), tuple(level), tuple(target))
        if key not in cache:
            cache[key] = C.forward_density(
                torch.as_tensor(np.asarray(mask), dtype=torch.float64),
                level, target)
        return cache[key]

    t0 = time.time()
    for run_key in sorted(runs):
        record = runs[run_key]
        target_str, seed, arm = run_key.split("|")
        target = tuple(int(v) for v in target_str.strip("()").split(","))
        if want is not None and target not in want:
            continue
        if run_key in scores:
            continue
        mask = np.load(os.path.join(out, "designs", record["binary_file"]))
        entry = {
            "target": list(target), "seed": int(seed), "arm": arm,
            "units": record["units"], "wall_s": record["wall_s"],
            "self_reported_binary": record["self_reported_binary"],
            "fill_fraction": float(mask.mean()),
            "blind": {}, "robustness": {}, "anytime": [],
        }
        for level in C.SCORE_LEVELS:
            entry["blind"]["{},{}".format(*level)] = score(mask, level, target)
        a = entry["blind"]["24,6"]
        b = entry["blind"]["28,7"]
        entry["reference_drift"] = abs(b - a) / max(abs(b), 1e-6)
        entry["self_report_inflation"] = (
            record["self_reported_binary"] - b) / max(abs(b), 1e-6)

        for bias in CD_BIAS_NM:
            perturbed = C.cd_bias_mask(mask > 0.5, bias)
            entry["robustness"]["cd_{:+.0f}nm".format(bias)] = score(
                perturbed, C.CHECKPOINT_LEVEL, target)
        nominal = score(mask, C.CHECKPOINT_LEVEL, target)
        entry["robustness"]["nominal_24_6"] = nominal
        entry["robustness"]["worst_relative"] = min(
            entry["robustness"]["cd_{:+.0f}nm".format(bias)] / max(nominal, 1e-9)
            for bias in CD_BIAS_NM)

        cps = record["checkpoints"]
        best_oracle, best_oracle_file = -float("inf"), None
        for i in subsample(cps, MAX_CHECKPOINTS):
            cp = cps[i]
            delivered = np.load(os.path.join(out, "designs", cp["file"]))
            eta_delivered = score(delivered, C.CHECKPOINT_LEVEL, target)
            cur_file = cp.get("current_file", cp["file"])
            current = np.load(os.path.join(out, "designs", cur_file))
            eta_current = score(current, C.CHECKPOINT_LEVEL, target)
            if eta_current > best_oracle:
                best_oracle, best_oracle_file = eta_current, cur_file
            entry["anytime"].append({
                "units": cp["units"], "wall_s": cp["wall_s"],
                "eta_24_6": eta_delivered, "eta_current_24_6": eta_current,
            })
        if not cps:
            best_oracle, best_oracle_file = b, record["binary_file"]
        entry["oracle_selection"] = {
            "eta_24_6": best_oracle,
            "file": best_oracle_file,
            "eta_28_7": score(np.load(os.path.join(out, "designs",
                                                   best_oracle_file)),
                              (28, 7), target) if best_oracle_file else None,
        }
        scores[run_key] = entry
        json.dump(scores, open(scores_path, "w"), indent=1)
        print("{:26s} eta(28,7)={:.4f} eta(24,6)={:.4f} drift={:5.1%} "
              "inflation={:+7.1%} worstCD={:.2f} oracle(28,7)={:.4f}".format(
                  run_key, b, a, entry["reference_drift"],
                  entry["self_report_inflation"],
                  entry["robustness"]["worst_relative"],
                  entry["oracle_selection"]["eta_28_7"]), flush=True)
    print("scoring done in {:.0f}s ->".format(time.time() - t0), scores_path)


if __name__ == "__main__":
    main()
