"""A1 seed: where does GPU memory go at high order?  (fwd / fwd+bwd / save_on_cpu / eig alone)

Measured 2026-09-04 on stage_d3 (RTX 3060 12 GB, torch 1.13.0+cu117, c64, 2x grid 70x240):
    (32,8)@2x  2N=2210  fwd 1.54 GiB/8.1 s   fwd+bwd 2.68 GiB/7.4 s   save_on_cpu 1.54 GiB/8.9 s   eig 0.07 GiB/2.2 s
    (40,10)@2x 2N=3402  fwd 3.66 GiB/22.2 s  fwd+bwd 6.30 GiB/25.3 s  save_on_cpu 3.63 GiB/27.7 s  eig 0.18 GiB/6.2 s
Reading: autograd-saved tensors ~0.7x forward peak (N^2); forward peak ~40x the matrix itself;
eig itself ~0 memory.  Extrapolated (48,12)@2x: 7.4 + 5.5 GiB = the E20 wall; 7.4 GiB with offload.

Run from anywhere:  python a1_mem_probe.py [--levels 32,8 40,10] [--grid 2]
Writes experiments/A1_memory_profile/data/mem_probe_<timestamp>.json
"""
import argparse
import json
import os
import sys
import time

import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
_E20 = os.path.abspath(os.path.join(_HERE, "..", "..", "E20_high_order", "scripts"))
if _E20 not in sys.path:
    sys.path.insert(0, _E20)
import e20_common as E  # noqa: E402  (pulls in e10_common -> src/ of THIS stage)

DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))


def peak(fn):
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats()
    torch.cuda.synchronize()
    t0 = time.time()
    out = fn()
    torch.cuda.synchronize()
    return time.time() - t0, torch.cuda.max_memory_allocated() / 2 ** 30, out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--levels", nargs="+", default=["32,8", "40,10"])
    ap.add_argument("--grid", type=int, default=2, help="k-x block upsampling of the 35x120 grid")
    ap.add_argument("--dtype", default="c64", choices=["c64", "c128"])
    args = ap.parse_args()
    dt = torch.complex64 if args.dtype == "c64" else torch.complex128
    dev = "cuda"
    torch.manual_seed(0)
    dens = E.upsample((torch.rand(35, 120) > 0.5).double(), args.grid)
    rows = []
    for lv in args.levels:
        level = tuple(int(v) for v in lv.split(","))
        n = (2 * level[0] + 1) * (2 * level[1] + 1)
        row = {"level": level, "n_terms": n, "two_n": 2 * n, "grid": list(dens.shape), "dtype": args.dtype}
        print(f"\n== level {level}  n_terms={n}  2N={2*n}", flush=True)
        t, m, _ = peak(lambda: E.ours_eta(dens, level, (1, 0), dt, dev))
        row["forward"] = {"s": t, "GiB": m}
        print(f"forward only        : {t:7.1f} s  peak {m:6.2f} GiB", flush=True)
        t, m, _ = peak(lambda: E.ours_eta_grad(dens, level, (1, 0), dt, dev))
        row["forward_backward"] = {"s": t, "GiB": m}
        print(f"forward+backward    : {t:7.1f} s  peak {m:6.2f} GiB", flush=True)

        def with_offload():
            with torch.autograd.graph.save_on_cpu(pin_memory=True):
                return E.ours_eta_grad(dens, level, (1, 0), dt, dev)

        t, m, _ = peak(with_offload)
        row["forward_backward_save_on_cpu"] = {"s": t, "GiB": m}
        print(f"fwd+bwd save_on_cpu : {t:7.1f} s  peak {m:6.2f} GiB", flush=True)
        a = torch.randn(2 * n, 2 * n, dtype=dt, device=dev)
        t, m, _ = peak(lambda: torch.linalg.eig(a))
        row["eig_alone_random"] = {"s": t, "GiB": m, "matrix_GiB": a.numel() * a.element_size() / 2 ** 30}
        print(f"eig alone 2N={2*n:5d} : {t:7.1f} s  peak {m:6.2f} GiB", flush=True)
        del a
        rows.append(row)
    os.makedirs(DATA, exist_ok=True)
    out = os.path.join(DATA, time.strftime("mem_probe_%Y%m%d_%H%M%S.json"))
    with open(out, "w", encoding="utf-8") as f:
        json.dump({"gpu": torch.cuda.get_device_name(0), "torch": torch.__version__,
                   "cuda": torch.version.cuda, "rows": rows}, f, indent=2)
    print("saved", out)


if __name__ == "__main__":
    main()
