"""A1: per-stage GPU memory / time profile of one vector_2d solve.

Answers the two A1 questions (PROMPT.md):
  (i)  why is the forward peak ~40x the 2Nx2N matrix itself -- which stage,
       which temporaries, and what does autograd actually save per stage;
  (ii) where does forward time go on real (structured) problems -- eig on the
       structured P@Q vs the S-matrix algebra / 4Nx4N interface solves.

Method: the exact operation sequence of ``solve_multilayer_vector_2d`` for the
frozen single-layer protocol is replayed inline (same building blocks, same op
order), with a stage meter around each block:
  conv -> pq_assembly -> eig -> v_solve -> iface_in -> prop_star
       -> iface_out+star -> power
Each stage records wall time, CUDA peak during the stage, live allocated bytes
at stage end, and (in backward runs) the bytes of tensors autograd saved while
the stage ran (tagged via ``torch.autograd.graph.saved_tensors_hooks``,
deduplicated by storage pointer).  The replica's eta is checked against
``e20_common.ours_eta`` before any numbers are trusted.  ``nvidia-smi`` total
board memory is sampled in a thread because MAGMA workspaces live outside the
PyTorch allocator (WDDM shows no per-process figure).

Run:  python a1_stage_profile.py [--configs ...] [--grid 2]
Writes experiments/A1_memory_profile/data/stage_profile_<timestamp>.json
"""
import argparse
import gc
import json
import math
import os
import subprocess
import sys
import threading
import time
from contextlib import contextmanager

import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
_E20 = os.path.abspath(os.path.join(_HERE, "..", "..", "E20_high_order", "scripts"))
if _E20 not in sys.path:
    sys.path.insert(0, _E20)
import e20_common as E  # noqa: E402  (sets VECTORIZED_CONV / FAST_DIAGNOSTICS)
import e10_common as C  # noqa: E402

from trustworthy_fmm.fourier.factorization import (  # noqa: E402
    FFT_BASELINE,
    transverse_permittivity_2d,
)
from trustworthy_fmm.physics.channels import outgoing_sqrt  # noqa: E402
from trustworthy_fmm.scattering.smatrix import (  # noqa: E402
    interface_smatrix,
    redheffer_star,
    transparent_propagation,
)
from trustworthy_fmm.solvers.eigendecomposition import eigendecomposition  # noqa: E402
from trustworthy_fmm.solvers.vector_2d import (  # noqa: E402
    _block2,
    _external_v,
    _order_power,
)

DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
GIB = 2.0 ** 30


class SmiSampler:
    """Sample nvidia-smi total board memory in a thread (MAGMA is outside torch)."""

    def __init__(self, interval_s=0.3):
        self.interval = interval_s
        self.max_mib = 0
        self.baseline_mib = self._read()
        self._stop = threading.Event()
        self._thread = None

    @staticmethod
    def _read():
        try:
            out = subprocess.run(
                ["nvidia-smi", "--query-gpu=memory.used",
                 "--format=csv,noheader,nounits"],
                capture_output=True, text=True, timeout=5)
            return int(out.stdout.strip().splitlines()[0])
        except Exception:
            return -1

    def _loop(self):
        while not self._stop.is_set():
            value = self._read()
            if value > self.max_mib:
                self.max_mib = value
            self._stop.wait(self.interval)

    def __enter__(self):
        self.max_mib = 0
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *exc):
        self._stop.set()
        self._thread.join(timeout=5)
        return False


def _storage_ptr(tensor):
    if hasattr(tensor, "untyped_storage"):
        return tensor.untyped_storage().data_ptr()
    return tensor.storage().data_ptr()


class StageMeter:
    def __init__(self, offload=False):
        self.rows = []
        self.saved = None  # per-stage {data_ptr: nbytes} when tagging
        self.offload = offload  # replicate save_on_cpu inside our own hooks
        self.current = None

    @contextmanager
    def stage(self, name):
        self.current = name
        torch.cuda.synchronize()
        torch.cuda.reset_peak_memory_stats()
        live_before = torch.cuda.memory_allocated()
        tag_bucket = []
        t0 = time.time()
        if self.saved is not None:
            offload = self.offload

            def pack(tensor):
                if tensor.is_cuda:
                    tag_bucket.append(
                        (_storage_ptr(tensor),
                         tensor.numel() * tensor.element_size()))
                    if offload:
                        host = torch.empty(
                            tensor.size(), dtype=tensor.dtype,
                            layout=tensor.layout, pin_memory=True)
                        host.copy_(tensor)
                        return (tensor.device, host)
                return (None, tensor)

            def unpack(packed):
                device, tensor = packed
                if device is not None:
                    return tensor.to(device, non_blocking=True)
                return tensor

            with torch.autograd.graph.saved_tensors_hooks(pack, unpack):
                yield
        else:
            yield
        torch.cuda.synchronize()
        row = {
            "stage": name,
            "s": time.time() - t0,
            "peak_GiB": torch.cuda.max_memory_allocated() / GIB,
            "live_before_GiB": live_before / GIB,
            "live_after_GiB": torch.cuda.memory_allocated() / GIB,
        }
        if self.saved is not None:
            unique = {}
            for ptr, nbytes in tag_bucket:
                unique[ptr] = max(unique.get(ptr, 0), nbytes)
            row["autograd_saved_GiB"] = sum(unique.values()) / GIB
            row["autograd_saved_raw_GiB"] = sum(n for _, n in tag_bucket) / GIB
            row["autograd_saved_count"] = len(tag_bucket)
            self.saved[name] = unique
        self.rows.append(row)


def staged_forward(density, level, target, dtype, device, meter):
    """Replay solve_multilayer_vector_2d (single layer, theta=0) with stages."""
    mx, my = level
    orders = [(m, n) for m in range(-mx, mx + 1) for n in range(-my, my + 1)]
    count = len(orders)
    eps = (C.EPS_BG + (C.EPS_FEAT - C.EPS_BG) * density).to(dtype).to(device)
    n_in = torch.as_tensor(complex(C.N_IN), dtype=dtype, device=device)
    n_out = torch.as_tensor(complex(C.N_OUT), dtype=dtype, device=device)
    kx = torch.as_tensor(
        [m * C.WL / C.LATTICE[0] for m, _ in orders], dtype=dtype, device=device)
    ky = torch.as_tensor(
        [n * C.WL / C.LATTICE[1] for _, n in orders], dtype=dtype, device=device)
    kx_matrix, ky_matrix = torch.diag(kx), torch.diag(ky)
    identity = torch.eye(count, dtype=dtype, device=device)
    zeros = torch.zeros_like(identity)
    kz_in, v_in = _external_v(kx, ky, n_in * n_in)
    kz_out, v_out = _external_v(kx, ky, n_out * n_out)
    external_w = torch.eye(2 * count, dtype=dtype, device=device)

    with meter.stage("conv"):
        eps_conv, transverse_eps, _ = transverse_permittivity_2d(
            eps, level, FFT_BASELINE, lattice_nm=C.LATTICE,
            basis_orders=None, tangent_field=None,
            smoothing_sigma_px=1.0, detach_tangent_field=False)
    with meter.stage("pq_assembly"):
        left = torch.cat((kx_matrix, ky_matrix), dim=0)
        p_right = torch.cat((ky_matrix, -kx_matrix), dim=1)
        q_right = torch.cat((-ky_matrix, kx_matrix), dim=1)
        p_base = _block2(zeros, identity, -identity, zeros)
        q_base = -transverse_eps @ p_base
        p_matrix = p_base + left @ torch.linalg.solve(eps_conv, p_right)
        q_matrix = q_base + left @ q_right
        pq = p_matrix @ q_matrix
    with meter.stage("eig"):
        eigenvalues, w_layer = eigendecomposition(pq, "default")
    with meter.stage("v_solve"):
        q_layer = outgoing_sqrt(eigenvalues)
        v_layer = torch.linalg.solve(p_matrix, w_layer @ torch.diag(q_layer))
    # mirror the real _layer_modes frame exit: these locals die there before
    # any S-matrix algebra runs (keeps live-memory comparable to the solver)
    del left, p_right, q_right, p_base, q_base, q_matrix, pq, p_matrix
    del eps_conv, transverse_eps
    with meter.stage("iface_in"):
        global_s = interface_smatrix(external_w, v_in, w_layer, v_layer)
    with meter.stage("prop_star"):
        phase = torch.exp(1j * (2 * math.pi / C.WL) * q_layer * C.THICK)
        global_s = redheffer_star(global_s, transparent_propagation(phase))
    with meter.stage("iface_out_star"):
        exit_interface = interface_smatrix(w_layer, v_layer, external_w, v_out)
        global_s = redheffer_star(global_s, exit_interface)
    with meter.stage("power"):
        incident = torch.zeros(2 * count, dtype=dtype, device=device)
        zero_index = orders.index((0, 0))
        jones = torch.as_tensor((1.0 + 0j, 0.0 + 0j), dtype=dtype, device=device)
        jones = jones / torch.clamp(torch.linalg.vector_norm(jones), min=1e-15)
        incident[zero_index] = jones[0]
        incident[count + zero_index] = jones[1]
        transmitted = global_s.s21 @ incident
        incident_h = v_in @ incident
        incident_power = torch.real(
            incident[zero_index] * torch.conj(incident_h[count + zero_index])
            - incident[count + zero_index] * torch.conj(incident_h[zero_index]))
        propagating_out = (kz_out.real > 0) & (torch.abs(kz_out.imag) < 1e-9)
        power_t = _order_power(
            transmitted, v_out, count, incident_power, propagating_out)
        eta = power_t[orders.index(tuple(target))]
    return eta


def run_config(density, level, target, dtype, device, mode):
    """mode: 'forward' | 'backward' | 'backward_save_on_cpu'"""
    gc.collect()  # break autograd reference cycles from the previous run
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats()
    meter = StageMeter(offload=(mode == "backward_save_on_cpu"))
    result = {"mode": mode, "stages": meter.rows}
    smi = SmiSampler()
    result["smi_baseline_MiB"] = smi.baseline_mib
    try:
        with smi:
            torch.cuda.synchronize()
            t0 = time.time()
            if mode == "forward":
                with torch.no_grad():
                    eta = staged_forward(density, level, target, dtype, device, meter)
                torch.cuda.synchronize()
                result["total_s"] = time.time() - t0
            else:
                meter.saved = {}
                x = density.detach().clone().requires_grad_(True)
                # offload mode replicates save_on_cpu inside the meter's own
                # hooks (no nesting of two saved-tensor hook contexts)
                eta = staged_forward(x, level, target, dtype, device, meter)
                torch.cuda.synchronize()
                result["forward_s"] = time.time() - t0
                torch.cuda.reset_peak_memory_stats()
                meter.current = "backward"
                t1 = time.time()
                eta.backward()
                torch.cuda.synchronize()
                result["backward_s"] = time.time() - t1
                result["backward_peak_GiB"] = torch.cuda.max_memory_allocated() / GIB
                result["total_s"] = time.time() - t0
                result["grad_norm"] = float(x.grad.norm())
            result["eta"] = float(eta)
        result["smi_max_MiB"] = smi.max_mib
        result["cuda_peak_over_run_GiB"] = max(
            row["peak_GiB"] for row in meter.rows)
    except RuntimeError as error:
        if "out of memory" not in str(error).lower():
            raise
        result["oom"] = True
        result["oom_at_stage"] = meter.current or "startup"
        result["oom_message"] = str(error).splitlines()[0]
        result["smi_max_MiB"] = smi.max_mib
        torch.cuda.empty_cache()
    if meter.saved is not None and "oom" not in result:
        merged = {}
        for bucket in meter.saved.values():
            merged.update(bucket)
        result["autograd_saved_total_GiB"] = sum(merged.values()) / GIB
    return result


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--grid", type=int, default=2)
    ap.add_argument("--target", default="1,0")
    ap.add_argument("--design", default="random",
                    help="'random' (seed 0, matches a1_mem_probe) or an E19 tag")
    ap.add_argument("--configs", nargs="+", default=[
        "32,8:c64:forward",
        "32,8:c64:backward",
        "40,10:c64:forward",
        "40,10:c64:backward",
        "40,10:c64:backward_save_on_cpu",
        "48,12:c64:forward",
        "48,12:c64:backward",              # expected OOM: record the wall
        "48,12:c64:backward_save_on_cpu",  # expected to fit (~7.4 GiB)
        "32,8:c128:backward",
        "40,10:c128:forward",
        "40,10:c128:backward_save_on_cpu",
        "48,12:c128:forward",              # expected OOM (~14.8 GiB)
        "32,8:c64:eig_random",
        "40,10:c64:eig_random",
        "48,12:c64:eig_random",
    ])
    args = ap.parse_args()
    device = "cuda"
    target = tuple(int(v) for v in args.target.split(","))
    torch.manual_seed(0)
    if args.design == "random":
        density = E.upsample((torch.rand(35, 120) > 0.5).double(), args.grid)
    else:
        density = E.upsample(E.load_e19_binary(args.design), args.grid)
    report = {"gpu": torch.cuda.get_device_name(0), "torch": torch.__version__,
              "cuda": torch.version.cuda, "grid": list(density.shape),
              "design": args.design, "target": list(target), "runs": []}

    for spec in args.configs:
        lv, dt, mode = spec.split(":")
        level = tuple(int(v) for v in lv.split(","))
        dtype = torch.complex64 if dt == "c64" else torch.complex128
        n = (2 * level[0] + 1) * (2 * level[1] + 1)
        unit = (2 * n) ** 2 * (8 if dt == "c64" else 16) / GIB
        header = {"level": list(level), "two_n": 2 * n, "dtype": dt,
                  "matrix_unit_GiB": unit}
        print(f"\n== {spec}  2N={2*n}  unit={unit:.3f} GiB", flush=True)
        if mode == "eig_random":
            torch.cuda.empty_cache()
            torch.cuda.reset_peak_memory_stats()
            a = torch.randn(2 * n, 2 * n, dtype=dtype, device=device)
            torch.cuda.synchronize()
            t0 = time.time()
            torch.linalg.eig(a)
            torch.cuda.synchronize()
            run = {"mode": mode, "s": time.time() - t0,
                   "peak_GiB": torch.cuda.max_memory_allocated() / GIB}
            del a
        else:
            run = run_config(density, level, target, dtype, device, mode)
            if mode == "forward" and "oom" not in run:
                reference = E.ours_eta(density, level, target, dtype, device)
                run["eta_reference"] = reference
                run["eta_abs_diff"] = abs(run["eta"] - reference)
                print(f"   eta={run['eta']:.9f}  ref={reference:.9f}  "
                      f"diff={run['eta_abs_diff']:.3e}", flush=True)
        run.update(header)
        report["runs"].append(run)
        if "stages" in run:
            for row in run["stages"]:
                saved = row.get("autograd_saved_GiB")
                saved_txt = f"  saved {saved:6.2f} GiB" if saved is not None else ""
                print(f"   {row['stage']:<14s} {row['s']:7.2f} s  "
                      f"peak {row['peak_GiB']:6.2f}  "
                      f"live {row['live_after_GiB']:6.2f}{saved_txt}", flush=True)
        for key in ("oom_at_stage", "backward_s", "smi_max_MiB",
                    "autograd_saved_total_GiB"):
            if key in run:
                print(f"   {key} = {run[key]}", flush=True)
        os.makedirs(DATA, exist_ok=True)
        out = os.path.join(DATA, "stage_profile_latest.json")
        with open(out, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2)
    final = os.path.join(DATA, time.strftime("stage_profile_%Y%m%d_%H%M%S.json"))
    os.replace(out, final)
    print("\nsaved", final)


if __name__ == "__main__":
    main()
