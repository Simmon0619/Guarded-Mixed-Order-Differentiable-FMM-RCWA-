"""Headless capture of the FMM Workbench (Fig. 5): P2 task (1,0) in the panel, run of seed 151014 on the Summary tab.
Chrome DevTools protocol over websocket-client; viewport W x H CSS px at device scale factor 2."""
import base64
import json
import os
import subprocess
import sys
import time
import urllib.request

import websocket

HERE = os.path.dirname(os.path.abspath(__file__))
CHROME = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
PORT = 9333
URL = "http://127.0.0.1:8322/"
RUN = "run_20260928_190217_j0001"
W, H = int(sys.argv[1]) if len(sys.argv) > 1 else 1360, int(sys.argv[2]) if len(sys.argv) > 2 else 960

proc = subprocess.Popen([CHROME, "--headless=new", "--remote-debugging-port=%d" % PORT, "--remote-allow-origins=*",
                         "--user-data-dir=" + os.path.join(HERE, "chrome_prof"), "--hide-scrollbars", "--no-first-run",
                         "--no-default-browser-check", "--lang=en-US", "--window-size=%d,%d" % (W, H), "about:blank"])
try:
    tabs = None
    for _ in range(100):
        try:
            tabs = json.load(urllib.request.urlopen("http://127.0.0.1:%d/json" % PORT))
            if any(t["type"] == "page" for t in tabs):
                break
        except Exception:
            pass
        time.sleep(0.2)
    page = [t for t in tabs if t["type"] == "page"][0]
    ws = websocket.create_connection(page["webSocketDebuggerUrl"], suppress_origin=True, timeout=60)
    state = {"id": 0}

    def cdp(method, **params):
        state["id"] += 1
        ws.send(json.dumps({"id": state["id"], "method": method, "params": params}))
        while True:
            r = json.loads(ws.recv())
            if r.get("id") == state["id"]:
                if "error" in r:
                    raise RuntimeError("%s: %s" % (method, r["error"]))
                return r.get("result", {})

    def js(expr, wait=False):
        r = cdp("Runtime.evaluate", expression=expr, awaitPromise=wait, returnByValue=True)
        if r.get("exceptionDetails"):
            raise RuntimeError(json.dumps(r["exceptionDetails"])[:400])
        return r.get("result", {}).get("value")

    def shot(name):
        data = cdp("Page.captureScreenshot", format="png")["data"]
        with open(os.path.join(HERE, name), "wb") as f:
            f.write(base64.b64decode(data))
        print("saved", name)

    cdp("Emulation.setDeviceMetricsOverride", width=W, height=H, deviceScaleFactor=2, mobile=False)
    cdp("Page.enable")
    cdp("Page.navigate", url=URL)
    time.sleep(3)
    js("localStorage.setItem('fmm_lang', 'en'); 1")
    cdp("Page.reload")
    time.sleep(3.5)
    # the task of the run (P2, target (1,0)); orders from the rule
    vals = {"thickness_nm": "300", "lx_nm": "3000", "ly_nm": "500", "nx": "600", "ny": "100", "tm": "1", "tn": "0",
            "seeds": "151014"}
    for k, v in vals.items():
        js("(() => { const e = document.getElementById(%s); e.value = %s; "
           "e.dispatchEvent(new Event('input', {bubbles: true})); e.dispatchEvent(new Event('change', {bubbles: true})); return 1; })()"
           % (json.dumps(k), json.dumps(v)))
    js("document.getElementById('btn_rule').click(); 1")
    time.sleep(2)
    print(js("['mx','my','gx','gy','levels_certify','tm','seeds'].map(i => i + '=' + document.getElementById(i).value).join(' ')"))
    js("loadRun(%s)" % json.dumps(RUN), wait=True)
    time.sleep(2.5)
    js("document.getElementById('panel').scrollTop = 0; document.getElementById('content').scrollTop = 0; 1")
    time.sleep(0.5)
    rects = js(r"""(() => {
      const R = e => { const r = e.getBoundingClientRect(); return [r.left, r.top, r.width, r.height]; };
      const out = {};
      const fs = document.querySelectorAll('#panel fieldset');
      ['incidence', 'materials', 'period', 'orders', 'fabrication'].forEach((k, i) => out['fs_' + k] = R(fs[i]));
      ['mx', 'my', 'gx', 'gy', 'levels_certify', 'tm', 'tn', 'btn_rule'].forEach(id => out['in_' + id] = R(document.getElementById(id)));
      const hint = Array.from(document.querySelectorAll('#panel *')).find(e => e.children.length === 0 && /Order rule \(target order/.test(e.textContent));
      if (hint) out.rule_line = R(hint);
      out.tabs = R(document.getElementById('tabs'));
      document.querySelectorAll('#summary_cards .card').forEach((c, i) => out['card' + i] = R(c));
      out.repair = R(document.getElementById('repair_block'));
      const tb = document.getElementById('tickets_block');
      out.tickets_h3 = R(tb.querySelector('h3'));
      out.tickets_table = R(document.getElementById('tickets_table'));
      out.guard_table = R(document.getElementById('guard_table'));
      out.guard_h3 = R(tb.querySelectorAll('h3')[1]);
      const h3s = Array.from(document.querySelectorAll('#tab-summary > h3'));
      out.ladder_h3 = R(h3s.find(h => /Certification ladder/.test(h.textContent)));
      out.ladder_table = R(document.getElementById('certify_table'));
      out.robust_h3 = R(h3s.find(h => /Robustness/.test(h.textContent)));
      return out; })()""")
    with open(os.path.join(HERE, "fig5_rects.json"), "w") as f:
        json.dump(rects, f, indent=1)
    shot("fig5_raw_summary.png")
    js("switchTab('torcwa'); 1")
    time.sleep(2.5)
    shot("fig5_raw_engine.png")
    js("switchTab('jobs'); 1")
    time.sleep(2.5)
    shot("fig5_raw_progress.png")
    ws.close()
finally:
    proc.terminate()
    try:
        proc.wait(timeout=10)
    except Exception:
        proc.kill()
