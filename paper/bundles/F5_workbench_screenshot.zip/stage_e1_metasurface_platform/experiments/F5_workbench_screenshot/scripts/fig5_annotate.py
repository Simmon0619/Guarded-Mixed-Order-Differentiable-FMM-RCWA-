"""Fig. 5: the FMM Workbench after the run of Fig. 4(a,b) (P2, target (1,0), seed 151014), Summary tab.
Input: data/fig5_raw_summary.png (headless Chrome, 1360 x 1080 CSS px at scale 2, scripts/capture_fig5.py) and
data/fig5_rects.json (element boxes in CSS px). Output: figures/fig5_workbench.(png|pdf).
Style (user rulings): Times New Roman, colour = truncation order (M_d #0d0887, M_g #aa2395, M_r #f89540), text in ink;
numbered callouts in reading order, explained in the caption."""
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, FancyBboxPatch
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "..", "data")
FIG = os.path.join(HERE, "..", "figures")
INK = "#0b0b0b"
MD, MG, MR = "#0d0887", "#aa2395", "#f89540"
S = 2                      # device scale factor of the capture
PAD_L = 26                 # white margin (CSS px) left of the screenshot, for the badges
Y_END = 1046               # crop (CSS px): above the "Robustness audit" heading
W_MM = 180.0

plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman"], "font.weight": "bold"})
img = Image.open(os.path.join(DATA, "fig5_raw_summary.png")).convert("RGB")
img = img.crop((0, 0, img.width, Y_END * S))
R = {k: v for k, v in json.load(open(os.path.join(DATA, "fig5_rects.json"))).items()}

wcss, hcss = img.width / S + PAD_L, Y_END
fig = plt.figure(figsize=(W_MM / 25.4, W_MM / 25.4 * hcss / wcss))
ax = fig.add_axes([0, 0, 1, 1])
ax.set_xlim(-PAD_L, img.width / S); ax.set_ylim(Y_END, 0); ax.axis("off")
ax.imshow(img, extent=[0, img.width / S, Y_END, 0], interpolation="lanczos")


def box(x0, y0, x1, y1, color=INK, lw=0.9, pad=4):
    ax.add_patch(FancyBboxPatch((x0 - pad, y0 - pad), x1 - x0 + 2 * pad, y1 - y0 + 2 * pad,
                                boxstyle="round,pad=0,rounding_size=4", fc="none", ec=color, lw=lw, zorder=3))


def badge(cx, cy, n):
    ax.add_patch(Circle((cx, cy), 11.5, fc=INK, ec="white", lw=0.8, zorder=5))
    ax.text(cx, cy + 0.6, str(n), ha="center", va="center", color="white", fontsize=8.2, fontweight="bold", zorder=6)


def rect(k):
    x, y, w, h = R[k]
    return x, y, x + w, y + h


def union(*ks):
    rs = [rect(k) for k in ks]
    return min(r[0] for r in rs), min(r[1] for r in rs), max(r[2] for r in rs), max(r[3] for r in rs)


GX = 361.5                                   # gutter between the panel and the result page
# 1 task, 2 orders (left panel)
x0, y0, x1, y1 = union("fs_incidence", "fs_period")
box(x0, y0, x1, y1); badge(-8, y0 + 12, 1)
x0, y0, x1, y1 = rect("fs_orders")
box(x0, y0, x1, y1); badge(-8, y0 + 12, 2)
box(*union("in_mx", "in_my"), color=MD, lw=1.4, pad=3)
box(*union("in_gx", "in_gy"), color=MG, lw=1.4, pad=3)
box(*rect("in_levels_certify"), color=MR, lw=1.4, pad=3)
# 3 values of the delivered pattern; 4 delivered checkpoint (right column, top down)
box(*rect("card0"), color=MR, lw=1.5, pad=2)
box(*rect("card2"), color=MG, lw=1.5, pad=2)
badge(GX, R["card0"][1] + 12, 3)
box(*rect("card5"), pad=2); badge(R["card5"][0] - 1, R["card5"][1] + 1, 4)
# 5 refinement, 6 per-run table, 7 screen statistics, 8 the ladder
x, y, w, h = R["repair"]; box(x, y, x + 382, y + h); badge(GX, y + 12, 5)
x0, y0, x1, y1 = union("tickets_h3", "tickets_table"); box(x0, y0, x1, y1); badge(GX, y0 + 12, 6)
x0, y0, x1, y1 = union("guard_h3", "guard_table"); box(x0, y0, x0 + 613, y1); badge(GX, y0 + 12, 7)
x0, y0, x1, y1 = union("ladder_h3", "ladder_table"); box(x0, y0, x0 + 228, y1 - 4); badge(GX, y0 + 12, 8)

os.makedirs(FIG, exist_ok=True)
for ext, dpi in (("png", 400), ("pdf", 400)):
    fig.savefig(os.path.join(FIG, "fig5_workbench." + ext), dpi=dpi)
plt.close(fig)
print("saved fig5_workbench", img.size)
