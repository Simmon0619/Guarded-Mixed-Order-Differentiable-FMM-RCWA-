"""Attribution diagnostic for acceptance (d): is a per-seed delivered
difference caused by precision (bounded error) or by trajectory chaos
(exponential divergence of the SAME descent under a 1e-5 gradient
perturbation)?

Runs the first N steps of the (2,0)/2030 torcwa_M12 trajectory twice --
c128/CPU and c64/GPU -- from the identical initial latent, and records the
relative latent distance after every step.  Exponential growth with a
positive rate means no precision fix short of bitwise identity can keep two
implementations on the same trajectory, and per-seed delivered equality is
the wrong acceptance metric (the distributional one is right).

    python e17_divergence.py          # writes ../data/divergence.json
"""
import json
import os

import torch

from e17_common import C, CPU, DATA, GPU, THREADS

TARGET = (2, 0)
SEED = 2030
LEVEL = (12, 3)
BUDGET = 120.0
N_STEPS = 60


def main():
    torch.set_num_threads(THREADS)
    rho_a = C.initial_latent(SEED, CPU)
    rho_b = C.initial_latent(SEED, GPU)
    adam_a, adam_b = C.Adam(rho_a.shape, CPU), C.Adam(rho_b.shape, GPU)
    units = 0.0
    lv = LEVEL
    dist = []
    for step in range(N_STEPS):
        progress = units / BUDGET
        beta = C.beta_at(progress, cfg=CPU)
        lr = C.cosine_lr(progress, CPU)
        _, ga = C.value_grad_latent(rho_a, lv, TARGET, beta, CPU)
        _, gb = C.value_grad_latent(rho_b, lv, TARGET, beta, GPU)
        units += C.cost_fwd(lv, CPU) + C.cost_bwd(lv, CPU)
        # keep the unit/beta stream identical to the arm's (audit every 6)
        if step % 6 == 0:
            units += C.cost_fwd(lv, CPU)
        rho_a = adam_a.step(rho_a, ga, lr)
        rho_b = adam_b.step(rho_b, gb, lr)
        d = float((rho_a - rho_b.cpu()).norm() / rho_a.norm())
        gcos = float(torch.dot(ga.flatten().double(),
                               gb.cpu().flatten().double())
                     / (ga.norm() * gb.cpu().norm() + 1e-30))
        dist.append({"step": step, "rel_latent_dist": d, "grad_cosine": gcos})
        if step % 10 == 0:
            print("step %3d: rel latent dist %.3e   grad cos %.8f"
                  % (step, d, gcos))
    path = os.path.join(DATA, "divergence.json")
    with open(path, "w") as f:
        json.dump({"rows": dist, "target": list(TARGET), "seed": SEED,
                   "steps": N_STEPS}, f, indent=1)
    d0 = next((r for r in dist if r["rel_latent_dist"] > 0), None)
    print()
    if d0 is not None and dist[-1]["rel_latent_dist"] > 0:
        import math
        span = dist[-1]["step"] - d0["step"]
        rate = (math.log(dist[-1]["rel_latent_dist"])
                - math.log(d0["rel_latent_dist"])) / max(span, 1)
        print("first nonzero at step %d (%.1e); final %.1e; "
              "mean log-growth %.3f/step -> %s"
              % (d0["step"], d0["rel_latent_dist"],
                 dist[-1]["rel_latent_dist"], rate,
                 "CHAOTIC divergence" if rate > 0.05 else "bounded drift"))
    print("wrote %s" % path)


if __name__ == "__main__":
    main()
