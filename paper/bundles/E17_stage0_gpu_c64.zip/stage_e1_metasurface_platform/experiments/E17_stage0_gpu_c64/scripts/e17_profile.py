"""Where does the GPU c64 solve spend its 1.4 s?  Sub-step attribution.

The parity run measured our solver at (12,3): CPU/c128 1.414 s, GPU/c64
1.417 s -- a 1.0x "speedup", against TORCWA's 0.105 s on the same GPU.  This
script times the individual pieces of one solve to find out whether one line
dominates (fixable) or launch overhead is spread everywhere (not fixable
without a rewrite).

    python e17_profile.py
"""
import time

import torch

from e17_common import C, CPU, GPU, THREADS, load_latent
from trustworthy_fmm.fourier.factorization import (FFT_BASELINE,
                                                   transverse_permittivity_2d)


def sync(dev):
    if dev == "cuda":
        torch.cuda.synchronize()


def timeit(fn, dev, n=5):
    fn()                      # warm
    sync(dev)
    ts = []
    for _ in range(n):
        t0 = time.perf_counter()
        fn()
        sync(dev)
        ts.append(time.perf_counter() - t0)
    return sorted(ts)[n // 2]


def profile(cfg, label):
    dev = cfg.device
    lat = load_latent("2_0_2030_torcwa_M12_latent.npy")
    dens = C.projected(lat, 8.0, CPU)
    eps = C._eps(dens, cfg)
    lv = (12, 3)
    mx, my = lv
    count = (2 * mx + 1) * (2 * my + 1)
    dt = eps.dtype

    print("== %s  (dtype %s, device %s, n_terms %d)" % (label, dt, dev, count))

    t = timeit(lambda: transverse_permittivity_2d(
        eps, lv, FFT_BASELINE, lattice_nm=cfg.lattice_nm), dev)
    print("  conv-matrix build       : %7.4f s" % t)

    eps_conv, transverse_eps, _ = transverse_permittivity_2d(
        eps, lv, FFT_BASELINE, lattice_nm=cfg.lattice_nm)
    kx = torch.randn(count, dtype=dt, device=eps.device)
    kxm = torch.diag(kx)
    kym = torch.diag(torch.randn(count, dtype=dt, device=eps.device))
    identity = torch.eye(count, dtype=dt, device=eps.device)
    zeros = torch.zeros_like(identity)
    left = torch.cat((kxm, kym), dim=0)
    p_right = torch.cat((kym, -kxm), dim=1)

    t = timeit(lambda: torch.linalg.solve(eps_conv, p_right), dev)
    print("  solve(eps_conv, ...)    : %7.4f s" % t)

    p_base = torch.cat((torch.cat((zeros, identity), 1),
                        torch.cat((-identity, zeros), 1)), 0)
    q_base = -transverse_eps @ p_base
    p_matrix = p_base + left @ torch.linalg.solve(eps_conv, p_right)
    q_matrix = q_base + left @ torch.cat((-kym, kxm), dim=1)
    pq = p_matrix @ q_matrix

    t = timeit(lambda: torch.linalg.eig(pq), dev)
    print("  linalg.eig(PQ)          : %7.4f s" % t)

    w = torch.linalg.eig(pq)[1]
    t = timeit(lambda: torch.linalg.cond(w), dev)
    print("  linalg.cond(W)  [SVD]   : %7.4f s" % t)

    t = timeit(lambda: torch.linalg.solve(p_matrix, w), dev)
    print("  solve(P, W)             : %7.4f s" % t)

    # full forward, no grad
    def fwd():
        with torch.no_grad():
            C._solve(eps, lv, cfg)
    t = timeit(fwd, dev)
    print("  FULL forward (no grad)  : %7.4f s" % t)

    # full value+grad through design map
    rho = lat if dev == "cpu" else lat.to(dev)
    def vg():
        C.value_grad_latent(rho, lv, (2, 0), 8.0, cfg)
    t = timeit(vg, dev)
    print("  FULL value+grad         : %7.4f s" % t)


def main():
    torch.set_num_threads(THREADS)
    profile(CPU, "CPU / c128")
    profile(GPU, "GPU / c64")


if __name__ == "__main__":
    main()
