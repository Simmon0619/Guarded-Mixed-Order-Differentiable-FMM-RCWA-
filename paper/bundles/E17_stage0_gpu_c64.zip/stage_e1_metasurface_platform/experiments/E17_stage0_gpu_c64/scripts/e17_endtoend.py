"""Stage-0 acceptance (d): a full torcwa_M12 arm with descent on GPU/c64.

Line-for-line port of e10_arms.run_torcwa_style with one addition -- a ``cfg``
parameter -- so the inherited script stays untouched.  Budget-units mode keeps
the step count identical to the frozen c128 baseline (219 steps); the only
independent variable is descent precision/device.  Delivered binaries are
scored at (24,6)/(28,7) in c128/CPU (audit path), then compared per-seed with
the frozen baseline in data/main/scores.json.

    python e17_endtoend.py          # (2,0) x {2029,2030,2031}
"""
import json
import os
import time

import torch

from e17_common import C, CPU, DATA, GPU, THREADS

TARGET = (2, 0)
SEEDS = [2029, 2030, 2031]
LEVEL = (12, 3)
ACCEPT_REL = 0.024      # reference-self MAD of the frozen campaign
BUDGET = 120.0          # the frozen campaign ran --budget 120 (219 steps),
                        # NOT the ProblemConfig default of 60 (data/main
                        # s2_0_runs.json _meta.budget_units = 120.0)


def run_torcwa_style_cfg(target, seed, level, cfg, budget=None,
                         binary_audit_every=6):
    """e10_arms.run_torcwa_style, budget-units branch only, + cfg."""
    lv = tuple(level)
    budget = BUDGET if budget is None else budget
    rho = C.initial_latent(seed, cfg)
    adam = C.Adam(rho.shape, cfg)
    units = 0.0
    t0 = time.perf_counter()
    best_bin = C.hard_binary(rho, cfg)
    best_self = -float("inf")
    history, n_audits = [], 0
    step = 0
    while True:
        if units + C.cost_fwd(lv, cfg) + C.cost_bwd(lv, cfg) > budget:
            break
        progress = units / budget
        beta = C.beta_at(progress, cfg=cfg)
        lr = C.cosine_lr(progress, cfg)
        j, g = C.value_grad_latent(rho, lv, target, beta, cfg)
        units += C.cost_fwd(lv, cfg) + C.cost_bwd(lv, cfg)
        if step % binary_audit_every == 0 and \
                units + C.cost_fwd(lv, cfg) <= budget:
            b = C.hard_binary(rho, cfg)
            self_score = C.forward_density(b, lv, target, cfg)
            units += C.cost_fwd(lv, cfg)
            n_audits += 1
            if self_score > best_self:
                best_self, best_bin = self_score, b
        history.append({"step": step, "soft": j, "beta": beta})
        rho = adam.step(rho, g, lr)
        step += 1
    b = C.hard_binary(rho, cfg)
    self_score = C.forward_density(b, lv, target, cfg)
    units += C.cost_fwd(lv, cfg)
    if self_score > best_self:
        best_self, best_bin = self_score, b
    return {
        "delivered_binary": best_bin,
        "units": units,
        "wall_s": time.perf_counter() - t0,
        "steps": step,
        "audits": n_audits,
        "self_reported_binary": best_self,
    }


def main():
    torch.set_num_threads(THREADS)
    base = json.load(open(os.path.join(
        os.path.dirname(DATA), "..", "E16_inherited_baseline", "data", "main",
        "scores.json")))
    ref = {}
    for k, v in base.items():
        if k.startswith("_"):
            continue
        if v["arm"] == "torcwa_M12" and tuple(v["target"]) == TARGET:
            ref[v["seed"]] = {"24,6": v["blind"]["24,6"],
                              "28,7": v["blind"]["28,7"],
                              "wall_s": v.get("wall_s")}
    print("frozen c128 baseline, torcwa_M12 @ %s: %s"
          % (TARGET, {s: round(r["24,6"], 4) for s, r in ref.items()}))

    # GPU warmup, untimed
    warm = C.initial_latent(SEEDS[0], GPU)
    C.value_grad_latent(warm, LEVEL, TARGET, 8.0, GPU)
    torch.cuda.synchronize()

    # Two experimental arms against the frozen baseline:
    #   gpu_c64      -- the stage-0 candidate;
    #   cpu_c128fast -- identical numerics to the baseline except the
    #                   vectorized-conv gradient accumulation order (~1e-16).
    #                   Its per-seed drift measures the chaos horizon: any
    #                   divergence here bounds what per-seed agreement ANY
    #                   implementation change could achieve.
    arms = [("gpu_c64", GPU), ("cpu_c128fast", CPU)]
    rows = []
    for arm_name, cfg in arms:
        for seed in SEEDS:
            r = run_torcwa_style_cfg(TARGET, seed, LEVEL, cfg)
            b = r["delivered_binary"].cpu()
            eta24 = C.forward_density(b, (24, 6), TARGET, CPU, audit=True)
            eta28 = C.forward_density(b, (28, 7), TARGET, CPU, audit=True)
            ref24 = ref[seed]["24,6"]
            d = abs(eta24 - ref24) / max(abs(ref24), 1e-12)
            rows.append({
                "arm": arm_name, "seed": seed, "steps": r["steps"],
                "units": r["units"], "wall_s": r["wall_s"],
                "self_reported": r["self_reported_binary"],
                "eta24": eta24, "eta28": eta28,
                "eta24_c128baseline": ref24,
                "eta28_c128baseline": ref[seed]["28,7"],
                "rel_diff_24_6": d,
                "within_mad": d <= ACCEPT_REL,
            })
            print("%s seed %d: %d steps, wall %.0f s | eta24 %.4f vs "
                  "baseline %.4f (rel diff %.1f%%) %s"
                  % (arm_name, seed, r["steps"], r["wall_s"], eta24, ref24,
                     100 * d, "OK" if d <= ACCEPT_REL else "DIFF"))

    summary = {"target": list(TARGET), "level": list(LEVEL), "arms": {}}
    best_ref = max(ref[s]["24,6"] for s in SEEDS)
    for arm_name, _ in arms:
        sub = [r for r in rows if r["arm"] == arm_name]
        best = max(r["eta24"] for r in sub)
        summary["arms"][arm_name] = {
            "per_seed_within_mad": [r["within_mad"] for r in sub],
            "per_seed_rel_diff": [r["rel_diff_24_6"] for r in sub],
            "best_of_3": best,
            "best_of_3_baseline": best_ref,
            "best_rel_diff": abs(best - best_ref) / best_ref,
            "wall_s_median": sorted(r["wall_s"] for r in sub)[1],
        }
    summary["environment"] = {"threads": THREADS, "torch": torch.__version__,
                              "gpu": torch.cuda.get_device_name(0)}
    out = {"summary": summary, "rows": rows}
    path = os.path.join(DATA, "endtoend.json")
    with open(path, "w") as f:
        json.dump(out, f, indent=1)
    print()
    for arm_name, _ in arms:
        a = summary["arms"][arm_name]
        print("%s: best-of-3 %.4f vs baseline %.4f (rel diff %.1f%%); "
              "per-seed within-MAD %s"
              % (arm_name, a["best_of_3"], best_ref,
                 100 * a["best_rel_diff"], a["per_seed_within_mad"]))
    print("wrote %s" % path)


if __name__ == "__main__":
    main()
