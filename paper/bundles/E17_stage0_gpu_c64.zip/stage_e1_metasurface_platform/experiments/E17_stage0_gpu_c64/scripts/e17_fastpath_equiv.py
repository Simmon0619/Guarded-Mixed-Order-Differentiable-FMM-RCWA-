"""Equivalence audit of the opt-in fast paths (vectorized conv + skipped
diagnostics) against the frozen loop-based implementation.

Claims to verify, on real delivered designs at several levels/betas:
  1. conv matrix: bitwise-identical elements (torch.equal);
  2. forward eta: bitwise identical (float.hex comparison);
  3. gradient: accumulation-order (last-ulp) differences ONLY --
     report max |rel| component diff and 1-cosine;
  4. FAST_DIAGNOSTICS: eta and gradient bitwise identical with and without.

    python e17_fastpath_equiv.py      # writes ../data/fastpath_equiv.json
"""
import importlib
import json
import os

import torch

import e17_common
from e17_common import C, CPU, DATA, THREADS, load_latent

import trustworthy_fmm.fourier.convolution as conv
import trustworthy_fmm.solvers.vector_2d as v2d
from trustworthy_fmm.fourier.convolution import convolution_matrix_2d

SAMPLES = [
    ("1_0_2031_certified_screened_latent.npy", (1, 0)),
    ("2_0_2030_torcwa_M12_latent.npy", (2, 0)),
    ("3_0_2029_torcwa_M12_latent.npy", (3, 0)),
]
LEVELS = [(12, 3), (24, 6)]
BETAS = [8.0, 64.0]


def main():
    torch.set_num_threads(THREADS)
    report = {"conv_bitwise": [], "eta": [], "grad": [], "fast_diag": []}

    # -- 1. conv matrix bitwise ---------------------------------------------
    for name, tgt in SAMPLES:
        lat = load_latent(name)
        for beta in BETAS:
            dens = C.projected(lat, beta, CPU)
            eps = C._eps(dens, CPU)
            for lv in LEVELS:
                conv.VECTORIZED_CONV = False
                slow = convolution_matrix_2d(eps, lv)
                conv.VECTORIZED_CONV = True
                fast = convolution_matrix_2d(eps, lv)
                same = bool(torch.equal(slow, fast))
                report["conv_bitwise"].append(
                    {"latent": name, "beta": beta, "level": list(lv),
                     "bitwise": same})
                assert same, "conv matrix not bitwise identical!"

    # -- 2/3. eta bitwise + gradient ulp ------------------------------------
    for name, tgt in SAMPLES:
        lat = load_latent(name)
        for beta in BETAS:
            conv.VECTORIZED_CONV = False
            j_slow, g_slow = C.value_grad_latent(lat, (12, 3), tgt, beta, CPU)
            conv.VECTORIZED_CONV = True
            j_fast, g_fast = C.value_grad_latent(lat, (12, 3), tgt, beta, CPU)
            eta_bitwise = float(j_slow).hex() == float(j_fast).hex()
            diff = (g_fast - g_slow)
            denom = g_slow.abs().max()
            max_rel = float(diff.abs().max() / (denom + 1e-300))
            cos = float(torch.dot(g_slow.flatten(), g_fast.flatten())
                        / (g_slow.norm() * g_fast.norm() + 1e-300))
            report["eta"].append({"latent": name, "beta": beta,
                                  "bitwise": eta_bitwise,
                                  "j_slow": j_slow, "j_fast": j_fast})
            report["grad"].append({"latent": name, "beta": beta,
                                   "max_rel_component_diff": max_rel,
                                   "one_minus_cosine": 1.0 - cos})
            print("%s b=%g: eta bitwise %s   grad max-rel %.2e   1-cos %.2e"
                  % (name.split("_latent")[0], beta, eta_bitwise, max_rel,
                     1.0 - cos))

    # -- 4. FAST_DIAGNOSTICS neutrality (fast conv held ON) ------------------
    for name, tgt in SAMPLES[:1]:
        lat = load_latent(name)
        v2d.FAST_DIAGNOSTICS = False
        j0, g0 = C.value_grad_latent(lat, (12, 3), tgt, 8.0, CPU)
        v2d.FAST_DIAGNOSTICS = True
        j1, g1 = C.value_grad_latent(lat, (12, 3), tgt, 8.0, CPU)
        v2d.FAST_DIAGNOSTICS = False
        same = float(j0).hex() == float(j1).hex() and bool(torch.equal(g0, g1))
        report["fast_diag"].append({"latent": name, "bitwise": same})
        print("FAST_DIAGNOSTICS neutrality: eta+grad bitwise %s" % same)
        assert same, "diagnostics skip changed numerics!"

    conv.VECTORIZED_CONV = False
    path = os.path.join(DATA, "fastpath_equiv.json")
    with open(path, "w") as f:
        json.dump(report, f, indent=1)
    n_eta_bit = sum(r["bitwise"] for r in report["eta"])
    print()
    print("conv bitwise: %d/%d   eta bitwise: %d/%d   grad max-rel worst: %.2e"
          % (len(report["conv_bitwise"]), len(report["conv_bitwise"]),
             n_eta_bit, len(report["eta"]),
             max(r["max_rel_component_diff"] for r in report["grad"])))
    print("wrote %s" % path)


if __name__ == "__main__":
    main()
