"""E17 stage-0 wiring: descent on GPU/complex64, audits on CPU/complex128.

Nothing in the inherited E16 tree is modified.  This module only *imports*
e10_common and builds config variants; the bitwise regression of the frozen
baseline therefore cannot be affected (verified: p0 --check PASS on 2026-08-31
before any E17 run).

Thread pinning matches p0 (3 threads) so every CPU-side number produced here is
comparable with the frozen baseline.
"""
import os
import sys

import torch

THREADS = int(os.environ.get("P0_THREADS", "3"))
torch.set_num_threads(THREADS)

_HERE = os.path.dirname(os.path.abspath(__file__))
_E16_SCRIPTS = os.path.abspath(os.path.join(
    _HERE, "..", "..", "E16_inherited_baseline", "scripts"))
if _E16_SCRIPTS not in sys.path:
    sys.path.insert(0, _E16_SCRIPTS)

import e10_common as C  # noqa: E402

DESIGNS = os.path.abspath(os.path.join(
    _HERE, "..", "..", "E16_inherited_baseline", "data", "main", "designs"))
DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))

# Descent side: complex64 on CUDA.  audit_dtype/audit_device stay c128/cpu, so
# forward_density(..., audit=True) is bit-compatible with the frozen scorer.
GPU = C.DEFAULT.variant(dtype=torch.complex64, device="cuda")
CPU = C.DEFAULT


def load_latent(name):
    """Delivered latent from the frozen E10 campaign, as a CPU float64 tensor."""
    import numpy as np
    return torch.from_numpy(
        np.load(os.path.join(DESIGNS, name)).astype("float64"))
