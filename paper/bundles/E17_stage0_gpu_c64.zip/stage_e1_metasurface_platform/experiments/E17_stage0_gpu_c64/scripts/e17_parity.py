"""Stage-0 acceptance (a)(b)(c) + microbenchmark.

(a) c64/GPU forward value vs c128/CPU reference, relative error <= 1e-4;
(b) gradient cosine (d eta / d latent, through the full design map) >= 0.9999;
(c) both must hold specifically on the near-degenerate tail, ranked by the
    solver's own min_eigen_gap and modal_condition diagnostics, plus a
    deliberately constructed near-degenerate sample from an interpolation scan.

All 63 delivered latents x beta in {1, 8, 64} at the descent level (12,3),
plus hard-binary forwards at (12,3) and (24,6).  Reference side always
c128/CPU at 3 pinned threads (p0 convention).

    python e17_parity.py            # full run, writes ../data/parity.json
"""
import glob
import json
import os
import time

import torch

from e17_common import C, CPU, DATA, DESIGNS, GPU, THREADS, load_latent

LV = (12, 3)
BETAS = [1.0, 8.0, 64.0]
VAL_TOL = 1e-4
COS_TOL = 0.9999


def rel(a, b):
    return abs(a - b) / max(abs(b), 1e-12)


def cosine(g1, g2):
    g1 = g1.double().flatten().cpu()
    g2 = g2.double().flatten().cpu()
    return float(torch.dot(g1, g2) / (g1.norm() * g2.norm() + 1e-30))


def diagnostics_cpu(density, level, cfg=CPU):
    """One no-grad c128/CPU solve, returning (min_eigen_gap, modal_cond, eig_range)."""
    with torch.no_grad():
        r = C._solve(C._eps(density, cfg), level, cfg)
        gap = float(r.diagnostics["min_eigen_gap"])
        cond = float(r.diagnostics["modal_condition"])
    return gap, cond


def target_of(name):
    m, n = name.split("_")[0], name.split("_")[1]
    return (int(m), int(n))


def main():
    torch.set_num_threads(THREADS)
    assert torch.cuda.is_available(), "stage 0 requires CUDA"
    lat_names = sorted(os.path.basename(p) for p in
                       glob.glob(os.path.join(DESIGNS, "*_latent.npy")))
    print("%d delivered latents; levels %s; betas %s; threads %d"
          % (len(lat_names), (LV,), BETAS, THREADS))

    # -- GPU warmup (context + cuFFT/eig plans), untimed
    warm = load_latent(lat_names[0]).to("cuda")
    C.value_grad_latent(warm, LV, target_of(lat_names[0]), 8.0, cfg=GPU)
    torch.cuda.synchronize()

    rows = []
    t_start = time.perf_counter()
    for i, name in enumerate(lat_names):
        lat = load_latent(name)
        tgt = target_of(name)
        for beta in BETAS:
            j_ref, g_ref = C.value_grad_latent(lat, LV, tgt, beta, cfg=CPU)
            j_gpu, g_gpu = C.value_grad_latent(lat.to("cuda"), LV, tgt, beta,
                                               cfg=GPU)
            gap, cond = diagnostics_cpu(C.projected(lat, beta, CPU), LV)
            rows.append({
                "latent": name, "target": list(tgt), "beta": beta,
                "level": list(LV),
                "j_c128": j_ref, "j_c64": j_gpu,
                "rel_value_err": rel(j_gpu, j_ref),
                "grad_cosine": cosine(g_gpu, g_ref),
                "min_eigen_gap": gap, "modal_condition": cond,
            })
        if (i + 1) % 10 == 0:
            print("  %d/%d latents  (%.0f s)"
                  % (i + 1, len(lat_names), time.perf_counter() - t_start))

    # -- hard binary forwards (delivered objects; forward-only parity)
    bin_rows = []
    for name in lat_names[::5]:
        lat = load_latent(name)
        tgt = target_of(name)
        b = C.hard_binary(lat, CPU)
        for lv in [(12, 3), (24, 6)]:
            with torch.no_grad():
                r_ref = C._solve(C._eps(b, CPU), lv, CPU)
                j_ref = float(r_ref.power_t[r_ref.orders.index(tgt)])
                r_gpu = C._solve(C._eps(b.to("cuda"), GPU), lv, GPU)
                j_gpu = float(r_gpu.power_t[r_gpu.orders.index(tgt)])
            bin_rows.append({"latent": name, "target": list(tgt),
                             "level": list(lv), "j_c128": j_ref,
                             "j_c64": j_gpu, "rel_value_err": rel(j_gpu, j_ref)})

    # -- constructed near-degenerate sample: interpolation scan at beta=64
    la = load_latent("2_0_2030_torcwa_M12_latent.npy")
    lb = load_latent("3_0_2029_torcwa_M12_latent.npy")
    scan = []
    for k in range(21):
        t = k / 20.0
        mix = (1 - t) * la + t * lb
        gap, cond = diagnostics_cpu(C.projected(mix, 64.0, CPU), LV)
        scan.append((cond, gap, t))
    scan.sort(reverse=True)          # worst modal condition first
    worst_cond, worst_gap, worst_t = scan[0]
    mix = (1 - worst_t) * la + worst_t * lb
    j_ref, g_ref = C.value_grad_latent(mix, LV, (2, 0), 64.0, cfg=CPU)
    j_gpu, g_gpu = C.value_grad_latent(mix.to("cuda"), LV, (2, 0), 64.0,
                                       cfg=GPU)
    constructed = {
        "t": worst_t, "min_eigen_gap": worst_gap,
        "modal_condition": worst_cond,
        "j_c128": j_ref, "j_c64": j_gpu,
        "rel_value_err": rel(j_gpu, j_ref),
        "grad_cosine": cosine(g_gpu, g_ref),
    }

    # -- microbenchmark: one value+gradient, median of 5
    bench = {}
    lat = load_latent("2_0_2030_torcwa_M12_latent.npy")
    for lv in [(8, 2), (12, 3), (16, 4), (24, 6)]:
        ts = []
        for _ in range(5):
            t0 = time.perf_counter()
            C.value_grad_latent(lat, lv, (2, 0), 8.0, cfg=CPU)
            ts.append(time.perf_counter() - t0)
        cpu_s = sorted(ts)[2]
        lg = lat.to("cuda")
        C.value_grad_latent(lg, lv, (2, 0), 8.0, cfg=GPU)   # warm
        torch.cuda.synchronize()
        ts = []
        for _ in range(5):
            t0 = time.perf_counter()
            C.value_grad_latent(lg, lv, (2, 0), 8.0, cfg=GPU)
            torch.cuda.synchronize()
            ts.append(time.perf_counter() - t0)
        gpu_s = sorted(ts)[2]
        bench[str(lv)] = {"cpu_c128_s": cpu_s, "gpu_c64_s": gpu_s,
                          "speedup": cpu_s / gpu_s}
        print("bench %s: cpu %.3f s  gpu %.3f s  (%.1fx)"
              % (lv, cpu_s, gpu_s, cpu_s / gpu_s))

    # -- summary + verdicts -------------------------------------------------
    vals = [r["rel_value_err"] for r in rows] + [r["rel_value_err"] for r in bin_rows]
    coss = [r["grad_cosine"] for r in rows]
    conds = sorted(rows, key=lambda r: -r["modal_condition"])
    tail = conds[:15]                       # near-degenerate tail by cond
    gaps = sorted(rows, key=lambda r: r["min_eigen_gap"])[:15]
    tail_names = {(r["latent"], r["beta"]) for r in tail} | \
                 {(r["latent"], r["beta"]) for r in gaps}
    tail_rows = [r for r in rows if (r["latent"], r["beta"]) in tail_names]

    pass_a = max(vals) <= VAL_TOL
    pass_b = min(coss) >= COS_TOL
    pass_c = (min(r["grad_cosine"] for r in tail_rows) >= COS_TOL
              and max(r["rel_value_err"] for r in tail_rows) <= VAL_TOL
              and constructed["grad_cosine"] >= COS_TOL
              and constructed["rel_value_err"] <= VAL_TOL)

    summary = {
        "n_latents": len(lat_names), "n_projected_samples": len(rows),
        "n_binary_samples": len(bin_rows),
        "value_err_max": max(vals),
        "value_err_median": sorted(vals)[len(vals) // 2],
        "grad_cosine_min": min(coss),
        "grad_cosine_median": sorted(coss)[len(coss) // 2],
        "near_degenerate_tail_n": len(tail_rows),
        "tail_grad_cosine_min": min(r["grad_cosine"] for r in tail_rows),
        "tail_value_err_max": max(r["rel_value_err"] for r in tail_rows),
        "tail_modal_condition_range": [
            min(r["modal_condition"] for r in tail_rows),
            max(r["modal_condition"] for r in tail_rows)],
        "all_modal_condition_range": [
            min(r["modal_condition"] for r in rows),
            max(r["modal_condition"] for r in rows)],
        "all_min_eigen_gap_range": [
            min(r["min_eigen_gap"] for r in rows),
            max(r["min_eigen_gap"] for r in rows)],
        "constructed_near_degenerate": constructed,
        "bench": bench,
        "pass_a_value": pass_a, "pass_b_gradient": pass_b,
        "pass_c_near_degenerate": pass_c,
        "environment": {"threads": THREADS, "torch": torch.__version__,
                        "gpu": torch.cuda.get_device_name(0)},
    }
    out = {"summary": summary, "projected": rows, "binary": bin_rows}
    path = os.path.join(DATA, "parity.json")
    with open(path, "w") as f:
        json.dump(out, f, indent=1)
    print()
    print("value err: max %.2e  median %.2e   -> (a) %s"
          % (summary["value_err_max"], summary["value_err_median"],
             "PASS" if pass_a else "FAIL"))
    print("grad cos : min %.8f median %.8f   -> (b) %s"
          % (summary["grad_cosine_min"], summary["grad_cosine_median"],
             "PASS" if pass_b else "FAIL"))
    print("near-degenerate tail (n=%d, cond up to %.1e): cos min %.8f, "
          "val max %.2e; constructed (cond %.1e): cos %.8f -> (c) %s"
          % (len(tail_rows), summary["tail_modal_condition_range"][1],
             summary["tail_grad_cosine_min"], summary["tail_value_err_max"],
             constructed["modal_condition"], constructed["grad_cosine"],
             "PASS" if pass_c else "FAIL"))
    print("wrote %s" % path)


if __name__ == "__main__":
    main()
