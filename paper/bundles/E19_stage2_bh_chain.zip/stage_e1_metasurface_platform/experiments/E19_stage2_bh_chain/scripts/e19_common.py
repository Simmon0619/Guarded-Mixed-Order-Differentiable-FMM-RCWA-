"""E19 stage-2 wiring: same conventions as E18 (CPU/c128 + E17 fast paths,
3 pinned threads, audits always c128/CPU)."""
import os
import sys

import numpy as np
import torch

THREADS = int(os.environ.get("P0_THREADS", "3"))
torch.set_num_threads(THREADS)

_HERE = os.path.dirname(os.path.abspath(__file__))
_E16_SCRIPTS = os.path.abspath(os.path.join(
    _HERE, "..", "..", "E16_inherited_baseline", "scripts"))
if _E16_SCRIPTS not in sys.path:
    sys.path.insert(0, _E16_SCRIPTS)

import e10_common as C  # noqa: E402
import trustworthy_fmm.fourier.convolution as _conv  # noqa: E402
import trustworthy_fmm.solvers.vector_2d as _v2d  # noqa: E402

_conv.VECTORIZED_CONV = True     # E17: forward bitwise, grad 1e-16
_v2d.FAST_DIAGNOSTICS = True     # E17: exactly neutral

DESIGNS = os.path.abspath(os.path.join(
    _HERE, "..", "..", "E16_inherited_baseline", "data", "main", "designs"))
DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
CPU = C.DEFAULT
BUDGET = 120.0                   # frozen campaign protocol

BASES = {
    (1, 0): "1_0_2031_certified_screened_latent.npy",
    (2, 0): "2_0_2030_torcwa_M12_latent.npy",
    (3, 0): "3_0_2029_torcwa_M12_latent.npy",
}
FROZEN_BEST_28 = {(1, 0): 0.3976, (2, 0): 0.4895, (3, 0): 0.3710}


def load_latent(name):
    return torch.from_numpy(
        np.load(os.path.join(DESIGNS, name)).astype("float64"))


def filtered_noise(seed, cfg=C.DEFAULT):
    g = torch.Generator().manual_seed(int(seed))
    noise = torch.randn((cfg.ny, cfg.nx), generator=g, dtype=cfg.latent_dtype)
    smooth = C.periodic_gaussian_filter(noise, cfg.lattice_nm, cfg.filter_nm)
    return smooth / smooth.std()


def audit24(binary, target):
    return C.forward_density(binary, (24, 6), target, CPU, audit=True)


def audit28(binary, target):
    return C.forward_density(binary, (28, 7), target, CPU, audit=True)
