"""Final deliverable audit for both E19 arms: blind (28,7) + held-out process
audit ((24,6): +-20 nm CD, 40 nm opening/closing) on each delivered binary.

    python e19_final_audit.py         # writes ../data/final_audit.json
"""
import json
import os

import numpy as np
import torch

from e19_common import (BASES, C, CPU, DATA, FROZEN_BEST_28, THREADS,
                        audit24, audit28)
from trustworthy_fmm.fabrication.process import periodic_binary_morphology

CD_BIAS_NM = [-20.0, 20.0]
MORPH_RADIUS_NM = 40.0


def held_out(mask_t, target):
    mask = mask_t.numpy().astype(bool)
    nominal = audit24(mask_t, target)
    held = {"nominal_24_6": nominal}
    for bias in CD_BIAS_NM:
        pert = torch.from_numpy(C.cd_bias_mask(mask, bias))
        held["cd_{:+.0f}nm".format(bias)] = audit24(pert, target)
    for op in ("opening", "closing"):
        pert = periodic_binary_morphology(mask, op, MORPH_RADIUS_NM,
                                          C.DEFAULT.pixel_yx)
        held["{}_{:.0f}nm".format(op, MORPH_RADIUS_NM)] = audit24(
            torch.from_numpy(np.asarray(pert, dtype=np.float64)), target)
    scen = {k: v for k, v in held.items() if k != "nominal_24_6"}
    held["worst_absolute"] = min(scen.values())
    held["worst_relative"] = min(scen.values()) / max(nominal, 1e-12)
    held["worst_scenario"] = min(scen, key=scen.get)
    return held


def main():
    torch.set_num_threads(THREADS)
    designs_dir = os.path.join(DATA, "designs")
    out = {}
    for tgt in BASES:
        rec = {"frozen_best_28": FROZEN_BEST_28[tgt]}
        for arm in ("bh", "rs"):
            path = os.path.join(designs_dir,
                                "%d_%d_%s_final_binary.npy" % (tgt + (arm,)))
            b = torch.from_numpy(np.load(path).astype("float64"))
            e24 = audit24(b, tgt)
            e28 = audit28(b, tgt)
            held = held_out(b, tgt)
            rec[arm] = {"eta24": e24, "eta28": e28,
                        "drift": (e28 - e24) / max(e24, 1e-12),
                        "vs_frozen_28": (e28 - FROZEN_BEST_28[tgt])
                        / FROZEN_BEST_28[tgt],
                        "held_out": held}
            print("%s %s: eta24 %.4f  eta28 %.4f (%+.1f%% vs frozen best) | "
                  "held-out worst %.4f (%.2f, %s)"
                  % (tgt, arm.upper(), e24, e28,
                     100 * rec[arm]["vs_frozen_28"], held["worst_absolute"],
                     held["worst_relative"], held["worst_scenario"]))
        out[str(tgt)] = rec
    with open(os.path.join(DATA, "final_audit.json"), "w") as f:
        json.dump(out, f, indent=1)
    print("wrote final_audit.json")


if __name__ == "__main__":
    main()
