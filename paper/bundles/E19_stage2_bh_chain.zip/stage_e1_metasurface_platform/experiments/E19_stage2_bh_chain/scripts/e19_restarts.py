"""Arm RS: independent-restart widening at equal wall clock.

Six fresh seeds (3001-3006) through the letter-for-letter frozen torcwa_M12
protocol (budget 120 units, 219 steps, 6-step self-audit cadence,
running-best delivery), on the fast-path implementation.  D-008: an ulp-level
implementation difference is a fresh draw of the same protocol lottery, so
these are valid new restarts.

    python e19_restarts.py            # writes ../data/restarts.json
"""
import json
import os
import time

import numpy as np
import torch

from e19_common import BASES, BUDGET, C, CPU, DATA, THREADS, audit24

SEEDS = [3001, 3002, 3003, 3004, 3005, 3006]
LEVEL = (12, 3)


def run_restart(target, seed):
    """e10_arms.run_torcwa_style, budget branch, cfg-free (frozen DEFAULT)."""
    lv = LEVEL
    rho = C.initial_latent(seed, CPU)
    adam = C.Adam(rho.shape, CPU)
    units = 0.0
    t0 = time.perf_counter()
    best_bin = C.hard_binary(rho, CPU)
    best_self = -float("inf")
    step = 0
    while True:
        if units + C.cost_fwd(lv, CPU) + C.cost_bwd(lv, CPU) > BUDGET:
            break
        progress = units / BUDGET
        beta = C.beta_at(progress, cfg=CPU)
        lr = C.cosine_lr(progress, CPU)
        j, g = C.value_grad_latent(rho, lv, target, beta, CPU)
        units += C.cost_fwd(lv, CPU) + C.cost_bwd(lv, CPU)
        if step % 6 == 0 and units + C.cost_fwd(lv, CPU) <= BUDGET:
            b = C.hard_binary(rho, CPU)
            s = C.forward_density(b, lv, target, CPU)
            units += C.cost_fwd(lv, CPU)
            if s > best_self:
                best_self, best_bin = s, b
        rho = adam.step(rho, g, lr)
        step += 1
    b = C.hard_binary(rho, CPU)
    s = C.forward_density(b, lv, target, CPU)
    if s > best_self:
        best_self, best_bin = s, b
    return {"binary": best_bin, "self": best_self, "steps": step,
            "wall_s": time.perf_counter() - t0}


def main():
    torch.set_num_threads(THREADS)
    designs_dir = os.path.join(DATA, "designs")
    os.makedirs(designs_dir, exist_ok=True)
    out = {"targets": {}}
    for tgt in BASES:
        t0 = time.perf_counter()
        rows = []
        best = None
        for seed in SEEDS:
            r = run_restart(tgt, seed)
            eta = audit24(r["binary"], tgt)
            rows.append({"seed": seed, "self_12_3": r["self"],
                         "eta24": eta, "steps": r["steps"],
                         "wall_s": r["wall_s"]})
            if best is None or eta > best[1]:
                best = (seed, eta, r["binary"])
            print("%s seed %d: self %.4f  eta24 %.4f  (%.0f s)"
                  % (tgt, seed, r["self"], eta, r["wall_s"]), flush=True)
        tag = "%d_%d_rs_final" % tgt
        np.save(os.path.join(designs_dir, tag + "_binary.npy"),
                best[2].numpy())
        out["targets"][str(tgt)] = {
            "rows": rows, "best_seed": best[0], "best_eta24": best[1],
            "wall_s": time.perf_counter() - t0, "files": tag,
        }
        print("%s restarts done: best eta24 %.4f (seed %d, %.0f s)"
              % (tgt, best[1], best[0], time.perf_counter() - t0), flush=True)
    with open(os.path.join(DATA, "restarts.json"), "w") as f:
        json.dump(out, f, indent=1)
    print("wrote restarts.json")


if __name__ == "__main__":
    main()
