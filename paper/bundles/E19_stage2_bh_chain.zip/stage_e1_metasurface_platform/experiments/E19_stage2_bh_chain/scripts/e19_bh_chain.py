"""Arm BH: monotone basin-hopping chain from the incumbent best design.

Jump k: perturb the incumbent latent with filtered noise (seed 5000+k,
alpha cycling {0.1, 0.25, 0.5}), re-descend 30 steps at beta=64 (fresh Adam,
cosine lr 0.02 -> 0, level (12,3)), certify the hard binary at (24,6)/c128,
accept iff it beats the incumbent's (24,6).  30 jumps or the wall budget,
whichever first.

    python e19_bh_chain.py            # writes ../data/bh_chain.json
"""
import json
import os
import time

import numpy as np
import torch

from e19_common import (BASES, C, CPU, DATA, THREADS, audit24, filtered_noise,
                        load_latent)

ALPHAS = [0.1, 0.25, 0.5]
N_JUMPS = 30
STEPS = 30
BETA = 64.0
LEVEL = (12, 3)
WALL_BUDGET_S = 780.0     # per target; matched to the restart arm's measured wall


def redescend(rho0, target):
    rho = rho0.clone()
    adam = C.Adam(rho.shape, CPU)
    for t in range(STEPS):
        lr = C.cosine_lr(t / STEPS, CPU)
        _, g = C.value_grad_latent(rho, LEVEL, target, BETA, CPU)
        rho = adam.step(rho, g, lr)
    return rho


def main():
    torch.set_num_threads(THREADS)
    designs_dir = os.path.join(DATA, "designs")
    os.makedirs(designs_dir, exist_ok=True)
    out = {"targets": {}}
    for tgt, base_name in BASES.items():
        t0 = time.perf_counter()
        incumbent = load_latent(base_name)
        inc_bin = C.hard_binary(incumbent, CPU)
        inc_eta = audit24(inc_bin, tgt)
        start_eta = inc_eta
        jumps = []
        accepts = 0
        for k in range(N_JUMPS):
            if time.perf_counter() - t0 > WALL_BUDGET_S:
                break
            alpha = ALPHAS[k % len(ALPHAS)]
            noise = filtered_noise(5000 + k)
            pert = C.symmetrize(
                (incumbent + alpha * C.DEFAULT.init_scale * noise)
                .clamp(0.0, 1.0))
            rho = redescend(pert, tgt)
            b = C.hard_binary(rho, CPU)
            eta = audit24(b, tgt)
            accepted = eta > inc_eta
            jumps.append({"jump": k, "alpha": alpha, "eta24": eta,
                          "incumbent_before": inc_eta,
                          "accepted": bool(accepted),
                          "wall_s": time.perf_counter() - t0})
            if accepted:
                incumbent, inc_bin, inc_eta = rho, b, eta
                accepts += 1
            print("%s jump %2d a=%.2f: eta24 %.4f  (incumbent %.4f) %s [%.0f s]"
                  % (tgt, k, alpha, eta, inc_eta,
                     "ACCEPT" if accepted else "reject",
                     time.perf_counter() - t0), flush=True)
        tag = "%d_%d_bh_final" % tgt
        np.save(os.path.join(designs_dir, tag + "_binary.npy"),
                inc_bin.numpy())
        np.save(os.path.join(designs_dir, tag + "_latent.npy"),
                incumbent.numpy())
        out["targets"][str(tgt)] = {
            "base": base_name, "start_eta24": start_eta,
            "final_eta24": inc_eta, "accepts": accepts,
            "n_jumps": len(jumps), "jumps": jumps,
            "wall_s": time.perf_counter() - t0, "files": tag,
        }
        print("%s chain done: %.4f -> %.4f (%d/%d accepts, %.0f s)"
              % (tgt, start_eta, inc_eta, accepts, len(jumps),
                 time.perf_counter() - t0), flush=True)
    with open(os.path.join(DATA, "bh_chain.json"), "w") as f:
        json.dump(out, f, indent=1)
    print("wrote bh_chain.json")


if __name__ == "__main__":
    main()
