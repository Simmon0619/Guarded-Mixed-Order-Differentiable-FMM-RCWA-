"""Part 2: (2,0) robust re-route.

Phase 1 harvests mid-nominal candidates: deterministic replay of E22 RS
replicates r=0..5 (each best-of-4 restarts, 20 nm) tracking the delivered
latent, plus the frozen parent; all seven get (nominal, cd+20)@(24,6).
Phase 2 upsamples the two best-maximin starts to 10 nm and runs 40-jump
maximin chains ((16,4) descent, (24,6)@native double audit).  Final: full
held-out (c128) + (32,8)/(40,10).

Preregistered success: any deliverable Pareto-dominates the frozen parent
(nominal(24,6,c128) > 0.4837 AND held-out worst-abs > 0.2055).

    python e28_reroute_2_0.py         # writes ../data/reroute_2_0.json
"""
import json
import os
import sys
import time

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.abspath(os.path.join(
    _HERE, "..", "..", "E26_fine_pixels", "scripts")))
sys.path.insert(0, os.path.abspath(os.path.join(
    _HERE, "..", "..", "E22_power_bh_vs_rs", "scripts")))

import e22_power as E22  # noqa: E402
from e26_common import (C, E16_DESIGNS, FINE, THREADS, eta_c128,  # noqa: E402
                        eta_gpu, filtered_noise, redescend, upsample)
from trustworthy_fmm.fabrication.process import periodic_binary_morphology  # noqa: E402

DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
TGT = (2, 0)
CFG10 = FINE[10]
N_JUMPS = 40
ALPHAS = [0.1, 0.25, 0.5]
PARENT_REF = {"nominal": 0.4837, "worst": 0.2055}


def replay_rs_replicate(rep):
    """E22 rs_replicate with latent tracking (same seeds -> same delivery)."""
    best = (-float("inf"), None, None)
    for j in range(E22.N_RESTARTS):
        seed = 4000 + 10 * rep + j
        lv = (12, 3)
        rho = C.initial_latent(seed, E22.GPU)
        adam = C.Adam(rho.shape, E22.GPU)
        units, step = 0.0, 0
        b_self, b_bin, b_rho = -float("inf"), None, None
        while True:
            if units + C.cost_fwd(lv, E22.GPU) + C.cost_bwd(lv, E22.GPU) \
                    > E22.BUDGET:
                break
            progress = units / E22.BUDGET
            beta = C.beta_at(progress, cfg=E22.GPU)
            lr = C.cosine_lr(progress, E22.GPU)
            _, g = C.value_grad_latent(rho, lv, TGT, beta, E22.GPU)
            units += C.cost_fwd(lv, E22.GPU) + C.cost_bwd(lv, E22.GPU)
            if step % 6 == 0 and units + C.cost_fwd(lv, E22.GPU) <= E22.BUDGET:
                b = C.hard_binary(rho, E22.GPU)
                s = C.forward_density(b, lv, TGT, E22.GPU)
                units += C.cost_fwd(lv, E22.GPU)
                if s > b_self:
                    b_self, b_bin, b_rho = s, b, rho.clone()
            rho = adam.step(rho, g, lr)
            step += 1
        b = C.hard_binary(rho, E22.GPU)
        s = C.forward_density(b, lv, TGT, E22.GPU)
        if s > b_self:
            b_self, b_bin, b_rho = s, b, rho.clone()
        eta = E22.eta_gpu(b_bin.cpu(), (24, 6), TGT)
        if eta > best[0]:
            best = (eta, b_rho.cpu(), b_bin.cpu())
    return best[1], best[2], best[0]


def maximin10(binary, cfg):
    nom = eta_gpu(binary, (24, 6), TGT, cfg)
    cd = torch.from_numpy(C.cd_bias_mask(binary.numpy().astype(bool), 20.0,
                                         cfg))
    worst = eta_gpu(cd, (24, 6), TGT, cfg)
    return min(nom, worst), nom, worst


def held_out10(binary, cfg):
    mask = binary.numpy().astype(bool)
    nominal = eta_c128(binary, (24, 6), TGT, cfg)
    held = {"nominal_24_6": nominal}
    for bias in (-20.0, 20.0):
        held["cd_{:+.0f}nm".format(bias)] = eta_c128(
            torch.from_numpy(C.cd_bias_mask(mask, bias, cfg)), (24, 6), TGT,
            cfg)
    for op in ("opening", "closing"):
        held["{}_40nm".format(op)] = eta_c128(
            torch.from_numpy(np.asarray(periodic_binary_morphology(
                mask, op, 40.0, cfg.pixel_yx), dtype=np.float64)),
            (24, 6), TGT, cfg)
    scen = {k: v for k, v in held.items() if k != "nominal_24_6"}
    held["worst_absolute"] = min(scen.values())
    held["worst_relative"] = min(scen.values()) / max(nominal, 1e-12)
    held["worst_scenario"] = min(scen, key=scen.get)
    return held


def main():
    torch.set_num_threads(THREADS)
    os.makedirs(DATA, exist_ok=True)
    t0 = time.perf_counter()

    # ---- phase 1: harvest candidates at 20 nm ------------------------------
    cands = []
    parent = torch.from_numpy(np.load(os.path.join(
        E16_DESIGNS, "2_0_2030_torcwa_M12_latent.npy")).astype("float64"))
    cands.append(("parent", parent))
    for r in range(6):
        lat, b, eta = replay_rs_replicate(r)
        cands.append(("rs_rep%d" % r, lat))
        print("harvest rs_rep%d: eta24 %.4f  [%.0f s]"
              % (r, eta, time.perf_counter() - t0), flush=True)

    scored = []
    for name, lat in cands:
        b20 = C.hard_binary(lat, C.DEFAULT)
        nom = E22.eta_gpu(b20, (24, 6), TGT)
        cd = torch.from_numpy(C.cd_bias_mask(b20.numpy().astype(bool), 20.0,
                                             C.DEFAULT))
        worst = E22.eta_gpu(cd, (24, 6), TGT)
        scored.append({"name": name, "nominal": nom, "cd20": worst,
                       "maximin": min(nom, worst), "latent": lat})
        print("candidate %-9s: nominal %.4f  cd+20 %.4f  maximin %.4f"
              % (name, nom, worst, min(nom, worst)), flush=True)
    scored.sort(key=lambda x: -x["maximin"])
    starts = scored[:2]
    print("selected starts: %s" % [s["name"] for s in starts], flush=True)

    # ---- phase 2: maximin chains at 10 nm ---------------------------------
    out = {"candidates": [{k: v for k, v in s.items() if k != "latent"}
                          for s in scored],
           "parent_ref": PARENT_REF, "chains": {}}
    for si, s in enumerate(starts):
        incumbent = upsample(s["latent"], 2)
        inc_bin = C.hard_binary(incumbent, CFG10)
        inc_score, inc_nom, inc_cd = maximin10(inc_bin, CFG10)
        startrec = {"score": inc_score, "nominal": inc_nom, "cd20": inc_cd}
        print("chain from %s @10nm: maximin %.4f (nom %.4f cd %.4f)"
              % (s["name"], inc_score, inc_nom, inc_cd), flush=True)
        jumps, accepts = [], 0
        t1 = time.perf_counter()
        for j in range(N_JUMPS):
            alpha = ALPHAS[j % len(ALPHAS)]
            noise = filtered_noise(69100 + 1000 * si + j, CFG10)
            pert = C.symmetrize(
                (incumbent + alpha * C.DEFAULT.init_scale * noise)
                .clamp(0, 1))
            rho = redescend(pert, TGT, CFG10)
            b = C.hard_binary(rho, CFG10)
            score, nom, cd = maximin10(b, CFG10)
            acc = score > inc_score
            jumps.append({"jump": j, "alpha": alpha, "score": score,
                          "nominal": nom, "cd20": cd, "accepted": bool(acc)})
            if acc:
                incumbent, inc_bin = rho, b
                inc_score, inc_nom, inc_cd = score, nom, cd
                accepts += 1
            print("%s jump %2d a=%.2f: maximin %.4f (nom %.4f cd %.4f) "
                  "(inc %.4f) %s [%.0f s]"
                  % (s["name"], j, alpha, score, nom, cd, inc_score,
                     "ACCEPT" if acc else "reject",
                     time.perf_counter() - t1), flush=True)
        tag = "2_0_reroute_%s" % s["name"]
        np.save(os.path.join(DATA, tag + "_binary.npy"), inc_bin.numpy())
        np.save(os.path.join(DATA, tag + "_latent.npy"), incumbent.numpy())
        held = held_out10(inc_bin, CFG10)
        e32 = eta_gpu(inc_bin, (32, 8), TGT, CFG10)
        e40 = eta_gpu(inc_bin, (40, 10), TGT, CFG10)
        pareto = (held["nominal_24_6"] > PARENT_REF["nominal"]
                  and held["worst_absolute"] > PARENT_REF["worst"])
        out["chains"][s["name"]] = {
            "start": startrec,
            "final": {"score": inc_score, "nominal": inc_nom,
                      "cd20": inc_cd},
            "accepts": accepts, "jumps": jumps, "held_out": held,
            "eta_32_8": e32, "eta_40_10": e40,
            "pareto_vs_parent": bool(pareto), "files": tag,
            "wall_s": time.perf_counter() - t1,
        }
        print("%s done: maximin %.4f -> %.4f (%d/%d) | nominal_c128 %.4f, "
              "worst %.4f (%s) | Pareto vs parent: %s"
              % (s["name"], startrec["score"], inc_score, accepts, N_JUMPS,
                 held["nominal_24_6"], held["worst_absolute"],
                 held["worst_scenario"], pareto), flush=True)
    with open(os.path.join(DATA, "reroute_2_0.json"), "w") as f:
        json.dump(out, f, indent=1)
    print("wrote reroute_2_0.json  (%.0f s total)"
          % (time.perf_counter() - t0))


if __name__ == "__main__":
    main()
