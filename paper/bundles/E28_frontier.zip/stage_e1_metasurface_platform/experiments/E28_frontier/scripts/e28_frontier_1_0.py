"""Part 3: (1,0)@5nm frontier midpoints via tau-floor lexicographic chains.

Accept criterion per tau: compare (min(cd+20, tau), nominal) lexicographically
-- first raise the worst case to the floor tau, then optimise nominal above
the floor.  tau in {0.05, 0.15, 0.25}, 40 jumps each, start = the 1_0_w5nm
record.  Final: full held-out + (40,10); assembles the (nominal, worst)
frontier figure from all known (1,0) deliverables.

    python e28_frontier_1_0.py        # writes ../data/frontier_1_0.json
                                      # and notes/figures/fig_frontier_1_0.png
"""
import json
import os
import sys
import time

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.abspath(os.path.join(
    _HERE, "..", "..", "E26_fine_pixels", "scripts")))

from e26_common import (C, FIG, FINE, THREADS, eta_c128, eta_gpu,  # noqa: E402
                        filtered_noise, redescend)
from trustworthy_fmm.fabrication.process import periodic_binary_morphology  # noqa: E402

E26_DATA = os.path.abspath(os.path.join(
    _HERE, "..", "..", "E26_fine_pixels", "data"))
DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
TGT = (1, 0)
CFG = FINE[5]
TAUS = [0.05, 0.15, 0.25]
N_JUMPS = 40
ALPHAS = [0.1, 0.25, 0.5]


def probe(binary):
    nom = eta_gpu(binary, (24, 6), TGT, CFG)
    cd = torch.from_numpy(C.cd_bias_mask(binary.numpy().astype(bool), 20.0,
                                         CFG))
    worst = eta_gpu(cd, (24, 6), TGT, CFG)
    return nom, worst


def held_out(binary):
    mask = binary.numpy().astype(bool)
    nominal = eta_c128(binary, (24, 6), TGT, CFG)
    held = {"nominal_24_6": nominal}
    for bias in (-20.0, 20.0):
        held["cd_{:+.0f}nm".format(bias)] = eta_c128(
            torch.from_numpy(C.cd_bias_mask(mask, bias, CFG)), (24, 6), TGT,
            CFG)
    for op in ("opening", "closing"):
        held["{}_40nm".format(op)] = eta_c128(
            torch.from_numpy(np.asarray(periodic_binary_morphology(
                mask, op, 40.0, CFG.pixel_yx), dtype=np.float64)),
            (24, 6), TGT, CFG)
    scen = {k: v for k, v in held.items() if k != "nominal_24_6"}
    held["worst_absolute"] = min(scen.values())
    held["worst_relative"] = min(scen.values()) / max(nominal, 1e-12)
    held["worst_scenario"] = min(scen, key=scen.get)
    return held


def main():
    torch.set_num_threads(THREADS)
    os.makedirs(DATA, exist_ok=True)
    lat0 = torch.from_numpy(np.load(os.path.join(
        E26_DATA, "1_0_w5nm_latent.npy")).astype("float64"))
    out = {"taus": TAUS, "chains": {}}
    for ti, tau in enumerate(TAUS):
        incumbent = lat0.clone()
        inc_bin = C.hard_binary(incumbent, CFG)
        inc_nom, inc_cd = probe(inc_bin)
        key = (min(inc_cd, tau), inc_nom)
        jumps, accepts = [], 0
        t0 = time.perf_counter()
        for j in range(N_JUMPS):
            alpha = ALPHAS[j % len(ALPHAS)]
            noise = filtered_noise(59100 + 1000 * ti + j, CFG)
            pert = C.symmetrize(
                (incumbent + alpha * C.DEFAULT.init_scale * noise)
                .clamp(0, 1))
            rho = redescend(pert, TGT, CFG)
            b = C.hard_binary(rho, CFG)
            nom, cd = probe(b)
            cand = (min(cd, tau), nom)
            acc = cand > key
            jumps.append({"jump": j, "alpha": alpha, "nominal": nom,
                          "cd20": cd, "accepted": bool(acc)})
            if acc:
                incumbent, inc_bin, inc_nom, inc_cd, key = rho, b, nom, cd, \
                    cand
                accepts += 1
            print("tau=%.2f jump %2d a=%.2f: nom %.4f cd %.4f (inc %.4f/"
                  "%.4f) %s [%.0f s]"
                  % (tau, j, alpha, nom, cd, inc_nom, inc_cd,
                     "ACCEPT" if acc else "reject",
                     time.perf_counter() - t0), flush=True)
        tag = "1_0_tau%03d" % round(100 * tau)
        np.save(os.path.join(DATA, tag + "_binary.npy"), inc_bin.numpy())
        np.save(os.path.join(DATA, tag + "_latent.npy"), incumbent.numpy())
        held = held_out(inc_bin)
        e40 = eta_gpu(inc_bin, (40, 10), TGT, CFG)
        out["chains"][str(tau)] = {
            "final_nominal_gpu": inc_nom, "final_cd20_gpu": inc_cd,
            "accepts": accepts, "jumps": jumps, "held_out": held,
            "eta_40_10": e40, "floor_reached": bool(inc_cd >= tau),
            "files": tag, "wall_s": time.perf_counter() - t0,
        }
        print("tau=%.2f done: nom %.4f cd %.4f (floor %s) | (40,10) %.4f | "
              "held-out worst %.4f (%s)"
              % (tau, inc_nom, inc_cd,
                 "reached" if inc_cd >= tau else "NOT reached", e40,
                 held["worst_absolute"], held["worst_scenario"]), flush=True)

    with open(os.path.join(DATA, "frontier_1_0.json"), "w") as f:
        json.dump(out, f, indent=1)

    # ---- frontier figure ---------------------------------------------------
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams["font.family"] = ["Microsoft YaHei", "SimHei", "sans-serif"]
    pts = [
        ("20nm 冻结父本", 0.3968, 0.1939, "#555555", "o"),
        ("E23 鲁棒链@20nm", 0.3445, 0.2909, "#555555", "D"),
        ("E19 非鲁棒链@20nm", 0.6209, 0.0981, "#999999", "s"),
        ("E26 纪录@5nm", 0.9127, 0.0047, "#d62728", "*"),
        ("E27 maximin@5nm", 0.8869, 0.1228, "#1f77b4", "D"),
    ]
    for tau in TAUS:
        c = out["chains"][str(tau)]
        pts.append(("τ=%.2f@5nm" % tau, c["held_out"]["nominal_24_6"],
                    c["held_out"]["worst_absolute"], "#2ca02c", "^"))
    fig, ax = plt.subplots(figsize=(7.6, 5.2))
    for name, x, y, col, mk in pts:
        ax.scatter([x], [y], s=110 if mk == "*" else 70, color=col,
                   marker=mk, zorder=3)
        ax.annotate("%s\n(%.3f, %.3f)" % (name, x, y), (x, y),
                    textcoords="offset points", xytext=(7, 5), fontsize=7.5,
                    color=col)
    ax.set_xlabel("标称 η(24,6)（c128）", fontsize=10)
    ax.set_ylabel("held-out 最差绝对值（±20nm CD、40nm 开/闭）", fontsize=10)
    ax.set_title("(1,0) 的效率-鲁棒 frontier：端点 + τ-地板中段（E28）",
                 fontsize=11)
    ax.grid(alpha=0.3)
    ax.set_xlim(left=0.25)
    ax.set_ylim(bottom=-0.01)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "fig_frontier_1_0.png"), dpi=220)
    print("wrote frontier_1_0.json + fig_frontier_1_0.png")


if __name__ == "__main__":
    main()
