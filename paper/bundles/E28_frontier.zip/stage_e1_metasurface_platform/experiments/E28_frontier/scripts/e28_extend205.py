"""Part 1: extend the (3,0)@10nm (20,5)-descent chain by 40 more jumps from
the E27 B2 incumbent.  Gate (32,8)@native; final ladder (40,10)/(48,12).

    python e28_extend205.py           # writes ../data/extend205.json
"""
import json
import os
import sys
import time

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.abspath(os.path.join(
    _HERE, "..", "..", "E26_fine_pixels", "scripts")))

from e26_common import (C, FINE, GATE_LEVEL, THREADS, eta_gpu,  # noqa: E402
                        filtered_noise)

E27_DATA = os.path.abspath(os.path.join(_HERE, "..", "..", "E27_merge", "data"))
DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))

TGT = (3, 0)
CFG = FINE[10]
LEVEL = (20, 5)
N_JUMPS = 40
ALPHAS = [0.1, 0.25, 0.5]


def redescend(rho0):
    rho = rho0.to("cuda")
    adam = C.Adam(rho.shape, CFG)
    for t in range(30):
        lr = C.cosine_lr(t / 30, CFG)
        _, g = C.value_grad_latent(rho, LEVEL, TGT, 64.0, CFG)
        rho = adam.step(rho, g, lr)
    return rho.cpu()


def main():
    torch.set_num_threads(THREADS)
    os.makedirs(DATA, exist_ok=True)
    incumbent = torch.from_numpy(np.load(os.path.join(
        E27_DATA, "3_0_B2_latent.npy")).astype("float64"))
    inc_bin = C.hard_binary(incumbent, CFG)
    inc_eta = eta_gpu(inc_bin, GATE_LEVEL, TGT, CFG)
    start = inc_eta
    print("incumbent gate: %.4f (E27 recorded 0.6323)" % inc_eta, flush=True)
    jumps, accepts = [], 0
    t0 = time.perf_counter()
    for j in range(N_JUMPS):
        alpha = ALPHAS[j % len(ALPHAS)]
        noise = filtered_noise(49100 + j, CFG)
        pert = C.symmetrize(
            (incumbent + alpha * C.DEFAULT.init_scale * noise).clamp(0, 1))
        rho = redescend(pert)
        b = C.hard_binary(rho, CFG)
        e = eta_gpu(b, GATE_LEVEL, TGT, CFG)
        acc = e > inc_eta
        jumps.append({"jump": j, "alpha": alpha, "eta": e,
                      "accepted": bool(acc)})
        if acc:
            incumbent, inc_bin, inc_eta = rho, b, e
            accepts += 1
        print("jump %2d a=%.2f: gate %.4f (inc %.4f) %s [%.0f s]"
              % (j, alpha, e, inc_eta, "ACCEPT" if acc else "reject",
                 time.perf_counter() - t0), flush=True)
    e40 = eta_gpu(inc_bin, (40, 10), TGT, CFG)
    e48 = eta_gpu(inc_bin, (48, 12), TGT, CFG)
    late_accepts = sum(jp["accepted"] for jp in jumps[20:])
    plateau = late_accepts < 2 and (inc_eta - start) / start < 0.01
    np.save(os.path.join(DATA, "3_0_ext205_binary.npy"), inc_bin.numpy())
    np.save(os.path.join(DATA, "3_0_ext205_latent.npy"), incumbent.numpy())
    out = {"start": start, "final": inc_eta, "accepts": accepts,
           "jumps": jumps, "eta_40_10": e40, "eta_48_12": e48,
           "late_accepts": late_accepts, "plateau": bool(plateau),
           "wall_s": time.perf_counter() - t0}
    with open(os.path.join(DATA, "extend205.json"), "w") as f:
        json.dump(out, f, indent=1)
    print("ext: gate %.4f -> %.4f (%d/%d), (40,10) %.4f, (48,12) %.4f, "
          "plateau=%s" % (start, inc_eta, accepts, N_JUMPS, e40, e48, plateau))
    print("wrote extend205.json")


if __name__ == "__main__":
    main()
