"""S5-8a  The published descent schedule, run by our engine, with the gate
watching it.

S5-7 found that TORCWA's README workflow (800 Adam steps, exponential beta
1 -> 1000 in their parameterisation, delivery = the final field) out-delivers
our 219-step / beta -> 64 baseline at m <= 2 by a wide margin (Sec. 7.6), and
that the engine is not the difference (T-BASE = O-BASE).  The schedule is.
This script runs that schedule on OUR engine and instruments it the way our
own baseline is instrumented, so one set of runs answers four questions:

  1. ENGINE REPLICATION.  Same seeds as S5-7's T-README-D, hence the same
     initial latent; same schedule; our gradients instead of TORCWA's.  If the
     certified deliveries land in the same distribution, S5-7's result belongs
     to the schedule, not to the engine.
  2. IS MID-COURSE SELECTION STILL WORTH ANYTHING?  Every 25 steps the latent
     is hard-thresholded and scored at the GATE order -- our baseline's
     mechanism at a coarser cadence.  Each run delivers TWO designs, the best
     gate checkpoint (our rule) and the final field (README's rule), and both
     are certified on the ladder.  Under beta -> 64 the mid-course pick
     rescued 10/24, 10/24 and 9/16 of S5-4's tickets by more than 0.05;
     whether it still does anything under beta -> 2000 is a paired question
     that costs no extra solves.
  3. WHERE DOES A SINGLE-ORDER DESCENT GO?  Every 100 steps the same binary is
     also read at (40,10) and at the descent order, beside the continuous
     value the optimiser is climbing.  If the certified curve peaks and turns
     down while the descent-order curve keeps rising, that is the drift the
     gate exists to veto, recorded step by step.
  4. PARENTS for S5-8b.  The best gate checkpoint of every run is saved as a
     latent, so the chain can start from README-schedule designs instead of
     S4-2's (16,4) designs.

Orders are order_rule's, unchanged: descent (12,3)/(12,3)/(20,5), gate
(24,6)/(24,6)/(32,8), ladder to (40,10)/(40,10)/(48,12), trace (40,10).  The
design map, Adam, cosine lr and the NaN guard are the workbench's / S5-1's.

Descriptive: numbers, not verdicts.

    python s5_8a_readme_schedule.py --targets 1 --dry-run
    python s5_8a_readme_schedule.py
    python s5_8a_readme_schedule.py --resume
"""
import argparse
import json
import math
import os
import sys
import time
from types import SimpleNamespace

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import s5_1_gate_tier as S1                                        # noqa: E402
from workbench.protocol import DEFAULT, cosine_lr                  # noqa: E402
from workbench.app import (                                        # noqa: E402
    order_rule, app_hard_binary, app_filtered, app_initial_latent, gate_eval,
    AppAdam,
)
from trustworthy_fmm.fabrication.process import tanh_projection    # noqa: E402
import trustworthy_fmm.solvers.vector_2d as _v2d                   # noqa: E402
import trustworthy_fmm.fourier.convolution as _conv                # noqa: E402

DATA, DESIGNS = S1.DATA, S1.DESIGNS
STEPS = 800                   # TORCWA README Example 6
BETA_HI_TORCWA = 1000.0       # their b; the same projection in ours is B = 2b
CKPT_EVERY = 25               # gate checkpoints (our baseline: every 6 of 219)
TRACE_EVERY = 100             # certified trace points
TRACE_LEVEL = (40, 10)        # S5-1's trace level, uniform across m
SEED_BASE = {1: 51000, 2: 52000, 3: 53000}   # S5-7's block: same init as T-README-D
N_SEEDS = {1: 6, 2: 6, 3: 6}
DRY = {"steps": 12, "ckpt": 4, "trace": 8, "seeds": 1}


def beta_readme(step, steps):
    """README's ramp b = 1000^(t/T) in their parameterisation, B = 2b in ours:
    B(0) = 2, B(T) = 2000, the value their final field is projected at."""
    return 2.0 * math.exp(step * math.log(BETA_HI_TORCWA) / steps)


def q(v):
    a = np.asarray([x for x in v if x is not None], float)
    if not a.size:
        return None
    return {"n": int(a.size), "median": float(np.median(a)),
            "q1": float(np.percentile(a, 25)), "q3": float(np.percentile(a, 75)),
            "min": float(a.min()), "max": float(a.max())}


def run(ctx, reader, seed, steps, ckpt_every, trace_every, events):
    """One README-schedule descent with gate checkpoints and a certified trace.

    Returns both deliveries: the best gate checkpoint and the final field."""
    cfg, mode = ctx.cfg, ctx.mode
    latent = app_initial_latent(seed, cfg, mode, ctx.device)
    adam = AppAdam(latent.shape, cfg, mode, ctx.device)
    traj, ckpts, trace = [], [], []
    st = {"best": None, "t_gate": 0.0, "t_trace": 0.0, "last": None}

    def checkpoint(step, do_trace):
        beta = beta_readme(step, steps)
        lat = latent.detach().cpu().clone()
        b = app_hard_binary(lat, cfg, mode)
        t0 = time.perf_counter()
        eg = gate_eval(b, ctx.gate, ctx)
        st["t_gate"] += time.perf_counter() - t0
        ckpts.append({"step": step, "eta_gate": eg, "beta": beta})
        if st["best"] is None or eg > st["best"]["eta_gate"]:
            st["best"] = {"eta_gate": eg, "step": step, "latent": lat, "binary": b}
        if do_trace:
            t0 = time.perf_counter()
            dens = tanh_projection(app_filtered(lat, cfg, mode), beta, cfg.threshold)
            e_c = gate_eval(dens, ctx.level_d, ctx)     # what the optimiser sees
            e_d = gate_eval(b, ctx.level_d, ctx)        # same binary, same order
            e_t = reader.trace(b)                       # same binary, (40,10)
            st["t_trace"] += time.perf_counter() - t0
            trace.append({"step": step, "beta": beta,
                          "eta_continuous_descent": e_c,
                          "eta_binary_descent": e_d,
                          "eta_gate": eg, "eta_trace": e_t})
        st["last"] = {"binary": b, "latent": lat, "step": step, "eta_gate": eg}

    checkpoint(0, True)                                 # the initial latent
    t_desc = 0.0
    for t in range(steps):
        beta = beta_readme(t, steps)
        lr = cosine_lr(t / max(steps - 1, 1), cfg)
        t0 = time.perf_counter()
        eta, grad = S1.guarded_value_grad(latent, ctx.level_d, beta, ctx, events, t)
        t_desc += time.perf_counter() - t0
        if grad is not None:
            latent = adam.step(latent, grad, lr)
            traj.append(round(float(eta), 6))
        else:
            traj.append(None)
        step = t + 1
        if step % ckpt_every == 0 or step == steps:
            checkpoint(step, step % trace_every == 0 or step == steps)
    return {"best": st["best"], "final": st["last"],
            "checkpoints": ckpts, "trace": trace, "trajectory": traj,
            "reported_continuous": trace[-1]["eta_continuous_descent"],
            "eta_binary_descent_final": trace[-1]["eta_binary_descent"],
            "wall_descent_s": t_desc, "wall_gate_s": st["t_gate"],
            "wall_trace_s": st["t_trace"]}


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--targets", type=str, default="1,2,3")
    ap.add_argument("--seeds", type=int, default=0)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--out", type=str, default=None)
    args = ap.parse_args()

    torch.set_num_threads(int(os.environ.get("FMM_THREADS", "3")))
    _conv.VECTORIZED_CONV = True
    _v2d.FAST_DIAGNOSTICS = True
    _v2d.MEMORY_EFFICIENT = True
    device = "cuda" if torch.cuda.is_available() else "cpu"
    dtype = torch.complex64
    cfg = DEFAULT.variant(ny=S1.NY, nx=S1.NX)
    ref_cfg = DEFAULT.variant(ny=S1.REF_NY, nx=S1.REF_NX)
    targets = [(int(t.strip()), 0) for t in args.targets.split(",") if t.strip()]
    steps, ck, tr = STEPS, CKPT_EVERY, TRACE_EVERY
    if args.dry_run:
        steps, ck, tr = DRY["steps"], DRY["ckpt"], DRY["trace"]

    out = args.out or os.path.join(
        DATA, "s5_8a_readme_schedule%s.json" % ("_dry" if args.dry_run else ""))
    store = {"meta": {}, "units": {}, "summary": {}}
    if args.resume and os.path.exists(out):
        store = json.load(open(out, encoding="utf-8"))
        print("resuming: %d units done" % len(store["units"]), flush=True)
    store["meta"].update({
        "script": os.path.basename(__file__),
        "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "gpu": torch.cuda.get_device_name(0) if device == "cuda" else "cpu",
        "engine": "ours (fmm_workbench value_grad, complex64, no broadening)",
        "pixel_nm": S1.PIXEL_NM, "grid": [S1.NY, S1.NX],
        "ref_grid": [S1.REF_NY, S1.REF_NX],
        "steps": steps, "ckpt_every": ck, "trace_every": tr,
        "trace_level": list(TRACE_LEVEL),
        "beta_schedule": "B(t) = 2 * 1000^(t/T), t = 0..T-1 "
                         "(README's b = 1000^(t/T), B = 2b)",
        "beta_final": 2.0 * BETA_HI_TORCWA,
        "seed_base": SEED_BASE,
        "reading_notes": [
            "Same seeds as S5-7's T-README-D, so the SAME initial latent; the "
            "engines differ (ours, no broadening; TORCWA there, broadening on) "
            "and trajectories diverge, so the pairing is on the start only.",
            "Two deliveries from one run.  deliver_best = the best gate "
            "checkpoint (our rule, checkpoint every %d steps incl. step 0); "
            "deliver_final = the final field hard-thresholded (README's "
            "rule).  When best_step == %d the two are the same design and "
            "same_design is true.  best_minus_final_top is the value of "
            "mid-course selection under this schedule, paired per seed."
            % (ck, steps),
            "reported_continuous is what README's workflow would publish: the "
            "final continuous field at B = 2000 read at its single (descent) "
            "order.  gap_relaxation = reported - binary at that order; "
            "gap_truncation = binary at that order - certified top.",
            "trace: at step 0 and every %d steps, the SAME hard binary read at "
            "the descent order, the gate order and (40,10), beside the "
            "continuous value at the current beta.  eta_trace minus eta_gate "
            "is what the gate misses; eta_binary_descent minus eta_trace is "
            "what the descent order overstates." % tr,
            "Wall clocks: opt_wall_s = descent + gate checkpoints (S5-4's "
            "definition, so equal-wall-clock slices are comparable); "
            "opt_wall_readme_s = descent only (README has no checkpoints); "
            "wall_trace_s and cert_wall_s are instrumentation and delivery, "
            "not part of either optimiser.",
        ],
    })

    print("=" * 78)
    print("s5_8a_readme_schedule | %s | c64 | %d steps, ckpt/%d, trace/%d @%s"
          % (store["meta"]["gpu"], steps, ck, tr, TRACE_LEVEL), flush=True)
    t_start, done = time.perf_counter(), 0
    for tgt in targets:
        m = tgt[0]
        rule = order_rule(tgt, cfg)
        ladder = list(rule["ladder"])
        n_seeds = args.seeds or N_SEEDS[m]
        if args.dry_run:
            n_seeds = DRY["seeds"]
        ctx = SimpleNamespace(cfg=cfg, mode=S1.MODE, theta=0.0, phi=0.0,
                              target=tgt, level_d=tuple(rule["descent"]),
                              gate=tuple(rule["gate"]), dtype=dtype,
                              device=device, offload=False,
                              accept_rule="nominal", cd_biases=[-20.0, 20.0])
        ref_ctx = SimpleNamespace(**{**vars(ctx), "cfg": ref_cfg})
        reader = S1.RefReader(ctx, ref_ctx, ladder)
        tkey = "%d-%d" % tgt
        topkey = "%d-%d" % ladder[-1]
        print("m=%d descent %s gate %s ladder %s | %d seeds"
              % (m, rule["descent"], rule["gate"], ladder, n_seeds), flush=True)
        for i in range(n_seeds):
            key = "%s|s%02d" % (tkey, i)
            if key in store["units"]:
                continue
            seed = SEED_BASE[m] + i
            ev = []
            t0 = time.perf_counter()
            r = run(ctx, reader, seed, steps, ck, tr, ev)
            w0 = reader.wall
            deliveries = {}
            for name in ("best", "final"):
                d = r[name]
                lad = reader.ladder_of(d["binary"])
                tag = "s5_8a_%s_s%02d_%s" % (tkey.replace("-", "_"), i, name)
                deliveries[name] = {
                    "step": d["step"], "eta_gate": d["eta_gate"],
                    "final_ladder": lad, "eta_top": lad[topkey],
                    "gate_optimism": d["eta_gate"] - lad[topkey],
                    "mask_sha1": S1.sha1_of(d["binary"]),
                    "files": S1.save_design(tag, d["binary"], d["latent"]),
                }
            cert_wall = reader.wall - w0
            fin = deliveries["final"]
            fin["reported_continuous"] = r["reported_continuous"]
            fin["eta_binary_descent"] = r["eta_binary_descent_final"]
            fin["gap_relaxation"] = (r["reported_continuous"]
                                     - r["eta_binary_descent_final"])
            fin["gap_truncation"] = r["eta_binary_descent_final"] - fin["eta_top"]
            best = deliveries["best"]
            store["units"][key] = {
                "target": list(tgt), "seed": seed, "index": i, "engine": "ours",
                "schedule": "readme", "steps": steps, "ckpt_every": ck,
                "trace_every": tr, "descent_level": list(rule["descent"]),
                "gate": list(rule["gate"]), "ladder": [list(l) for l in ladder],
                "trace_level": list(TRACE_LEVEL),
                "best_step": best["step"], "eta_gate_best": best["eta_gate"],
                "n_ckpt": len(r["checkpoints"]),
                "same_design": best["mask_sha1"] == fin["mask_sha1"],
                "best_minus_final_gate": best["eta_gate"] - fin["eta_gate"],
                "best_minus_final_top": best["eta_top"] - fin["eta_top"],
                "deliver_best": best, "deliver_final": fin,
                "checkpoints": r["checkpoints"], "trace": r["trace"],
                "trajectory": r["trajectory"],
                "wall_descent_s": r["wall_descent_s"],
                "wall_gate_s": r["wall_gate_s"],
                "wall_trace_s": r["wall_trace_s"], "cert_wall_s": cert_wall,
                "opt_wall_s": r["wall_descent_s"] + r["wall_gate_s"],
                "opt_wall_readme_s": r["wall_descent_s"],
                "unit_wall_s": time.perf_counter() - t0,
                "grad_events": ev,
                "solves": {"value_grad_%d_%d" % ctx.level_d: steps,
                           "fwd_gate_%d_%d" % ctx.gate: len(r["checkpoints"]),
                           "fwd_trace_%d_%d" % TRACE_LEVEL: len(r["trace"]),
                           "fwd_descent_%d_%d" % ctx.level_d: 2 * len(r["trace"])},
            }
            S1.save_json(out, store)
            done += 1
            print("  s%02d seed %d | best@%-3d gate %.4f top %.4f | final gate "
                  "%.4f top %.4f | reported %.4f = top + relax %+.4f + trunc "
                  "%+.4f | desc %s gate %s trace %s cert %s  [%s]"
                  % (i, seed, best["step"], best["eta_gate"], best["eta_top"],
                     fin["eta_gate"], fin["eta_top"], fin["reported_continuous"],
                     fin["gap_relaxation"], fin["gap_truncation"],
                     S1.fmt_s(r["wall_descent_s"]), S1.fmt_s(r["wall_gate_s"]),
                     S1.fmt_s(r["wall_trace_s"]), S1.fmt_s(cert_wall),
                     S1.fmt_s(time.perf_counter() - t_start)), flush=True)

        rows = [v for k, v in store["units"].items() if k.startswith(tkey + "|")]
        if rows:
            rows.sort(key=lambda u: u["index"])
            bt = [u["deliver_best"]["eta_top"] for u in rows]
            ft = [u["deliver_final"]["eta_top"] for u in rows]
            d = [b - f for b, f in zip(bt, ft)]
            store["summary"][tkey] = {
                "n": len(rows), "best_top": q(bt), "final_top": q(ft),
                "best_minus_final_top": {
                    "median": float(np.median(d)), "min": float(min(d)),
                    "max": float(max(d)), "n_pos": int(sum(x > 0 for x in d)),
                    "n_neg": int(sum(x < 0 for x in d)),
                    "n_over_0p05": int(sum(x > 0.05 for x in d)), "values": d},
                "best_steps": [u["best_step"] for u in rows],
                "n_same_design": int(sum(u["same_design"] for u in rows)),
                "reported": q([u["deliver_final"]["reported_continuous"]
                               for u in rows]),
                "gap_relaxation": q([u["deliver_final"]["gap_relaxation"]
                                     for u in rows]),
                "gap_truncation": q([u["deliver_final"]["gap_truncation"]
                                     for u in rows]),
                "gate_optimism_best": q([u["deliver_best"]["gate_optimism"]
                                         for u in rows]),
                "wall": {k: q([u[k] for u in rows]) for k in
                         ("wall_descent_s", "wall_gate_s", "wall_trace_s",
                          "cert_wall_s", "opt_wall_s", "unit_wall_s")},
            }
            s = store["summary"][tkey]
            print("  --> n=%d | best-gate top med %.4f [%.4f,%.4f] | final top "
                  "med %.4f [%.4f,%.4f] | best-final med %+.4f (+%d/-%d, >0.05 "
                  "in %d) | best_steps %s | same %d/%d"
                  % (s["n"], s["best_top"]["median"], s["best_top"]["min"],
                     s["best_top"]["max"], s["final_top"]["median"],
                     s["final_top"]["min"], s["final_top"]["max"],
                     s["best_minus_final_top"]["median"],
                     s["best_minus_final_top"]["n_pos"],
                     s["best_minus_final_top"]["n_neg"],
                     s["best_minus_final_top"]["n_over_0p05"],
                     s["best_steps"], s["n_same_design"], s["n"]), flush=True)
            S1.save_json(out, store)

    store["meta"]["total_wall_s"] = time.perf_counter() - t_start
    store["meta"]["finished_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ",
                                                  time.gmtime())
    S1.save_json(out, store)
    print("=" * 78)
    print("wrote %s (%d units, %s)"
          % (out, len(store["units"]), S1.fmt_s(store["meta"]["total_wall_s"])))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
