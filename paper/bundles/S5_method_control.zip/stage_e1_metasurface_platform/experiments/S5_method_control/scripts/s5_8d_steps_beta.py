"""S5-8d  Steps x beta: which half of the schedule gap is which.

Our baseline (219 steps, beta 1 -> 64) and README's schedule (800 steps,
beta 2 -> 2000) differ in two things at once.  S5-8a supplies the (800, 2000)
cell on our engine and S5-4 the (219, 64) cell on other seeds; this script
fills the two crossed cells and re-runs (219, 64) on S5-8a's seeds so that all
four cells share the initial latent:

                     beta -> 64            beta -> 2000
    219 steps     S219-B64 (here)        S219-B2000 (here)
    800 steps     S800-B64 (here)        S800-B2000 = S5-8a

Everything else is S5-8a's: our engine, gate checkpoints (every 6 steps on the
219-step cells as in S5-4, every 25 on the 800-step cells as in S5-8a), both
deliveries certified.  The trace is kept only at the ends of the 219-step
cells and every 100 steps of S800-B64.  m = 1 and 2 only, where a run is
cheap and where the schedule gap was measured.

    python s5_8d_steps_beta.py --dry-run
    python s5_8d_steps_beta.py
    python s5_8d_steps_beta.py --resume
"""
import argparse
import json
import os
import sys
import time
from types import SimpleNamespace

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import s5_1_gate_tier as S1                                        # noqa: E402
import s5_8a_readme_schedule as A                                  # noqa: E402
from s5_8_common import unit_row, print_unit                       # noqa: E402
from workbench.protocol import DEFAULT, beta_at                    # noqa: E402
from workbench.app import order_rule                               # noqa: E402
import trustworthy_fmm.solvers.vector_2d as _v2d                   # noqa: E402
import trustworthy_fmm.fourier.convolution as _conv                # noqa: E402

DATA = S1.DATA
# name, steps, schedule, ckpt_every, trace_every
CELLS = [
    ("S219-B64", 219, "ours", 6, 219),
    ("S219-B2000", 219, "readme", 6, 219),
    ("S800-B64", 800, "ours", 25, 100),
]
EXISTING = {"S800-B2000": "s5_8a_readme_schedule.json (same seeds)",
            "S219-B64 (other seeds)": "s5_4_restart_baseline.json (seeds 41000+/42000+)"}
TARGETS = [(1, 0), (2, 0)]
N_SEEDS = 6
DRY = {"steps": 12, "ckpt": 4, "trace": 8, "seeds": 1}


def schedule_fn(kind, cfg):
    if kind == "readme":
        return A.beta_readme                       # 2 * 1000^(t/T)
    return lambda step, steps: beta_at(step / max(steps - 1, 1), cfg=cfg)  # 1 -> 64


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--targets", type=str, default="1,2")
    ap.add_argument("--cells", type=str, default=",".join(c[0] for c in CELLS))
    ap.add_argument("--seeds", type=int, default=0)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--out", type=str, default=None)
    args = ap.parse_args()

    torch.set_num_threads(int(os.environ.get("FMM_THREADS", "3")))
    _conv.VECTORIZED_CONV = True
    _v2d.FAST_DIAGNOSTICS = True
    _v2d.MEMORY_EFFICIENT = True
    device = "cuda" if torch.cuda.is_available() else "cpu"
    cfg = DEFAULT.variant(ny=S1.NY, nx=S1.NX)
    ref_cfg = DEFAULT.variant(ny=S1.REF_NY, nx=S1.REF_NX)
    targets = [(int(t.strip()), 0) for t in args.targets.split(",") if t.strip()]
    want = {c.strip() for c in args.cells.split(",") if c.strip()}
    cells = [c for c in CELLS if c[0] in want]
    n_seeds = args.seeds or N_SEEDS
    if args.dry_run:
        n_seeds = DRY["seeds"]
        cells = [(c[0], DRY["steps"], c[2], DRY["ckpt"], DRY["trace"]) for c in cells]

    out = args.out or os.path.join(
        DATA, "s5_8d_steps_beta%s.json" % ("_dry" if args.dry_run else ""))
    store = {"meta": {}, "units": {}, "summary": {}}
    if args.resume and os.path.exists(out):
        store = json.load(open(out, encoding="utf-8"))
        print("resuming: %d units done" % len(store["units"]), flush=True)
    store["meta"].update({
        "script": os.path.basename(__file__),
        "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "gpu": torch.cuda.get_device_name(0) if device == "cuda" else "cpu",
        "engine": "ours (fmm_workbench value_grad, complex64, no broadening)",
        "code_path": "s5_8a_readme_schedule.run with the beta schedule swapped",
        "pixel_nm": S1.PIXEL_NM, "grid": [S1.NY, S1.NX],
        "cells": [{"name": c[0], "steps": c[1], "schedule": c[2],
                   "ckpt_every": c[3], "trace_every": c[4]} for c in cells],
        "existing_cells": EXISTING, "seed_base": A.SEED_BASE, "n_seeds": n_seeds,
        "reading_notes": [
            "'ours' = beta_at: 1 -> 64 exponential over the run (the frozen "
            "protocol); 'readme' = 2 * 1000^(t/T) (README's ramp, B = 2b).  "
            "Same seeds as S5-8a, so every cell shares its initial latent with "
            "S800-B2000 there; differences per seed are paired on the start.",
            "deliver_best / deliver_final as in S5-8a.  On the 219-step cells "
            "the checkpoint cadence is S5-4's (6), on S800-B64 S5-8a's (25).",
        ],
    })

    print("=" * 78)
    print("s5_8d_steps_beta | %s | c64 | cells %s | %d seeds"
          % (store["meta"]["gpu"], [c[0] for c in cells], n_seeds), flush=True)
    t_start = time.perf_counter()
    for tgt in targets:
        m = tgt[0]
        rule = order_rule(tgt, cfg)
        ladder = list(rule["ladder"])
        ctx = SimpleNamespace(cfg=cfg, mode=S1.MODE, theta=0.0, phi=0.0,
                              target=tgt, level_d=tuple(rule["descent"]),
                              gate=tuple(rule["gate"]), dtype=torch.complex64,
                              device=device, offload=False,
                              accept_rule="nominal", cd_biases=[-20.0, 20.0])
        ref_ctx = SimpleNamespace(**{**vars(ctx), "cfg": ref_cfg})
        reader = S1.RefReader(ctx, ref_ctx, ladder)
        tkey = "%d-%d" % tgt
        print("m=%d descent %s gate %s ladder %s"
              % (m, rule["descent"], rule["gate"], ladder), flush=True)
        for name, steps, kind, ck, tr in cells:
            fn = schedule_fn(kind, cfg)
            for i in range(n_seeds):
                key = "%s|%s|s%02d" % (tkey, name, i)
                if key in store["units"]:
                    continue
                seed = A.SEED_BASE[m] + i
                ev = []
                t0 = time.perf_counter()
                saved = A.beta_readme
                A.beta_readme = fn
                try:
                    r = A.run(ctx, reader, seed, steps, ck, tr, ev)
                finally:
                    A.beta_readme = saved
                meta = {"target": list(tgt), "cell": name, "seed": seed, "index": i,
                        "steps": steps, "beta_schedule": kind,
                        "beta_final": fn(steps, steps), "ckpt_every": ck,
                        "trace_every": tr, "descent_level": list(rule["descent"]),
                        "gate": list(rule["gate"]), "trace_level": list(A.TRACE_LEVEL)}
                row = unit_row(r, reader, ladder,
                               "s5_8d_%s_%s_s%02d" % (name, tkey.replace("-", "_"), i),
                               meta, certify=("best", "final"), t0=t0, events=ev)
                store["units"][key] = row
                S1.save_json(out, store)
                print_unit("%-10s s%02d" % (name, i), row, time.perf_counter() - t_start)

        summ = {}
        for name, steps, kind, ck, tr in cells:
            rs = sorted([v for k, v in store["units"].items()
                         if k.startswith("%s|%s|" % (tkey, name))],
                        key=lambda u: u["index"])
            if not rs:
                continue
            bt = [u["deliver_best"]["eta_top"] for u in rs]
            ft = [u["deliver_final"]["eta_top"] for u in rs]
            summ[name] = {"n": len(rs), "best_top": A.q(bt), "final_top": A.q(ft),
                          "best_minus_final_top": A.q([b - f for b, f in zip(bt, ft)]),
                          "best_steps": [u["best_step"] for u in rs],
                          "opt_wall_s": A.q([u["opt_wall_s"] for u in rs]),
                          "gap_truncation": A.q([u["deliver_final"]["gap_truncation"]
                                                 for u in rs])}
            print("  --> %-10s n=%d | best top med %.4f [%.4f,%.4f] | final top med "
                  "%.4f | best_steps %s | opt wall med %s"
                  % (name, len(rs), summ[name]["best_top"]["median"],
                     summ[name]["best_top"]["min"], summ[name]["best_top"]["max"],
                     summ[name]["final_top"]["median"], summ[name]["best_steps"],
                     S1.fmt_s(summ[name]["opt_wall_s"]["median"])), flush=True)
        store["summary"][tkey] = summ
        S1.save_json(out, store)

    store["meta"]["total_wall_s"] = time.perf_counter() - t_start
    store["meta"]["finished_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    S1.save_json(out, store)
    print("=" * 78)
    print("wrote %s (%d units, %s)"
          % (out, len(store["units"]), S1.fmt_s(store["meta"]["total_wall_s"])))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
