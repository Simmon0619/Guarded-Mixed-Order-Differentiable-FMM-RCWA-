"""Analysis of S5-8a: the README schedule on our engine, watched by the gate.

Zero solves.  Four readings, per target:

  1. REPLICATION   deliver_final (README's rule) against S5-7's T-README-D --
                   same seeds, different engine; distributional, and listed
                   pair by pair because the start is shared.
  2. SELECTION     deliver_best minus deliver_final, paired per seed: what
                   mid-course selection at the gate is still worth under
                   beta -> 2000.  best_step distribution; how many runs end
                   on their best checkpoint.
  3. DRIFT         the certified (40,10) trace: where it peaks, how far it
                   falls by the end, and whether the descent-order curve was
                   still rising while it fell.  Also the truncation gap along
                   the run (binary at the descent order minus (40,10)).
  4. POOL          the six certified deliveries as a restart pool: exact
                   E[max_N] for N <= 3 under README accounting (descent-only
                   wall) -- the null S5-8b's chains will be read against.
"""
import json
import math
import os
import sys

import numpy as np

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import s5_1_gate_tier as S1                                        # noqa: E402

DATA = S1.DATA
RNG = np.random.default_rng(20260911)
NBOOT = 10000


def q(v):
    a = np.asarray([x for x in v if x is not None], float)
    if not a.size:
        return None
    return {"n": int(a.size), "median": float(np.median(a)),
            "q1": float(np.percentile(a, 25)), "q3": float(np.percentile(a, 75)),
            "min": float(a.min()), "max": float(a.max()), "mean": float(a.mean())}


def paired(d):
    d = np.asarray(d, float)
    if not d.size:
        return None
    idx = RNG.integers(0, d.size, size=(NBOOT, d.size))
    meds = np.median(d[idx], axis=1)
    return {"n": int(d.size), "median": float(np.median(d)),
            "min": float(d.min()), "max": float(d.max()),
            "ci95": [float(np.percentile(meds, 2.5)), float(np.percentile(meds, 97.5))],
            "n_pos": int((d > 0).sum()), "n_neg": int((d < 0).sum()),
            "n_over_0p05": int((d > 0.05).sum()), "values": [float(x) for x in d]}


def e_max(values, N):
    x = sorted(float(v) for v in values)
    n = len(x)
    if N > n:
        return None
    return sum(x[k - 1] * math.comb(k - 1, N - 1) for k in range(1, n + 1)) / math.comb(n, N)


def main():
    A = json.load(open(os.path.join(DATA, "s5_8a_readme_schedule.json"), encoding="utf-8"))
    U7 = json.load(open(os.path.join(DATA, "s5_7_torcwa.json"), encoding="utf-8"))["units"]
    res = {"n_units": len(A["units"]), "targets": {}}
    targets = sorted({v["target"][0] for v in A["units"].values()})
    for m in targets:
        tk = "%d-0" % m
        rows = sorted([v for v in A["units"].values() if v["target"][0] == m],
                      key=lambda u: u["index"])
        out = {"n": len(rows)}
        print("\n" + "=" * 74 + "\nm=%d  (n=%d)  descent %s gate %s ladder %s"
              % (m, len(rows), rows[0]["descent_level"], rows[0]["gate"], rows[0]["ladder"]))

        # ---- 1. replication -------------------------------------------------
        t7 = {v["seed"]: v for v in U7.values()
              if v["target"][0] == m and v["arm"] == "T-README-D"}
        fin = [u["deliver_final"]["eta_top"] for u in rows]
        tor = [t7[u["seed"]]["eta_top"] for u in rows if u["seed"] in t7]
        pairs = [{"seed": u["seed"], "ours_final_top": u["deliver_final"]["eta_top"],
                  "torcwa_top": t7[u["seed"]]["eta_top"],
                  "ours_reported": u["deliver_final"]["reported_continuous"],
                  "torcwa_reported": t7[u["seed"]]["reported_continuous"]}
                 for u in rows if u["seed"] in t7]
        out["replication"] = {
            "ours_final_top": q(fin), "torcwa_top": q(tor),
            "median_diff_ours_minus_torcwa": (float(np.median(fin) - np.median(tor))
                                              if tor else None),
            "ours_reported": q([u["deliver_final"]["reported_continuous"] for u in rows]),
            "ours_gap_truncation": q([u["deliver_final"]["gap_truncation"] for u in rows]),
            "ours_gap_relaxation": q([u["deliver_final"]["gap_relaxation"] for u in rows]),
            "torcwa_gap_truncation": q([t7[s]["reported_continuous"] - t7[s]["eta_top"]
                                        for s in t7]),
            "pairs": pairs,
            "ours_wall_readme_s": q([u["opt_wall_readme_s"] for u in rows]),
            "torcwa_wall_s": q([t7[s]["opt_wall_s"] for s in t7]),
        }
        r = out["replication"]
        print("  1. REPLICATION (README rule = final field, certified)")
        print("     ours   n=%d med %.4f [%.4f,%.4f]  reported med %.4f  trunc gap med %+.4f  wall %s"
              % (r["ours_final_top"]["n"], r["ours_final_top"]["median"],
                 r["ours_final_top"]["min"], r["ours_final_top"]["max"],
                 r["ours_reported"]["median"], r["ours_gap_truncation"]["median"],
                 S1.fmt_s(r["ours_wall_readme_s"]["median"])))
        if tor:
            print("     torcwa n=%d med %.4f [%.4f,%.4f]  (S5-7 T-README-D, same seeds)  wall %s"
                  % (r["torcwa_top"]["n"], r["torcwa_top"]["median"], r["torcwa_top"]["min"],
                     r["torcwa_top"]["max"], S1.fmt_s(r["torcwa_wall_s"]["median"])))
            print("     per seed (ours / torcwa): " + "  ".join(
                "%d: %.3f/%.3f" % (p["seed"] % 1000, p["ours_final_top"], p["torcwa_top"])
                for p in pairs))

        # ---- 2. selection ---------------------------------------------------
        d = [u["best_minus_final_top"] for u in rows]
        out["selection"] = {
            "best_minus_final_top": paired(d),
            "best_minus_final_gate": q([u["best_minus_final_gate"] for u in rows]),
            "best_top": q([u["deliver_best"]["eta_top"] for u in rows]),
            "best_steps": [u["best_step"] for u in rows],
            "n_ends_on_best": int(sum(u["same_design"] for u in rows)),
            "gate_optimism_best": q([u["deliver_best"]["gate_optimism"] for u in rows]),
        }
        s = out["selection"]
        print("  2. SELECTION  best-gate-ckpt minus final, certified: med %+.4f CI [%+.4f,%+.4f] "
              "+%d/-%d  >0.05 in %d | best_steps %s | ends on best %d/%d"
              % (s["best_minus_final_top"]["median"], s["best_minus_final_top"]["ci95"][0],
                 s["best_minus_final_top"]["ci95"][1], s["best_minus_final_top"]["n_pos"],
                 s["best_minus_final_top"]["n_neg"], s["best_minus_final_top"]["n_over_0p05"],
                 s["best_steps"], s["n_ends_on_best"], len(rows)))

        # ---- 3. drift -------------------------------------------------------
        drift = []
        for u in rows:
            tr = u["trace"]
            steps = [t["step"] for t in tr]
            cert = [t["eta_trace"] for t in tr]
            cont = [t["eta_continuous_descent"] for t in tr]
            gate = [t["eta_gate"] for t in tr]
            kp = int(np.argmax(cert))
            gap = [t["eta_binary_descent"] - t["eta_trace"] for t in tr]
            drift.append({
                "seed": u["seed"], "peak_step": steps[kp], "peak_cert": cert[kp],
                "final_cert": cert[-1], "fall_from_peak": cert[kp] - cert[-1],
                "cont_rose_after_peak": bool(cont[-1] > cont[kp]) if kp < len(tr) - 1 else None,
                "gate_peak_step": steps[int(np.argmax(gate))],
                "gap_at_100": gap[1] if len(gap) > 1 else None, "gap_at_end": gap[-1],
                "gap_max": max(gap), "gap_max_step": steps[int(np.argmax(gap))],
                "curve_cert": cert, "curve_cont": cont, "curve_gate": gate,
                "curve_gap": gap, "steps": steps,
            })
        out["drift"] = {
            "per_run": drift,
            "fall_from_peak": q([x["fall_from_peak"] for x in drift]),
            "n_fall_over_0p05": int(sum(x["fall_from_peak"] > 0.05 for x in drift)),
            "n_peak_before_end": int(sum(x["peak_step"] < x["steps"][-1] for x in drift)),
            "n_cont_rose_while_cert_fell": int(sum(
                bool(x["cont_rose_after_peak"]) and x["fall_from_peak"] > 0.01 for x in drift)),
            "peak_steps": [x["peak_step"] for x in drift],
            "gap_at_100": q([x["gap_at_100"] for x in drift]),
            "gap_at_end": q([x["gap_at_end"] for x in drift]),
            "n_gap_grew": int(sum((x["gap_at_end"] or 0) > (x["gap_at_100"] or 0) for x in drift)),
        }
        dd = out["drift"]
        print("  3. DRIFT at (40,10): peak steps %s | fall from peak med %.4f max %.4f, >0.05 in %d "
              "| cont. rose while cert. fell (>0.01) in %d | trunc gap @100 med %+.4f -> @end %+.4f, grew in %d/%d"
              % (dd["peak_steps"], dd["fall_from_peak"]["median"], dd["fall_from_peak"]["max"],
                 dd["n_fall_over_0p05"], dd["n_cont_rose_while_cert_fell"],
                 dd["gap_at_100"]["median"], dd["gap_at_end"]["median"], dd["n_gap_grew"], len(rows)))
        for x in drift:
            print("       s%03d cert %s" % (x["seed"] % 1000,
                  " ".join("%.3f" % c for c in x["curve_cert"])))

        # ---- 4. pool --------------------------------------------------------
        fin_w = float(np.median([u["opt_wall_readme_s"] for u in rows]))
        best_w = float(np.median([u["opt_wall_s"] for u in rows]))
        bt = [u["deliver_best"]["eta_top"] for u in rows]
        out["pool"] = {
            "readme_rule": {"wall_s": fin_w, "e_max": {N: e_max(fin, N) for N in (1, 2, 3)},
                            "max": max(fin)},
            "our_rule": {"wall_s": best_w, "e_max": {N: e_max(bt, N) for N in (1, 2, 3)},
                         "max": max(bt)},
        }
        p = out["pool"]
        f4 = lambda v: "%.4f" % v if v is not None else "--"
        print("  4. POOL  README rule: E[max_1..3] %s  max %.4f  (%s/run) | our rule: E[max_1..3] %s  max %.4f  (%s/run)"
              % ([f4(p["readme_rule"]["e_max"][N]) for N in (1, 2, 3)], p["readme_rule"]["max"],
                 S1.fmt_s(fin_w), [f4(p["our_rule"]["e_max"][N]) for N in (1, 2, 3)],
                 p["our_rule"]["max"], S1.fmt_s(best_w)))
        out["wall"] = {k: q([u[k] for u in rows]) for k in
                       ("wall_descent_s", "wall_gate_s", "wall_trace_s", "cert_wall_s", "unit_wall_s")}
        res["targets"][tk] = out

    S1.save_json(os.path.join(DATA, "s5_8a_analysis.json"), res)
    print("\nwrote s5_8a_analysis.json")
    return 0


if __name__ == "__main__":
    sys.exit(main())
