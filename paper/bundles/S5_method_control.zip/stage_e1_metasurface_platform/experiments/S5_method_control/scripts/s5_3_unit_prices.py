"""S5-3  Measured unit prices, and what they say about the analytic cost model.

Every 'equal budget' statement in the paper currently rests on an analytic
model (cost proportional to the cube of the retained mode count, one (16,4)
forward as the unit).  Recomputing the E22 ledger two ways gives OPPOSITE
signs for which arm is cheaper: in analytic units the chain is +16.9% more
expensive than the restart arm, in measured seconds the restart arm is +0.8%
more expensive.  This script measures the prices so the ledger can be stated
in one currency and the analytic model retired to a complexity remark.

Timed, single session, GPU exclusive, complex64:
  * forward at (12,3) (16,4) (20,5) (24,6) (28,7) (32,8) (40,10) (48,12)
  * value+gradient at (12,3) (16,4) (20,5) (24,6)
on both the 10 nm design grid (70,240) and the 5 nm reference grid (140,480),
which also re-measures the S4-3 finding that solve cost is set by the mode
count and not by the design grid.

    python s5_3_unit_prices.py            # ~15 min
    python s5_3_unit_prices.py --reps 5   # shorter
"""
import argparse
import os
import sys
import time
from typing import Dict, List, Sequence, Tuple

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.abspath(os.path.join(
    _HERE, "..", "..", "S4_truncation_and_pixel", "scripts")))
import s4_common as s4c                                    # noqa: E402
import e10_common as C                                     # noqa: E402

DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))

FWD_LEVELS = [(12, 3), (16, 4), (20, 5), (24, 6), (28, 7), (32, 8),
              (40, 10), (48, 12)]
VG_LEVELS = [(12, 3), (16, 4), (20, 5), (24, 6)]
GRIDS = [10, 5]
TARGET = (1, 0)
BETA = 64.0


def _sync():
    if torch.cuda.is_available():
        torch.cuda.synchronize()


def n_modes(level: Sequence[int]) -> int:
    return (2 * int(level[0]) + 1) * (2 * int(level[1]) + 1)


def time_it(fn, reps: int) -> Dict[str, float]:
    fn()                                        # one discarded warm call
    _sync()
    ts: List[float] = []
    for _ in range(reps):
        _sync()
        t0 = time.perf_counter()
        fn()
        _sync()
        ts.append(time.perf_counter() - t0)
    a = np.asarray(ts)
    return {"n": int(a.size), "median": float(np.median(a)),
            "mean": float(a.mean()), "min": float(a.min()),
            "max": float(a.max()),
            "sd": float(a.std(ddof=1)) if a.size > 1 else 0.0}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--reps", type=int, default=10)
    ap.add_argument("--out", type=str,
                    default=os.path.join(DATA, "s5_3_unit_prices.json"))
    args = ap.parse_args()

    store = s4c.new_store(os.path.basename(__file__),
                          {"reps": args.reps, "grids_nm": GRIDS,
                           "fwd_levels": [list(l) for l in FWD_LEVELS],
                           "vg_levels": [list(l) for l in VG_LEVELS],
                           "target": list(TARGET), "beta": BETA})
    store["meta"]["reading_notes"] = [
        "Forward = C.forward_density on a delivered binary; value+gradient = "
        "C.value_grad_latent through the frozen design map, so it also carries "
        "the map's forward and backward and the permittivity/FFT build.",
        "A level is skipped on a grid where it violates the 4M+1 constraint; "
        "the skip is recorded rather than silently dropped.",
        "Prices are for THIS machine and session (RTX 3060, complex64, 3 "
        "threads, exclusive GPU).  They are a currency for the ledger, not a "
        "portable benchmark; the mode counts in the same table are the "
        "hardware-independent column.",
    ]
    rows: Dict[str, Dict] = {}

    print("=" * 72)
    print("s5_3_unit_prices | %s | c64/GPU | reps=%d"
          % (torch.cuda.get_device_name(0) if torch.cuda.is_available()
             else "CPU", args.reps))
    print("=" * 72, flush=True)

    for pix in GRIDS:
        cfg = s4c.PIX[pix]
        seed = s4c.SEED_BASE[TARGET[0]]
        lat = s4c.paired_initial_latent(seed, cfg).to(cfg.device)
        binary = C.hard_binary(lat, cfg)
        for lv in FWD_LEVELS:
            key = "fwd|%d|%d-%d" % (pix, lv[0], lv[1])
            if not cfg.supports(tuple(lv)):
                ny_min, nx_min = cfg.min_grid_for(tuple(lv))
                rows[key] = {"kind": "fwd", "pixel_nm": pix, "level": list(lv),
                             "n_modes": n_modes(lv), "skipped": True,
                             "reason": "4M+1: needs (ny,nx)>=(%d,%d), grid %r"
                                       % (ny_min, nx_min, tuple(cfg.shape))}
                print("  skip fwd %2d nm %-8s  %s" % (pix, str(lv),
                                                      rows[key]["reason"]),
                      flush=True)
                continue
            t = time_it(lambda: C.forward_density(binary, tuple(lv), TARGET,
                                                  cfg, audit=False), args.reps)
            rows[key] = {"kind": "fwd", "pixel_nm": pix, "level": list(lv),
                         "n_modes": n_modes(lv), "skipped": False, "t": t}
            print("  fwd  %2d nm %-8s 2N=%5d  median %8.4f s  [%.4f, %.4f]"
                  % (pix, str(lv), 2 * n_modes(lv), t["median"], t["min"],
                     t["max"]), flush=True)

        for lv in VG_LEVELS:
            key = "vg|%d|%d-%d" % (pix, lv[0], lv[1])
            if not cfg.supports(tuple(lv)):
                rows[key] = {"kind": "vg", "pixel_nm": pix, "level": list(lv),
                             "n_modes": n_modes(lv), "skipped": True,
                             "reason": "4M+1"}
                continue

            def _vg(level=tuple(lv)):
                v, g = C.value_grad_latent(lat, level, TARGET, BETA, cfg)
                del g
            t = time_it(_vg, args.reps)
            rows[key] = {"kind": "vg", "pixel_nm": pix, "level": list(lv),
                         "n_modes": n_modes(lv), "skipped": False, "t": t}
            print("  vg   %2d nm %-8s 2N=%5d  median %8.4f s  [%.4f, %.4f]"
                  % (pix, str(lv), 2 * n_modes(lv), t["median"], t["min"],
                     t["max"]), flush=True)

    store["units"] = rows

    # --- the two ledgers, side by side, on E22's own arm definitions --------
    def price(kind, pix, lv):
        r = rows.get("%s|%d|%d-%d" % (kind, pix, lv[0], lv[1]))
        return None if (r is None or r.get("skipped")) else r["t"]["median"]

    ref = price("fwd", 10, (16, 4))
    model = {}
    measured = {}
    for lv in FWD_LEVELS:
        p = price("fwd", 10, lv)
        if p is None or ref is None:
            continue
        model[str(lv)] = (n_modes(lv) / n_modes((16, 4))) ** 3
        measured[str(lv)] = p / ref
    store["model_vs_measured_fwd_ratio_to_16_4"] = {
        "analytic_n_cubed": model, "measured": measured,
        "note": "analytic = (N/N_16_4)^3 with N the retained mode count; "
                "measured = median seconds ratio on the 10 nm grid",
    }
    vg12, vg24 = price("vg", 10, (12, 3)), price("vg", 10, (24, 6))
    if vg12 and vg24:
        store["descent_ratio_24_6_over_12_3"] = {
            "analytic": (n_modes((24, 6)) / n_modes((12, 3))) ** 3,
            "measured": vg24 / vg12}
    p10 = {k: price("fwd", 10, k) for k in [(20, 5), (24, 6), (32, 8), (40, 10)]}
    p5 = {k: price("fwd", 5, k) for k in [(20, 5), (24, 6), (32, 8), (40, 10)]}
    store["grid_independence_fwd"] = {
        str(k): {"10nm": p10[k], "5nm": p5[k],
                 "rel_diff": (None if not (p10[k] and p5[k])
                              else (p5[k] - p10[k]) / p10[k])}
        for k in p10}

    s4c.save_json(args.out, store)
    print("=" * 72)
    if ref:
        print("  analytic vs measured forward ratios (relative to (16,4)):")
        for k in measured:
            print("    %-9s analytic %8.2f   measured %8.2f" %
                  (k, model[k], measured[k]))
    if vg12 and vg24:
        print("  descent (24,6)/(12,3): analytic %.1f, measured %.1f"
              % (store["descent_ratio_24_6_over_12_3"]["analytic"],
                 store["descent_ratio_24_6_over_12_3"]["measured"]))
    print("wrote %s" % args.out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
