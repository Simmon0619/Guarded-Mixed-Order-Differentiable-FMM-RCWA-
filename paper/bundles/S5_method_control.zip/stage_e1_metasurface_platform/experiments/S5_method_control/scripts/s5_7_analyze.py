"""Analysis of S5-7: engine, broadening, and the published workflow.

Three contrasts plus one decomposition.

  1. ENGINE       T-BASE vs O-BASE (s5_4).  Same protocol, same steps, same
                  gate, same design map; only the gradient engine differs.
                  Seed blocks are disjoint, so this is distributional, not
                  paired.
  2. BROADENING   T-BASE vs T-BASE-NOBROAD.  SAME seeds, so paired: the only
                  difference is torcwa's stable_eig_grad.
  3. END TO END   T-README vs O-CHAIN (s5_1 GATE1), at matched wall clock.
  4. DECOMPOSITION of what T-README would report.  Its headline number is its
     final CONTINUOUS field read at its own SINGLE order.  The certified number
     is that design hard-thresholded and read at the top of the ladder.  The
     gap between them is two different things and must be split:

         reported(continuous @ L)  -  eta(binary @ L)        = relaxation
         eta(binary @ L)           -  eta(binary @ ladder)   = truncation

     The second needs one extra forward per design at its own single order;
     that is what this script computes (a few seconds in total).
"""
import json
import os
import sys
from types import SimpleNamespace

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import s5_1_gate_tier as S1                                        # noqa: E402
from workbench.protocol import DEFAULT                             # noqa: E402
from workbench.app import gate_eval                                # noqa: E402
import trustworthy_fmm.solvers.vector_2d as _v2d                   # noqa: E402
import trustworthy_fmm.fourier.convolution as _conv                # noqa: E402

DATA = S1.DATA
EXPD = S1.DESIGNS
RNG = np.random.default_rng(20260910)
NBOOT = 10000


def q(v):
    a = np.asarray(v, float)
    if not a.size:
        return None
    return {"n": int(a.size), "median": float(np.median(a)),
            "q1": float(np.percentile(a, 25)), "q3": float(np.percentile(a, 75)),
            "min": float(a.min()), "max": float(a.max()),
            "mean": float(a.mean()),
            "sd": float(a.std(ddof=1)) if a.size > 1 else 0.0}


def paired(a, b):
    d = np.asarray(a, float) - np.asarray(b, float)
    if not d.size:
        return None
    idx = RNG.integers(0, d.size, size=(NBOOT, d.size))
    meds = np.median(d[idx], axis=1)
    return {"n": int(d.size), "median": float(np.median(d)),
            "min": float(d.min()), "max": float(d.max()),
            "ci95": [float(np.percentile(meds, 2.5)),
                     float(np.percentile(meds, 97.5))],
            "n_pos": int((d > 0).sum()), "n_neg": int((d < 0).sum())}


def main():
    torch.set_num_threads(int(os.environ.get("FMM_THREADS", "3")))
    _conv.VECTORIZED_CONV = True
    _v2d.FAST_DIAGNOSTICS = True
    _v2d.MEMORY_EFFICIENT = True
    device = "cuda" if torch.cuda.is_available() else "cpu"
    cfg = DEFAULT.variant(ny=S1.NY, nx=S1.NX)

    U7 = json.load(open(os.path.join(DATA, "s5_7_torcwa.json"),
                        encoding="utf-8"))["units"]
    U4 = json.load(open(os.path.join(DATA, "s5_4_restart_baseline.json"),
                        encoding="utf-8"))["units"]
    U1 = json.load(open(os.path.join(DATA, "s5_1_gate_tier.json"),
                        encoding="utf-8"))["units"]
    res = {"n_units_s5_7": len(U7), "targets": {}}
    targets = sorted({v["target"][0] for v in U7.values()})

    # ---- 4. decomposition: one extra forward per T-README design ----------
    print("=== 0. decomposing what T-README would report")
    for k, v in U7.items():
        if not v["arm"].startswith("T-README") or "eta_binary_at_level" in v:
            continue
        b = torch.from_numpy(np.load(os.path.join(
            DATA, v["files"]["binary"])).astype("float64"))
        c = SimpleNamespace(cfg=cfg, mode=S1.MODE, theta=0.0, phi=0.0,
                            target=tuple(v["target"]), dtype=torch.complex64,
                            device=device, offload=False)
        lv = tuple(v["level_used"])
        eb = gate_eval(b, lv, c)
        v["eta_binary_at_level"] = eb
        v["gap_relaxation"] = v["reported_continuous"] - eb
        v["gap_truncation"] = eb - v["eta_top"]
    print("  done (%d T-README units)"
          % sum(1 for v in U7.values() if v["arm"].startswith("T-README")))

    for m in targets:
        tk = "%d-0" % m
        out = {}
        arms7 = {}
        for arm in ("T-BASE", "T-BASE-NOBROAD", "T-README-D", "T-README-G"):
            rows = [v for v in U7.values()
                    if v["target"][0] == m and v["arm"] == arm]
            if rows:
                rows.sort(key=lambda r: r["index"])
                arms7[arm] = rows
        o_base = [v for v in U4.values() if v["target"][0] == m]
        o_chain = [v for v in U1.values()
                   if v["target"][0] == m and v["arm"] == "GATE1"]

        print("\n" + "=" * 74)
        print("m=%d" % m)
        # ---- 1. engine -----------------------------------------------------
        if "T-BASE" in arms7 and o_base:
            t = [r["eta_top"] for r in arms7["T-BASE"]]
            o = [r["eta_top"] for r in o_base]
            tw = [r["opt_wall_s"] for r in arms7["T-BASE"]]
            ow = [r["opt_wall_s"] for r in o_base]
            out["engine"] = {"T_BASE": q(t), "O_BASE": q(o),
                             "T_BASE_wall_s": q(tw), "O_BASE_wall_s": q(ow),
                             "median_diff": float(np.median(t) - np.median(o)),
                             "note": "disjoint seed blocks -> distributional"}
            print("  1. ENGINE (same protocol, different gradient source)")
            print("     T-BASE  n=%2d med %.4f [%.4f,%.4f]  ticket %.0f s"
                  % (len(t), np.median(t), min(t), max(t), np.median(tw)))
            print("     O-BASE  n=%2d med %.4f [%.4f,%.4f]  ticket %.0f s"
                  % (len(o), np.median(o), min(o), max(o), np.median(ow)))
            print("     median difference %+.4f ; torcwa ticket is %.2fx ours"
                  % (np.median(t) - np.median(o), np.median(tw) / np.median(ow)))

        # ---- 2. broadening (paired: same seeds) -----------------------------
        if "T-BASE" in arms7 and "T-BASE-NOBROAD" in arms7:
            a = {r["seed"]: r["eta_top"] for r in arms7["T-BASE"]}
            b = {r["seed"]: r["eta_top"] for r in arms7["T-BASE-NOBROAD"]}
            common = sorted(set(a) & set(b))
            p = paired([a[s] for s in common], [b[s] for s in common])
            same = sum(1 for s in common
                       if next(r for r in arms7["T-BASE"] if r["seed"] == s)
                       ["mask_sha1"] ==
                       next(r for r in arms7["T-BASE-NOBROAD"]
                            if r["seed"] == s)["mask_sha1"])
            out["broadening"] = {"paired_on_minus_off": p,
                                 "identical_masks": same, "n": len(common)}
            print("  2. BROADENING, paired on the same seeds (on - off)")
            print("     med %+.4f  range [%+.4f,%+.4f]  CI95 [%+.4f,%+.4f]"
                  "  +%d/-%d | identical masks %d/%d"
                  % (p["median"], p["min"], p["max"], p["ci95"][0],
                     p["ci95"][1], p["n_pos"], p["n_neg"], same, len(common)))

        # ---- 4. decomposition ----------------------------------------------
        for arm in ("T-README-D", "T-README-G"):
            if arm not in arms7:
                continue
            rows = arms7[arm]
            rep = [r["reported_continuous"] for r in rows]
            eb = [r["eta_binary_at_level"] for r in rows]
            top = [r["eta_top"] for r in rows]
            rel = [r["gap_relaxation"] for r in rows]
            tru = [r["gap_truncation"] for r in rows]
            out[arm] = {"reported": q(rep), "binary_at_level": q(eb),
                        "certified_top": q(top), "gap_relaxation": q(rel),
                        "gap_truncation": q(tru),
                        "level_used": rows[0]["level_used"],
                        "wall_s": q([r["opt_wall_s"] for r in rows])}
            print("  4. %s at %s (n=%d): reports %.4f -> binary@same order "
                  "%.4f -> certified %.4f"
                  % (arm, str(tuple(rows[0]["level_used"])), len(rows),
                     np.median(rep), np.median(eb), np.median(top)))
            print("     gap = relaxation %+.4f  +  truncation %+.4f"
                  "   (total %+.4f, %.0f%% of the certified value)"
                  % (np.median(rel), np.median(tru),
                     np.median(rep) - np.median(top),
                     100 * (np.median(rep) - np.median(top)) / np.median(top)))
            print("     wall %s per run" % S1.fmt_s(np.median(
                [r["opt_wall_s"] for r in rows])))

        # ---- 3. end to end --------------------------------------------------
        if "T-README-D" in arms7 and o_chain:
            r = [x["eta_top"] for x in arms7["T-README-D"]]
            c = [x["final_eta_top"] for x in o_chain]
            rw = np.median([x["opt_wall_s"] for x in arms7["T-README-D"]])
            cw = np.median([x["wall_s"]["redescent"] + x["wall_s"]["gate"]
                            for x in o_chain])
            out["end_to_end"] = {"T_README_D": q(r), "O_CHAIN": q(c),
                                 "T_README_wall_s": float(rw),
                                 "O_CHAIN_wall_s": float(cw),
                                 "wall_ratio": float(rw / cw)}
            print("  3. END TO END (certified, both hard-thresholded)")
            print("     T-README-D n=%d med %.4f [%.4f,%.4f]  %s per run"
                  % (len(r), np.median(r), min(r), max(r), S1.fmt_s(rw)))
            print("     O-CHAIN    n=%d med %.4f [%.4f,%.4f]  %s per run "
                  "(%.2fx cheaper)"
                  % (len(c), np.median(c), min(c), max(c), S1.fmt_s(cw),
                     rw / cw))
        res["targets"][tk] = out

    S1.save_json(os.path.join(DATA, "s5_7_torcwa.json"),
                 {"meta": json.load(open(os.path.join(
                     DATA, "s5_7_torcwa.json"), encoding="utf-8"))["meta"],
                  "units": U7})
    S1.save_json(os.path.join(DATA, "s5_7_analysis.json"), res)
    print("\nwrote s5_7_analysis.json (and the decomposition back into "
          "s5_7_torcwa.json)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
