"""Analysis of the S5-8 batch beyond 8a: chains on strong parents (8b), the
parent-order swap (8e), README at the gate order (8c), steps x beta (8d).

Zero solves.  Every file but S5-8a's is optional; what is missing is skipped.

  8b  per unit: gain over its parent, and the equal-budget null -- README gets
      floor(total / run) runs from S5-8a's pool (exact E[max_N], README
      accounting = descent-only wall; our accounting = descent + gate wall
      with our delivery rule).  RAMP - CHAIN paired on parent and noise (m=2).
  8e  per slot against 8b's CHAIN at m=3: same start, same noise, parent
      order (12,3)/(24,6) instead of (20,5)/(32,8).
  8c  README-G at m=3 against S5-8a's (20,5) runs per seed (same start) and
      against the chains; its wall beside theirs.
  8d  the 2x2, paired on the start with S5-8a's (800, 2000) cell.
  Best-of table per target across everything on disk, beside the records.
"""
import json
import math
import os
import sys

import numpy as np

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import s5_1_gate_tier as S1                                        # noqa: E402

DATA = S1.DATA
RNG = np.random.default_rng(20260912)
NBOOT = 10000
RECORDS = {1: 0.8951, 2: 0.8598, 3: 0.6950}     # S5-2's reread of E28 on this machine


def load(name):
    p = os.path.join(DATA, name)
    return json.load(open(p, encoding="utf-8")) if os.path.exists(p) else None


def q(v):
    a = np.asarray([x for x in v if x is not None], float)
    if not a.size:
        return None
    return {"n": int(a.size), "median": float(np.median(a)),
            "q1": float(np.percentile(a, 25)), "q3": float(np.percentile(a, 75)),
            "min": float(a.min()), "max": float(a.max())}


def paired(d):
    d = np.asarray([x for x in d if x is not None], float)
    if not d.size:
        return None
    idx = RNG.integers(0, d.size, size=(NBOOT, d.size))
    meds = np.median(d[idx], axis=1)
    return {"n": int(d.size), "median": float(np.median(d)), "min": float(d.min()),
            "max": float(d.max()),
            "ci95": [float(np.percentile(meds, 2.5)), float(np.percentile(meds, 97.5))],
            "n_pos": int((d > 0).sum()), "n_neg": int((d < 0).sum()),
            "values": [float(x) for x in d]}


def e_max(values, N):
    x = sorted(float(v) for v in values)
    n = len(x)
    if N < 1 or N > n:
        return None
    return sum(x[k - 1] * math.comb(k - 1, N - 1) for k in range(1, n + 1)) / math.comb(n, N)


def fmt(v, f="%.4f"):
    return (f % v) if v is not None else "--"


def main():
    A = load("s5_8a_readme_schedule.json")
    if A is None:
        raise SystemExit("s5_8a_readme_schedule.json missing")
    B = load("s5_8b_chain_strong_parents.json")
    C = load("s5_8c_readme_gate_order.json")
    D = load("s5_8d_steps_beta.json")
    E = load("s5_8e_parent_order.json")
    U7 = load("s5_7_torcwa.json")["units"]
    U1 = load("s5_1_gate_tier.json")["units"]
    res = {"targets": {}, "files": {k: v is not None for k, v in
                                    (("8b", B), ("8c", C), ("8d", D), ("8e", E))}}
    targets = sorted({v["target"][0] for v in A["units"].values()})
    for m in targets:
        tk = "%d-0" % m
        out = {}
        pool = sorted([v for v in A["units"].values() if v["target"][0] == m],
                      key=lambda u: u["index"])
        fin_tops = [u["deliver_final"]["eta_top"] for u in pool]
        best_tops = [u["deliver_best"]["eta_top"] for u in pool]
        w_readme = float(np.median([u["opt_wall_readme_s"] for u in pool]))
        w_ours = float(np.median([u["opt_wall_s"] for u in pool]))
        print("\n" + "=" * 74 + "\nm=%d | 8a pool n=%d: README rule med %.4f max %.4f (%s/run); "
              "our rule med %.4f max %.4f (%s/run)"
              % (m, len(pool), np.median(fin_tops), max(fin_tops), S1.fmt_s(w_readme),
                 np.median(best_tops), max(best_tops), S1.fmt_s(w_ours)))
        out["pool"] = {"n": len(pool), "final_top": q(fin_tops), "best_top": q(best_tops),
                       "wall_readme_s": w_readme, "wall_ours_s": w_ours}

        # ---- 8b ---------------------------------------------------------------
        if B:
            out["8b"] = {}
            for arm in ("CHAIN", "CHAIN-R", "RAMP"):
                rows = sorted([v for v in B["units"].values()
                               if v["target"][0] == m and v["arm"] == arm],
                              key=lambda r: r["parent"]["slot"])
                if not rows:
                    continue
                per = []
                for r in rows:
                    bud = r["budget"]
                    N_r = max(1, int(bud["total_readme_s"] // w_readme))
                    N_o = max(1, int(bud["total_ours_s"] // w_ours))
                    em_r, em_o = e_max(fin_tops, N_r), e_max(best_tops, N_o)
                    per.append({"slot": r["parent"]["slot"], "parent_top": r["parent_eta_top"],
                                "final_top": r["final_eta_top"], "gain": r["gain_top_over_parent"],
                                "n_accept": r["n_accept"], "false": r["n_false_accepts"],
                                "traced": r["n_traced_accepts"],
                                "marginal_s": bud["chain_marginal_s"],
                                "total_readme_s": bud["total_readme_s"], "N_readme": N_r,
                                "e_max_readme": em_r,
                                "chain_minus_e_readme": (r["final_eta_top"] - em_r) if em_r is not None else None,
                                "N_ours": N_o, "e_max_ours": em_o,
                                "chain_minus_e_ours": (r["final_eta_top"] - em_o) if em_o is not None else None,
                                "gate_optimism": r["gate_optimism"]})
                s = {"n": len(per), "per_unit": per,
                     "parent_top": q([p["parent_top"] for p in per]),
                     "final_top": q([p["final_top"] for p in per]),
                     "gain": paired([p["gain"] for p in per]),
                     "accepts": [p["n_accept"] for p in per],
                     "false_accepts": int(sum(p["false"] for p in per)),
                     "traced_accepts": int(sum(p["traced"] for p in per)),
                     "marginal_s": q([p["marginal_s"] for p in per]),
                     "N_readme": [p["N_readme"] for p in per],
                     "chain_minus_e_readme": paired([p["chain_minus_e_readme"] for p in per]),
                     "chain_minus_e_ours": paired([p["chain_minus_e_ours"] for p in per]),
                     "gate_optimism": q([p["gate_optimism"] for p in per])}
                out["8b"][arm] = s
                g, cr = s["gain"], s["chain_minus_e_readme"]
                print("  8b %-7s n=%d | parent med %.4f -> final med %.4f [%.4f,%.4f] | gain med %+.4f "
                      "CI [%+.4f,%+.4f] +%d/-%d | accepts %s | false %d/%d | marginal med %s"
                      % (arm, s["n"], s["parent_top"]["median"], s["final_top"]["median"],
                         s["final_top"]["min"], s["final_top"]["max"], g["median"], g["ci95"][0],
                         g["ci95"][1], g["n_pos"], g["n_neg"], s["accepts"], s["false_accepts"],
                         s["traced_accepts"], S1.fmt_s(s["marginal_s"]["median"])))
                if cr:
                    print("     equal budget vs 8a pool: N_readme %s | chain - E[max_N] med %+.4f CI [%+.4f,%+.4f] +%d/-%d "
                          "(README rule) | %+.4f (our rule)"
                          % (s["N_readme"], cr["median"], cr["ci95"][0], cr["ci95"][1], cr["n_pos"],
                             cr["n_neg"], s["chain_minus_e_ours"]["median"]))
            if "CHAIN" in out["8b"] and "RAMP" in out["8b"]:
                c = {p["slot"]: p["final_top"] for p in out["8b"]["CHAIN"]["per_unit"]}
                g = {p["slot"]: p["final_top"] for p in out["8b"]["RAMP"]["per_unit"]}
                d = paired([g[s] - c[s] for s in sorted(set(c) & set(g))])
                out["8b"]["RAMP_minus_CHAIN"] = d
                if d:
                    print("  8b RAMP - CHAIN (paired on parent+noise): med %+.4f CI [%+.4f,%+.4f] +%d/-%d"
                          % (d["median"], d["ci95"][0], d["ci95"][1], d["n_pos"], d["n_neg"]))

        # ---- 8e (m=3) -----------------------------------------------------------
        if E and m == 3 and E.get("units"):
            rows = sorted(E["units"].values(), key=lambda r: r["parent"]["slot"])
            prs = {u["index"]: u for u in E["parents"].values()}
            chain_b = {}
            if B:
                chain_b = {r["parent"]["slot"]: r for r in B["units"].values()
                           if r["target"][0] == 3 and r["arm"] == "CHAIN"}
            per = []
            for r in rows:
                s_ = r["parent"]["slot"]
                b = chain_b.get(s_)
                per.append({"slot": s_, "parent_top_low": r["parent_eta_top"],
                            "parent_top_rule": b["parent_eta_top"] if b else None,
                            "final_top_low": r["final_eta_top"],
                            "final_top_rule": b["final_eta_top"] if b else None,
                            "diff_low_minus_rule": (r["final_eta_top"] - b["final_eta_top"]) if b else None,
                            "n_accept": r["n_accept"],
                            "total_ours_low_s": r["budget"]["total_ours_s"],
                            "total_ours_rule_s": b["budget"]["total_ours_s"] if b else None,
                            "parent_wall_low_s": prs[s_]["opt_wall_s"] if s_ in prs else None})
            out["8e"] = {"n": len(per), "per_slot": per,
                         "parent_top_low": q([p["parent_top_low"] for p in per]),
                         "parent_top_rule": q([p["parent_top_rule"] for p in per]),
                         "final_top_low": q([p["final_top_low"] for p in per]),
                         "final_top_rule": q([p["final_top_rule"] for p in per]),
                         "diff_low_minus_rule": paired([p["diff_low_minus_rule"] for p in per]),
                         "total_ours_low_s": q([p["total_ours_low_s"] for p in per]),
                         "total_ours_rule_s": q([p["total_ours_rule_s"] for p in per])}
            e = out["8e"]
            print("  8e parents (12,3)/(24,6): top med %s (rule parents %s) -> chain final med %s "
                  "(rule-parent chains %s) | low - rule paired med %s CI %s | total wall med %s vs %s"
                  % (fmt(e["parent_top_low"] and e["parent_top_low"]["median"]),
                     fmt(e["parent_top_rule"] and e["parent_top_rule"]["median"]),
                     fmt(e["final_top_low"] and e["final_top_low"]["median"]),
                     fmt(e["final_top_rule"] and e["final_top_rule"]["median"]),
                     fmt(e["diff_low_minus_rule"] and e["diff_low_minus_rule"]["median"], "%+.4f"),
                     ["%+.4f" % x for x in e["diff_low_minus_rule"]["ci95"]] if e["diff_low_minus_rule"] else "--",
                     S1.fmt_s(e["total_ours_low_s"]["median"]) if e["total_ours_low_s"] else "--",
                     S1.fmt_s(e["total_ours_rule_s"]["median"]) if e["total_ours_rule_s"] else "--"))

        # ---- 8c (m=3) -----------------------------------------------------------
        if C and m == 3 and C.get("units"):
            rows = sorted(C["units"].values(), key=lambda u: u["index"])
            a_by_seed = {u["seed"]: u for u in pool}
            per = [{"seed": u["seed"], "readme_g_final": u["deliver_final"]["eta_top"],
                    "readme_g_best": u["deliver_best"]["eta_top"],
                    "readme_g_reported": u["deliver_final"]["reported_continuous"],
                    "readme_d_final": a_by_seed[u["seed"]]["deliver_final"]["eta_top"]
                    if u["seed"] in a_by_seed else None,
                    "g_minus_d": (u["deliver_final"]["eta_top"]
                                  - a_by_seed[u["seed"]]["deliver_final"]["eta_top"])
                    if u["seed"] in a_by_seed else None,
                    "wall_readme_s": u["opt_wall_readme_s"]} for u in rows]
            out["8c"] = {"n": len(per), "per_seed": per,
                         "readme_g_final": q([p["readme_g_final"] for p in per]),
                         "readme_g_best": q([p["readme_g_best"] for p in per]),
                         "readme_g_reported": q([p["readme_g_reported"] for p in per]),
                         "g_minus_d_paired": paired([p["g_minus_d"] for p in per]),
                         "wall_readme_s": q([p["wall_readme_s"] for p in per])}
            c = out["8c"]
            gd = c["g_minus_d_paired"]
            print("  8c README-G (32,8) m=3: final med %.4f [%.4f,%.4f] | reported med %.4f | G - D paired med %s "
                  "CI %s +%d/-%d | wall med %s (README-D %s)"
                  % (c["readme_g_final"]["median"], c["readme_g_final"]["min"], c["readme_g_final"]["max"],
                     c["readme_g_reported"]["median"], fmt(gd and gd["median"], "%+.4f"),
                     ["%+.4f" % x for x in gd["ci95"]] if gd else "--", gd["n_pos"] if gd else 0,
                     gd["n_neg"] if gd else 0, S1.fmt_s(c["wall_readme_s"]["median"]), S1.fmt_s(w_readme)))

        # ---- 8d (m=1,2) ---------------------------------------------------------
        if D and m in (1, 2):
            cells = {}
            a_by_seed = {u["seed"]: u for u in pool}
            for name in ("S219-B64", "S219-B2000", "S800-B64"):
                rows = sorted([v for k, v in D["units"].items()
                               if v["target"][0] == m and v["cell"] == name],
                              key=lambda u: u["index"])
                if not rows:
                    continue
                bt = [u["deliver_best"]["eta_top"] for u in rows]
                d_vs_8a = paired([u["deliver_best"]["eta_top"]
                                  - a_by_seed[u["seed"]]["deliver_best"]["eta_top"]
                                  for u in rows if u["seed"] in a_by_seed])
                cells[name] = {"n": len(rows), "best_top": q(bt),
                               "final_top": q([u["deliver_final"]["eta_top"] for u in rows]),
                               "best_steps": [u["best_step"] for u in rows],
                               "minus_S800_B2000_paired": d_vs_8a,
                               "opt_wall_s": q([u["opt_wall_s"] for u in rows])}
            cells["S800-B2000"] = {"n": len(pool), "best_top": q(best_tops), "final_top": q(fin_tops),
                                   "best_steps": [u["best_step"] for u in pool],
                                   "opt_wall_s": q([u["opt_wall_s"] for u in pool])}
            out["8d"] = cells
            for name, c in cells.items():
                dv = c.get("minus_S800_B2000_paired")
                print("  8d %-10s n=%d | best top med %.4f [%.4f,%.4f] | vs S800-B2000 paired med %s | best_steps %s"
                      % (name, c["n"], c["best_top"]["median"], c["best_top"]["min"], c["best_top"]["max"],
                         fmt(dv and dv["median"], "%+.4f"), c["best_steps"]))

        # ---- best-of --------------------------------------------------------------
        bo = {"record_S5_2_reread": RECORDS.get(m),
              "8a_readme_rule_max": max(fin_tops), "8a_our_rule_max": max(best_tops),
              "T_README_D_max": max(v["eta_top"] for v in U7.values()
                                    if v["target"][0] == m and v["arm"] == "T-README-D"),
              "S5_1_chain_max_weak_parents": max(v["final_eta_top"] for v in U1.values()
                                                 if v["target"][0] == m)}
        if B:
            for arm in ("CHAIN", "CHAIN-R", "RAMP"):
                vals = [v["final_eta_top"] for v in B["units"].values()
                        if v["target"][0] == m and v["arm"] == arm]
                if vals:
                    bo["8b_%s_max" % arm] = max(vals)
        if E and m == 3 and E.get("units"):
            bo["8e_max"] = max(v["final_eta_top"] for v in E["units"].values())
        if C and m == 3 and C.get("units"):
            bo["8c_README_G_max"] = max(v["deliver_final"]["eta_top"] for v in C["units"].values())
        out["best_of"] = bo
        print("  best-of: " + " | ".join("%s %s" % (k, fmt(v)) for k, v in bo.items()))
        res["targets"][tk] = out

    S1.save_json(os.path.join(DATA, "s5_8_analysis.json"), res)
    print("\nwrote s5_8_analysis.json")
    return 0


if __name__ == "__main__":
    sys.exit(main())
