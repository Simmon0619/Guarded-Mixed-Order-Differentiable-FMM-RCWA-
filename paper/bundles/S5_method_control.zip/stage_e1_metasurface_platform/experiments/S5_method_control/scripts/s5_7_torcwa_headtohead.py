"""S5-7  Head-to-head with TORCWA: engine, then protocol.

Three contrasts, each isolating one thing:

  T-BASE  - O-BASE   =>  the ENGINE.  Same design map, same Adam, same cosine
                         lr, same beta schedule, same 219 steps, same gate
                         scoring, same seeds -- only d(eta)/d(density) comes
                         from TORCWA instead of us.
  O-CHAIN - O-BASE   =>  the PROTOCOL.  Already measured (Sec. 7.2).
  T-README vs O-CHAIN => END TO END: the published practice against our method.

What TORCWA's README (Example 6) actually prescribes, and what we reproduce:

  reproduced exactly : Adam(0.9, 0.999, 1e-8); lr 0.02 with cosine annealing;
                       800 iterations; exponential beta continuation 1 -> 1000;
                       the tanh projection; delivery = the FINAL field; ONE
                       truncation order throughout; no restarts, no global
                       search; TORCWA's own broadening default (on).
  deliberately kept  : our 60 nm periodic Gaussian filter and our y-mirror
    from our side      symmetrisation -- these are the FABRICATION constraint
                       of this problem, not part of anyone's optimiser.  The
                       README's "Gaussian blur" is the same idea with an
                       unspecified radius; changing the radius would change the
                       minimum feature size and make the two arms solve
                       different problems.

  A note on beta.  TORCWA writes the projection as
      1/2 + tanh(2*b*rho - b) / (2*tanh(b))
  and ours is tanh_projection(rho, B, 0.5) = 1/2 + tanh(B*(rho-0.5))/(2*tanh(B/2)).
  These are the SAME function with B = 2b.  So their ramp b: 1 -> 1000 is
  B: 2 -> 2000 in our parameterisation -- 31x sharper than our protocol's
  B: 1 -> 64.  We implement their ramp exactly, via B = 2b.

Delivery is made comparable the only way it can be: BOTH arms are hard
thresholded and scored by ONE engine on the certification ladder.  That single
scorer is licensed by S5-6, which found the two engines agree on these very
designs to |d eta| median 3.7e-5, max 3.1e-4 -- inside this paper's own
resolution floor (Sec. 7.4.2: median 7.2e-5, max 8.5e-4).  For T-README we also
record the value it would REPORT (its final continuous field at its own single
order), because the gap between that and the certified binary is a result.

Descriptive: numbers, not verdicts.

    python s5_7_torcwa_headtohead.py --arms T-BASE --dry-run
    python s5_7_torcwa_headtohead.py --arms T-BASE,T-README-D
    python s5_7_torcwa_headtohead.py --resume
"""
import argparse
import hashlib
import json
import math
import os
import sys
import time
from types import SimpleNamespace

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import s5_1_gate_tier as S1                                        # noqa: E402
from workbench.protocol import DEFAULT, n_terms, cosine_lr, beta_at  # noqa: E402
from workbench.app import (                                        # noqa: E402
    order_rule, app_hard_binary, app_filtered, app_initial_latent, gate_eval,
    value_grad, AppAdam, _has_torcwa,
)
from trustworthy_fmm.fabrication.process import tanh_projection    # noqa: E402
import trustworthy_fmm.solvers.vector_2d as _v2d                   # noqa: E402
import trustworthy_fmm.fourier.convolution as _conv                # noqa: E402

DATA = S1.DATA
DESIGNS = S1.DESIGNS
STEPS_BASE = 219            # our baseline protocol
CKPT_EVERY = 6
STEPS_README = 800          # TORCWA README Example 6
BETA_README_HI = 1000.0     # their parameterisation; ours is 2x that
SEED_BASE = {1: 51000, 2: 52000, 3: 53000}
N_SEEDS = {1: 6, 2: 6, 3: 6}
ARMS = ("T-BASE", "T-BASE-NOBROAD", "T-README-D", "T-README-G")
DRY = {"steps_base": 8, "steps_readme": 12, "ckpt": 4, "seeds": 1}


def sha1_of(t):
    return hashlib.sha1(t.detach().cpu().numpy().astype(np.uint8).tobytes()).hexdigest()


def torcwa_vg(rho, level, target, beta, cfg, mode, dtype, device, broaden):
    """torcwa_value_grad_latent with the broadening switch exposed.

    Identical to workbench.app.torcwa_value_grad_latent except that
    ``stable_eig_grad`` is a parameter: True is TORCWA's own default (its
    Lorentzian broadening, 1e-10), False matches our engine, which runs with no
    broadening at all.
    """
    import torcwa
    x = rho.detach().clone().requires_grad_(True)
    dens = tanh_projection(app_filtered(x, cfg, mode), float(beta), cfg.threshold)
    d = dens.detach().clone().requires_grad_(True)
    real_dtype = torch.float32 if dtype == torch.complex64 else torch.float64
    eps_xy = (cfg.eps_background + (cfg.eps_feature - cfg.eps_background)
              * d.transpose(0, 1).to(device=device, dtype=real_dtype))
    sim = torcwa.rcwa(freq=1.0 / cfg.wavelength_nm,
                      order=[int(level[0]), int(level[1])],
                      L=list(cfg.lattice_nm), dtype=dtype, device=device,
                      stable_eig_grad=bool(broaden))
    sim.add_input_layer(eps=cfg.n_incident ** 2)
    sim.add_output_layer(eps=cfg.n_output ** 2)
    sim.set_incident_angle(inc_ang=0.0, azi_ang=0.0)
    sim.add_layer(cfg.thickness_nm, eps_xy)
    sim.solve_global_smatrix()
    txx = sim.S_parameters(orders=list(target), direction="forward",
                           port="transmission", polarization="xx", ref_order=[0, 0])
    tyx = sim.S_parameters(orders=list(target), direction="forward",
                           port="transmission", polarization="yx", ref_order=[0, 0])
    j = torch.sum(torch.abs(txx) ** 2 + torch.abs(tyx) ** 2)
    g_dens = torch.autograd.grad(j, d)[0]
    dens.backward(g_dens.to(dens.dtype))
    del sim
    return float(j.detach()), x.grad.detach()


def run_base_ticket(ctx, seed, steps, ckpt_every, broaden, events):
    """Our baseline protocol, TORCWA supplying value+gradient.

    Mirrors s5_4_restart_baseline.ticket exactly: beta continuation 1 -> 64,
    cosine lr, hard-binary checkpoints scored AT THE GATE ORDER by OUR engine
    (the neutral scorer), deliver the best gate checkpoint.
    """
    cfg, mode = ctx.cfg, ctx.mode
    latent = app_initial_latent(seed, cfg, mode, ctx.device)
    adam = AppAdam(latent.shape, cfg, mode, ctx.device)
    best, ckpts = None, []
    t_desc = t_gate = 0.0
    for t in range(steps):
        progress = t / max(steps - 1, 1)
        beta = beta_at(progress, cfg=cfg)
        lr = cosine_lr(progress, cfg)
        t0 = time.perf_counter()
        try:
            _, grad = torcwa_vg(latent, ctx.level_d, ctx.target, beta, cfg,
                                mode, ctx.dtype, ctx.device, broaden)
            ok = bool(torch.isfinite(grad).all())
        except RuntimeError as exc:
            events.append({"event": "raised", "step": t, "detail": str(exc)[:160]})
            ok, grad = False, None
        t_desc += time.perf_counter() - t0
        if ok:
            latent = adam.step(latent, grad, lr)
        else:
            events.append({"event": "skipped_update", "step": t})
        if (t + 1) % ckpt_every == 0 or t == steps - 1:
            b = app_hard_binary(latent.detach().cpu(), cfg, mode)
            t0 = time.perf_counter()
            eg = gate_eval(b, ctx.gate, ctx)          # OUR engine scores
            t_gate += time.perf_counter() - t0
            ckpts.append({"step": t + 1, "eta_gate": eg, "beta": beta})
            if best is None or eg > best["eta_gate"]:
                best = {"eta_gate": eg, "step": t + 1, "binary": b,
                        "latent": latent.detach().cpu().clone()}
    return {"best": best, "checkpoints": ckpts, "n_ckpt": len(ckpts),
            "opt_wall_s": t_desc + t_gate, "wall_descent_s": t_desc,
            "wall_gate_s": t_gate}


def run_readme(ctx, seed, level, steps, events):
    """TORCWA's README workflow at ONE truncation order.

    800 steps, exponential beta 1 -> 1000 in THEIR parameterisation (= 2 -> 2000
    in ours; see the module docstring), cosine lr, no checkpoints, no gate
    tier, delivery = the final field.
    """
    cfg, mode = ctx.cfg, ctx.mode
    latent = app_initial_latent(seed, cfg, mode, ctx.device)
    adam = AppAdam(latent.shape, cfg, mode, ctx.device)
    t_desc = 0.0
    traj = []
    for t in range(steps):
        b_t = math.exp(t * math.log(BETA_README_HI) / steps)   # their ramp
        beta_ours = 2.0 * b_t                                  # same function
        lr = cosine_lr(t / max(steps - 1, 1), cfg)
        t0 = time.perf_counter()
        try:
            v, grad = torcwa_vg(latent, level, ctx.target, beta_ours, cfg,
                                mode, ctx.dtype, ctx.device, True)
            ok = bool(torch.isfinite(grad).all())
        except RuntimeError as exc:
            events.append({"event": "raised", "step": t, "detail": str(exc)[:160]})
            ok, grad, v = False, None, float("nan")
        t_desc += time.perf_counter() - t0
        if ok:
            latent = adam.step(latent, grad, lr)
            traj.append(round(v, 6))
        else:
            events.append({"event": "skipped_update", "step": t})
    # what it would REPORT: its own final continuous field at its own order
    beta_final = 2.0 * BETA_README_HI
    dens = tanh_projection(app_filtered(latent.detach().cpu(), cfg, mode),
                           beta_final, cfg.threshold)
    reported = gate_eval(dens, level, ctx)
    b = app_hard_binary(latent.detach().cpu(), cfg, mode)
    return {"best": {"binary": b, "latent": latent.detach().cpu().clone(),
                     "eta_gate": reported, "step": steps},
            "reported_continuous": reported, "single_level": list(level),
            "trajectory_tail": traj[-10:], "opt_wall_s": t_desc,
            "wall_descent_s": t_desc, "wall_gate_s": 0.0, "n_ckpt": 0}


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--arms", type=str, default="T-BASE,T-README-D")
    ap.add_argument("--targets", type=str, default="1,2,3")
    ap.add_argument("--seeds", type=int, default=0)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--out", type=str, default=None)
    args = ap.parse_args()
    if not _has_torcwa():
        raise SystemExit("torcwa is not importable")

    torch.set_num_threads(int(os.environ.get("FMM_THREADS", "3")))
    _conv.VECTORIZED_CONV = True
    _v2d.FAST_DIAGNOSTICS = True
    _v2d.MEMORY_EFFICIENT = True
    device = "cuda" if torch.cuda.is_available() else "cpu"
    dtype = torch.complex64
    cfg = DEFAULT.variant(ny=S1.NY, nx=S1.NX)
    ref_cfg = DEFAULT.variant(ny=S1.REF_NY, nx=S1.REF_NX)
    targets = [(int(t.strip()), 0) for t in args.targets.split(",") if t.strip()]
    arms = [a.strip() for a in args.arms.split(",") if a.strip()]
    for a in arms:
        if a not in ARMS:
            raise SystemExit("unknown arm %r; known: %s" % (a, list(ARMS)))
    sb, sr, ck = STEPS_BASE, STEPS_README, CKPT_EVERY
    if args.dry_run:
        sb, sr, ck = DRY["steps_base"], DRY["steps_readme"], DRY["ckpt"]

    out = args.out or os.path.join(
        DATA, "s5_7_torcwa%s.json" % ("_dry" if args.dry_run else ""))
    store = {"meta": {}, "units": {}}
    if args.resume and os.path.exists(out):
        store = json.load(open(out, encoding="utf-8"))
        print("resuming: %d units done" % len(store["units"]), flush=True)
    store["meta"].update({
        "script": os.path.basename(__file__),
        "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "gpu": torch.cuda.get_device_name(0) if device == "cuda" else "cpu",
        "pixel_nm": S1.PIXEL_NM, "grid": [S1.NY, S1.NX],
        "steps_base": sb, "ckpt_every": ck, "steps_readme": sr,
        "beta_readme_hi_torcwa": BETA_README_HI,
        "beta_readme_hi_ours": 2 * BETA_README_HI,
        "seed_base": SEED_BASE, "arms": arms,
        "reading_notes": [
            "T-BASE is OUR baseline protocol with TORCWA supplying "
            "value+gradient; every checkpoint is scored by OUR engine at the "
            "gate order, so the two engines' deliveries are ranked by one "
            "neutral scorer.  Its comparator is S5-4 (same protocol, same "
            "steps, same gate, our gradients) -- NOT the same seeds, since the "
            "arms use disjoint seed blocks; the comparison is distributional.",
            "T-README reproduces TORCWA's README Example 6: 800 steps, "
            "exponential beta 1->1000 in their parameterisation (= 2->2000 in "
            "ours; the two tanh projections are the same function with B=2b), "
            "cosine lr, one order throughout, no gate tier, delivery = the "
            "final field.  Their 'Gaussian blur' is replaced by OUR 60 nm "
            "periodic Gaussian because the filter is this problem's "
            "fabrication constraint, not part of their optimiser.",
            "reported_continuous is what T-README would PUBLISH: its final "
            "continuous field read at its own single order.  eta_top is the "
            "same design hard-thresholded and certified.  Their difference is "
            "the relaxed-value inflation, and it is a result, not an error.",
            "T-BASE-NOBROAD is T-BASE with torcwa's stable_eig_grad=False, so "
            "both engines run with NO eigendecomposition broadening.  T-BASE "
            "itself uses TORCWA's own default (broadening on, 1e-10).",
        ],
    })

    print("=" * 78)
    print("s5_7_torcwa_headtohead | %s | c64 | arms %s"
          % (store["meta"]["gpu"], arms))
    t_start, done = time.perf_counter(), 0
    for tgt in targets:
        m = tgt[0]
        rule = order_rule(tgt, cfg)
        ladder = list(rule["ladder"])
        n_seeds = args.seeds or N_SEEDS[m]
        if args.dry_run:
            n_seeds = DRY["seeds"]
        ctx = SimpleNamespace(cfg=cfg, mode=S1.MODE, theta=0.0, phi=0.0,
                              target=tgt, level_d=rule["descent"],
                              gate=rule["gate"], dtype=dtype, device=device,
                              offload=False, accept_rule="nominal",
                              cd_biases=[-20.0, 20.0])
        ref_ctx = SimpleNamespace(**{**vars(ctx), "cfg": ref_cfg})
        reader = S1.RefReader(ctx, ref_ctx, ladder)
        tkey = "%d-%d" % tgt
        print("  m=%d descent %s gate %s ladder %s | %d seeds"
              % (m, rule["descent"], rule["gate"], ladder, n_seeds), flush=True)
        for arm in arms:
            for i in range(n_seeds):
                key = "%s|%s|s%02d" % (tkey, arm, i)
                if key in store["units"]:
                    continue
                seed = SEED_BASE[m] + i
                ev = []
                t0 = time.perf_counter()
                if arm.startswith("T-BASE"):
                    r = run_base_ticket(ctx, seed, sb, ck,
                                        arm == "T-BASE", ev)
                    level = tuple(rule["descent"])
                else:
                    level = (tuple(rule["descent"]) if arm.endswith("-D")
                             else tuple(rule["gate"]))
                    r = run_readme(ctx, seed, level, sr, ev)
                b = r["best"]["binary"]
                lad = reader.ladder_of(b)
                top = lad["%d-%d" % ladder[-1]]
                tag = "s5_7_%s_%s_s%02d" % (arm.replace("-", ""),
                                            tkey.replace("-", "_"), i)
                np.save(os.path.join(DESIGNS, tag + "_binary.npy"),
                        b.detach().cpu().numpy())
                np.save(os.path.join(DESIGNS, tag + "_latent.npy"),
                        r["best"]["latent"].detach().cpu().numpy())
                store["units"][key] = {
                    "target": list(tgt), "arm": arm, "seed": seed, "index": i,
                    "engine": "torcwa", "level_used": list(level),
                    "descent_level": list(rule["descent"]),
                    "gate": list(rule["gate"]),
                    "ladder": [list(l) for l in ladder],
                    "eta_gate_best": r["best"]["eta_gate"],
                    "best_step": r["best"]["step"], "n_ckpt": r["n_ckpt"],
                    "final_ladder": lad, "eta_top": top,
                    "reported_continuous": r.get("reported_continuous"),
                    "relaxed_inflation": (
                        r["reported_continuous"] - top
                        if r.get("reported_continuous") is not None else None),
                    "opt_wall_s": r["opt_wall_s"],
                    "wall_descent_s": r["wall_descent_s"],
                    "wall_gate_s": r["wall_gate_s"],
                    "mask_sha1": sha1_of(b), "grad_events": ev,
                    "unit_wall_s": time.perf_counter() - t0,
                    "files": {"binary": "designs/%s_binary.npy" % tag,
                              "latent": "designs/%s_latent.npy" % tag},
                }
                S1.save_json(out, store)
                done += 1
                el = time.perf_counter() - t_start
                extra = ("" if r.get("reported_continuous") is None else
                         "  reported %.4f (inflation %+.4f)"
                         % (r["reported_continuous"],
                            r["reported_continuous"] - top))
                print("    %-16s s%02d @%-8s gate %.4f -> top %.4f%s | opt %s"
                      "  [%s]" % (arm, i, str(level), r["best"]["eta_gate"],
                                  top, extra, S1.fmt_s(r["opt_wall_s"]),
                                  S1.fmt_s(el)), flush=True)
    store["meta"]["total_wall_s"] = time.perf_counter() - t_start
    S1.save_json(out, store)
    print("=" * 78)
    print("wrote %s (%d units, %s)"
          % (out, len(store["units"]), S1.fmt_s(store["meta"]["total_wall_s"])))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
