"""Descriptive summary of S5-1 (the gate tier inside the chain).

Reads data/s5_1_gate_tier.json, prints the tables for S5_实验记录.md and writes
data/s5_1_analysis.json.  Medians, quartiles, extremes, sign counts, and
percentile-bootstrap intervals for paired differences.  No hypothesis tests,
no p-values.
"""
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "..", "data")
SRC = os.path.join(DATA, "s5_1_gate_tier.json")
OUT = os.path.join(DATA, "s5_1_analysis.json")

CHAINS = ("GATE0", "GATE1", "GATE2")
ALL_ARMS = CHAINS + ("SHOT",)
PAIRS = (("GATE1", "GATE0"), ("GATE2", "GATE1"), ("GATE2", "GATE0"),
         ("GATE1", "SHOT"))
RNG = np.random.default_rng(20260909)
NBOOT = 10000


def q(v):
    a = np.asarray(v, dtype=float)
    if a.size == 0:
        return None
    return {"n": int(a.size), "median": float(np.median(a)),
            "q1": float(np.percentile(a, 25)), "q3": float(np.percentile(a, 75)),
            "min": float(a.min()), "max": float(a.max()),
            "mean": float(a.mean()),
            "sd": float(a.std(ddof=1)) if a.size > 1 else 0.0}


def paired(a, b):
    d = np.asarray(a, dtype=float) - np.asarray(b, dtype=float)
    if d.size == 0:
        return None
    idx = RNG.integers(0, d.size, size=(NBOOT, d.size))
    meds = np.median(d[idx], axis=1)
    return {"n": int(d.size), "median": float(np.median(d)),
            "q1": float(np.percentile(d, 25)), "q3": float(np.percentile(d, 75)),
            "min": float(d.min()), "max": float(d.max()),
            "ci95": [float(np.percentile(meds, 2.5)),
                     float(np.percentile(meds, 97.5))],
            "n_pos": int((d > 0).sum()), "n_neg": int((d < 0).sum()),
            "n_zero": int((d == 0).sum())}


def main():
    d = json.load(open(SRC, encoding="utf-8"))
    U = d["units"]
    meta = d["meta"]
    bases = sorted({k.rsplit("|", 1)[0] for k in U})
    targets = sorted({U[k]["target"][0] for k in U})
    res = {"source": os.path.basename(SRC), "n_units": len(U),
           "order_rule": meta.get("order_rule"),
           "total_wall_s": meta.get("total_wall_s")}

    print("=== 0. coverage and mechanical checks")
    ev = {k: v["grad_events"] for k, v in U.items() if v.get("grad_events")}
    n_skip = sum(1 for k, v in U.items() for e in v.get("grad_events", [])
                 if e.get("event") == "skipped_update")
    print("  %d arm-runs over %d units; NaN-guard events in %d runs, "
          "skipped updates %d" % (len(U), len(bases), len(ev), n_skip))
    res["grad_events"] = {k: v for k, v in ev.items()}
    res["n_skipped_updates"] = n_skip

    # ---------- 1. delivered value at the top of the certification ladder ----
    print("\n=== 1. delivered eta at the top ladder rung, by target x arm")
    tab = {}
    for m in targets:
        for arm in ALL_ARMS:
            rows = [v for k, v in U.items()
                    if v["target"][0] == m and v["arm"] == arm]
            if not rows:
                continue
            tab["m%d|%s" % (m, arm)] = {
                "top": q([r["final_eta_top"] for r in rows]),
                "gain_over_parent": q([r["gain_top_over_parent"] for r in rows]),
                "gate_optimism": q([r["gate_optimism"] for r in rows]),
                "n_accept": q([r["n_accept"] for r in rows]),
                "unchanged_from_parent": int(sum(
                    1 for r in rows if r["delivered_parent_unchanged"])),
                "gate": rows[0]["gate"],
                "ladder_top": rows[0]["ladder"][-1] if rows[0]["ladder"] else None,
            }
            e = tab["m%d|%s" % (m, arm)]
            print("  m=%d %-5s gate %-8s top med %.4f [%.4f,%.4f] | gain %+.4f "
                  "| optimism %+.4f | accepts med %.1f | =parent %d/%d"
                  % (m, arm, str(tuple(e["gate"])), e["top"]["median"],
                     e["top"]["min"], e["top"]["max"],
                     e["gain_over_parent"]["median"],
                     e["gate_optimism"]["median"], e["n_accept"]["median"],
                     e["unchanged_from_parent"], e["top"]["n"]))
    res["by_target_arm"] = tab

    # ---------- 2. paired differences, same parent + same noise --------------
    print("\n=== 2. paired differences in delivered eta (same unit)")
    pd = {}
    for m in list(targets) + ["all"]:
        for (a, b) in PAIRS:
            xs, ys = [], []
            for base in bases:
                ra, rb = U.get(base + "|" + a), U.get(base + "|" + b)
                if ra is None or rb is None:
                    continue
                if m != "all" and ra["target"][0] != m:
                    continue
                xs.append(ra["final_eta_top"])
                ys.append(rb["final_eta_top"])
            p = paired(xs, ys)
            if p is None:
                continue
            pd["%s-%s|%s" % (a, b, m)] = p
            print("  %-13s m=%-3s med %+.4f  IQR [%+.4f,%+.4f]  CI95 "
                  "[%+.4f,%+.4f]  +%d/-%d/0:%d (n=%d)"
                  % ("%s-%s" % (a, b), str(m), p["median"], p["q1"], p["q3"],
                     p["ci95"][0], p["ci95"][1], p["n_pos"], p["n_neg"],
                     p["n_zero"], p["n"]))
    res["paired"] = pd

    # ---------- 3. gate optimism, the honesty of each tier -------------------
    print("\n=== 3. gate optimism (gate reading - top rung), by target x arm")
    opt = {}
    for m in targets:
        for arm in ALL_ARMS:
            rows = [v for k, v in U.items()
                    if v["target"][0] == m and v["arm"] == arm]
            if not rows:
                continue
            rel = [r["gate_optimism"] / r["final_eta_top"] for r in rows
                   if r["final_eta_top"]]
            opt["m%d|%s" % (m, arm)] = {
                "abs": q([r["gate_optimism"] for r in rows]),
                "rel": q(rel),
                "vs_40_10_at_5nm": q([r["gate_optimism_vs_40_10_at_5nm"]
                                      for r in rows]),
                "gate": rows[0]["gate"]}
            e = opt["m%d|%s" % (m, arm)]
            print("  m=%d %-5s gate %-8s abs med %+.4f  rel med %+.1f%%"
                  % (m, arm, str(tuple(e["gate"])), e["abs"]["median"],
                     100 * e["rel"]["median"]))
    res["gate_optimism"] = opt

    # ---------- 4. accepts, false accepts, divergence ------------------------
    print("\n=== 4. acceptance behaviour")
    acc = {}
    for m in targets:
        for arm in CHAINS:
            rows = [v for k, v in U.items()
                    if v["target"][0] == m and v["arm"] == arm]
            if not rows:
                continue
            traced = sum(r["n_traced_accepts"] for r in rows)
            false = sum(r["n_false_accepts"] for r in rows)
            acc["m%d|%s" % (m, arm)] = {
                "n_accept": q([r["n_accept"] for r in rows]),
                "n_jumps": rows[0]["n_jumps"],
                "traced_accepts": traced, "false_accepts": false,
                "false_rate": (false / traced) if traced else None,
                "false_loss_total": sum(r["false_accept_loss"] for r in rows),
                "n_runs": len(rows)}
            e = acc["m%d|%s" % (m, arm)]
            print("  m=%d %-5s accepts med %.1f of %d | traced %d, false %d%s"
                  % (m, arm, e["n_accept"]["median"], e["n_jumps"], traced,
                     false, ("  (%.0f%%, total loss %+.4f)"
                             % (100 * e["false_rate"], e["false_loss_total"]))
                     if traced else ""))
    res["acceptance"] = acc

    div = d.get("divergence") or {}
    if div:
        firsts = [v["first_divergence_jump"] for v in div.values()
                  if v["first_divergence_jump"] is not None]
        ndiff = [v["n_jumps_with_differing_decision"] for v in div.values()]
        res["divergence_summary"] = {
            "n_units": len(div),
            "n_units_that_ever_diverge": len(firsts),
            "first_divergence_jump": q(firsts) if firsts else None,
            "n_differing_decisions": q(ndiff)}
        print("  chains diverge in %d/%d units; first divergence at jump "
              "median %s; differing decisions median %.1f"
              % (len(firsts), len(div),
                 ("%.1f" % np.median(firsts)) if firsts else "n/a",
                 float(np.median(ndiff))))

    # ---------- 5. native vs 5 nm-lifted reference ---------------------------
    nl = [v["native_minus_lifted_40_10"] for v in U.values()
          if v.get("native_minus_lifted_40_10") is not None]
    if nl:
        res["native_minus_lifted_40_10"] = q(nl)
        rel = [v["native_minus_lifted_40_10"] / v["final_ladder"]["40-10@5nm"]
               for v in U.values()
               if v.get("native_minus_lifted_40_10") is not None
               and v["final_ladder"].get("40-10@5nm")]
        res["native_minus_lifted_40_10_rel"] = q(rel)
        print("\n=== 5. (40,10) native 10 nm minus 5 nm-lifted: med %+.4f "
              "(%.2f%%), max |.| %.4f"
              % (np.median(nl), 100 * np.median(rel),
                 max(abs(x) for x in nl)))

    # ---------- 6. cost ------------------------------------------------------
    print("\n=== 6. wall clock by arm (median seconds per run)")
    cost = {}
    for m in targets:
        for arm in ALL_ARMS:
            rows = [v for k, v in U.items()
                    if v["target"][0] == m and v["arm"] == arm]
            if not rows:
                continue
            cost["m%d|%s" % (m, arm)] = {
                "redescent_s": q([r["wall_s"]["redescent"] for r in rows]),
                "gate_s": q([r["wall_s"]["gate"] for r in rows]),
                "ref_s": q([r["ref_wall_s"] for r in rows]),
                "unit_s": q([r["unit_wall_s"] for r in rows]),
                "solves": rows[0]["solves"]}
            e = cost["m%d|%s" % (m, arm)]
            print("  m=%d %-5s redescent %6.0f  gate %6.0f  ref %6.0f  "
                  "total %6.0f s" % (m, arm, e["redescent_s"]["median"],
                                     e["gate_s"]["median"],
                                     e["ref_s"]["median"],
                                     e["unit_s"]["median"]))
    res["cost"] = cost

    json.dump(res, open(OUT, "w", encoding="utf-8"), indent=1, ensure_ascii=False)
    print("\nwrote %s" % OUT)
    return 0


if __name__ == "__main__":
    sys.exit(main())
