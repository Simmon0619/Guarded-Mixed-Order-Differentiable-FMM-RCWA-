"""Shared row builder for S5-8c / S5-8e.

Both scripts run ``s5_8a_readme_schedule.run`` (the README schedule with gate
checkpoints and a certified trace) under other orders, then certify the
deliveries.  This lays the result out with exactly S5-8a's unit keys, so one
analysis can read 8a, 8c and 8e alike.  No solves of its own beyond the
certification reads it is asked for.
"""
import time

import s5_1_gate_tier as S1


def unit_row(r, reader, ladder, tag_prefix, meta, certify=("best", "final"),
             t0=None, events=None):
    """``r`` is what s5_8a_readme_schedule.run returns; ``meta`` carries the
    identifiers (target, seed, index, steps, ckpt_every, trace_every,
    descent_level, gate, trace_level, ...).  Deliveries not in ``certify``
    are saved and gate-scored but not read on the ladder."""
    topkey = "%d-%d" % tuple(ladder[-1])
    w0 = reader.wall
    deliveries = {}
    for name in ("best", "final"):
        d = r[name]
        row = {"step": d["step"], "eta_gate": d["eta_gate"],
               "mask_sha1": S1.sha1_of(d["binary"]),
               "files": S1.save_design("%s_%s" % (tag_prefix, name),
                                       d["binary"], d["latent"])}
        if name in certify:
            lad = reader.ladder_of(d["binary"])
            row.update({"final_ladder": lad, "eta_top": lad[topkey],
                        "gate_optimism": d["eta_gate"] - lad[topkey]})
        else:
            row.update({"final_ladder": None, "eta_top": None,
                        "gate_optimism": None})
        deliveries[name] = row
    cert_wall = reader.wall - w0
    best, fin = deliveries["best"], deliveries["final"]
    fin["reported_continuous"] = r["reported_continuous"]
    fin["eta_binary_descent"] = r["eta_binary_descent_final"]
    fin["gap_relaxation"] = r["reported_continuous"] - r["eta_binary_descent_final"]
    fin["gap_truncation"] = (r["eta_binary_descent_final"] - fin["eta_top"]
                             if fin["eta_top"] is not None else None)
    out = dict(meta)
    out.update({
        "engine": "ours", "schedule": "readme",
        "ladder": [list(l) for l in ladder],
        "best_step": best["step"], "eta_gate_best": best["eta_gate"],
        "n_ckpt": len(r["checkpoints"]),
        "same_design": best["mask_sha1"] == fin["mask_sha1"],
        "best_minus_final_gate": best["eta_gate"] - fin["eta_gate"],
        "best_minus_final_top": (best["eta_top"] - fin["eta_top"]
                                 if best["eta_top"] is not None
                                 and fin["eta_top"] is not None else None),
        "deliver_best": best, "deliver_final": fin,
        "checkpoints": r["checkpoints"], "trace": r["trace"],
        "trajectory": r["trajectory"],
        "wall_descent_s": r["wall_descent_s"], "wall_gate_s": r["wall_gate_s"],
        "wall_trace_s": r["wall_trace_s"], "cert_wall_s": cert_wall,
        "opt_wall_s": r["wall_descent_s"] + r["wall_gate_s"],
        "opt_wall_readme_s": r["wall_descent_s"],
        "unit_wall_s": (time.perf_counter() - t0) if t0 is not None else None,
        "grad_events": events if events is not None else [],
        "solves": {"value_grad_%d_%d" % tuple(meta["descent_level"]): meta["steps"],
                   "fwd_gate_%d_%d" % tuple(meta["gate"]): len(r["checkpoints"]),
                   "fwd_trace_%d_%d" % tuple(meta["trace_level"]): len(r["trace"]),
                   "fwd_descent_%d_%d" % tuple(meta["descent_level"]):
                       2 * len(r["trace"])},
    })
    return out


def print_unit(prefix, row, elapsed_s):
    b, f = row["deliver_best"], row["deliver_final"]
    top = lambda d: ("%.4f" % d["eta_top"]) if d["eta_top"] is not None else "  --  "
    print("  %s | best@%-3d gate %.4f top %s | final gate %.4f top %s | reported "
          "%.4f | desc %s gate %s trace %s cert %s  [%s]"
          % (prefix, b["step"], b["eta_gate"], top(b), f["eta_gate"], top(f),
             f["reported_continuous"], S1.fmt_s(row["wall_descent_s"]),
             S1.fmt_s(row["wall_gate_s"]), S1.fmt_s(row["wall_trace_s"]),
             S1.fmt_s(row["cert_wall_s"]), S1.fmt_s(elapsed_s)), flush=True)
