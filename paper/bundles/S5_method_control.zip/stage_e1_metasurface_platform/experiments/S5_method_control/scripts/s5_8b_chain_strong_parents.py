"""S5-8b  The chain on top of strong parents.

S5-1 ran the chain from S4-2's (16,4) deliveries (0.37 / 0.35 / 0.21 at the
top rung), which S5-7 then showed are far weaker than what the published
800-step / beta -> 2000 schedule reaches in one run.  So "chain minus README"
in Sec. 7.6.4 was really "(weak parent + chain) minus (strong single run)".
S5-8a now supplies README-schedule parents on our engine, one per seed.  This
script starts the chain from them, unchanged in every other respect from
S5-1's GATE1 arm, and asks the only question left on the m <= 2 side:

    on top of a parent the published schedule already found, how much does
    the chain still add, and at what marginal cost?

Three unit kinds:

  CHAIN    parent = S5-8a's best gate checkpoint (six per target); the
           shipped chain: 30-step re-descent at fixed beta = 64, alpha
           rotating 0.1/0.25/0.5, monotone acceptance at the gate order.
  CHAIN-R  parent = the single best T-README-D design of S5-7 for this
           target (TORCWA's own engine, its own delivery).  One unit per
           target, zero parent cost: the chain applied to the competitor's
           best run.
  RAMP     (m = 2 only) CHAIN's parents and CHAIN's per-jump noise, with the
           re-descent beta ramped 64 -> 2000 over the 30 steps instead of
           held at 64 -- so each candidate is binary before it is
           thresholded.  Paired with CHAIN on parent AND noise.

Equal-budget arithmetic against S5-8a's pool (README gets floor(budget /
run) more runs, exact E[max_N]) is done in the analysis, not here -- it needs
no solves.  Noise seeds are 60000 + 100*unit + jump, clear of every earlier
block (E-series <= 9323, S4 7101-7340, S5-1/S5-5 9500-30723, S5-4
41000-43015, S5-7 51000-53005).

Descriptive: numbers, not verdicts.

    python s5_8b_chain_strong_parents.py --targets 1 --dry-run
    python s5_8b_chain_strong_parents.py
    python s5_8b_chain_strong_parents.py --resume
"""
import argparse
import json
import os
import sys
import time
from types import SimpleNamespace

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import s5_1_gate_tier as S1                                        # noqa: E402
from workbench.protocol import DEFAULT, n_terms, cosine_lr         # noqa: E402
from workbench.app import order_rule, AppAdam                      # noqa: E402
import trustworthy_fmm.solvers.vector_2d as _v2d                   # noqa: E402
import trustworthy_fmm.fourier.convolution as _conv                # noqa: E402

DATA, DESIGNS = S1.DATA, S1.DESIGNS
PARENTS_8A = os.path.join(DATA, "s5_8a_readme_schedule.json")
PARENTS_S57 = os.path.join(DATA, "s5_7_torcwa.json")
NOISE_BASE = 60000
N_JUMPS = dict(S1.N_JUMPS)          # {1: 24, 2: 24, 3: 16}, as in S5-1
STEPS = S1.REDESCENT_STEPS          # 30
CAP = S1.REF_TRACE_CAP              # 5 traced accepts per chain
RAMP_TARGETS = (2,)
BETA_RAMP = (64.0, 2000.0)
ARMS = ("CHAIN", "CHAIN-R", "RAMP")
SLOT_R = 10                         # unit slot of the CHAIN-R parent


def redescend_ramp(rho0, ctx, steps, beta, events):
    """S1.redescend_guarded with beta ramped BETA_RAMP[0] -> BETA_RAMP[1]
    (exponential) over the re-descent; the fixed ``beta`` argument is ignored."""
    rho = rho0.to(ctx.device)
    adam = AppAdam(rho.shape, ctx.cfg, ctx.mode, ctx.device)
    lo, hi = BETA_RAMP
    for t in range(steps):
        lr = cosine_lr(t / steps, ctx.cfg)
        b = lo * (hi / lo) ** (t / max(steps - 1, 1))
        _, grad = S1.guarded_value_grad(rho, ctx.level_d, b, ctx, events, t)
        if grad is not None:
            rho = adam.step(rho, grad, lr)
    return rho.detach().cpu()


def load_latent(rel):
    return torch.from_numpy(np.load(os.path.join(DATA, rel)).astype("float64"))


def parents_8a(m, path):
    s = json.load(open(path, encoding="utf-8"))
    rows = sorted(((k, v) for k, v in s["units"].items() if v["target"][0] == m),
                  key=lambda kv: kv[1]["index"])
    out = []
    for k, v in rows:
        d = v["deliver_best"]
        out.append({"slot": v["index"], "source": "s5_8a|" + k,
                    "seed": v["seed"], "latent": d["files"]["latent"],
                    "eta_top": d["eta_top"], "eta_gate": d["eta_gate"],
                    "best_step": d["step"],
                    "parent_opt_wall_s": v["opt_wall_s"],
                    "parent_wall_readme_s": v["opt_wall_readme_s"]})
    return out


def parent_s57(m, path):
    s = json.load(open(path, encoding="utf-8"))
    rows = [(k, v) for k, v in s["units"].items()
            if v["target"][0] == m and v["arm"] == "T-README-D"]
    k, v = max(rows, key=lambda kv: kv[1]["eta_top"])
    return {"slot": SLOT_R, "source": "s5_7|" + k, "seed": v["seed"],
            "latent": v["files"]["latent"], "eta_top": v["eta_top"],
            "eta_gate": v["eta_gate_best"], "best_step": v["best_step"],
            "parent_opt_wall_s": v["opt_wall_s"],
            "parent_wall_readme_s": v["wall_descent_s"]}


def q(v):
    a = np.asarray(v, float)
    if not a.size:
        return None
    return {"n": int(a.size), "median": float(np.median(a)),
            "min": float(a.min()), "max": float(a.max())}


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--targets", type=str, default="1,2,3")
    ap.add_argument("--arms", type=str, default=",".join(ARMS))
    ap.add_argument("--parents-8a", type=str, default=PARENTS_8A)
    ap.add_argument("--jumps", type=int, default=0)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--out", type=str, default=None)
    args = ap.parse_args()

    torch.set_num_threads(int(os.environ.get("FMM_THREADS", "3")))
    _conv.VECTORIZED_CONV = True
    _v2d.FAST_DIAGNOSTICS = True
    _v2d.MEMORY_EFFICIENT = True
    device = "cuda" if torch.cuda.is_available() else "cpu"
    cfg = DEFAULT.variant(ny=S1.NY, nx=S1.NX)
    ref_cfg = DEFAULT.variant(ny=S1.REF_NY, nx=S1.REF_NX)
    targets = [(int(t.strip()), 0) for t in args.targets.split(",") if t.strip()]
    arms = [a.strip() for a in args.arms.split(",") if a.strip()]
    for a in arms:
        if a not in ARMS:
            raise SystemExit("unknown arm %r; known %s" % (a, list(ARMS)))
    steps, cap = STEPS, CAP
    if args.dry_run:
        steps, cap = S1.DRY["steps"], S1.DRY["cap"]

    # the chain code is S5-1's, untouched; only its noise block and the list
    # of arms that get an accept trace are pointed at this batch
    S1.NOISE_BASE = NOISE_BASE
    S1.TRACE_ARMS = tuple(ARMS)
    redescend_fixed = S1.redescend_guarded

    out = args.out or os.path.join(
        DATA, "s5_8b_chain_strong_parents%s.json" % ("_dry" if args.dry_run else ""))
    store = {"meta": {}, "units": {}, "summary": {}}
    if args.resume and os.path.exists(out):
        store = json.load(open(out, encoding="utf-8"))
        print("resuming: %d units done" % len(store["units"]), flush=True)
    store["meta"].update({
        "script": os.path.basename(__file__),
        "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "gpu": torch.cuda.get_device_name(0) if device == "cuda" else "cpu",
        "code_path": "fmm_workbench, via s5_1_gate_tier.run_arm (S5-1 GATE1 protocol)",
        "pixel_nm": S1.PIXEL_NM, "grid": [S1.NY, S1.NX],
        "redescent_steps": steps, "beta_redescent": S1.BETA_REDESCENT,
        "beta_ramp": list(BETA_RAMP), "ramp_targets": list(RAMP_TARGETS),
        "alphas": list(S1.ALPHAS), "n_jumps": N_JUMPS, "ref_trace_cap": cap,
        "noise_base": NOISE_BASE, "arms": arms,
        "parents_8a": os.path.relpath(args.parents_8a, DATA).replace("\\", "/"),
        "reading_notes": [
            "CHAIN units start from S5-8a's best gate checkpoints (README "
            "schedule on our engine); CHAIN-R from S5-7's single best "
            "T-README-D design per target (TORCWA engine, its delivery); RAMP "
            "(m=2) from CHAIN's parents with CHAIN's noise, re-descent beta "
            "ramped %g -> %g instead of fixed %g.  RAMP and CHAIN on the same "
            "slot are paired on parent and noise." % (BETA_RAMP[0], BETA_RAMP[1],
                                                       S1.BETA_REDESCENT),
            "unit_idx = (m-1)*100 + slot; slots 0-5 are the 8a parents (by "
            "seed index), slot %d the T-README-D parent.  Noise seed of jump k "
            "= %d + 100*unit_idx + k." % (SLOT_R, NOISE_BASE),
            "budget: chain_marginal_s = re-descent + gate forwards (S5-1's "
            "definition); total_readme_s adds the parent's descent-only wall "
            "(what README's workflow paid for it); total_ours_s adds the "
            "parent's descent + gate-checkpoint wall.  Certification and "
            "traces are outside every budget.",
            "The accept trace is at (40,10), capped at %d traced accepts per "
            "chain, as in S5-1; false-accept counts are lower bounds." % cap,
        ],
    })

    print("=" * 78)
    print("s5_8b_chain_strong_parents | %s | c64 | arms %s | %d-step re-descent"
          % (store["meta"]["gpu"], arms, steps), flush=True)
    t_start, done = time.perf_counter(), 0
    for tgt in targets:
        m = tgt[0]
        rule = order_rule(tgt, cfg)
        ladder = list(rule["ladder"])
        n_jumps = args.jumps or N_JUMPS[m]
        if args.dry_run:
            n_jumps = S1.DRY["jumps"]
        tkey = "%d-%d" % tgt
        ctx = SimpleNamespace(cfg=cfg, mode=S1.MODE, theta=0.0, phi=0.0,
                              target=tgt, level_d=tuple(rule["descent"]),
                              gate=tuple(rule["gate"]), dtype=torch.complex64,
                              device=device, offload=False,
                              accept_rule="nominal", cd_biases=[-20.0, 20.0])
        ref_ctx = SimpleNamespace(**{**vars(ctx), "cfg": ref_cfg})
        reader = S1.RefReader(ctx, ref_ctx, ladder)

        units = []
        p8a = parents_8a(m, args.parents_8a) if os.path.exists(args.parents_8a) else []
        if args.dry_run:
            p8a = p8a[:1]
        for p in p8a:
            if "CHAIN" in arms:
                units.append(("CHAIN", p))
            if "RAMP" in arms and m in RAMP_TARGETS:
                units.append(("RAMP", p))
        if "CHAIN-R" in arms and os.path.exists(PARENTS_S57):
            units.append(("CHAIN-R", parent_s57(m, PARENTS_S57)))
        print("m=%d descent %s gate %s ladder %s | %d units x %d jumps (%d 8a parents)"
              % (m, rule["descent"], rule["gate"], ladder, len(units), n_jumps,
                 len(p8a)), flush=True)
        if not units:
            print("  no parents for m=%d (missing %s?)" % (m, args.parents_8a))
            continue

        for arm, p in units:
            key = "%s|%s|p%02d" % (tkey, arm, p["slot"])
            if key in store["units"]:
                continue
            unit_idx = (m - 1) * 100 + p["slot"]
            lat = load_latent(p["latent"])
            tag = "s5_8b_%s_%s_p%02d" % (arm.replace("-", ""),
                                         tkey.replace("-", "_"), p["slot"])
            S1.redescend_guarded = redescend_ramp if arm == "RAMP" else redescend_fixed
            t0 = time.perf_counter()
            try:
                row = S1.run_arm(arm, rule["gate"], lat, ctx, reader, unit_idx,
                                 n_jumps, steps, cap, tag)
            finally:
                S1.redescend_guarded = redescend_fixed
            marginal = row["wall_s"]["redescent"] + row["wall_s"]["gate"]
            row.update({
                "target": list(tgt), "unit_idx": unit_idx, "pixel_nm": S1.PIXEL_NM,
                "descent_level": list(rule["descent"]),
                "ladder": [list(l) for l in ladder],
                "parent": {k: v for k, v in p.items()},
                "beta_schedule": ("ramp %g->%g" % BETA_RAMP if arm == "RAMP"
                                  else "fixed %g" % S1.BETA_REDESCENT),
                "noise_seeds": [NOISE_BASE + 100 * unit_idx + k
                                for k in range(n_jumps)],
                "budget": {"chain_marginal_s": marginal,
                           "parent_opt_wall_s": p["parent_opt_wall_s"],
                           "parent_wall_readme_s": p["parent_wall_readme_s"],
                           "total_readme_s": p["parent_wall_readme_s"] + marginal,
                           "total_ours_s": p["parent_opt_wall_s"] + marginal},
                "unit_wall_s": time.perf_counter() - t0,
                "ref_reads_cumulative": reader.n,
                "ref_wall_s_cumulative": reader.wall,
            })
            store["units"][key] = row
            S1.save_json(out, store)
            done += 1
            print("  %-7s p%02d acc %2d/%-2d | parent %.4f -> gate %.4f top %.4f "
                  "(%+.4f) | optimism %+.4f | false %d/%d | marginal %s  [%s]"
                  % (arm, p["slot"], row["n_accept"], n_jumps,
                     row["parent_eta_top"], row["final_eta_gate"],
                     row["final_eta_top"], row["gain_top_over_parent"],
                     row["gate_optimism"], row["n_false_accepts"],
                     row["n_traced_accepts"], S1.fmt_s(marginal),
                     S1.fmt_s(time.perf_counter() - t_start)), flush=True)

        rows = [v for k, v in store["units"].items() if k.startswith(tkey + "|")]
        summ = {}
        for arm in arms:
            rs = sorted([r for r in rows if r["arm"] == arm],
                        key=lambda r: r["parent"]["slot"])
            if not rs:
                continue
            summ[arm] = {
                "n": len(rs),
                "parent_top": q([r["parent_eta_top"] for r in rs]),
                "final_top": q([r["final_eta_top"] for r in rs]),
                "gain_top_over_parent": q([r["gain_top_over_parent"] for r in rs]),
                "n_gain_pos": int(sum(r["gain_top_over_parent"] > 0 for r in rs)),
                "n_accept": [r["n_accept"] for r in rs],
                "chain_marginal_s": q([r["budget"]["chain_marginal_s"] for r in rs]),
                "false_accepts": int(sum(r["n_false_accepts"] for r in rs)),
                "traced_accepts": int(sum(r["n_traced_accepts"] for r in rs)),
            }
        if "CHAIN" in summ and "RAMP" in summ:
            c = {r["parent"]["slot"]: r["final_eta_top"] for r in rows if r["arm"] == "CHAIN"}
            g = {r["parent"]["slot"]: r["final_eta_top"] for r in rows if r["arm"] == "RAMP"}
            d = [g[s] - c[s] for s in sorted(set(c) & set(g))]
            if d:
                summ["RAMP_minus_CHAIN_top"] = {
                    "n": len(d), "median": float(np.median(d)),
                    "min": float(min(d)), "max": float(max(d)),
                    "n_pos": int(sum(x > 0 for x in d)),
                    "n_neg": int(sum(x < 0 for x in d)), "values": d}
        store["summary"][tkey] = summ
        for arm, s in summ.items():
            if "final_top" in s:
                print("  --> %-7s n=%d | parent top med %.4f | final top med %.4f "
                      "[%.4f,%.4f] | gain med %+.4f (%d/%d >0) | accepts %s | "
                      "marginal med %s"
                      % (arm, s["n"], s["parent_top"]["median"],
                         s["final_top"]["median"], s["final_top"]["min"],
                         s["final_top"]["max"], s["gain_top_over_parent"]["median"],
                         s["n_gain_pos"], s["n"], s["n_accept"],
                         S1.fmt_s(s["chain_marginal_s"]["median"])), flush=True)
            else:
                print("  --> RAMP - CHAIN top: med %+.4f [%+.4f,%+.4f] +%d/-%d"
                      % (s["median"], s["min"], s["max"], s["n_pos"], s["n_neg"]),
                      flush=True)
        S1.save_json(out, store)

    store["meta"]["total_wall_s"] = time.perf_counter() - t_start
    store["meta"]["finished_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    S1.save_json(out, store)
    print("=" * 78)
    print("wrote %s (%d units, %s)"
          % (out, len(store["units"]), S1.fmt_s(store["meta"]["total_wall_s"])))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
