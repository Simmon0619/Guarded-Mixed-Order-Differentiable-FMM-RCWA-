"""S5-4  The restart lottery: the baseline the chain has to beat.

S5-1 has no restart arm -- all four of its arms start from the same parent --
so it can say which gate order is right and whether chaining helps, but it
cannot support a superiority claim.  This script supplies the missing half.

Each ticket is the shipped baseline protocol (``e10_descent``): a fresh random
seed, ``steps`` Adam steps with beta continued 1 -> 64 and a cosine learning
rate, hard-binary checkpoints scored AT THE GATE ORDER, and the best gate
checkpoint delivered.  Note this is already the gate-selected baseline -- the
E22-era confound (restart tickets selected at the descent order) does not
exist in the shipped code.

Two products from one set of runs:

  1. **Equal-wall-clock comparison.**  Every ticket's optimisation wall clock
     is recorded, so the delivery of "the first N tickets that fit inside a
     chain's measured budget" can be read off exactly, per target, against
     S5-1's chains.
  2. **Empirical E[max_N]**, N <= n/2, by order statistics (no resampling, no
     extrapolation): the marginal return of the N-th restart -- the null model
     the chain has to beat.

Descriptive: numbers, not verdicts.

    python s5_4_restart_baseline.py --dry-run
    python s5_4_restart_baseline.py --resume
"""
import argparse
import hashlib
import json
import math
import os
import sys
import time
from types import SimpleNamespace
from typing import Dict, List, Sequence

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
_WB = os.path.abspath(os.path.join(_HERE, "..", "..", "..", "fmm_workbench"))
sys.path.insert(0, _WB)
from workbench.protocol import DEFAULT, n_terms, cosine_lr, beta_at   # noqa: E402
from workbench.app import (                                            # noqa: E402
    order_rule, gate_eval, gate_score, app_hard_binary, app_initial_latent,
    value_grad, AppAdam,
)
import trustworthy_fmm.solvers.vector_2d as _v2d                       # noqa: E402
import trustworthy_fmm.fourier.convolution as _conv                    # noqa: E402

DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
DESIGNS = os.path.join(DATA, "designs")

PIXEL_NM = 10
NY, NX = 70, 240
REF_NY, REF_NX = 140, 480
MODE = "y"
STEPS = 219                     # the frozen protocol's descent length
CKPT_EVERY = 6                  # as in S4-2, so a ticket is an S4-2 L-arm run
N_TICKETS = {1: 24, 2: 24, 3: 16}
SEED_BASE = {1: 41000, 2: 42000, 3: 43000}   # clear of every prior block
DRY = {"steps": 8, "ckpt": 4, "tickets": 2}

GRAD_JITTERS = (1e-6, -1e-6, 1e-5, -1e-5)


def sha1_of(t):
    return hashlib.sha1(t.detach().cpu().numpy().astype(np.uint8).tobytes()).hexdigest()


def lift(b, k):
    return b.clone() if k == 1 else torch.repeat_interleave(
        torch.repeat_interleave(b, k, 0), k, 1)


def fmt_s(s):
    return ("%.0f s" % s) if s < 90 else (
        "%.1f min" % (s / 60.0) if s < 5400 else "%.2f h" % (s / 3600.0))


def guarded_value_grad(rho, level, beta, ctx, events, step):
    def call(b):
        return value_grad(rho, level, ctx.target, b, ctx.cfg, ctx.mode,
                          ctx.theta, ctx.phi, ctx.dtype, ctx.device, ctx.offload)
    try:
        eta, grad = call(beta)
        if bool(torch.isfinite(grad).all()):
            return eta, grad
        del grad
    except RuntimeError as exc:
        events.append({"event": "raised", "step": step, "detail": str(exc)[:160]})
    for j in GRAD_JITTERS:
        try:
            eta, grad = call(float(beta) * (1.0 + j))
            if bool(torch.isfinite(grad).all()):
                events.append({"event": "jitter_recovered", "step": step,
                               "jitter": j})
                return eta, grad
            del grad
        except RuntimeError:
            continue
    events.append({"event": "skipped_update", "step": step})
    return None, None


def ticket(ctx, seed, steps, ckpt_every, events):
    """The shipped baseline descent: beta continuation, gate-scored checkpoints,
    deliver the best gate checkpoint.  ``e10_descent`` with the S4 NaN guard and
    without the job/progress plumbing."""
    cfg, mode = ctx.cfg, ctx.mode
    latent = app_initial_latent(seed, cfg, mode, ctx.device)
    adam = AppAdam(latent.shape, cfg, mode, ctx.device)
    best = None
    ckpts = []
    t_desc = t_gate = 0.0
    for t in range(steps):
        progress = t / max(steps - 1, 1)
        beta = beta_at(progress, cfg=cfg)
        lr = cosine_lr(progress, cfg)
        t0 = time.perf_counter()
        _, grad = guarded_value_grad(latent, ctx.level_d, beta, ctx, events, t)
        t_desc += time.perf_counter() - t0
        if grad is not None:
            latent = adam.step(latent, grad, lr)
        if (t + 1) % ckpt_every == 0 or t == steps - 1:
            b = app_hard_binary(latent.detach().cpu(), cfg, mode)
            t0 = time.perf_counter()
            eg = gate_eval(b, ctx.gate, ctx)
            t_gate += time.perf_counter() - t0
            ckpts.append({"step": t + 1, "eta_gate": eg, "beta": beta})
            if best is None or eg > best["eta_gate"]:
                best = {"eta_gate": eg, "step": t + 1,
                        "latent": latent.detach().cpu().clone(), "binary": b}
    return {"seed": seed, "best": best, "checkpoints": ckpts,
            "n_ckpt": len(ckpts), "eta_gate_best": best["eta_gate"],
            "best_step": best["step"],
            "opt_wall_s": t_desc + t_gate,
            "wall_descent_s": t_desc, "wall_gate_s": t_gate}


def e_max_n(values: Sequence[float], n_max: int) -> Dict[str, List[float]]:
    """Exact E[max of N drawn without replacement] by order statistics.

    E[max_N] = sum_k x_(k) * C(k-1, N-1) / C(n, N), x_(k) the k-th smallest.
    No resampling, no distributional assumption, no extrapolation.
    """
    x = sorted(float(v) for v in values)
    n = len(x)
    out = {"N": [], "e_max": [], "p10": [], "p90": []}
    for N in range(1, min(n_max, n) + 1):
        denom = math.comb(n, N)
        em = sum(x[k - 1] * math.comb(k - 1, N - 1) for k in range(1, n + 1)) / denom
        # exact distribution of max_N: P(max <= x_(k)) = C(k,N)/C(n,N)
        cdf = [math.comb(k, N) / denom for k in range(1, n + 1)]
        p10 = next(x[k] for k in range(n) if cdf[k] >= 0.10)
        p90 = next(x[k] for k in range(n) if cdf[k] >= 0.90)
        out["N"].append(N)
        out["e_max"].append(em)
        out["p10"].append(p10)
        out["p90"].append(p90)
    return out


def save_json(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=1, ensure_ascii=False, default=float)
    os.replace(tmp, path)


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--targets", type=str, default="3,1,2")
    ap.add_argument("--tickets", type=int, default=0)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--out", type=str, default=None)
    args = ap.parse_args()

    torch.set_num_threads(int(os.environ.get("FMM_THREADS", "3")))
    _conv.VECTORIZED_CONV = True
    _v2d.FAST_DIAGNOSTICS = True
    _v2d.MEMORY_EFFICIENT = True
    device = "cuda" if torch.cuda.is_available() else "cpu"
    cfg = DEFAULT.variant(ny=NY, nx=NX)
    ref_cfg = DEFAULT.variant(ny=REF_NY, nx=REF_NX)
    steps, ckpt_every = STEPS, CKPT_EVERY
    if args.dry_run:
        steps, ckpt_every = DRY["steps"], DRY["ckpt"]
    targets = [(int(t.strip()), 0) for t in args.targets.split(",") if t.strip()]

    out = args.out or os.path.join(
        DATA, "s5_4_restart_baseline%s.json" % ("_dry" if args.dry_run else ""))
    store = {"meta": {}, "units": {}, "curves": {}}
    if args.resume and os.path.exists(out):
        store = json.load(open(out, encoding="utf-8"))
        print("resuming: %d tickets done" % len(store["units"]), flush=True)
    store["meta"].update({
        "script": os.path.basename(__file__),
        "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "gpu": torch.cuda.get_device_name(0) if device == "cuda" else "cpu",
        "code_path": "fmm_workbench (shipped baseline protocol e10_descent)",
        "pixel_nm": PIXEL_NM, "grid": [NY, NX], "steps": steps,
        "ckpt_every": ckpt_every, "seed_base": SEED_BASE,
        "reading_notes": [
            "A ticket is the SHIPPED baseline: beta continuation 1->64 over "
            "`steps`, checkpoints every `ckpt_every` scored at the GATE order, "
            "best gate checkpoint delivered.  The gate-selection is already in "
            "the shipped code, so the E22-era confound (tickets selected at "
            "the descent order) does not exist here.",
            "opt_wall_s counts descent + gate only -- the certification reads "
            "are NOT in it, because a chain's budget in S5-1 is also measured "
            "on descent + gate.  That is what makes the equal-wall-clock slice "
            "comparable.",
            "E[max_N] is exact order statistics over the n tickets, capped at "
            "N <= n/2, with the exact distribution of the maximum for the "
            "10/90 band.  No resampling, no fitted distribution, no "
            "extrapolation beyond n/2.",
            "Seeds 41000/42000/43000 + i are clear of every prior block "
            "(E19 3001-3006, E22 restarts 4000-4239, E26 5001-5006, E22 noise "
            "7000-9323, S4 7101-7340, workbench default 9100-9139, S5-1 "
            "9500-30723).",
        ],
    })

    for tgt in targets:
        m = tgt[0]
        rule = order_rule(tgt, cfg)
        ladder = list(rule["ladder"])
        n_tick = args.tickets or N_TICKETS[m]
        if args.dry_run:
            n_tick = DRY["tickets"]
        ctx = SimpleNamespace(cfg=cfg, mode=MODE, theta=0.0, phi=0.0,
                              target=tgt, level_d=rule["descent"],
                              gate=rule["gate"], dtype=torch.complex64,
                              device=device, offload=False,
                              accept_rule="nominal", cd_biases=[-20.0, 20.0])
        ref_ctx = SimpleNamespace(**{**vars(ctx), "cfg": ref_cfg})
        tkey = "%d-%d" % tgt
        print("=" * 74)
        print("m=%d  descent %s  gate %s  ladder %s | %d tickets x %d steps"
              % (m, rule["descent"], rule["gate"], ladder, n_tick, steps),
              flush=True)
        t0 = time.perf_counter()
        for i in range(n_tick):
            key = "%s|t%02d" % (tkey, i)
            if key in store["units"]:
                continue
            seed = SEED_BASE[m] + i
            events = []
            r = ticket(ctx, seed, steps, ckpt_every, events)
            b = r["best"]["binary"]
            t1 = time.perf_counter()
            lad = {"%d-%d" % lv: gate_eval(b, lv, ctx) for lv in ladder}
            lad["40-10@5nm"] = gate_eval(lift(b, PIXEL_NM // 5), (40, 10), ref_ctx)
            cert_wall = time.perf_counter() - t1
            top = lad["%d-%d" % ladder[-1]] if ladder else r["eta_gate_best"]
            tag = "s5_4_%s_t%02d" % (tkey.replace("-", "_"), i)
            np.save(os.path.join(DESIGNS, tag + "_binary.npy"),
                    b.detach().cpu().numpy())
            np.save(os.path.join(DESIGNS, tag + "_latent.npy"),
                    r["best"]["latent"].detach().cpu().numpy())
            store["units"][key] = {
                "target": list(tgt), "ticket": i, "seed": seed,
                "descent_level": list(rule["descent"]),
                "gate": list(rule["gate"]),
                "ladder": [list(l) for l in ladder],
                "eta_gate_best": r["eta_gate_best"], "best_step": r["best_step"],
                "n_ckpt": r["n_ckpt"], "checkpoints": r["checkpoints"],
                "final_ladder": lad, "eta_top": top,
                "gate_optimism": r["eta_gate_best"] - top,
                "opt_wall_s": r["opt_wall_s"],
                "wall_descent_s": r["wall_descent_s"],
                "wall_gate_s": r["wall_gate_s"], "cert_wall_s": cert_wall,
                "mask_sha1": sha1_of(b), "grad_events": events,
                "files": {"binary": "designs/%s_binary.npy" % tag,
                          "latent": "designs/%s_latent.npy" % tag},
                "solves": {"value_grad_%d_%d" % tuple(rule["descent"]): steps,
                           "fwd_gate_%d_%d" % tuple(rule["gate"]): r["n_ckpt"]},
            }
            save_json(out, store)
            print("  t%02d seed %d  gate %.4f @step %3d -> top %.4f "
                  "(optimism %+.4f) | opt %s, cert %s  [%s]"
                  % (i, seed, r["eta_gate_best"], r["best_step"], top,
                     r["eta_gate_best"] - top, fmt_s(r["opt_wall_s"]),
                     fmt_s(cert_wall), fmt_s(time.perf_counter() - t0)),
                  flush=True)

        rows = [v for k, v in store["units"].items() if k.startswith(tkey + "|")]
        if rows:
            tops = [r["eta_top"] for r in rows]
            gates = [r["eta_gate_best"] for r in rows]
            walls = [r["opt_wall_s"] for r in rows]
            # best-of-N selected BY THE GATE, reported at the top rung:
            order = sorted(range(len(rows)), key=lambda i: gates[i], reverse=True)
            sel = [tops[i] for i in order]
            store["curves"][tkey] = {
                "n": len(rows),
                "eta_top": {"median": float(np.median(tops)),
                            "q1": float(np.percentile(tops, 25)),
                            "q3": float(np.percentile(tops, 75)),
                            "min": float(min(tops)), "max": float(max(tops)),
                            "sd": float(np.std(tops, ddof=1)) if len(tops) > 1 else 0.0},
                "e_max_n_by_top": e_max_n(tops, len(rows) // 2),
                "gate_selected_best_top": sel[0],
                "median_ticket_wall_s": float(np.median(walls)),
                "total_wall_s": float(sum(walls)),
                "gate_optimism_median": float(np.median(
                    [r["gate_optimism"] for r in rows])),
            }
            c = store["curves"][tkey]
            print("  --> n=%d  top med %.4f [%.4f,%.4f]  best-by-gate %.4f  "
                  "E[max_N] N=1 %.4f -> N=%d %.4f  | ticket %s"
                  % (c["n"], c["eta_top"]["median"], c["eta_top"]["min"],
                     c["eta_top"]["max"], c["gate_selected_best_top"],
                     c["e_max_n_by_top"]["e_max"][0],
                     c["e_max_n_by_top"]["N"][-1],
                     c["e_max_n_by_top"]["e_max"][-1],
                     fmt_s(c["median_ticket_wall_s"])), flush=True)
            save_json(out, store)

    store["meta"]["finished_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ",
                                                  time.gmtime())
    save_json(out, store)
    print("=" * 74)
    print("wrote %s (%d tickets)" % (out, len(store["units"])))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
