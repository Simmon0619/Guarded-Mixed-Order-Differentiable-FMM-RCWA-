"""S5-8c  The published schedule at the GATE order, m = 3: the cell S5-7 left
to arithmetic.

S5-7 ran README's single-order workflow at m = 3 only at the descent order
(20,5), where it reported 1.4-3x its certified value and delivered < 0.2 in
four of six runs.  Two mechanisms are confounded in that failure: (A) the
order is too low for a free descent, so the optimiser climbs (20,5)'s errors;
(B) a single descent from a random start does not reach a good basin at m = 3
whatever the order.  This is the cell that separates them: the same schedule,
the same six initial latents (S5-8a's m = 3 seeds), 800 steps entirely at the
gate order (32,8).  If it certifies where S5-8a's (20,5) runs do, (B) is the
story; if it certifies far above them, (A) is.  Either way its wall clock is
the price of honesty by the single-order route, beside the chain's.

Instrumentation is S5-8a's: a checkpoint every 100 steps scored at the next
rung (40,10) -- README's workflow has none, so ``deliver_final`` is its
delivery and ``deliver_best`` is the same run with a gate at the next rung --
and the certified trace at (40,10) with the (32,8) continuous/binary readings
beside it.  Certification at (48,12).

    python s5_8c_readme_gate_order.py --dry-run
    python s5_8c_readme_gate_order.py
    python s5_8c_readme_gate_order.py --resume
"""
import argparse
import json
import os
import sys
import time
from types import SimpleNamespace

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import s5_1_gate_tier as S1                                        # noqa: E402
import s5_8a_readme_schedule as A                                  # noqa: E402
from s5_8_common import unit_row, print_unit                       # noqa: E402
from workbench.protocol import DEFAULT                             # noqa: E402
from workbench.app import order_rule                               # noqa: E402
import trustworthy_fmm.solvers.vector_2d as _v2d                   # noqa: E402
import trustworthy_fmm.fourier.convolution as _conv                # noqa: E402

DATA = S1.DATA
TARGET = (3, 0)
STEPS = A.STEPS                 # 800
CKPT_EVERY = 100                # scored at the next rung; README itself has none
TRACE_EVERY = 100
SEED_BASE = A.SEED_BASE[3]      # 53000: S5-8a's and S5-7's m=3 initial latents
N_SEEDS = 6
DRY = {"steps": 12, "ckpt": 4, "trace": 8, "seeds": 1}


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--seeds", type=int, default=0)
    ap.add_argument("--max-units", type=int, default=0,
                    help="stop after this many NEW units (0 = all); lets a driver "
                         "loop run one unit per process, so host memory held by "
                         "a run is released between units")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--out", type=str, default=None)
    args = ap.parse_args()

    torch.set_num_threads(int(os.environ.get("FMM_THREADS", "3")))
    _conv.VECTORIZED_CONV = True
    _v2d.FAST_DIAGNOSTICS = True
    _v2d.MEMORY_EFFICIENT = True
    device = "cuda" if torch.cuda.is_available() else "cpu"
    cfg = DEFAULT.variant(ny=S1.NY, nx=S1.NX)
    ref_cfg = DEFAULT.variant(ny=S1.REF_NY, nx=S1.REF_NX)
    steps, ck, tr = STEPS, CKPT_EVERY, TRACE_EVERY
    n_seeds = args.seeds or N_SEEDS
    if args.dry_run:
        steps, ck, tr, n_seeds = DRY["steps"], DRY["ckpt"], DRY["trace"], DRY["seeds"]

    rule = order_rule(TARGET, cfg)
    ladder = list(rule["ladder"])                     # [(40,10), (48,12)]
    level = tuple(rule["gate"])                       # (32,8): the single order
    next_rung = tuple(ladder[0])                      # (40,10): checkpoint scorer
    ctx = SimpleNamespace(cfg=cfg, mode=S1.MODE, theta=0.0, phi=0.0,
                          target=TARGET, level_d=level, gate=next_rung,
                          dtype=torch.complex64, device=device, offload=False,
                          accept_rule="nominal", cd_biases=[-20.0, 20.0])
    ref_ctx = SimpleNamespace(**{**vars(ctx), "cfg": ref_cfg})
    reader = S1.RefReader(ctx, ref_ctx, ladder)
    tkey = "%d-%d" % TARGET

    out = args.out or os.path.join(
        DATA, "s5_8c_readme_gate_order%s.json" % ("_dry" if args.dry_run else ""))
    store = {"meta": {}, "units": {}, "summary": {}}
    if args.resume and os.path.exists(out):
        store = json.load(open(out, encoding="utf-8"))
        print("resuming: %d units done" % len(store["units"]), flush=True)
    store["meta"].update({
        "script": os.path.basename(__file__),
        "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "gpu": torch.cuda.get_device_name(0) if device == "cuda" else "cpu",
        "engine": "ours (fmm_workbench value_grad, complex64, no broadening)",
        "code_path": "s5_8a_readme_schedule.run at level_d = rule gate",
        "target": list(TARGET), "pixel_nm": S1.PIXEL_NM, "grid": [S1.NY, S1.NX],
        "single_level": list(level), "checkpoint_level": list(next_rung),
        "ladder": [list(l) for l in ladder], "trace_level": list(A.TRACE_LEVEL),
        "steps": steps, "ckpt_every": ck, "trace_every": tr,
        "beta_schedule": "B(t) = 2 * 1000^(t/T) (README's ramp, B = 2b)",
        "seed_base": SEED_BASE, "n_seeds": n_seeds,
        "rule_says": {"descent": list(rule["descent"]), "gate": list(rule["gate"])},
        "reading_notes": [
            "README's workflow at ONE order = the rule's gate order (32,8) for "
            "m=3, 800 steps, delivery = the final field (deliver_final).  Same "
            "seeds as S5-8a's m=3 units, so the same initial latent; the only "
            "difference from those runs is the order the gradient is computed "
            "at ((32,8) here, (20,5) there).",
            "deliver_best is the same run with a checkpoint every %d steps "
            "scored at the next rung (40,10): README plus a gate.  README "
            "itself has no checkpoints; opt_wall_readme_s is its cost." % ck,
            "reported_continuous is the final continuous field at B = 2000 "
            "read at (32,8); gap_truncation is now (32,8) binary minus the "
            "(48,12) certification.",
        ],
    })

    print("=" * 78)
    print("s5_8c_readme_gate_order | %s | c64 | m=3 at %s, ckpt/%d @%s, trace/%d "
          "@%s, certify %s | %d seeds x %d steps"
          % (store["meta"]["gpu"], level, ck, next_rung, tr, A.TRACE_LEVEL,
             ladder, n_seeds, steps), flush=True)
    t_start = time.perf_counter()
    n_new = 0
    for i in range(n_seeds):
        key = "%s|README-G|s%02d" % (tkey, i)
        if key in store["units"]:
            continue
        if args.max_units and n_new >= args.max_units:
            break
        n_new += 1
        seed = SEED_BASE + i
        ev = []
        t0 = time.perf_counter()
        r = A.run(ctx, reader, seed, steps, ck, tr, ev)
        meta = {"target": list(TARGET), "arm": "README-G", "seed": seed, "index": i,
                "steps": steps, "ckpt_every": ck, "trace_every": tr,
                "descent_level": list(level), "single_level": list(level),
                "gate": list(next_rung), "trace_level": list(A.TRACE_LEVEL)}
        row = unit_row(r, reader, ladder, "s5_8c_%s_s%02d" % (tkey.replace("-", "_"), i),
                       meta, certify=("best", "final"), t0=t0, events=ev)
        store["units"][key] = row
        S1.save_json(out, store)
        print_unit("s%02d seed %d" % (i, seed), row, time.perf_counter() - t_start)

    rows = sorted(store["units"].values(), key=lambda u: u["index"])
    if rows:
        ft = [u["deliver_final"]["eta_top"] for u in rows]
        bt = [u["deliver_best"]["eta_top"] for u in rows]
        store["summary"][tkey] = {
            "n": len(rows), "final_top": A.q(ft), "best_top": A.q(bt),
            "best_minus_final_top": A.q([b - f for b, f in zip(bt, ft)]),
            "reported": A.q([u["deliver_final"]["reported_continuous"] for u in rows]),
            "gap_truncation": A.q([u["deliver_final"]["gap_truncation"] for u in rows]),
            "best_steps": [u["best_step"] for u in rows],
            "wall_readme_s": A.q([u["opt_wall_readme_s"] for u in rows]),
            "unit_wall_s": A.q([u["unit_wall_s"] for u in rows]),
        }
        s = store["summary"][tkey]
        print("  --> n=%d | final top med %.4f [%.4f,%.4f] | best-ckpt top med %.4f "
              "| reported med %.4f | README wall med %s"
              % (s["n"], s["final_top"]["median"], s["final_top"]["min"],
                 s["final_top"]["max"], s["best_top"]["median"],
                 s["reported"]["median"], S1.fmt_s(s["wall_readme_s"]["median"])),
              flush=True)
    store["meta"]["total_wall_s"] = time.perf_counter() - t_start
    store["meta"]["finished_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    S1.save_json(out, store)
    print("=" * 78)
    print("wrote %s (%d units, %s)"
          % (out, len(store["units"]), S1.fmt_s(store["meta"]["total_wall_s"])))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
