"""S5-2  Read every delivered mask in the paper on ONE yardstick.

Right now section 4 reports (40,10) on a 5 nm-equivalent grid at 10 nm pixel,
section 5 reports (28,7)@1x at 20 nm pixel, section 6 quotes flagship gains at
(48,12), and section 7 reports nominal at (24,6)@1x.  No two numbers in the
paper can be compared without a conversion the paper does not supply, and of
the 48 delivered designs behind the section-5 main result only two have ever
been read at (40,10).

This script re-reads every delivered mask it can find at the section-4
reference -- (40,10) on the common 5 nm-equivalent grid (140,480) -- and adds
(48,12) for the strongest ones.  No descent, no optimisation: forward solves
on masks that already exist on disk.

A mask's design pixel is inferred from its array shape and its target from its
filename.  Files whose target cannot be parsed are REPORTED, not guessed at.

    python s5_2_common_yardstick.py --list        # inventory only, no solves
    python s5_2_common_yardstick.py               # the real pass
    python s5_2_common_yardstick.py --resume
"""
import argparse
import hashlib
import os
import re
import sys
import time
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.abspath(os.path.join(
    _HERE, "..", "..", "S4_truncation_and_pixel", "scripts")))
import s4_common as s4c                                    # noqa: E402
import e10_common as C                                     # noqa: E402

DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
EXPERIMENTS = os.path.abspath(os.path.join(_HERE, "..", ".."))

# Which experiments to sweep, and a short provenance label for each.
SOURCES = [
    ("E19_stage2_bh_chain", "sec5 single chain + restart control"),
    ("E20_high_order", "sec3 order ladder protagonists"),
    ("E21_m3_chain_high_gate", "sec6 m=3 high-gate chain"),
    ("E22_power_bh_vs_rs", "sec5 main result (BH vs restarts)"),
    ("E23_robust_chain", "sec7 robust chain"),
    ("E26_fine_pixels", "sec6 fine pixel"),
    ("E27_merge", "sec6 merge"),
    ("E28_frontier", "sec6 frontier / records"),
    ("E16_inherited_baseline", "frozen campaign parents"),
]
SHAPE_TO_PIX = {(35, 120): 20, (70, 240): 10, (140, 480): 5}
TOP_N_FOR_48 = 15
LEVEL_48 = (48, 12)

_TGT = re.compile(r"(?:^|[^0-9])([123])[_\-]0(?:[^0-9]|$)")


def parse_target(name: str) -> Optional[Tuple[int, int]]:
    m = _TGT.search(os.path.basename(name))
    return (int(m.group(1)), 0) if m else None


def sha1_of(a: np.ndarray) -> str:
    return hashlib.sha1(a.astype(np.uint8).tobytes()).hexdigest()


def inventory(sources) -> Tuple[List[Dict], List[Dict]]:
    """Find every *_binary.npy; return (usable, unusable-with-reason)."""
    ok: List[Dict] = []
    bad: List[Dict] = []
    for exp, label in sources:
        root = os.path.join(EXPERIMENTS, exp)
        if not os.path.isdir(root):
            bad.append({"path": root, "reason": "experiment directory missing"})
            continue
        for dirpath, _dirs, files in os.walk(root):
            for fn in sorted(files):
                if not fn.endswith("_binary.npy"):
                    continue
                p = os.path.join(dirpath, fn)
                rel = os.path.relpath(p, EXPERIMENTS).replace("\\", "/")
                try:
                    a = np.load(p)
                except Exception as exc:                    # noqa: BLE001
                    bad.append({"path": rel, "reason": "unreadable: %s" % exc})
                    continue
                shape = tuple(int(v) for v in a.shape)
                pix = SHAPE_TO_PIX.get(shape)
                tgt = parse_target(fn) or parse_target(dirpath)
                vals = np.unique(a)
                if pix is None:
                    bad.append({"path": rel, "reason": "shape %r is not a "
                                "known design grid" % (shape,)})
                    continue
                if tgt is None:
                    bad.append({"path": rel, "reason": "target not parseable "
                                "from the filename"})
                    continue
                if not np.all(np.isin(vals, (0.0, 1.0))):
                    bad.append({"path": rel, "reason": "not binary: %d distinct"
                                " values" % vals.size})
                    continue
                ok.append({"path": rel, "abs": p, "experiment": exp,
                           "provenance": label, "pixel_nm": pix,
                           "shape": list(shape), "target": list(tgt),
                           "fill": float(a.mean()), "sha1": sha1_of(a)})
    return ok, bad


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--list", action="store_true",
                    help="inventory only; no solves")
    ap.add_argument("--top-n", type=int, default=TOP_N_FOR_48,
                    help="how many of the strongest masks also get (48,12)")
    ap.add_argument("--no-48", action="store_true")
    ap.add_argument("--no-floor", action="store_true",
                    help="skip the resolution-floor measurement")
    ap.add_argument("--floor-n", type=int, default=20,
                    help="masks re-read on the second numerical path")
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--out", type=str,
                    default=os.path.join(DATA, "s5_2_common_yardstick.json"))
    args = ap.parse_args()

    found, bad = inventory(SOURCES)
    # de-duplicate by (sha1, target): the same physical mask read once
    uniq: Dict[str, Dict] = {}
    for r in found:
        k = "%s|%d-%d" % (r["sha1"], r["target"][0], r["target"][1])
        if k in uniq:
            uniq[k].setdefault("also_at", []).append(r["path"])
        else:
            uniq[k] = dict(r)
    items = list(uniq.values())

    print("=" * 72)
    print("s5_2_common_yardstick | %d binaries found, %d distinct (mask,target)"
          " | %d unusable" % (len(found), len(items), len(bad)))
    by_exp: Dict[str, int] = {}
    for r in items:
        by_exp[r["experiment"]] = by_exp.get(r["experiment"], 0) + 1
    for e, n in sorted(by_exp.items()):
        print("    %-28s %3d" % (e, n))
    if bad:
        print("  unusable (reported, not guessed at):")
        for b in bad[:20]:
            print("    %-60s %s" % (b["path"][:60], b["reason"]))
        if len(bad) > 20:
            print("    ... and %d more" % (len(bad) - 20))
    est = len(items) * 19.0 + (0 if args.no_48 else args.top_n * 60.0)
    print("  estimated %s of forward solves" % s4c.fmt_s(est))
    print("=" * 72, flush=True)
    if args.list:
        return 0

    params = {"ref_level": list(s4c.REF_LEVEL), "ref_grid": list(s4c.REF_SHAPE),
              "level_48": list(LEVEL_48), "top_n_for_48": args.top_n,
              "sources": [s[0] for s in SOURCES]}
    store = s4c.resume_store(args.out, os.path.basename(__file__), params,
                             args.resume)
    store["meta"]["reading_notes"] = [
        "Every mask is lifted to the common 5 nm-equivalent grid (140,480) by "
        "block replication before the reference solve.  Block replication of a "
        "BINARY mask is pointwise exact -- the same physical structure -- only "
        "the DFT aliasing terms change.  20 nm masks HAVE to be lifted: "
        "(40,10) needs 161 samples per period and the 20 nm grid holds 120, "
        "violating the 4M+1 constraint.",
        "Masks are de-duplicated by sha1: the same physical mask stored in two "
        "places is solved once and the other paths are listed in also_at.",
        "The target is parsed from the filename; anything unparseable is in "
        "meta.unusable, not silently dropped or guessed.",
        "These readings do NOT re-run any optimisation and do not change any "
        "delivered design; they only put existing deliveries on one yardstick.",
    ]
    store["meta"]["unusable"] = bad
    store["meta"]["n_binaries_found"] = len(found)

    t0 = time.perf_counter()
    for i, r in enumerate(items):
        key = s4c.unit_key(r["sha1"][:12], r["target"])
        if s4c.unit_done(store, key):
            continue
        a = np.load(r["abs"]).astype("float64")
        b = torch.from_numpy(a)
        t1 = time.perf_counter()
        eta_ref = s4c.eta_ref(b, tuple(r["target"]), r["pixel_nm"])
        dt = time.perf_counter() - t1
        row = dict(r)
        row.pop("abs", None)
        row.update({"eta_ref_40_10_at_5nm": eta_ref, "ref_wall_s": dt})
        if r["pixel_nm"] != s4c.REF_PIX:
            cfg = s4c.PIX[r["pixel_nm"]]
            if cfg.supports(s4c.REF_LEVEL):
                row["eta_ref_40_10_native"] = s4c.eta(
                    b, s4c.REF_LEVEL, tuple(r["target"]), cfg)
                row["ref_grid_shift_rel"] = (
                    (row["eta_ref_40_10_native"] - eta_ref) / eta_ref
                    if eta_ref else None)
            else:
                row["eta_ref_40_10_native"] = None
                row["ref_grid_shift_rel"] = None
                row["native_note"] = ("(40,10) violates 4M+1 on this grid; "
                                      "only the lifted reading exists")
        s4c.record_unit(store, key, row, args.out)
        el = time.perf_counter() - t0
        print("  [%3d/%3d] %-52s %2d nm  eta_ref %.4f  (%s elapsed)"
              % (i + 1, len(items), r["path"][-52:], r["pixel_nm"], eta_ref,
                 s4c.fmt_s(el)), flush=True)

    if not args.no_48:
        done = [(v["eta_ref_40_10_at_5nm"], k)
                for k, v in store["units"].items()
                if "eta_ref_40_10_at_5nm" in v]
        done.sort(reverse=True)
        for _e, k in done[:args.top_n]:
            row = store["units"][k]
            if "eta_48_12_at_5nm" in row:
                continue
            p = os.path.join(EXPERIMENTS, row["path"])
            b = torch.from_numpy(np.load(p).astype("float64"))
            lifted = s4c.to_ref_grid(b, row["pixel_nm"])
            t1 = time.perf_counter()
            row["eta_48_12_at_5nm"] = s4c.eta(lifted, LEVEL_48,
                                              tuple(row["target"]), s4c.REF_CFG)
            row["eta_48_12_wall_s"] = time.perf_counter() - t1
            row["d_48_vs_40_rel"] = ((row["eta_48_12_at_5nm"]
                                      - row["eta_ref_40_10_at_5nm"])
                                     / row["eta_ref_40_10_at_5nm"])
            s4c.record_unit(store, k, row, args.out)
            print("  (48,12) %-46s %.4f  (%+.2f%% vs (40,10))"
                  % (row["path"][-46:], row["eta_48_12_at_5nm"],
                     100 * row["d_48_vs_40_rel"]), flush=True)

    # ---- resolution floor: the same mask down two numerical paths ----------
    # Section 4's "differences smaller than this are not commented on" line is
    # currently 3e-3, inherited from an E17 measurement at (12,3) on the 20 nm
    # grid and never measured at the reference order.  Here it is measured
    # directly: read the same mask at (40,10) with MEMORY_EFFICIENT on (the
    # path every number in the paper uses) and off (an exact algebraic
    # rearrangement of the same mathematics).  Their difference is the floor.
    if not args.no_floor and "resolution_floor" not in store:
        import trustworthy_fmm.solvers.vector_2d as _v2d
        picks = sorted(
            [(v["eta_ref_40_10_at_5nm"], k) for k, v in store["units"].items()
             if "eta_ref_40_10_at_5nm" in v], reverse=True)
        step = max(1, len(picks) // args.floor_n)
        picks = picks[::step][:args.floor_n]
        rows = []
        t1 = time.perf_counter()
        for _e, k in picks:
            row = store["units"][k]
            b = torch.from_numpy(np.load(
                os.path.join(EXPERIMENTS, row["path"])).astype("float64"))
            lifted = s4c.to_ref_grid(b, row["pixel_nm"])
            try:
                _v2d.MEMORY_EFFICIENT = False
                off = s4c.eta(lifted, s4c.REF_LEVEL, tuple(row["target"]),
                              s4c.REF_CFG)
            finally:
                _v2d.MEMORY_EFFICIENT = True
            on = row["eta_ref_40_10_at_5nm"]
            rows.append({"key": k, "path": row["path"],
                         "target": row["target"], "pixel_nm": row["pixel_nm"],
                         "eta_me_on": on, "eta_me_off": off,
                         "abs_diff": abs(on - off),
                         "rel_diff": abs(on - off) / on if on else None})
        d = [r["abs_diff"] for r in rows]
        store["resolution_floor"] = {
            "n": len(rows), "level": list(s4c.REF_LEVEL),
            "grid": list(s4c.REF_SHAPE),
            "median_abs": float(np.median(d)), "max_abs": float(max(d)),
            "median_rel": float(np.median([r["rel_diff"] for r in rows])),
            "max_rel": float(max(r["rel_diff"] for r in rows)),
            "wall_s": time.perf_counter() - t1, "rows": rows,
            "note": "MEMORY_EFFICIENT on vs off is an exact algebraic "
                    "rearrangement of the same solve, so this difference is "
                    "pure complex64 rounding: the smallest eta gap this paper "
                    "can resolve at (40,10).  It replaces the inherited 3e-3 "
                    "convention, which came from an E17 measurement at (12,3) "
                    "on the 20 nm grid.",
        }
        print("\n  resolution floor at (40,10), n=%d: |delta| median %.2e, "
              "max %.2e (rel median %.2e, max %.2e)"
              % (len(rows), store["resolution_floor"]["median_abs"],
                 store["resolution_floor"]["max_abs"],
                 store["resolution_floor"]["median_rel"],
                 store["resolution_floor"]["max_rel"]), flush=True)

    store["meta"]["total_wall_s"] = time.perf_counter() - t0
    s4c.save_json(args.out, store)
    print("=" * 72)
    print("wrote %s (%d masks, %s)"
          % (args.out, len(store["units"]),
             s4c.fmt_s(store["meta"]["total_wall_s"])))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
