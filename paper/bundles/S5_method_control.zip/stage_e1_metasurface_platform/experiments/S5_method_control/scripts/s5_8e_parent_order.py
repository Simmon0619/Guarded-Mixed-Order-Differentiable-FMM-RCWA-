"""S5-8e  Where must the descent order scale with m: at the start, or only in
the chain's local re-descents?

D-013 says the descent order must rise with the target order, and S5-5's 2x2
showed that for the chain's re-descent at m = 3 ((12,3) -> (20,5): +0.154,
8/8 paired differences positive).  The other place the descent order enters --
the parent, i.e. the free descent from a random start -- has never been
varied: every m = 3 parent so far was made at (16,4) (S4-2) or (20,5)
(S5-8a).  This script makes m = 3 parents with the README schedule at the
m <= 2 tier, (12,3) with gate (24,6), about a seventh of the price, and runs
the shipped chain on them at the rule's m = 3 orders (20,5)/(32,8).

Pairing: the parents use S5-8a's m = 3 seeds (same initial latent as its
(20,5) parents), and the chain uses S5-8b's m = 3 unit indices (same per-jump
noise as its CHAIN units).  So 8e minus 8b, slot by slot, is the effect of
the parent's descent order with start and noise held fixed.

Three readings are possible and each is a result: parity (the expensive
order is only needed locally; the start can be cheap), worse (the start must
be at the rule's order too), better (coarse-to-fine in the order is itself
useful -- the hint being README-G(24,6) < README-D(12,3) at m = 2, n = 2).

    python s5_8e_parent_order.py --dry-run
    python s5_8e_parent_order.py
    python s5_8e_parent_order.py --resume
"""
import argparse
import json
import os
import sys
import time
from types import SimpleNamespace

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import s5_1_gate_tier as S1                                        # noqa: E402
import s5_8a_readme_schedule as A                                  # noqa: E402
import s5_8b_chain_strong_parents as B                             # noqa: E402
from s5_8_common import unit_row, print_unit                       # noqa: E402
from workbench.protocol import DEFAULT                             # noqa: E402
from workbench.app import order_rule                               # noqa: E402
import trustworthy_fmm.solvers.vector_2d as _v2d                   # noqa: E402
import trustworthy_fmm.fourier.convolution as _conv                # noqa: E402

DATA = S1.DATA
TARGET = (3, 0)
PARENT_LEVELS = None            # filled from order_rule((1,0)): (12,3) / (24,6)
STEPS = A.STEPS                 # 800
CKPT_EVERY = A.CKPT_EVERY       # 25
SEED_BASE = A.SEED_BASE[3]      # 53000: same initial latents as S5-8a m=3
N_SEEDS = 6
ARM = "CHAIN-E"
DRY = {"steps": 12, "ckpt": 4, "seeds": 1}


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--seeds", type=int, default=0)
    ap.add_argument("--jumps", type=int, default=0)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--out", type=str, default=None)
    args = ap.parse_args()

    torch.set_num_threads(int(os.environ.get("FMM_THREADS", "3")))
    _conv.VECTORIZED_CONV = True
    _v2d.FAST_DIAGNOSTICS = True
    _v2d.MEMORY_EFFICIENT = True
    device = "cuda" if torch.cuda.is_available() else "cpu"
    cfg = DEFAULT.variant(ny=S1.NY, nx=S1.NX)
    ref_cfg = DEFAULT.variant(ny=S1.REF_NY, nx=S1.REF_NX)
    steps, ck = STEPS, CKPT_EVERY
    n_seeds = args.seeds or N_SEEDS
    re_steps, cap = S1.REDESCENT_STEPS, S1.REF_TRACE_CAP
    rule = order_rule(TARGET, cfg)
    low = order_rule((1, 0), cfg)                      # the m<=2 tier
    n_jumps = args.jumps or B.N_JUMPS[3]
    if args.dry_run:
        steps, ck, n_seeds = DRY["steps"], DRY["ckpt"], DRY["seeds"]
        re_steps, cap, n_jumps = S1.DRY["steps"], S1.DRY["cap"], S1.DRY["jumps"]
    ladder = list(rule["ladder"])                      # [(40,10), (48,12)]
    p_level, p_gate = tuple(low["descent"]), tuple(low["gate"])   # (12,3), (24,6)

    # chain context = the rule's m=3 orders; the parent phase borrows it with
    # the low tier substituted (RefReader only needs the physics fields)
    ctx = SimpleNamespace(cfg=cfg, mode=S1.MODE, theta=0.0, phi=0.0,
                          target=TARGET, level_d=tuple(rule["descent"]),
                          gate=tuple(rule["gate"]), dtype=torch.complex64,
                          device=device, offload=False,
                          accept_rule="nominal", cd_biases=[-20.0, 20.0])
    ctx_p = SimpleNamespace(**{**vars(ctx), "level_d": p_level, "gate": p_gate})
    ref_ctx = SimpleNamespace(**{**vars(ctx), "cfg": ref_cfg})
    reader = S1.RefReader(ctx, ref_ctx, ladder)
    S1.NOISE_BASE = B.NOISE_BASE
    S1.TRACE_ARMS = (ARM,)
    tkey = "%d-%d" % TARGET

    out = args.out or os.path.join(
        DATA, "s5_8e_parent_order%s.json" % ("_dry" if args.dry_run else ""))
    store = {"meta": {}, "parents": {}, "units": {}, "summary": {}}
    if args.resume and os.path.exists(out):
        store = json.load(open(out, encoding="utf-8"))
        print("resuming: %d parents, %d units done"
              % (len(store["parents"]), len(store["units"])), flush=True)
    store["meta"].update({
        "script": os.path.basename(__file__),
        "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "gpu": torch.cuda.get_device_name(0) if device == "cuda" else "cpu",
        "code_path": "parents: s5_8a_readme_schedule.run at the m<=2 tier; "
                     "chain: s5_1_gate_tier.run_arm (S5-1 GATE1 protocol)",
        "target": list(TARGET), "pixel_nm": S1.PIXEL_NM, "grid": [S1.NY, S1.NX],
        "parent": {"descent": list(p_level), "gate": list(p_gate), "steps": steps,
                   "ckpt_every": ck, "trace_every": steps,
                   "certified": "best gate checkpoint only, on the m=3 ladder",
                   "seed_base": SEED_BASE, "n_seeds": n_seeds},
        "chain": {"descent": list(rule["descent"]), "gate": list(rule["gate"]),
                  "n_jumps": n_jumps, "redescent_steps": re_steps,
                  "beta_redescent": S1.BETA_REDESCENT, "noise_base": B.NOISE_BASE,
                  "unit_idx": "200 + seed index, = S5-8b's m=3 CHAIN slots",
                  "ref_trace_cap": cap},
        "ladder": [list(l) for l in ladder],
        "reading_notes": [
            "The parent is the README schedule at (12,3)/(24,6) -- the m<=2 "
            "tier -- for the m=3 target, delivered as its best (24,6) "
            "checkpoint and certified on the m=3 ladder.  S5-8a's m=3 parents "
            "are the same schedule at (20,5)/(32,8) from the same seeds.",
            "The chain is S5-1's GATE1 protocol at the rule's m=3 orders with "
            "S5-8b's noise seeds for the same slot, so 8e - 8b per slot holds "
            "start and noise fixed and varies only the parent's order.",
            "Parent trace: step 0 and the final step only (the trace is "
            "S5-8a's instrument; here the parent is a means).",
        ],
    })

    print("=" * 78)
    print("s5_8e_parent_order | %s | c64 | parents at %s/%s (%d steps), chain at "
          "%s/%s (%d jumps x %d) | %d seeds"
          % (store["meta"]["gpu"], p_level, p_gate, steps, rule["descent"],
             rule["gate"], n_jumps, re_steps, n_seeds), flush=True)
    t_start = time.perf_counter()
    for i in range(n_seeds):
        seed = SEED_BASE + i
        pkey = "%s|parent|s%02d" % (tkey, i)
        if pkey not in store["parents"]:
            ev = []
            t0 = time.perf_counter()
            r = A.run(ctx_p, reader, seed, steps, ck, steps, ev)
            meta = {"target": list(TARGET), "arm": "PARENT-LOW", "seed": seed,
                    "index": i, "steps": steps, "ckpt_every": ck, "trace_every": steps,
                    "descent_level": list(p_level), "gate": list(p_gate),
                    "trace_level": list(A.TRACE_LEVEL)}
            prow = unit_row(r, reader, ladder,
                            "s5_8e_parent_%s_s%02d" % (tkey.replace("-", "_"), i),
                            meta, certify=("best",), t0=t0, events=ev)
            store["parents"][pkey] = prow
            S1.save_json(out, store)
            print_unit("parent s%02d seed %d" % (i, seed), prow,
                       time.perf_counter() - t_start)
        prow = store["parents"][pkey]

        ukey = "%s|%s|p%02d" % (tkey, ARM, i)
        if ukey in store["units"]:
            continue
        unit_idx = (TARGET[0] - 1) * 100 + i
        lat = B.load_latent(prow["deliver_best"]["files"]["latent"])
        tag = "s5_8e_%s_%s_p%02d" % (ARM.replace("-", ""), tkey.replace("-", "_"), i)
        t0 = time.perf_counter()
        row = S1.run_arm(ARM, rule["gate"], lat, ctx, reader, unit_idx, n_jumps,
                         re_steps, cap, tag)
        marginal = row["wall_s"]["redescent"] + row["wall_s"]["gate"]
        row.update({
            "target": list(TARGET), "unit_idx": unit_idx, "pixel_nm": S1.PIXEL_NM,
            "descent_level": list(rule["descent"]),
            "ladder": [list(l) for l in ladder],
            "parent": {"slot": i, "source": "s5_8e|" + pkey, "seed": seed,
                       "latent": prow["deliver_best"]["files"]["latent"],
                       "eta_top": prow["deliver_best"]["eta_top"],
                       "eta_gate_low": prow["deliver_best"]["eta_gate"],
                       "best_step": prow["best_step"],
                       "descent": list(p_level), "gate": list(p_gate),
                       "parent_opt_wall_s": prow["opt_wall_s"],
                       "parent_wall_readme_s": prow["opt_wall_readme_s"]},
            "beta_schedule": "fixed %g" % S1.BETA_REDESCENT,
            "noise_seeds": [B.NOISE_BASE + 100 * unit_idx + k for k in range(n_jumps)],
            "budget": {"chain_marginal_s": marginal,
                       "parent_opt_wall_s": prow["opt_wall_s"],
                       "parent_wall_readme_s": prow["opt_wall_readme_s"],
                       "total_readme_s": prow["opt_wall_readme_s"] + marginal,
                       "total_ours_s": prow["opt_wall_s"] + marginal},
            "unit_wall_s": time.perf_counter() - t0,
            "ref_reads_cumulative": reader.n,
            "ref_wall_s_cumulative": reader.wall,
        })
        store["units"][ukey] = row
        S1.save_json(out, store)
        print("  %-7s p%02d acc %2d/%-2d | parent %.4f -> gate %.4f top %.4f (%+.4f) "
              "| optimism %+.4f | false %d/%d | marginal %s  [%s]"
              % (ARM, i, row["n_accept"], n_jumps, row["parent_eta_top"],
                 row["final_eta_gate"], row["final_eta_top"],
                 row["gain_top_over_parent"], row["gate_optimism"],
                 row["n_false_accepts"], row["n_traced_accepts"],
                 S1.fmt_s(marginal), S1.fmt_s(time.perf_counter() - t_start)),
              flush=True)

    rows = sorted(store["units"].values(), key=lambda u: u["parent"]["slot"])
    prs = sorted(store["parents"].values(), key=lambda u: u["index"])
    if rows:
        store["summary"][tkey] = {
            "n": len(rows),
            "parent_top": B.q([u["deliver_best"]["eta_top"] for u in prs]),
            "parent_best_steps": [u["best_step"] for u in prs],
            "parent_opt_wall_s": B.q([u["opt_wall_s"] for u in prs]),
            "final_top": B.q([r["final_eta_top"] for r in rows]),
            "gain_top_over_parent": B.q([r["gain_top_over_parent"] for r in rows]),
            "n_accept": [r["n_accept"] for r in rows],
            "chain_marginal_s": B.q([r["budget"]["chain_marginal_s"] for r in rows]),
            "total_ours_s": B.q([r["budget"]["total_ours_s"] for r in rows]),
        }
        s = store["summary"][tkey]
        print("  --> n=%d | parent top med %.4f (%s per parent) | final top med %.4f "
              "[%.4f,%.4f] | gain med %+.4f | accepts %s | total med %s"
              % (s["n"], s["parent_top"]["median"],
                 S1.fmt_s(s["parent_opt_wall_s"]["median"]), s["final_top"]["median"],
                 s["final_top"]["min"], s["final_top"]["max"],
                 s["gain_top_over_parent"]["median"], s["n_accept"],
                 S1.fmt_s(s["total_ours_s"]["median"])), flush=True)
    store["meta"]["total_wall_s"] = time.perf_counter() - t_start
    store["meta"]["finished_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    S1.save_json(out, store)
    print("=" * 78)
    print("wrote %s (%d parents, %d units, %s)"
          % (out, len(store["parents"]), len(store["units"]),
             S1.fmt_s(store["meta"]["total_wall_s"])))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
