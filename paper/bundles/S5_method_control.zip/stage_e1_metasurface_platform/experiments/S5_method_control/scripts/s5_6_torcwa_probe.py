"""S5-6 probe  What TORCWA costs, and whether the two engines still agree.

Two minutes of measurement, no optimisation.  It exists to make the TORCWA
head-to-head (S5-7) costable and licensable:

  1. **Price.**  TORCWA's value+gradient and forward at each order this paper
     uses, on the same 10 nm grid, beside our own measured prices (S5-3).
     Without this the head-to-head's budget is a guess.
  2. **Licence for a single scorer.**  The head-to-head scores BOTH engines'
     delivered designs with ONE engine at the certification order.  That is
     only legitimate if the two engines read the same structure the same way,
     so this re-checks parity on the actual designs involved (the S5-1 m=3
     parents and a couple of S5-4 tickets), at every order in the ladder.

Both are read-only measurements on existing designs.

    python s5_6_torcwa_probe.py
"""
import json
import os
import sys
import time

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import s5_1_gate_tier as S1                                        # noqa: E402
from workbench.protocol import DEFAULT, n_terms                    # noqa: E402
from workbench.app import (                                        # noqa: E402
    order_rule, app_hard_binary, app_projected, gate_eval, value_grad,
    torcwa_value_grad_latent, torcwa_eta_density, _has_torcwa,
)
import trustworthy_fmm.solvers.vector_2d as _v2d                   # noqa: E402
import trustworthy_fmm.fourier.convolution as _conv                # noqa: E402

DATA = S1.DATA
LEVELS = [(12, 3), (20, 5), (24, 6), (32, 8), (40, 10), (48, 12)]
VG_LEVELS = [(12, 3), (20, 5), (24, 6), (32, 8)]
REPS = 5
BETA = 64.0


def timeit(fn, reps=REPS):
    fn()
    if torch.cuda.is_available():
        torch.cuda.synchronize()
    ts = []
    for _ in range(reps):
        if torch.cuda.is_available():
            torch.cuda.synchronize()
        t0 = time.perf_counter()
        fn()
        if torch.cuda.is_available():
            torch.cuda.synchronize()
        ts.append(time.perf_counter() - t0)
    a = np.asarray(ts)
    return {"n": int(a.size), "median": float(np.median(a)),
            "min": float(a.min()), "max": float(a.max())}


def main():
    if not _has_torcwa():
        raise SystemExit("torcwa is not importable in this environment")
    torch.set_num_threads(int(os.environ.get("FMM_THREADS", "3")))
    _conv.VECTORIZED_CONV = True
    _v2d.FAST_DIAGNOSTICS = True
    _v2d.MEMORY_EFFICIENT = True
    device = "cuda" if torch.cuda.is_available() else "cpu"
    dtype = torch.complex64
    cfg = DEFAULT.variant(ny=S1.NY, nx=S1.NX)
    target = (3, 0)
    mode = S1.MODE

    with open(os.path.join(DATA, "parents.json"), encoding="utf-8") as f:
        parents = json.load(f)
    lat = torch.from_numpy(np.load(os.path.join(
        S1.S4_DATA, parents["3-0"]["median"]["latent"])).astype("float64"))
    binary = app_hard_binary(lat, cfg, mode)

    ctx = type("C", (), {})()
    ctx.cfg, ctx.mode, ctx.theta, ctx.phi = cfg, mode, 0.0, 0.0
    ctx.target, ctx.dtype, ctx.device, ctx.offload = target, dtype, device, False

    out = {"meta": {"gpu": torch.cuda.get_device_name(0) if device == "cuda"
                    else "cpu", "grid": [S1.NY, S1.NX], "pixel_nm": S1.PIXEL_NM,
                    "dtype": "complex64", "beta": BETA, "reps": REPS,
                    "target": list(target),
                    "note": "torcwa uses stable_eig_grad=True (its Lorentzian "
                            "broadening, default 1e-10); ours runs with the "
                            "broadening OFF.  Each engine at its own default."},
           "price": {}, "parity": {}}

    print("=" * 78)
    print("s5_6_torcwa_probe | %s | c64 | grid %r"
          % (out["meta"]["gpu"], (S1.NY, S1.NX)))
    print("=" * 78)
    print("\n=== 1. price: value+gradient through the SAME design map")
    print("  %-9s %6s  %10s  %10s  %6s" % ("level", "2N", "ours", "torcwa",
                                           "ratio"))
    for lv in VG_LEVELS:
        if not cfg.supports(lv):
            continue

        def ours(level=lv):
            v, g = value_grad(lat, level, target, BETA, cfg, mode, 0.0, 0.0,
                              dtype, device, False)
            del g

        def tor(level=lv):
            v, g = torcwa_value_grad_latent(lat, level, target, BETA, cfg,
                                            mode, 0.0, 0.0, dtype, device)
            del g
        a, b = timeit(ours), timeit(tor)
        out["price"]["vg|%d-%d" % lv] = {"level": list(lv),
                                         "two_n": 2 * n_terms(lv),
                                         "ours": a, "torcwa": b,
                                         "ratio": b["median"] / a["median"]}
        print("  %-9s %6d  %8.4f s  %8.4f s  %6.2f"
              % (str(lv), 2 * n_terms(lv), a["median"], b["median"],
                 b["median"] / a["median"]), flush=True)

    print("\n=== 2. price: forward on a delivered binary")
    print("  %-9s %6s  %10s  %10s  %6s" % ("level", "2N", "ours", "torcwa",
                                           "ratio"))
    for lv in LEVELS:
        if not cfg.supports(lv):
            continue
        a = timeit(lambda level=lv: gate_eval(binary, level, ctx))
        b = timeit(lambda level=lv: torcwa_eta_density(
            binary, level, target, cfg, 0.0, 0.0, dtype, device))
        out["price"]["fwd|%d-%d" % lv] = {"level": list(lv),
                                          "two_n": 2 * n_terms(lv),
                                          "ours": a, "torcwa": b,
                                          "ratio": b["median"] / a["median"]}
        print("  %-9s %6d  %8.4f s  %8.4f s  %6.2f"
              % (str(lv), 2 * n_terms(lv), a["median"], b["median"],
                 b["median"] / a["median"]), flush=True)

    print("\n=== 3. parity on the designs the head-to-head will use")
    print("  (licences scoring BOTH engines' deliveries with ONE engine)")
    designs = [("s5-1 parent m=3 median", lat)]
    for tag in ("median", "top"):
        for m in (1, 2):
            p = parents["%d-0" % m][tag]
            designs.append(("s4-2 parent m=%d %s" % (m, tag),
                            torch.from_numpy(np.load(os.path.join(
                                S1.S4_DATA, p["latent"])).astype("float64"))))
    rows = []
    for name, l in designs:
        b = app_hard_binary(l, cfg, mode)
        tgt = (3, 0) if "m=3" in name else ((1, 0) if "m=1" in name else (2, 0))
        c2 = type("C", (), {})()
        c2.__dict__.update(ctx.__dict__)
        c2.target = tgt
        for lv in [(24, 6), (32, 8), (40, 10)]:
            if not cfg.supports(lv):
                continue
            e_o = gate_eval(b, lv, c2)
            e_t = torcwa_eta_density(b, lv, tgt, cfg, 0.0, 0.0, dtype, device)
            rows.append({"design": name, "target": list(tgt), "level": list(lv),
                         "ours": e_o, "torcwa": e_t, "abs_diff": abs(e_o - e_t),
                         "rel_diff": abs(e_o - e_t) / e_o if e_o else None})
            print("  %-26s %-8s ours %.6f  torcwa %.6f  |d| %.2e (%.1e rel)"
                  % (name, str(lv), e_o, e_t, rows[-1]["abs_diff"],
                     rows[-1]["rel_diff"]), flush=True)
    d = [r["abs_diff"] for r in rows]
    rel = [r["rel_diff"] for r in rows if r["rel_diff"] is not None]
    out["parity"] = {"rows": rows, "n": len(rows),
                     "median_abs": float(np.median(d)),
                     "max_abs": float(max(d)),
                     "median_rel": float(np.median(rel)),
                     "max_rel": float(max(rel))}
    print("\n  parity over %d (design, level) pairs: |d| median %.2e max %.2e"
          "  (rel median %.1e max %.1e)"
          % (len(rows), out["parity"]["median_abs"], out["parity"]["max_abs"],
             out["parity"]["median_rel"], out["parity"]["max_rel"]))

    # ---- what the head-to-head would cost, from the measured prices --------
    est = {}
    for m in (1, 2, 3):
        rule = order_rule((m, 0), cfg)
        d_lv, g_lv = tuple(rule["descent"]), tuple(rule["gate"])
        vt = out["price"].get("vg|%d-%d" % d_lv)
        gf = out["price"].get("fwd|%d-%d" % g_lv)
        if not vt or not gf:
            continue
        t_vg_t, t_fwd_o = vt["torcwa"]["median"], gf["ours"]["median"]
        # T-BASE: our 219-step baseline, torcwa gradients, our gate scoring
        t_base = 219 * t_vg_t + 37 * t_fwd_o
        # T-README: 800 steps at ONE order, no gate checkpoints, one delivery
        rm = {}
        for lab, lv in (("at_descent", d_lv), ("at_gate", g_lv)):
            v = out["price"].get("vg|%d-%d" % lv)
            if v:
                rm[lab] = 800 * v["torcwa"]["median"]
        est["m%d" % m] = {"descent": list(d_lv), "gate": list(g_lv),
                          "t_base_per_ticket_s": t_base, "t_readme_s": rm}
    out["head_to_head_estimate"] = est
    print("\n=== 4. what S5-7 would cost (per run, from the prices above)")
    for k, v in est.items():
        print("  %s  T-BASE ticket %s | T-README %s"
              % (k, S1.fmt_s(v["t_base_per_ticket_s"]),
                 " / ".join("%s %s" % (a, S1.fmt_s(b))
                            for a, b in v["t_readme_s"].items())))
    for n_seeds in (6,):
        tot = sum(v["t_base_per_ticket_s"] * n_seeds
                  + sum(v["t_readme_s"].values()) * n_seeds
                  for v in est.values())
        print("  --> n=%d seeds x 3 targets, both arms: %s"
              % (n_seeds, S1.fmt_s(tot)))

    p = os.path.join(DATA, "s5_6_torcwa_probe.json")
    S1.save_json(p, out)
    print("\nwrote %s" % p)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
