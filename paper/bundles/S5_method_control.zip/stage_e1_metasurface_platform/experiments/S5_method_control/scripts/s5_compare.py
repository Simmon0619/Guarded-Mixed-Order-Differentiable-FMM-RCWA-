"""Equal-wall-clock comparison: the chain (S5-1) against the restart lottery (S5-4).

The chain does NOT start from nothing -- it starts from a parent that had to be
produced.  So the comparison is reported at two budgets, and the difference
between them is the whole argument:

  marginal  = the chain's own descent + gate seconds.  The parent is free.
              This is "given an incumbent, is chaining a good way to spend the
              next N seconds?"
  total     = marginal + the cost of producing one parent.  The chain's parents
              are S4-2 L16 deliveries, i.e. one 219-step baseline descent each,
              so one restart ticket is the right price for one parent.
              This is "starting from nothing, is chain-after-a-restart better
              than more restarts?"

The restart side is read off the exact E[max_N] curve at N = floor(budget /
median ticket wall).  Only the MEDIAN-parent chain units enter the headline
comparison: the top parent is itself a max-of-8 statistic that the restart arm
is not given, and pricing it as one ticket would flatter the chain.  The
top-parent units are reported separately.
"""
import json
import math
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "..", "data")
OUT = os.path.join(DATA, "s5_comparison.json")
CHAINS = ("GATE0", "GATE1", "GATE2", "SHOT")


def med(v):
    return float(np.median(v)) if len(v) else None


def main():
    c1 = json.load(open(os.path.join(DATA, "s5_1_gate_tier.json"), encoding="utf-8"))
    c4 = json.load(open(os.path.join(DATA, "s5_4_restart_baseline.json"),
                        encoding="utf-8"))
    U1, U4, curves = c1["units"], c4["units"], c4["curves"]
    res = {"note": __doc__.strip().splitlines()[0], "targets": {}}

    for m in (1, 2, 3):
        tkey = "%d-0" % m
        cur = curves.get(tkey)
        if cur is None:
            continue
        tick = cur["median_ticket_wall_s"]
        emax = cur["e_max_n_by_top"]
        tops4 = [v["eta_top"] for v in U4.values() if v["target"][0] == m]

        out = {"restart": {
            "n_tickets": cur["n"], "median_ticket_wall_s": tick,
            "single_ticket": {"median": cur["eta_top"]["median"],
                              "min": cur["eta_top"]["min"],
                              "max": cur["eta_top"]["max"],
                              "q1": cur["eta_top"]["q1"], "q3": cur["eta_top"]["q3"]},
            "gate_optimism_median": cur["gate_optimism_median"],
            "e_max_n": {"N": emax["N"], "e_max": emax["e_max"],
                        "p10": emax["p10"], "p90": emax["p90"],
                        "wall_s": [n * tick for n in emax["N"]]},
        }}

        # ---- chain side, by arm and by parent tag ---------------------------
        arms = {}
        for arm in CHAINS:
            for ptag in ("median", "top"):
                rows = [v for k, v in U1.items()
                        if v["target"][0] == m and v["arm"] == arm
                        and v["parent_tag"] == ptag]
                if not rows:
                    continue
                budget = med([r["wall_s"]["redescent"] + r["wall_s"]["gate"]
                              for r in rows])
                arms["%s|%s" % (arm, ptag)] = {
                    "n": len(rows),
                    "top_median": med([r["final_eta_top"] for r in rows]),
                    "top_min": min(r["final_eta_top"] for r in rows),
                    "top_max": max(r["final_eta_top"] for r in rows),
                    "parent_top": rows[0]["parent_eta_top"],
                    "gain_over_parent_median": med(
                        [r["gain_top_over_parent"] for r in rows]),
                    "marginal_budget_s": budget,
                    "total_budget_s": budget + tick,
                }
        out["chain"] = arms

        # ---- the headline: median-parent GATE1 at both budgets --------------
        g1 = arms.get("GATE1|median")
        if g1:
            def restart_at(budget):
                n = int(budget // tick)
                if n < 1:
                    return {"N": 0, "e_max": None,
                            "note": "budget buys less than one ticket"}
                n = min(n, emax["N"][-1])
                i = emax["N"].index(n)
                return {"N": n, "e_max": emax["e_max"][i],
                        "p10": emax["p10"][i], "p90": emax["p90"][i],
                        "capped_at_n_over_2": n == emax["N"][-1]}
            out["headline"] = {
                "chain_top_median": g1["top_median"],
                "parent_top": g1["parent_top"],
                "marginal": {"budget_s": g1["marginal_budget_s"],
                             "restart": restart_at(g1["marginal_budget_s"])},
                "total": {"budget_s": g1["total_budget_s"],
                          "restart": restart_at(g1["total_budget_s"])},
                "restart_needs_N_to_match": next(
                    (n for n, e in zip(emax["N"], emax["e_max"])
                     if e >= g1["top_median"]), None),
                "restart_best_of_all_n": max(tops4),
                "chain_best_of_all_units": max(
                    v["final_eta_top"] for v in U1.values()
                    if v["target"][0] == m),
            }
        # ---- sensitivity: the restart arm's audit cadence -------------------
        # The tickets were run with ckpt_every=6 (S4-2's cadence), so 37 gate
        # forwards per ticket -- 72% of a ticket's wall clock.  The workbench's
        # own default is max(5, steps//10) = 21, i.e. ~11 forwards, which makes
        # a ticket much cheaper and buys MORE tickets for the same budget.
        # This penalises the restart arm in the comparison above, so the
        # sensitivity has to be reported.
        #
        # Only the best checkpoint's design was certified, so the top-rung
        # value under a coarser cadence is not measured.  Here it is assumed
        # UNCHANGED, which is optimistic for the restart arm (a coarser cadence
        # can only pick a checkpoint with a weakly lower gate value), so these
        # numbers are an UPPER BOUND on what restarts deliver.
        rows4 = [v for v in U4.values() if v["target"][0] == m]
        n_ck = med([v["n_ckpt"] for v in rows4])
        t_desc = med([v["wall_descent_s"] for v in rows4])
        t_gate1 = med([v["wall_gate_s"] for v in rows4]) / n_ck
        sens = {}
        for cad in (6, 12, 24, 42):
            k = math.ceil(219 / cad)
            tick_c = t_desc + k * t_gate1
            row = {"ckpt_every": cad, "n_ckpt": k, "ticket_wall_s": tick_c}
            if g1:
                for lab, budget in (("marginal", g1["marginal_budget_s"]),
                                    ("total", g1["marginal_budget_s"] + tick_c)):
                    n = min(int(budget // tick_c), emax["N"][-1])
                    row[lab] = {"budget_s": budget, "N": n,
                                "e_max_upper_bound": (emax["e_max"][n - 1]
                                                      if n >= 1 else None),
                                "chain_minus_restart": (
                                    g1["top_median"] - emax["e_max"][n - 1]
                                    if n >= 1 else None)}
            sens["ckpt%d" % cad] = row
        out["restart_cadence_sensitivity"] = sens
        out["restart_cadence_note"] = (
            "upper bound on the restart arm: the top-rung value is held at its "
            "ckpt_every=6 measurement while the ticket is priced at the coarser "
            "cadence")
        res["targets"][tkey] = out

    # ------------------------------------------------------------------ print
    for tkey, o in res["targets"].items():
        m = int(tkey[0])
        r, h = o["restart"], o.get("headline")
        print("=" * 74)
        print("m=%d   restart ticket %.0f s, n=%d | single-ticket top med %.4f "
              "[%.4f,%.4f]" % (m, r["median_ticket_wall_s"], r["n_tickets"],
                               r["single_ticket"]["median"],
                               r["single_ticket"]["min"],
                               r["single_ticket"]["max"]))
        e = r["e_max_n"]
        show = [i for i, n in enumerate(e["N"]) if n in (1, 2, 3, 4, 6, 8, 12)]
        print("      E[max_N]: " + "  ".join(
            "N=%d %.4f (%.0f s)" % (e["N"][i], e["e_max"][i], e["wall_s"][i])
            for i in show))
        if h:
            print("  chain GATE1 (median parent, n=%d): parent %.4f -> %.4f"
                  % (o["chain"]["GATE1|median"]["n"], h["parent_top"],
                     h["chain_top_median"]))
            for lab in ("marginal", "total"):
                b = h[lab]
                rr = b["restart"]
                if rr.get("e_max") is None:
                    print("    %-8s budget %5.0f s -> restarts: %s"
                          % (lab, b["budget_s"], rr["note"]))
                else:
                    print("    %-8s budget %5.0f s -> best-of-%d restarts "
                          "E[max]=%.4f  |  chain %.4f  |  chain %+.4f"
                          % (lab, b["budget_s"], rr["N"], rr["e_max"],
                             h["chain_top_median"],
                             h["chain_top_median"] - rr["e_max"]))
            print("    restarts need N=%s to match the chain's median "
                  "(cap N<=%d) ; best single restart over all n: %.4f ; "
                  "best chain unit: %.4f"
                  % (h["restart_needs_N_to_match"], e["N"][-1],
                     h["restart_best_of_all_n"], h["chain_best_of_all_units"]))
        s = o.get("restart_cadence_sensitivity")
        if s and h:
            print("  restart audit-cadence sensitivity (UPPER BOUND on restarts):")
            for k in ("ckpt6", "ckpt12", "ckpt24", "ckpt42"):
                v = s[k]
                t = v.get("total")
                if not t or t.get("e_max_upper_bound") is None:
                    continue
                print("    every %2d steps: %2d fwd, ticket %5.0f s -> total "
                      "budget %5.0f s buys N=%d, E[max]<=%.4f, chain %+.4f"
                      % (v["ckpt_every"], v["n_ckpt"], v["ticket_wall_s"],
                         t["budget_s"], t["N"], t["e_max_upper_bound"],
                         t["chain_minus_restart"]))
        print("  chain arms (top median / marginal budget s):")
        for k, v in o["chain"].items():
            print("    %-14s n=%d  %.4f  (parent %.4f, %+.4f)  %5.0f s"
                  % (k, v["n"], v["top_median"], v["parent_top"],
                     v["gain_over_parent_median"], v["marginal_budget_s"]))

    json.dump(res, open(OUT, "w", encoding="utf-8"), indent=1, ensure_ascii=False)
    print("\nwrote %s" % OUT)
    return 0


if __name__ == "__main__":
    sys.exit(main())
