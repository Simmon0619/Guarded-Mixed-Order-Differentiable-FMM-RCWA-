"""S5-1  Does the GATE tier earn its keep inside the chain?

Runs the workbench's own shipped code path (fmm_workbench/workbench/app.py)
with exactly one field varied: ``ctx.gate``, the order at which a candidate is
scored and accepted.  Everything else is the protocol as shipped -- the same
design map, the same Adam, the same perturbation operator, the same 30-step
fixed-beta re-descent, the same monotone acceptance, the same order rule.

The rule under test (docs/algorithm.md Sec. 4): three tiers of truncation
order, with the descent order supplying gradients only ("its value enters no
decision") and the gate order, required to be >= 2x the descent order, making
every selection.  ``run_optimize`` warns when a gate is under 2x -- so the rule
is enforced in the UI, but nothing in the repository measures what violating it
costs, or what buying more than it costs.

  arm     gate order                     incumbent   what it is
  GATE0   = descent order                moves       rule violated: no gate tier
  GATE1   = order_rule's gate            moves       the method as shipped
  GATE2   = order_rule's first ladder    moves       over-gated: is 2x enough?
  SHOT    = order_rule's gate            FROZEN      same proposals, no chain

order_rule at 10 nm (70,240) for the frozen physics:
  m<=2 : descent (12,3)  gate (24,6)  ladder (32,8),(40,10)
  m=3  : descent (20,5)  gate (32,8)  ladder (40,10),(48,12)

Note the pixel is not free to choose: at 20 nm (35,120) the rule CLIPS for
every target -- m<=2's ladder collapses to one rung and m=3 has no ladder at
all and a clipped gate -- because (40,10) needs 161 samples per period and the
20 nm grid holds 120.  S4-3 found the design pixel buys no efficiency for a
single descent; what it buys is the headroom to certify.

Prior art, both n=1 and pointing opposite ways: E19's (3,0) chain accepted
2/26 at a (24,6) gate, reported +12.62% there, and was -7.59% at (40,10) /
-11.69% at (48,12) against its parent; E21's (3,0) chain at a (32,8) gate
accepted 0/60 and stayed bitwise at the parent.

Descriptive: numbers, not verdicts.  No success criteria, no kill gates, no
hypothesis tests.

    python s5_1_gate_tier.py --dry-run
    python s5_1_gate_tier.py --targets 1        # one target at a time
    python s5_1_gate_tier.py --resume
"""
import argparse
import hashlib
import json
import os
import sys
import time
from types import SimpleNamespace
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
_WB = os.path.abspath(os.path.join(_HERE, "..", "..", "..", "fmm_workbench"))
if not os.path.isdir(_WB):
    raise SystemExit("fmm_workbench not found at %s" % _WB)
# Import ONLY from the workbench tree: it ships its own copy of trustworthy_fmm
# and mixing it with stage_e1/src under the same package name would silently
# load whichever came first on sys.path.
sys.path.insert(0, _WB)
import workbench.protocol as P                                    # noqa: E402
from workbench.protocol import DEFAULT, n_terms, cosine_lr        # noqa: E402
from workbench.app import (                                       # noqa: E402
    order_rule, filtered_noise, gate_eval, gate_score, app_hard_binary,
    value_grad, AppAdam, _sym,
)
import trustworthy_fmm.solvers.vector_2d as _v2d                  # noqa: E402
import trustworthy_fmm.fourier.convolution as _conv               # noqa: E402

DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
DESIGNS = os.path.join(DATA, "designs")
S4_DATA = os.path.abspath(os.path.join(_HERE, "..", "..",
                                       "S4_truncation_and_pixel", "data"))

# ------------------------------------------------------------------ protocol
PIXEL_NM = 10
NY, NX = 70, 240                       # 10 nm grid; the rule does not clip here
REF_NY, REF_NX = 140, 480              # 5 nm-equivalent grid, S4's convention
MODE = "y"                             # y-mirror symmetrisation, as shipped
BETA_REDESCENT = 64.0
REDESCENT_STEPS = 30
ALPHAS = (0.1, 0.25, 0.5)
N_JUMPS = {1: 24, 2: 24, 3: 16}        # m=3 re-descends at (20,5), ~7x costlier
N_REPS = {1: 3, 2: 3, 3: 2}
PARENT_TAGS = ("median", "top")
ARMS = ("GATE0", "GATE1", "GATE2", "SHOT")
REF_TRACE_CAP = 5                      # accept-traced reference reads per chain
TRACE_ARMS = ("GATE0", "GATE1")        # tracing GATE2 buys little for its cost
NOISE_BASE = 9500                      # 9500 + 100*unit + jump; see note below
# The workbench's own default chain noise base is 9100 (+j, so 9100-9139) and
# E22's stream is 7000+100r+k with r,k in 0..23, i.e. 7000-9323 -- which also
# overlaps S4's seed blocks 7101-7124 / 7201-7224 / 7301-7324.  9500+ is clear
# of all three.  (s4_common.seeds_for only guards 7000-7099; that guard is too
# narrow and is left alone because widening it would invalidate S4-2's store.)

DRY = {"jumps": 3, "steps": 4, "reps": 1, "cap": 2}


def sha1_of(t: torch.Tensor) -> str:
    a = t.detach().cpu().numpy().astype(np.uint8)
    return hashlib.sha1(a.tobytes()).hexdigest()


def lift(binary: torch.Tensor, k: int) -> torch.Tensor:
    """Block replication -- pointwise exact on a binary mask."""
    if k == 1:
        return binary.clone()
    return torch.repeat_interleave(torch.repeat_interleave(binary, k, 0), k, 1)


def fmt_s(s: float) -> str:
    if s < 90:
        return "%.0f s" % s
    if s < 5400:
        return "%.1f min" % (s / 60.0)
    return "%.2f h" % (s / 3600.0)


# --------------------------------------------------------------- NaN guard
# S4 measured 2 non-finite adjoints in ~3.2e4 gradient calls (both at low beta,
# the signature of the unregularised eigendecomposition adjoint at a complex64
# degeneracy).  The workbench's redescend has no guard; this run would make
# ~5e4 such calls.  Policy, identical to S4's: retry at beta*(1 +- jitter),
# and if every retry fails, skip the Adam update but still consume the step.
# The workbench also ships an optional Lorentzian broadening stabiliser
# (solvers/eigendecomposition.py, off by default); it is NOT enabled here, so
# this run stays on the same numerical path as everything else in the paper.
GRAD_JITTERS = (1e-6, -1e-6, 1e-5, -1e-5)


def guarded_value_grad(rho, level, beta, ctx, events: List[Dict], step: int):
    def call(b):
        return value_grad(rho, level, ctx.target, b, ctx.cfg, ctx.mode,
                          ctx.theta, ctx.phi, ctx.dtype, ctx.device, ctx.offload)
    try:
        eta, grad = call(beta)
        if bool(torch.isfinite(grad).all()):
            return eta, grad
        del grad
    except RuntimeError as exc:
        events.append({"event": "raised", "step": step, "beta": beta,
                       "detail": str(exc)[:200]})
    for j in GRAD_JITTERS:
        try:
            eta, grad = call(float(beta) * (1.0 + j))
            if bool(torch.isfinite(grad).all()):
                events.append({"event": "jitter_recovered", "step": step,
                               "beta": beta, "jitter": j})
                return eta, grad
            del grad
        except RuntimeError:
            continue
    events.append({"event": "skipped_update", "step": step, "beta": beta})
    return None, None


def redescend_guarded(rho0, ctx, steps, beta, events):
    """Line-for-line the workbench's ``redescend`` plus the NaN guard."""
    rho = rho0.to(ctx.device)
    adam = AppAdam(rho.shape, ctx.cfg, ctx.mode, ctx.device)
    for t in range(steps):
        lr = cosine_lr(t / steps, ctx.cfg)
        _, grad = guarded_value_grad(rho, ctx.level_d, beta, ctx, events, t)
        if grad is not None:
            rho = adam.step(rho, grad, lr)
    return rho.detach().cpu()


# ------------------------------------------------------------------- reader
class RefReader:
    """Certification reads, cached by (mask sha1, level, grid)."""

    def __init__(self, ctx, ref_ctx, ladder):
        self.ctx, self.ref_ctx, self.ladder = ctx, ref_ctx, ladder
        self.cache: Dict[str, float] = {}
        self.wall = 0.0
        self.n = 0

    def read(self, binary, level, lifted=False) -> float:
        sha = sha1_of(binary)
        key = "%s|%d-%d|%s" % (sha, level[0], level[1], "5nm" if lifted else "native")
        if key in self.cache:
            return self.cache[key]
        t0 = time.perf_counter()
        if lifted:
            b = lift(binary, PIXEL_NM // 5)
            v = gate_eval(b, tuple(level), self.ref_ctx)
        else:
            v = gate_eval(binary, tuple(level), self.ctx)
        self.wall += time.perf_counter() - t0
        self.n += 1
        self.cache[key] = float(v)
        return float(v)

    def ladder_of(self, binary) -> Dict[str, float]:
        out = {"%d-%d" % lv: self.read(binary, lv) for lv in self.ladder}
        out["40-10@5nm"] = self.read(binary, (40, 10), lifted=True)
        return out

    def top(self, binary) -> float:
        return self.read(binary, self.ladder[-1])

    def trace(self, binary) -> float:
        """Level used for the per-accept trace: (40,10), for every target.

        Uniform across m, so false-accept counts are comparable, and 3x
        cheaper than m=3's top rung (48,12) at 60 s a read.  E19's (3,0)
        false accept was -7.59% at (40,10) and -11.69% at (48,12), so (40,10)
        resolves the sign that the trace is there to detect.
        """
        return self.read(binary, (40, 10))


# --------------------------------------------------------------------- arms
def run_arm(arm: str, gate: Sequence[int], parent_lat: torch.Tensor,
            ctx, reader: RefReader, unit_idx: int, n_jumps: int, steps: int,
            cap: int, tag: str) -> Dict[str, object]:
    """One chain (incumbent moves) or one shotgun (incumbent frozen)."""
    chained = arm != "SHOT"
    ctx.gate = tuple(int(v) for v in gate)
    cfg, mode = ctx.cfg, ctx.mode
    events: List[Dict] = []
    t_desc = t_gate = 0.0

    inc_lat = parent_lat.clone()
    inc_bin = app_hard_binary(inc_lat, cfg, mode)
    t0 = time.perf_counter()
    inc_score, inc_detail = gate_score(inc_bin, ctx)
    t_gate += time.perf_counter() - t0
    parent_ladder = reader.ladder_of(inc_bin)
    parent_top = parent_ladder["%d-%d" % reader.ladder[-1]]
    parent_trace = parent_ladder["40-10"]

    jumps: List[Dict] = []
    cands: List[Dict] = []
    trace: List[Dict] = [{"jump": -1, "eta_trace_40_10": parent_trace,
                          "eta_top": parent_top, "eta_gate": inc_score,
                          "note": "parent"}]
    last_traced = parent_trace
    n_accept = 0
    for k in range(n_jumps):
        alpha = ALPHAS[k % len(ALPHAS)]
        noise = filtered_noise(NOISE_BASE + 100 * unit_idx + k, cfg)
        centre = inc_lat if chained else parent_lat
        pert = _sym((centre + alpha * cfg.init_scale * noise).clamp(0.0, 1.0), mode)
        t0 = time.perf_counter()
        rho = redescend_guarded(pert, ctx, steps, BETA_REDESCENT, events)
        t_desc += time.perf_counter() - t0
        b = app_hard_binary(rho, cfg, mode)
        t0 = time.perf_counter()
        score, detail = gate_score(b, ctx)
        t_gate += time.perf_counter() - t0
        row = {"jump": k, "alpha": alpha, "score": score,
               "incumbent_before": inc_score}
        if chained:
            acc = bool(score > inc_score)
            row["accepted"] = acc
            if acc:
                n_accept += 1
                inc_lat, inc_bin, inc_score, inc_detail = rho, b, score, detail
                if arm in TRACE_ARMS and len(trace) - 1 < cap:
                    tr = reader.trace(b)
                    row["eta_trace_after_accept"] = tr
                    row["d_eta_trace"] = tr - last_traced
                    trace.append({"jump": k, "eta_trace_40_10": tr,
                                  "eta_gate": score})
                    last_traced = tr
            jumps.append(row)
        else:
            cands.append({"cand": k, "alpha": alpha, "score": score,
                          "sha1": sha1_of(b), "_bin": b, "_lat": rho})

    if not chained:
        # monotone semantics: the parent is a candidate, so a shotgun that
        # finds nothing delivers the parent, exactly as a chain with 0 accepts
        best = max(cands, key=lambda c: c["score"]) if cands else None
        if best is not None and best["score"] > inc_score:
            inc_lat, inc_bin, inc_score = best["_lat"], best["_bin"], best["score"]
            n_accept = 1
        jumps = [{k: v for k, v in c.items() if not k.startswith("_")}
                 for c in cands]

    final_ladder = reader.ladder_of(inc_bin)
    final_top = final_ladder["%d-%d" % reader.ladder[-1]]
    files = save_design(tag, inc_bin, inc_lat)
    traced = [j for j in jumps if j.get("d_eta_trace") is not None]
    return {
        "arm": arm, "chained": chained, "gate": list(ctx.gate),
        "gate_n_terms": n_terms(ctx.gate),
        "gate_over_descent": n_terms(ctx.gate) / n_terms(ctx.level_d),
        "n_jumps": n_jumps, "redescent_steps": steps,
        "n_accept": n_accept,
        "accept_jumps": [j["jump"] for j in jumps if j.get("accepted")],
        "parent_eta_gate": trace[0]["eta_gate"], "parent_ladder": parent_ladder,
        "parent_eta_top": parent_top, "parent_eta_trace_40_10": parent_trace,
        "final_eta_gate": inc_score, "final_ladder": final_ladder,
        "final_eta_top": final_top,
        "gain_top_over_parent": final_top - parent_top,
        "gate_optimism": inc_score - final_top,
        "gate_optimism_vs_40_10_at_5nm": inc_score - final_ladder["40-10@5nm"],
        "native_minus_lifted_40_10": (
            final_ladder.get("40-10") - final_ladder["40-10@5nm"]
            if "40-10" in final_ladder else None),
        "ref_trace": trace, "n_traced_accepts": len(traced),
        "n_false_accepts": sum(1 for j in traced if j["d_eta_trace"] < 0),
        "false_accept_loss": sum(j["d_eta_trace"] for j in traced
                                 if j["d_eta_trace"] < 0),
        "jumps": jumps, "mask_sha1": sha1_of(inc_bin), "files": files,
        "delivered_parent_unchanged": sha1_of(inc_bin) == sha1_of(
            app_hard_binary(parent_lat, ctx.cfg, ctx.mode)),
        "grad_events": events,
        "wall_s": {"redescent": t_desc, "gate": t_gate},
        "solves": {"value_grad_%d_%d" % tuple(ctx.level_d): n_jumps * steps,
                   "fwd_gate_%d_%d" % tuple(ctx.gate): n_jumps + 1},
    }


def save_design(tag, binary, latent) -> Dict[str, str]:
    os.makedirs(DESIGNS, exist_ok=True)
    b = os.path.join(DESIGNS, tag + "_binary.npy")
    l = os.path.join(DESIGNS, tag + "_latent.npy")
    np.save(b, binary.detach().cpu().numpy())
    np.save(l, latent.detach().cpu().numpy())
    return {"binary": os.path.relpath(b, DATA).replace("\\", "/"),
            "latent": os.path.relpath(l, DATA).replace("\\", "/")}


# ------------------------------------------------------------------- driver
def save_json(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=1, ensure_ascii=False, default=float)
    os.replace(tmp, path)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--targets", type=str, default="1,2,3")
    ap.add_argument("--parents", type=str, default="median,top")
    ap.add_argument("--arms", type=str, default=",".join(ARMS))
    ap.add_argument("--reps", type=int, default=0, help="0 = per-target default")
    ap.add_argument("--jumps", type=int, default=0, help="0 = per-target default")
    ap.add_argument("--cap", type=int, default=REF_TRACE_CAP)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--out", type=str, default=None)
    args = ap.parse_args()

    torch.set_num_threads(int(os.environ.get("FMM_THREADS", "3")))
    _conv.VECTORIZED_CONV = True
    _v2d.FAST_DIAGNOSTICS = True
    _v2d.MEMORY_EFFICIENT = True
    device = "cuda" if torch.cuda.is_available() else "cpu"
    dtype = torch.complex64

    cfg = DEFAULT.variant(ny=NY, nx=NX)
    ref_cfg = DEFAULT.variant(ny=REF_NY, nx=REF_NX)
    targets = [(int(t.strip()), 0) for t in args.targets.split(",") if t.strip()]
    ptags = [t.strip() for t in args.parents.split(",") if t.strip()]
    arms = [a.strip() for a in args.arms.split(",") if a.strip()]
    steps = REDESCENT_STEPS
    cap = args.cap
    if args.dry_run:
        steps, cap = DRY["steps"], DRY["cap"]

    out = args.out or os.path.join(
        DATA, "s5_1_gate_tier%s.json" % ("_dry" if args.dry_run else ""))
    with open(os.path.join(DATA, "parents.json"), encoding="utf-8") as f:
        parents = json.load(f)

    store = {"meta": {}, "units": {}}
    if args.resume and os.path.exists(out):
        with open(out, encoding="utf-8") as f:
            store = json.load(f)
        print("resuming: %d units already done" % len(store["units"]), flush=True)
    store["meta"].update({
        "script": os.path.basename(__file__),
        "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "torch": torch.__version__,
        "gpu": torch.cuda.get_device_name(0) if device == "cuda" else "cpu",
        "device": device, "dtype": "complex64",
        "code_path": "fmm_workbench (the shipped protocol), MEMORY_EFFICIENT=True",
        "pixel_nm": PIXEL_NM, "grid": [NY, NX], "ref_grid": [REF_NY, REF_NX],
        "symmetry": MODE, "beta_redescent": BETA_REDESCENT,
        "redescent_steps": steps, "alphas": list(ALPHAS),
        "noise_base": NOISE_BASE, "ref_trace_cap": cap,
        "trace_arms": list(TRACE_ARMS), "arms": arms,
        "params": {"targets": [list(t) for t in targets], "parents": ptags,
                   "reps": args.reps or N_REPS, "jumps": args.jumps or N_JUMPS,
                   "dry_run": bool(args.dry_run)},
        "reading_notes": [
            "The ONLY field that differs between GATE0/GATE1/GATE2 is ctx.gate. "
            "Descent order, perturbation noise (paired jump by jump), alpha "
            "rotation, re-descent length, beta, Adam reset, jump count, parent "
            "and grid are identical, so the arms are the same run until the "
            "first acceptance decision differs.",
            "SHOT uses the same noise seeds and the same gate as GATE1 but "
            "always perturbs the PARENT, so its candidate k is GATE1's jump-k "
            "proposal with a frozen centre.  The parent counts as a candidate, "
            "matching monotone semantics.",
            "Gate scores are on the design's own 10 nm grid, as shipped.  The "
            "certification ladder is read natively AND, for (40,10), on the "
            "5 nm-equivalent grid so these numbers can sit beside S4's; "
            "native_minus_lifted_40_10 is the conversion.",
            "eta_trace_after_accept is recorded at (40,10) -- the SAME level "
            "for every target, so false-accept counts are comparable and m=3 "
            "does not pay 60 s a read at (48,12) -- for the first `cap` "
            "accepts of the GATE0 and GATE1 arms only.  d_eta_trace compares "
            "against the "
            "previous RECORDED reading, so the trace stops at the cap rather "
            "than silently comparing across gaps; n_false_accepts is therefore "
            "a LOWER bound.",
            "The workbench's redescend is reproduced line for line with one "
            "addition: the S4 NaN guard (retry at beta*(1+-jitter), else skip "
            "the update).  Lorentzian broadening stays off, as shipped.",
            "Deviations from the shipped defaults, both to fit the budget: "
            "chain_jumps 24 (16 for m=3) instead of 40, and the incumbent is a "
            "fixed S4-2 delivery instead of gate-selected start restarts -- a "
            "fixed parent is what makes the gate comparison paired.",
        ],
    })

    rules = {}
    print("=" * 74)
    print("s5_1_gate_tier | %s | c64/GPU | workbench code path"
          % store["meta"]["gpu"])
    print("  grid %r (%d nm), reference also on %r (5 nm)"
          % ((NY, NX), PIXEL_NM, (REF_NY, REF_NX)))
    for tgt in targets:
        r = order_rule(tgt, cfg)
        rules["%d-%d" % tgt] = {k: (list(v) if isinstance(v, tuple)
                                    else [list(x) for x in v] if k == "ladder"
                                    else v)
                                for k, v in r.items() if k != "unclipped"}
        print("  m=%d  descent %s  gate %s (%.2fx)  ladder %s  clipped=%s"
              % (tgt[0], r["descent"], r["gate"],
                 n_terms(r["gate"]) / n_terms(r["descent"]), r["ladder"],
                 r["clipped"]))
    store["meta"]["order_rule"] = rules
    print("=" * 74, flush=True)

    t_start = time.perf_counter()
    n_done = 0
    for tgt in targets:
        m = tgt[0]
        rule = order_rule(tgt, cfg)
        ladder = list(rule["ladder"])
        gates = {"GATE0": rule["descent"], "GATE1": rule["gate"],
                 "GATE2": ladder[0] if ladder else rule["gate"],
                 "SHOT": rule["gate"]}
        n_jumps = args.jumps or N_JUMPS[m]
        reps = args.reps or N_REPS[m]
        if args.dry_run:
            n_jumps, reps = DRY["jumps"], DRY["reps"]
        ctx = SimpleNamespace(cfg=cfg, mode=MODE, theta=0.0, phi=0.0,
                              target=tgt, level_d=rule["descent"],
                              gate=rule["gate"], dtype=dtype, device=device,
                              offload=False, accept_rule="nominal",
                              cd_biases=[-20.0, 20.0])
        ref_ctx = SimpleNamespace(**{**vars(ctx), "cfg": ref_cfg})
        tkey = "%d-%d" % tgt
        for pi, ptag in enumerate(ptags):
            pinfo = parents[tkey][ptag]
            lat = torch.from_numpy(
                np.load(os.path.join(S4_DATA, pinfo["latent"])).astype("float64"))
            if tuple(lat.shape) != (NY, NX):
                raise SystemExit("parent shape %r != %r"
                                 % (tuple(lat.shape), (NY, NX)))
            for rep in range(reps):
                unit_idx = (m - 1) * 100 + pi * 10 + rep
                reader = RefReader(ctx, ref_ctx, ladder)
                for arm in arms:
                    key = "%s|%s|r%d|%s" % (tkey, ptag, rep, arm)
                    if key in store["units"]:
                        print("  [skip] %s" % key, flush=True)
                        continue
                    tag = "s5_1_%s_%s_%s_r%d" % (arm, tkey.replace("-", "_"),
                                                 ptag, rep)
                    t0 = time.perf_counter()
                    row = run_arm(arm, gates[arm], lat, ctx, reader, unit_idx,
                                  n_jumps, steps, cap, tag)
                    row.update({
                        "target": list(tgt), "parent_tag": ptag, "rep": rep,
                        "unit_idx": unit_idx, "pixel_nm": PIXEL_NM,
                        "descent_level": list(rule["descent"]),
                        "ladder": [list(l) for l in ladder],
                        "parent_unit": pinfo["unit"],
                        "parent_file": pinfo["latent"],
                        "parent_eta_ref_s4_2": pinfo["eta_ref"],
                        "noise_seeds": [NOISE_BASE + 100 * unit_idx + k
                                        for k in range(n_jumps)],
                        "unit_wall_s": time.perf_counter() - t0,
                        "ref_reads": reader.n, "ref_wall_s": reader.wall,
                    })
                    store["units"][key] = row
                    store["meta"]["updated_utc"] = time.strftime(
                        "%Y-%m-%dT%H:%M:%SZ", time.gmtime())
                    save_json(out, store)
                    n_done += 1
                    el = time.perf_counter() - t_start
                    print("  %-22s %-5s gate %-8s acc %2d/%-2d | gate %.4f -> "
                          "top %.4f (parent %.4f, %+.4f) | optimism %+.4f | "
                          "false %d/%d | %s  [%s]"
                          % (key.rsplit("|", 1)[0], arm, str(tuple(gates[arm])),
                             row["n_accept"], n_jumps, row["final_eta_gate"],
                             row["final_eta_top"], row["parent_eta_top"],
                             row["gain_top_over_parent"], row["gate_optimism"],
                             row["n_false_accepts"], row["n_traced_accepts"],
                             fmt_s(row["unit_wall_s"]), fmt_s(el)), flush=True)

    store["meta"]["total_wall_s"] = time.perf_counter() - t_start
    store["divergence"] = divergence(store, arms)
    save_json(out, store)
    print("=" * 74)
    print("wrote %s (%d units, %s)"
          % (out, len(store["units"]), fmt_s(store["meta"]["total_wall_s"])))
    return 0


def divergence(store, arms) -> Dict:
    """First jump at which the chain arms' accept decisions differ."""
    chain_arms = [a for a in arms if a != "SHOT"]
    bases = sorted({k.rsplit("|", 1)[0] for k in store["units"]})
    out = {}
    for base in bases:
        rows = {a: store["units"].get(base + "|" + a) for a in chain_arms}
        if any(r is None for r in rows.values()) or len(chain_arms) < 2:
            continue
        dec = {a: [j.get("accepted") for j in rows[a]["jumps"]]
               for a in chain_arms}
        n = min(len(v) for v in dec.values())
        first, ndiff = None, 0
        for k in range(n):
            if len({dec[a][k] for a in chain_arms}) > 1:
                ndiff += 1
                if first is None:
                    first = k
        out[base] = {"first_divergence_jump": first,
                     "n_jumps_with_differing_decision": ndiff,
                     "n_accept": {a: rows[a]["n_accept"] for a in chain_arms},
                     "final_eta_top": {a: rows[a]["final_eta_top"]
                                       for a in chain_arms},
                     "gate_optimism": {a: rows[a]["gate_optimism"]
                                       for a in chain_arms}}
    return out


if __name__ == "__main__":
    raise SystemExit(main())
