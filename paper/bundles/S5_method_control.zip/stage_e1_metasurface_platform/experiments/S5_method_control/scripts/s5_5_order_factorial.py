"""S5-5  The 2x2 the m-scaling rule never had: descent order x gate order at m=3.

``order_rule`` changes THREE things at once when the target order goes from 2 to
3 -- descent (12,3)->(20,5), gate (24,6)->(32,8), and the ladder.  So S5-1's
"the chain's advantage is largest at m=3" is confounded: it cannot separate
"m=3 is a harder target" from "the rule handed m=3 higher orders".

Contribution (iii) of the paper -- both the descent order and the certification
order must scale with the target order (D-013) -- currently rests on two n=1
observations that changed device, precision, seed stream and jump count at the
same time (E19 vs E21).  This is the 2x2 that separates the two factors:

                      gate (24,6)          gate (32,8) = rule
    descent (12,3)      D12G24               D12G32
    descent (20,5)=rule D20G24               D20G32  <- = S5-1's GATE1

D20G32 already exists, so only three cells are new.  Everything else is held
fixed and PAIRED WITH S5-1: same parents, same unit indices, therefore the same
per-jump noise seeds, same 16 jumps, same 30-step re-descent at beta=64, same
certification ladder (40,10)/(48,12), same trace level (40,10).

Descriptive: numbers, not verdicts.

    python s5_5_order_factorial.py --dry-run
    python s5_5_order_factorial.py
    python s5_5_order_factorial.py --resume
"""
import argparse
import json
import os
import sys
import time
from types import SimpleNamespace

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import s5_1_gate_tier as S1                                        # noqa: E402
from workbench.protocol import DEFAULT, n_terms                    # noqa: E402
from workbench.app import order_rule                               # noqa: E402
import trustworthy_fmm.solvers.vector_2d as _v2d                   # noqa: E402
import trustworthy_fmm.fourier.convolution as _conv                # noqa: E402

DATA = S1.DATA
TARGET = (3, 0)
# (name, descent, gate).  D20G32 is S5-1's GATE1 and is NOT re-run.
CELLS = [
    ("D12G24", (12, 3), (24, 6)),
    ("D12G32", (12, 3), (32, 8)),
    ("D20G24", (20, 5), (24, 6)),
]
EXISTING_CELL = ("D20G32", (20, 5), (32, 8), "GATE1")
N_JUMPS = 16
REPS = 2
PARENT_TAGS = ("median", "top")


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--jumps", type=int, default=N_JUMPS)
    ap.add_argument("--reps", type=int, default=REPS)
    ap.add_argument("--cap", type=int, default=S1.REF_TRACE_CAP)
    ap.add_argument("--cells", type=str,
                    default=",".join(c[0] for c in CELLS))
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--out", type=str, default=None)
    args = ap.parse_args()

    torch.set_num_threads(int(os.environ.get("FMM_THREADS", "3")))
    _conv.VECTORIZED_CONV = True
    _v2d.FAST_DIAGNOSTICS = True
    _v2d.MEMORY_EFFICIENT = True
    device = "cuda" if torch.cuda.is_available() else "cpu"

    cfg = DEFAULT.variant(ny=S1.NY, nx=S1.NX)
    ref_cfg = DEFAULT.variant(ny=S1.REF_NY, nx=S1.REF_NX)
    rule = order_rule(TARGET, cfg)
    ladder = list(rule["ladder"])
    cells = [c for c in CELLS if c[0] in
             {t.strip() for t in args.cells.split(",")}]
    n_jumps, steps, cap, reps = args.jumps, S1.REDESCENT_STEPS, args.cap, args.reps
    if args.dry_run:
        n_jumps, steps, cap, reps = (S1.DRY["jumps"], S1.DRY["steps"],
                                     S1.DRY["cap"], 1)

    # every new cell gets its accept trace, unlike S5-1 where only two arms did
    S1.TRACE_ARMS = tuple(c[0] for c in cells)

    out = args.out or os.path.join(
        DATA, "s5_5_order_factorial%s.json" % ("_dry" if args.dry_run else ""))
    store = {"meta": {}, "units": {}}
    if args.resume and os.path.exists(out):
        store = json.load(open(out, encoding="utf-8"))
        print("resuming: %d units done" % len(store["units"]), flush=True)
    store["meta"].update({
        "script": os.path.basename(__file__),
        "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "gpu": torch.cuda.get_device_name(0) if device == "cuda" else "cpu",
        "code_path": "fmm_workbench, via s5_1_gate_tier.run_arm",
        "target": list(TARGET), "pixel_nm": S1.PIXEL_NM,
        "grid": [S1.NY, S1.NX], "ladder": [list(l) for l in ladder],
        "n_jumps": n_jumps, "redescent_steps": steps, "ref_trace_cap": cap,
        "reps": reps, "parents": list(PARENT_TAGS),
        "cells_run": [{"name": c[0], "descent": list(c[1]), "gate": list(c[2]),
                       "gate_over_descent": n_terms(c[2]) / n_terms(c[1])}
                      for c in cells],
        "cell_reused_from_s5_1": {"name": EXISTING_CELL[0],
                                  "descent": list(EXISTING_CELL[1]),
                                  "gate": list(EXISTING_CELL[2]),
                                  "source_arm": EXISTING_CELL[3],
                                  "source_file": "s5_1_gate_tier.json"},
        "rule_says": {"descent": list(rule["descent"]),
                      "gate": list(rule["gate"])},
        "reading_notes": [
            "PAIRED WITH S5-1: unit_idx is reproduced exactly as in "
            "s5_1_gate_tier ((m-1)*100 + parent_index*10 + rep), so every cell "
            "sees the SAME per-jump perturbation noise as S5-1's GATE0/1/2 and "
            "SHOT on the same unit.  The fourth cell of the 2x2 is S5-1's "
            "GATE1 rows, not re-run.",
            "Two factors, one table: the row factor is the DESCENT order (what "
            "the gradient is computed at, whose value enters no decision) and "
            "the column factor is the GATE order (what every acceptance is "
            "decided at).  order_rule moves both at once when m goes 2 -> 3; "
            "this separates them at m=3.",
            "The accept trace is at (40,10) for every cell, as in S5-1, so "
            "false-accept counts are comparable across cells and with S5-1.",
            "Costs differ enormously across cells by construction (a (20,5) "
            "re-descent step is ~7.5x a (12,3) one, a (32,8) gate forward "
            "~3.9x a (24,6) one), so the wall clock per cell is itself one of "
            "the reported quantities -- the rule's price.",
        ],
    })

    with open(os.path.join(DATA, "parents.json"), encoding="utf-8") as f:
        parents = json.load(f)
    tkey = "%d-%d" % TARGET

    print("=" * 78)
    print("s5_5_order_factorial | %s | c64/GPU | target %r, %d nm grid %r"
          % (store["meta"]["gpu"], TARGET, S1.PIXEL_NM, (S1.NY, S1.NX)))
    print("  rule says descent %s gate %s ; ladder %s"
          % (rule["descent"], rule["gate"], ladder))
    for name, d, g in cells:
        print("  cell %-7s descent %-8s gate %-8s  gate/descent %.2f"
              % (name, str(d), str(g), n_terms(g) / n_terms(d)))
    print("  cell %-7s descent %-8s gate %-8s  <- reused from S5-1 (%s)"
          % (EXISTING_CELL[0], str(EXISTING_CELL[1]), str(EXISTING_CELL[2]),
             EXISTING_CELL[3]))
    print("  %d units (%d parents x %d reps) x %d jumps x %d steps"
          % (len(PARENT_TAGS) * reps, len(PARENT_TAGS), reps, n_jumps, steps))
    print("=" * 78, flush=True)

    t_start = time.perf_counter()
    done = 0
    total = len(PARENT_TAGS) * reps * len(cells)
    for pi, ptag in enumerate(PARENT_TAGS):
        pinfo = parents[tkey][ptag]
        lat = torch.from_numpy(np.load(
            os.path.join(S1.S4_DATA, pinfo["latent"])).astype("float64"))
        for rep in range(reps):
            # identical to s5_1_gate_tier's indexing -> identical noise seeds
            unit_idx = (TARGET[0] - 1) * 100 + pi * 10 + rep
            ctx = SimpleNamespace(cfg=cfg, mode=S1.MODE, theta=0.0, phi=0.0,
                                  target=TARGET, level_d=rule["descent"],
                                  gate=rule["gate"], dtype=torch.complex64,
                                  device=device, offload=False,
                                  accept_rule="nominal",
                                  cd_biases=[-20.0, 20.0])
            ref_ctx = SimpleNamespace(**{**vars(ctx), "cfg": ref_cfg})
            reader = S1.RefReader(ctx, ref_ctx, ladder)
            for name, desc, gate in cells:
                key = "%s|%s|r%d|%s" % (tkey, ptag, rep, name)
                if key in store["units"]:
                    print("  [skip] %s" % key, flush=True)
                    done += 1
                    continue
                ctx.level_d = tuple(desc)          # the row factor
                tag = "s5_5_%s_%s_%s_r%d" % (name, tkey.replace("-", "_"),
                                             ptag, rep)
                t0 = time.perf_counter()
                row = S1.run_arm(name, gate, lat, ctx, reader, unit_idx,
                                 n_jumps, steps, cap, tag)
                row.update({
                    "target": list(TARGET), "parent_tag": ptag, "rep": rep,
                    "unit_idx": unit_idx, "pixel_nm": S1.PIXEL_NM,
                    "cell": name, "descent_level": list(desc),
                    "ladder": [list(l) for l in ladder],
                    "parent_unit": pinfo["unit"],
                    "parent_file": pinfo["latent"],
                    "parent_eta_ref_s4_2": pinfo["eta_ref"],
                    "noise_seeds": [S1.NOISE_BASE + 100 * unit_idx + k
                                    for k in range(n_jumps)],
                    "unit_wall_s": time.perf_counter() - t0,
                    "ref_reads_cumulative": reader.n,
                    "ref_wall_s_cumulative": reader.wall,
                })
                store["units"][key] = row
                store["meta"]["updated_utc"] = time.strftime(
                    "%Y-%m-%dT%H:%M:%SZ", time.gmtime())
                S1.save_json(out, store)
                done += 1
                el = time.perf_counter() - t_start
                print("  %-14s %-7s d%-7s g%-7s acc %2d/%-2d | gate %.4f -> "
                      "top %.4f (parent %.4f, %+.4f) | optimism %+.4f | "
                      "false %d/%d | %s  [%s, ~%s left]"
                      % ("%s|r%d" % (ptag, rep), name, str(tuple(desc)),
                         str(tuple(gate)), row["n_accept"], n_jumps,
                         row["final_eta_gate"], row["final_eta_top"],
                         row["parent_eta_top"], row["gain_top_over_parent"],
                         row["gate_optimism"], row["n_false_accepts"],
                         row["n_traced_accepts"],
                         S1.fmt_s(row["unit_wall_s"]), S1.fmt_s(el),
                         S1.fmt_s(el / done * (total - done))), flush=True)

    store["meta"]["total_wall_s"] = time.perf_counter() - t_start
    S1.save_json(out, store)
    print("=" * 78)
    print("wrote %s (%d units, %s)"
          % (out, len(store["units"]), S1.fmt_s(store["meta"]["total_wall_s"])))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
