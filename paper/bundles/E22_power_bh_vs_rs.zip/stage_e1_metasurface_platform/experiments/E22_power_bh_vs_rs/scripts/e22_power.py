"""Distribution-level power: BH chain vs equal-budget restart widening,
n=24 replicates per arm, targets (2,0) and (1,0).

Replicate r of arm BH  = 24-jump monotone chain from the frozen parent
                         (noise stream 7000+100r+k), E19 protocol, accept at
                         (24,6)@1x (order-stable for these targets, E20).
Replicate r of arm RS  = best-of-4 fresh restarts (seeds 4000+10r+j) through
                         the frozen 219-step torcwa_M12 protocol.
Budget ledger (clean single-process GPU/c64 unit prices):
    24 jumps    = 24*(30 vg(12,3) + 1 fwd(24,6)) ~ 112.8 s
    4 restarts  =  4*(219 vg + 37 fwd (12,3) + 1 fwd(24,6)) ~ 113.5 s  (+0.7%)
Primary metric: blind (28,7)@1x of each replicate's delivered design.
Test: two-sided Mann-Whitney U, alpha = 0.05.  Secondary: best-of-24.

    python e22_power.py               # writes ../data/power.json
"""
import json
import os
import sys
import time

import numpy as np
import torch

THREADS = int(os.environ.get("P0_THREADS", "3"))
torch.set_num_threads(THREADS)
_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.abspath(os.path.join(
    _HERE, "..", "..", "E16_inherited_baseline", "scripts")))
import e10_common as C  # noqa: E402
import trustworthy_fmm.fourier.convolution as _conv  # noqa: E402
import trustworthy_fmm.solvers.vector_2d as _v2d  # noqa: E402

_conv.VECTORIZED_CONV = True
_v2d.FAST_DIAGNOSTICS = True

E16_DESIGNS = os.path.abspath(os.path.join(
    _HERE, "..", "..", "E16_inherited_baseline", "data", "main", "designs"))
DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
GPU = C.DEFAULT.variant(dtype=torch.complex64, device="cuda")

TARGETS = [
    ((2, 0), "2_0_2030_torcwa_M12_latent.npy"),
    ((1, 0), "1_0_2031_certified_screened_latent.npy"),
]
N_REP = 24
N_JUMPS = 24
N_RESTARTS = 4
STEPS = 30
BETA = 64.0
ALPHAS = [0.1, 0.25, 0.5]
BUDGET = 120.0


def filtered_noise(seed):
    g = torch.Generator().manual_seed(int(seed))
    noise = torch.randn((C.NY, C.NX), generator=g, dtype=torch.float64)
    smooth = C.periodic_gaussian_filter(noise, C.LATTICE, C.FILTER_NM)
    return smooth / smooth.std()


def redescend(rho0, target):
    rho = rho0.to("cuda")
    adam = C.Adam(rho.shape, GPU)
    for t in range(STEPS):
        lr = C.cosine_lr(t / STEPS, GPU)
        _, g = C.value_grad_latent(rho, (12, 3), target, BETA, GPU)
        rho = adam.step(rho, g, lr)
    return rho.cpu()


def eta_gpu(binary, level, target):
    return C.forward_density(binary.to("cuda"), level, target, GPU)


def chain_replicate(target, parent_lat, r):
    incumbent = parent_lat.clone()
    inc_bin = C.hard_binary(incumbent, C.DEFAULT)
    inc_eta = eta_gpu(inc_bin, (24, 6), target)
    for k in range(N_JUMPS):
        alpha = ALPHAS[k % len(ALPHAS)]
        noise = filtered_noise(7000 + 100 * r + k)
        pert = C.symmetrize(
            (incumbent + alpha * C.DEFAULT.init_scale * noise).clamp(0, 1))
        rho = redescend(pert, target)
        b = C.hard_binary(rho, C.DEFAULT)
        eta = eta_gpu(b, (24, 6), target)
        if eta > inc_eta:
            incumbent, inc_bin, inc_eta = rho, b, eta
    return inc_bin, inc_eta


def restart_once(target, seed):
    lv = (12, 3)
    rho = C.initial_latent(seed, GPU)
    adam = C.Adam(rho.shape, GPU)
    units, step = 0.0, 0
    best_bin = C.hard_binary(rho, GPU)
    best_self = -float("inf")
    while True:
        if units + C.cost_fwd(lv, GPU) + C.cost_bwd(lv, GPU) > BUDGET:
            break
        progress = units / BUDGET
        beta = C.beta_at(progress, cfg=GPU)
        lr = C.cosine_lr(progress, GPU)
        _, g = C.value_grad_latent(rho, lv, target, beta, GPU)
        units += C.cost_fwd(lv, GPU) + C.cost_bwd(lv, GPU)
        if step % 6 == 0 and units + C.cost_fwd(lv, GPU) <= BUDGET:
            b = C.hard_binary(rho, GPU)
            s = C.forward_density(b, lv, target, GPU)
            units += C.cost_fwd(lv, GPU)
            if s > best_self:
                best_self, best_bin = s, b
        rho = adam.step(rho, g, lr)
        step += 1
    b = C.hard_binary(rho, GPU)
    s = C.forward_density(b, lv, target, GPU)
    if s > best_self:
        best_self, best_bin = s, b
    return best_bin.cpu()


def rs_replicate(target, r):
    best_bin, best_eta = None, -float("inf")
    for j in range(N_RESTARTS):
        b = restart_once(target, 4000 + 10 * r + j)
        eta = eta_gpu(b, (24, 6), target)
        if eta > best_eta:
            best_bin, best_eta = b, eta
    return best_bin, best_eta


def mann_whitney(x, y):
    """Two-sided Mann-Whitney U via normal approximation with tie correction
    (scipy fallback if available)."""
    try:
        from scipy.stats import mannwhitneyu
        res = mannwhitneyu(x, y, alternative="two-sided")
        return float(res.statistic), float(res.pvalue), "scipy"
    except Exception:
        import math
        n1, n2 = len(x), len(y)
        allv = [(v, 0) for v in x] + [(v, 1) for v in y]
        allv.sort()
        ranks, i = {}, 0
        rank_sum_x = 0.0
        vals = [v for v, _ in allv]
        r = 1
        i = 0
        rk = [0.0] * len(allv)
        while i < len(allv):
            j = i
            while j + 1 < len(allv) and vals[j + 1] == vals[i]:
                j += 1
            avg = (i + j) / 2.0 + 1
            for t in range(i, j + 1):
                rk[t] = avg
            i = j + 1
        for t, (v, grp) in enumerate(allv):
            if grp == 0:
                rank_sum_x += rk[t]
        u1 = rank_sum_x - n1 * (n1 + 1) / 2.0
        mu = n1 * n2 / 2.0
        # tie correction
        from collections import Counter
        ties = Counter(vals)
        tc = sum(c ** 3 - c for c in ties.values())
        n = n1 + n2
        sigma = math.sqrt(n1 * n2 / 12.0 * ((n + 1) - tc / (n * (n - 1))))
        z = (u1 - mu) / max(sigma, 1e-12)
        p = math.erfc(abs(z) / math.sqrt(2))
        return u1, p, "normal_approx"


def main():
    out = {"targets": {}}
    for tgt, parent_name in TARGETS:
        t0 = time.perf_counter()
        parent = torch.from_numpy(
            np.load(os.path.join(E16_DESIGNS, parent_name))
            .astype("float64"))
        bh_rows, rs_rows = [], []
        for r in range(N_REP):
            b_bin, b_eta24 = chain_replicate(tgt, parent, r)
            b28 = eta_gpu(b_bin, (28, 7), tgt)
            bh_rows.append({"rep": r, "eta24": b_eta24, "eta28": b28})
            s_bin, s_eta24 = rs_replicate(tgt, r)
            s28 = eta_gpu(s_bin, (28, 7), tgt)
            rs_rows.append({"rep": r, "eta24": s_eta24, "eta28": s28})
            print("%s rep %2d: BH eta28 %.4f | RS eta28 %.4f  [%.0f s]"
                  % (tgt, r, b28, s28, time.perf_counter() - t0),
                  flush=True)
        bh = [r["eta28"] for r in bh_rows]
        rs = [r["eta28"] for r in rs_rows]
        u, p, method = mann_whitney(bh, rs)
        med = lambda v: sorted(v)[len(v) // 2]
        out["targets"][str(tgt)] = {
            "parent": parent_name, "n_per_arm": N_REP,
            "bh": bh_rows, "rs": rs_rows,
            "bh_median": med(bh), "rs_median": med(rs),
            "bh_mean": sum(bh) / len(bh), "rs_mean": sum(rs) / len(rs),
            "bh_best": max(bh), "rs_best": max(rs),
            "bh_q10_q90": [sorted(bh)[2], sorted(bh)[-3]],
            "rs_q10_q90": [sorted(rs)[2], sorted(rs)[-3]],
            "mann_whitney_u": u, "p_two_sided": p, "test_impl": method,
            "wall_s": time.perf_counter() - t0,
        }
        print("%s: BH median %.4f mean %.4f best %.4f | RS median %.4f "
              "mean %.4f best %.4f | U=%.1f p=%.4g (%s)"
              % (tgt, med(bh), sum(bh) / len(bh), max(bh), med(rs),
                 sum(rs) / len(rs), max(rs), u, p, method), flush=True)
    with open(os.path.join(DATA, "power.json"), "w") as f:
        json.dump(out, f, indent=1)
    print("wrote power.json")


if __name__ == "__main__":
    main()
