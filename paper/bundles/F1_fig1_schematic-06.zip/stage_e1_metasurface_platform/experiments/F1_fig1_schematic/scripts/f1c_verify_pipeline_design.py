"""
F1c verification on the REAL Fig. 1(b) design state (fmm_pipeline.py, user's original), 2026-09-26.

 (A) binary pattern: sigma(K) ~ K^(-1/2), shell energy ~ h^(-2)            (fit K, h in [6, 30])
 (B) switch-on: beta_1/2 (sigma_M reaches half its binary value) vs 2 pi^2 M / (g Lambda),
     g = median |grad rho~| on the contour rho~ = tau
 (C) the order-M Laurent (fft_baseline) model sees exactly P_M eps (window |h| <= 2M):
     solve with eps, P_2M eps, P_(2M-1) eps and P_M eps (the window used by the pipeline's stage 8)
 (D) the sensitivity dJ_M/d eps is band-limited to the same window (autograd, complex128)
Writes ../data/f1c_pipeline_design.json.  Solver checks use the workbench solver on CPU (complex128).
"""
import os, sys, json
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
PIPE = os.path.join(ROOT, "fmm_pipeline.py")
MARK = "# ----------------------------- plotting"
src = open(PIPE, encoding="utf-8").read()
assert MARK in src, "plotting marker not found in fmm_pipeline.py"
g_ = {"__name__": "fmm_pipeline_design"}
exec(compile(src[:src.index(MARK)], PIPE, "exec"), g_)
rho_tilde, P_beta = g_["rho_tilde"], g_["tanh_projection"]
ETA, EPS_LOW, EPS_HIGH = g_["ETA"], g_["EPS_LOW"], g_["EPS_HIGH"]
D_EPS = EPS_HIGH - EPS_LOW
N = rho_tilde.shape[0]; c = N // 2
assert rho_tilde.shape == (N, N)
hy, hx = np.meshgrid(np.arange(N) - c, np.arange(N) - c, indexing="ij")
SHELL = np.maximum(abs(hx), abs(hy))


def eps_beta(beta):
    rb = (rho_tilde >= ETA).astype(float) if np.isinf(beta) else P_beta(rho_tilde, beta, ETA)
    return EPS_LOW + rb * D_EPS


def spectrum(e):
    return np.fft.fftshift(np.fft.fft2(e)) / e.size


def sigma_curve(S):
    E = np.bincount(SHELL.ravel(), weights=(np.abs(S) ** 2).ravel())
    beyond = np.cumsum(E[::-1])[::-1]
    return np.sqrt(np.append(beyond[1:], 0.0)) / D_EPS, E


def bandlimit(e, K):
    S = spectrum(e)
    return np.real(np.fft.ifft2(np.fft.ifftshift(np.where(SHELL <= K, S, 0))) * S.size)


out = {"N": N, "pipeline_sha1_note": "fmm_pipeline.py = user's original (sha1 1f9ea153...)",
       "rho_tilde_range": [float(rho_tilde.min()), float(rho_tilde.max())]}

# (A)
sb, Eb = sigma_curve(spectrum(eps_beta(np.inf)))
K = np.arange(6, 31)
out["A_slope_sigma_vs_K"] = float(np.polyfit(np.log(K), np.log(sb[K]), 1)[0])
out["A_slope_shell_energy"] = float(np.polyfit(np.log(K), np.log(Eb[K]), 1)[0])
out["A_sigma_inf_at_2M"] = {M: float(sb[2 * M]) for M in (3, 7, 15)}
print(f"(A) sigma_inf ~ K^{out['A_slope_sigma_vs_K']:.3f}, shell energy ~ h^{out['A_slope_shell_energy']:.3f};"
      f"  sigma_inf(2M) M=3/7/15: " + " ".join(f"{v:.4f}" for v in out["A_sigma_inf_at_2M"].values()))

# (B)
gy, gx = np.gradient(rho_tilde)
g = np.hypot(gx, gy)
gL = float(np.median(g[np.abs(rho_tilde - ETA) < 0.01]) * N)
betas = np.geomspace(0.5, 1e5, 600)
sig = np.array([sigma_curve(spectrum(eps_beta(b)))[0] for b in betas])
out["B_g_lambda"] = gL
rows = {}
for M in (3, 5, 7, 10, 15):
    half = float(np.interp(0.5 * sb[2 * M], sig[:, 2 * M], betas))
    pred = 2 * np.pi ** 2 * M / gL
    rows[M] = {"beta_half": half, "beta_x_pred": pred, "ratio": half / pred}
    print(f"(B) M={M:2d}: beta_1/2 {half:8.2f}   2pi^2 M/(g Lambda) {pred:8.2f}   ratio {half / pred:.2f}")
Ms = np.array(sorted(rows))
out["B_rows"] = {str(k): v for k, v in rows.items()}
out["B_slope_beta_half_vs_M"] = float(np.polyfit(np.log(Ms), np.log([rows[m]["beta_half"] for m in Ms]), 1)[0])
print(f"(B) beta_1/2 ~ M^{out['B_slope_beta_half_vs_M']:.3f};  median |grad rho~| Lambda on contour = {gL:.2f}")
tab = {}
for b in (1, 8, 32, 128, 512, np.inf):
    s = sigma_curve(spectrum(eps_beta(b)))[0]
    tab["inf" if np.isinf(b) else str(b)] = {M: float(s[2 * M]) for M in (3, 7, 15)}
out["sigma_table"] = tab
print("sigma_M(beta), M = 3 / 7 / 15:")
for k, v in tab.items():
    print(f"   beta {k:>4}: " + " ".join(f"{x:.4f}" for x in v.values()))

# (C) and (D): workbench solver
try:
    sys.path.insert(0, os.path.normpath(os.path.join(ROOT, "..", "..", "fmm_workbench")))
    import torch
    from trustworthy_fmm.solvers import vector_2d as V
    LAMBDA_NM, WL_NM, H_NM = 1000.0, 800.0, 557.0      # any values; the identity is structural

    def solve(e, M):
        r = V.solve_vector_2d(torch.as_tensor(e, dtype=torch.float64), H_NM, WL_NM, (LAMBDA_NM, LAMBDA_NM),
                              1.46, 1.0, (M, M), factorization="fft_baseline")
        return r.power_t.detach().numpy().real

    eb = eps_beta(np.inf)
    rowsC = []
    for M in (3, 7):
        p0 = solve(eb, M)
        d = {f"K={name}": float(np.max(np.abs(p0 - solve(bandlimit(eb, Kk), M))))
             for name, Kk in (("2M", 2 * M), ("2M-1", 2 * M - 1), ("M", M))}
        rowsC.append({"M": M, "T_total": float(p0.sum()), **d})
        print(f"(C) M={M}: max|P_t(eps) - P_t(P_K eps)|  " + "  ".join(f"{k} {v:.2e}" for k, v in d.items()))
    out["C"] = rowsC

    # (D) gradient of the (1,0) transmitted power w.r.t. eps(x, y), order M = 3, at beta = 32
    M = 3
    e = torch.as_tensor(eps_beta(32.0), dtype=torch.float64).requires_grad_(True)
    r = V.solve_vector_2d(e, H_NM, WL_NM, (LAMBDA_NM, LAMBDA_NM), 1.46, 1.0, (M, M), factorization="fft_baseline")
    r.power_t[r.order_index((1, 0))].real.backward()
    G = np.fft.fftshift(np.fft.fft2(e.grad.numpy()))
    frac = float(np.sum(np.abs(G[SHELL > 2 * M]) ** 2) / np.sum(np.abs(G) ** 2))
    out["D_grad_energy_fraction_outside_window"] = frac
    print(f"(D) M={M}, beta=32: fraction of |d eta_(1,0)/d eps|^2 outside |h| <= 2M = {frac:.2e}")
except Exception as err:  # noqa: BLE001
    print("(C)/(D) skipped:", err)

os.makedirs(os.path.join(ROOT, "data"), exist_ok=True)
with open(os.path.join(ROOT, "data", "f1c_pipeline_design.json"), "w", encoding="utf-8") as f:
    json.dump(out, f, indent=1)
