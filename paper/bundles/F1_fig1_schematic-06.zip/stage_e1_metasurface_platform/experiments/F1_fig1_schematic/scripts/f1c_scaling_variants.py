"""
F1c scaling check, part 2 (2026-09-26): robustness of (A) and (B) over design states, and the
normal-vector factorization contrast for (C).  Writes ../data/f1c_scaling_variants.json.
  (A) binary tail slope fitted over K in [6, 30] (well below Nyquist N/2).
  (B) beta_1/2 (tail reaches half of its binary value) vs 2 pi^2 M / (g Lambda), g = median |grad rho~| on the contour.
"""
import os, sys, json
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)

def periodic_gaussian(a, r_px):
    n = a.shape[0]
    d = np.minimum(np.arange(n), n - np.arange(n)).astype(float)
    k = np.exp(-(d[:, None] ** 2 + d[None, :] ** 2) / r_px ** 2); k /= k.sum()
    return np.real(np.fft.ifft2(np.fft.fft2(a) * np.fft.fft2(k)))

def P(u, beta, eta=0.5):
    return (np.tanh(beta * eta) + np.tanh(beta * (u - eta))) / (np.tanh(beta * eta) + np.tanh(beta * (1 - eta)))

def state(N, seed, corr_frac, amp, r_frac):
    rng = np.random.default_rng(seed)
    xi = periodic_gaussian(rng.standard_normal((N, N)), N * corr_frac); xi /= xi.std()
    return periodic_gaussian(np.clip(0.5 + amp * xi, 0, 1), N * r_frac)

def analyse(rt):
    N = rt.shape[0]; c = N // 2
    hy, hx = np.meshgrid(np.arange(N) - c, np.arange(N) - c, indexing="ij")
    SH = np.maximum(abs(hx), abs(hy))
    def spec(e): return np.fft.fftshift(np.fft.fft2(e)) / e.size
    def tails(S):
        E = np.bincount(SH.ravel(), weights=(abs(S) ** 2).ravel())
        beyond = np.cumsum(E[::-1])[::-1]
        return np.sqrt(np.append(beyond[1:], 0.0)), E
    Sb = spec((rt >= 0.5).astype(float))
    tb, Eb = tails(Sb)
    K = np.arange(6, 31)
    slope_tail = np.polyfit(np.log(K), np.log(tb[K]), 1)[0]
    slope_E = np.polyfit(np.log(K), np.log(Eb[K]), 1)[0]
    gy, gx = np.gradient(rt); g = np.hypot(gx, gy)
    gL = float(np.median(g[np.abs(rt - 0.5) < 0.02]) * N)
    betas = np.geomspace(0.5, 8192, 500)
    T = np.array([tails(spec(P(rt, b)))[0] for b in betas])      # [beta, K]
    res = {}
    for M in (3, 5, 7, 10, 15):
        half = float(np.interp(0.5 * tb[2 * M], T[:, 2 * M], betas))
        res[M] = half / (2 * np.pi ** 2 * M / gL)
    Ms = np.array(sorted(res))
    bh = np.array([res[M] * 2 * np.pi ** 2 * M / gL for M in Ms])
    return {"g_lambda": gL, "slope_tail_K6_30": float(slope_tail), "slope_shell_energy_K6_30": float(slope_E),
            "beta_half_over_pred": {int(M): float(res[M]) for M in Ms},
            "beta_half": {int(M): float(b) for M, b in zip(Ms, bh)},
            "slope_beta_half_vs_M": float(np.polyfit(np.log(Ms), np.log(bh), 1)[0])}

variants = {
    "standin (N128, corr N/12, amp .35, R N/40)": (128, 20260926, 1 / 12, 0.35, 1 / 40),
    "N256 same shape":                            (256, 20260926, 1 / 12, 0.35, 1 / 40),
    "coarser features corr N/8":                  (256, 11, 1 / 8, 0.35, 1 / 40),
    "finer features corr N/16":                   (256, 12, 1 / 16, 0.35, 1 / 40),
    "low contrast amp .15":                       (256, 13, 1 / 12, 0.15, 1 / 40),
    "wide filter R N/20":                         (256, 14, 1 / 12, 0.35, 1 / 20),
}
out = {}
for name, args in variants.items():
    r = analyse(state(*args))
    out[name] = r
    ratios = " ".join(f"{v:.2f}" for v in r["beta_half_over_pred"].values())
    print(f"{name:44s} gL {r['g_lambda']:6.2f} | tail~K^{r['slope_tail_K6_30']:.2f} E~h^{r['slope_shell_energy_K6_30']:.2f}"
          f" | beta_1/2 ~ M^{r['slope_beta_half_vs_M']:.2f} | beta_1/2 / (2pi^2 M/gL) = {ratios}")

# (C') normal-vector factorization: is the band-limited equivalence still exact?  (expected: no)
try:
    sys.path.insert(0, os.path.normpath(os.path.join(ROOT, "..", "..", "fmm_workbench")))
    import torch
    from trustworthy_fmm.solvers import vector_2d as V
    rt = state(*variants["standin (N128, corr N/12, amp .35, R N/40)"])
    eb = 1.0 + (3.2 ** 2 - 1.0) * (rt >= 0.5)
    N = eb.shape[0]; c = N // 2
    hy, hx = np.meshgrid(np.arange(N) - c, np.arange(N) - c, indexing="ij"); SH = np.maximum(abs(hx), abs(hy))
    def bl(e, K):
        S = np.fft.fftshift(np.fft.fft2(e)) / e.size
        return np.real(np.fft.ifft2(np.fft.ifftshift(np.where(SH <= K, S, 0))) * S.size)
    rows = []
    for fact in ("fft_baseline", "normal"):
        for M in (3, 7):
            f = lambda e: V.solve_vector_2d(torch.as_tensor(e, dtype=torch.float64), 300.0, 1300.0, (1000.0, 1000.0),
                                             1.46, 1.0, (M, M), factorization=fact).power_t.detach().numpy().real
            d = float(np.max(np.abs(f(eb) - f(bl(eb, 2 * M)))))
            rows.append({"factorization": fact, "M": M, "max_abs_diff_window": d})
            print(f"(C') {fact:13s} M={M}: |P_t(eps) - P_t(P_2M eps)| = {d:.2e}")
    out["C_prime"] = rows
except Exception as err:  # noqa: BLE001
    print("(C') skipped:", err)

with open(os.path.join(ROOT, "data", "f1c_scaling_variants.json"), "w", encoding="utf-8") as fh:
    json.dump(out, fh, indent=1)
