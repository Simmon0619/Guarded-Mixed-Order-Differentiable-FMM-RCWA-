"""
F1c scaling check (2026-09-26): two statements proposed for the Fig. 1(c) paragraph.

 (A) binary pattern: RMS of eps outside the window |h|_inf <= K decays as K^(-1/2)
     (piecewise-constant pattern with smooth boundaries: |eps~(h)| ~ |h|^(-3/2), shell energy ~ h^-2).
 (B) tanh edge of width a = 1/(beta g) (g = |grad rho~| on the contour rho~ = tau): its spectrum follows the
     binary one up to h_c = beta g Lambda / pi^2 and decays exponentially beyond, so the tail outside
     K = 2M switches on at beta_x ~ 2 pi^2 M / (g Lambda)  ->  beta_x proportional to M.
Also (C): exactness of "the order-M model sees only P_2M eps" for the FFT_BASELINE (Laurent) formulation:
     solve the same structure with eps and with its band-limited version at order M; efficiencies must agree.

Reads the design state from ../fmm_pipeline.py exactly as panels/c/fig1c_spectrum_beta_order.py does.
Writes ../data/f1c_scaling.json.
"""
import os, sys, json
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
PIPE = os.path.join(ROOT, "fmm_pipeline.py")
_src = open(PIPE, encoding="utf-8").read()
_g = {"__name__": "fmm_pipeline_design"}
exec(compile(_src[:_src.index("# ----------------------------- plotting")], PIPE, "exec"), _g)
rho_tilde, P_beta = _g["rho_tilde"], _g["tanh_projection"]
ETA, EPS_LOW, EPS_HIGH = _g["ETA"], _g["EPS_LOW"], _g["EPS_HIGH"]
D_EPS = EPS_HIGH - EPS_LOW
N = rho_tilde.shape[0]; c = N // 2
hy, hx = np.meshgrid(np.arange(N) - c, np.arange(N) - c, indexing="ij")
SHELL = np.maximum(abs(hx), abs(hy))


def eps_beta(beta):
    rb = (rho_tilde >= ETA).astype(float) if np.isinf(beta) else P_beta(rho_tilde, beta, ETA)
    return EPS_LOW + rb * D_EPS


def spectrum(e):
    return np.fft.fftshift(np.fft.fft2(e)) / e.size


def tail(S, K):
    return float(np.sqrt(np.sum(np.abs(S[SHELL > K]) ** 2)) / D_EPS)


out = {"N": N, "note": "stand-in design state unless fmm_pipeline.py is the user's"}

# (A) binary tail vs K, log-log slope
Sb = spectrum(eps_beta(np.inf))
Ks = np.arange(4, N // 2 - 8)
tb = np.array([tail(Sb, K) for K in Ks])
fit = np.polyfit(np.log(Ks[Ks >= 6]), np.log(tb[Ks >= 6]), 1)
shell_E = np.bincount(SHELL.ravel(), weights=(np.abs(Sb) ** 2).ravel())
hs = np.arange(6, N // 2 - 8)
fitE = np.polyfit(np.log(hs), np.log(shell_E[hs]), 1)
out["A_binary_tail_slope_vs_K"] = float(fit[0])
out["A_binary_shell_energy_slope"] = float(fitE[0])
out["A_tail_at_2M"] = {M: tail(Sb, 2 * M) for M in (3, 7, 15)}
print(f"(A) binary tail ~ K^{fit[0]:.3f} (fit K>=6);  shell energy ~ h^{fitE[0]:.3f}  (expected -0.5 / -2)")

# (B) switch-on beta vs M
gy, gx = np.gradient(rho_tilde)          # per pixel
g_px = np.hypot(gx, gy)
band = np.abs(rho_tilde - ETA) < 0.02
g_lambda = float(np.median(g_px[band]) * N)   # |grad rho~| * Lambda, dimensionless
betas = np.geomspace(0.5, 4096, 400)
res = {}
for M in (3, 5, 7, 10, 15):
    K = 2 * M
    tb_inf = tail(Sb, K)
    tcur = np.array([tail(spectrum(eps_beta(b)), K) for b in betas])
    half = float(np.interp(0.5 * tb_inf, tcur, betas))
    res[M] = {"tail_inf": tb_inf, "beta_half": half,
              "beta_x_pred": 2 * np.pi ** 2 * M / g_lambda}
    print(f"(B) M={M:2d}: tail_inf {tb_inf:.4f}  beta_1/2 {half:7.2f}  pred 2pi^2 M/(g Lambda) {res[M]['beta_x_pred']:7.2f}"
          f"  ratio {half / res[M]['beta_x_pred']:.2f}")
Ms = np.array(sorted(res)); bh = np.array([res[M]["beta_half"] for M in Ms])
slopeB = np.polyfit(np.log(Ms), np.log(bh), 1)[0]
print(f"(B) beta_1/2 ~ M^{slopeB:.3f}  (expected 1);  median |grad rho~| Lambda on contour = {g_lambda:.2f}")
out["B"] = {str(k): v for k, v in res.items()}
out["B_slope_beta_half_vs_M"] = float(slopeB)
out["B_g_lambda_median_contour"] = g_lambda

# (C) exactness of band-limited equivalence in the FFT_BASELINE solver (skipped if the package is missing)
try:
    WB = os.path.normpath(os.path.join(ROOT, "..", "..", "fmm_workbench"))
    sys.path.insert(0, WB)
    import torch
    from trustworthy_fmm.solvers import vector_2d as V
    out["C_solver_module"] = V.__file__

    def bandlimit(e, K):
        S = spectrum(e)
        return np.real(np.fft.ifft2(np.fft.ifftshift(np.where(SHELL <= K, S, 0))) * S.size)

    def solve(e, M, fact):
        r = V.solve_vector_2d(torch.as_tensor(e, dtype=torch.float64), 300.0, 1300.0, (1000.0, 1000.0),
                              1.46, 1.0, (M, M), factorization=fact)
        return r.power_t.detach().numpy().real

    eb = eps_beta(np.inf)
    rows = []
    for fact in ("fft_baseline", "li_inverse"):
        for M in (3, 7):
            try:
                p0 = solve(eb, M, fact)
                p_win = solve(bandlimit(eb, 2 * M), M, fact)        # keep exactly the window C_M uses
                p_less = solve(bandlimit(eb, 2 * M - 1), M, fact)   # one shell less: must differ
                rows.append({"factorization": fact, "M": M,
                             "max_abs_diff_window": float(np.max(np.abs(p0 - p_win))),
                             "max_abs_diff_window_minus_1": float(np.max(np.abs(p0 - p_less))),
                             "T_total": float(p0.sum())})
                print(f"(C) {fact:13s} M={M}: |P_t(eps) - P_t(P_2M eps)| = {rows[-1]['max_abs_diff_window']:.2e};"
                      f"  with K = 2M-1: {rows[-1]['max_abs_diff_window_minus_1']:.2e}")
            except Exception as err:  # noqa: BLE001
                print(f"(C) {fact} M={M} failed: {err}")
    out["C_bandlimit_equivalence"] = rows
except Exception as err:  # noqa: BLE001
    print("(C) skipped:", err)

os.makedirs(os.path.join(ROOT, "data"), exist_ok=True)
with open(os.path.join(ROOT, "data", "f1c_scaling.json"), "w", encoding="utf-8") as f:
    json.dump(out, f, indent=1)
