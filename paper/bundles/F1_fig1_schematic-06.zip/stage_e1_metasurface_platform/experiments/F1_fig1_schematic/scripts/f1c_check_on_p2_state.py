"""
Fig. 1(c) method applied to the REAL P2 frozen design state of Fig. 2(d,e)  (2026-10-01, read-only check).

Fig. 1(c) is drawn on an illustrative 12x12-variable square-cell state (fmm_pipeline.py).  This script applies the
same definitions (sigma_M = rms of eps_beta outside W_M = {|h_x|<=2M_x, |h_y|<=2M_y}, Parseval form, forward-normalised
DFT; beta_x = 2 pi^2 M_x / (|grad rho~| Lambda_x)) to the stored latent of m1_s00_st095 (P2, target (1,0), R = 60 nm,
y-mirror symmetry; S8_order_beta_map) and compares sigma_M(beta) with the truncation error of the smooth objective
E(M,beta) = J_M - J_(60,9) stored in s8_map.json (the data of Fig. 2(d)).  FFT only: no solver, no GPU.

Run from stage_e1_metasurface_platform/ :  PYTHONPATH=src python experiments/F1_fig1_schematic/scripts/f1c_check_on_p2_state.py
"""
import json
import os
import numpy as np
import torch
from trustworthy_fmm.fabrication.process import periodic_gaussian_filter, tanh_projection

ROOT = os.getcwd()
D = os.path.join(ROOT, "experiments", "S8_order_beta_map", "data")
OUT = os.path.join(ROOT, "experiments", "F1_fig1_schematic", "data", "f1c_check_p2_state.json")

lat = np.load(os.path.join(D, "designs", "m1_s00_st095_latent.npy"))          # (Ny, Nx) = (100, 600)
Ny, Nx = lat.shape
LX, LY, R, ETA = 3000.0, 500.0, 60.0, 0.5
EB, EF = 1.0, 3.2 ** 2
DE = EF - EB


def S(a):                                                                      # y -> -y mirror average
    return 0.5 * (a + a[::-1, :])


rt = S(periodic_gaussian_filter(torch.tensor(S(lat)), (LX, LY), R).numpy())   # rho~ = S G S rho


def eps(beta):
    if np.isinf(beta):
        return EB + DE * (rt >= ETA)
    return EB + DE * tanh_projection(torch.tensor(rt), float(beta), ETA).numpy()


hy = np.fft.fftfreq(Ny, 1 / Ny).astype(int)
hx = np.fft.fftfreq(Nx, 1 / Nx).astype(int)
HY, HX = np.meshgrid(hy, hx, indexing="ij")


def sigma(e, M):
    s = np.fft.fft2(e) / e.size
    inside = (np.abs(HX) <= 2 * M[0]) & (np.abs(HY) <= 2 * M[1])
    return float(np.sqrt((np.abs(s[~inside]) ** 2).sum()) / DE)


ORD = {"M_d": (16, 2), "M_g": (28, 4), "M_r": (48, 7)}
betas = np.geomspace(2, 2000, 60)
sig = {k: np.array([sigma(eps(b), M) for b in betas]) for k, M in ORD.items()}
sinf = {k: sigma(eps(np.inf), M) for k, M in ORD.items()}

gy, gx = np.gradient(rt, LY / Ny, LX / Nx)
mask = np.abs(rt - ETA) < 0.01
Gx = float(np.median(np.abs(gx)[mask]) * LX)
Gt = float(np.median(np.hypot(gx, gy)[mask]) * LX)

res = {"state": "m1_s00_st095", "grad_rho_tilde_Lambda_x": {"abs_dx": Gx, "abs_grad": Gt},
       "sigma_inf": sinf, "orders": {}}
for k, M in ORD.items():
    half = float(np.interp(0.5 * sinf[k], sig[k], betas))
    res["orders"][k] = {"M": M, "beta_half": half, "beta_x_dx": 2 * np.pi ** 2 * M[0] / Gx,
                        "beta_x_grad": 2 * np.pi ** 2 * M[0] / Gt}

pts = json.load(open(os.path.join(D, "s8_map.json")))["points"]
rows = []
for key, p in pts.items():
    if key.startswith("m1_s00_st095|b"):
        v = p["value"]
        rows.append((p["beta"], v[p["i_desc"]] - v[p["i_ref"]], v[p["i_gate"]] - v[p["i_ref"]]))
rows.sort()
res["compare"] = [{"beta": b, "E_Md": ed, "E_Mg": eg,
                   "sigma_Md": float(np.interp(b, betas, sig["M_d"])), "sigma_Mg": float(np.interp(b, betas, sig["M_g"]))}
                  for b, ed, eg in rows]

# share of the out-of-window weight that lies outside in x only / y only / both (order M_d)
M = ORD["M_d"]
inx = np.abs(HX) <= 2 * M[0]
iny = np.abs(HY) <= 2 * M[1]
res["share_out_Md"] = {}
for b in (8, 16, 32, 64, 128, 512, np.inf):
    s = np.abs(np.fft.fft2(eps(b)) / rt.size) ** 2
    tot = s[~(inx & iny)].sum()
    res["share_out_Md"]["inf" if np.isinf(b) else str(b)] = {
        "x_only": float(s[(~inx) & iny].sum() / tot), "y_only": float(s[inx & (~iny)].sum() / tot),
        "both": float(s[(~inx) & (~iny)].sum() / tot)}

os.makedirs(os.path.dirname(OUT), exist_ok=True)
json.dump(res, open(OUT, "w"), indent=1)
print(json.dumps({k: res[k] for k in ("grad_rho_tilde_Lambda_x", "sigma_inf", "orders")}, indent=1))
