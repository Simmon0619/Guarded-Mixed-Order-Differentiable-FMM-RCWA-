"""S7  Head-to-head: the published workflow (T) against our pipeline (O), per
target order, "draw 3 and keep the best", on either frozen problem.

  T   README Example-6 workflow as published: 800 steps, Adam lr 0.02 cosine,
      beta 2 -> beta_end (geometric), ONE truncation order (the rule's descent
      order), delivery = final field, the number it reports = the continuous
      objective at its own order.  Gate checkpoints and descent-order binary
      reads are recorded as an instrument only (not part of T's workflow or cost).
  O   219-step MIX4 ticket (every 4th gradient at the gate order from beta ~ 11)
      -> gate checkpoint delivery -> 3 tickets, keep the best by GATE reading
      -> chain from that ticket's latent ("chain"), and, as the repair arm, the
      same chain from the WORST ticket of the group ("repair"): 15 hops, each =
      filtered-noise perturbation (alpha 0.1/0.25/0.5 rotating) + 30-step
      mixed-order re-descent (k = 4 from step 0, Adam reset, cosine lr) at the
      parent's delivery beta (beta*, floored at 64), hard threshold, gate score,
      monotone acceptance.

Both arms are paired on the initial latent (one seed rule per problem).
Tickets are grouped in triples by index (0-2, 3-5, ...); every triple yields
one delivery per arm.  All deliveries are read at the first certification
rung; the best 3 per arm per target at the top rung (upper bounds).  Cost:
T = its own descent wall; O = descent wall (incl. high-order gradients) + 12
gate reads at the calibrated price + chain wall.  Instruments (certification,
extra checkpoint reads, rung-1 reads at accepts, candidate reads) are logged
separately and charged to nobody.

P2 (default): S6's problem; at beta_end = 2000 the O tickets are the existing
MIX4 pool (2d: first 24 per target at m <= 2; 3b: all 12 at m = 3, 4).
P1: S4/S5's problem at the 10 nm grid; seeds = S5-7/8a's block so the first
six T tickets at m = 3 restart 8a's initial latents (replication check).
Descriptive: numbers, not verdicts.

    python s7_headtohead.py --phase all --targets 1,2 --beta-end 2000
    python s7_headtohead.py --problem P1 --phase all --targets 3 --beta-end 2000
    python s7_headtohead.py --phase chain --chain-on worst --targets 1,4 --beta-end 2000
    python s7_headtohead.py --phase analyze --targets 1,2,3,4 --beta-end 2000
"""
import argparse
import importlib
import json
import math
import os
import sys
import time
from typing import Dict, List, Optional

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
_S6 = os.path.abspath(os.path.join(_HERE, "..", "..", "S6_lottery_pricing", "scripts"))
sys.path.insert(0, _S6)
import s6_common as C                                              # noqa: E402
from workbench.app import _sym, filtered_noise, app_hard_binary, order_rule   # noqa: E402
from workbench.protocol import DEFAULT                              # noqa: E402

DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
DESIGNS = os.path.join(DATA, "designs")
S6DATA = C.DATA
S5DATA = os.path.abspath(os.path.join(_HERE, "..", "..", "S5_method_control", "data"))
POOL_FILES = {1: "s6_2d_mixed.json", 2: "s6_2d_mixed.json", 3: "s6_3b_mixed_m34.json", 4: "s6_3b_mixed_m34.json"}


def _orders_p1(m, cfg):
    r = order_rule((m, 0), cfg)
    lad = [tuple(int(x) for x in l) for l in r["ladder"]] or [tuple(r["gate"])]
    return {"descent": tuple(int(x) for x in r["descent"]), "gate": tuple(int(x) for x in r["gate"]), "rung1": lad[0], "top": lad[-1]}


# The two frozen problems.  P2 (default) is S6's; P1 is S4/S5's at the 10 nm
# grid (the rule needs it), seeds = S5-7/8a's block so T pairs with 8a's six.
# gate_fwd = price of one gate forward (CPU eig): P2 from S6-1c; P1 (32,8)
# 5.15 s native (S5-3) x 1.17-1.26 CPU-eig ratio, in-situ 6.4-7.1 s -> 6.5.
# noise_base blocks: P2 180000-220314, P1 230000-260314 (S5 <= 94723, S6 <= 174205).
PROBLEMS = {
    "P2": {"tag": "", "cfg": lambda: C.make_cfg(5), "orders": C.orders_for,
           "seed": lambda m, i: 150000 + 1000 * m + i, "o_pool": POOL_FILES,
           "gate_fwd": {1: 0.75, 2: 0.75, 3: 5.3, 4: 6.9}, "n": {1: 24, 2: 24, 3: 12, 4: 12},
           "t_ckpt": {1: 25, 2: 25, 3: 50, 4: 50}, "noise_base": 180000,
           "physics": "3000x500 nm, 300 nm, 5 nm pixels", "replicate": None},
    "P1": {"tag": "P1_", "cfg": lambda: DEFAULT.variant(ny=70, nx=240), "orders": _orders_p1,
           "seed": lambda m, i: 50000 + 1000 * m + i, "o_pool": None,
           "gate_fwd": {1: 1.4, 2: 1.4, 3: 6.5}, "n": {1: 12, 2: 12, 3: 12},
           "t_ckpt": {1: 25, 2: 25, 3: 25}, "noise_base": 230000,
           "physics": "2400x700 nm, 800 nm, 10 nm pixels",
           "replicate": {"file": os.path.join(S5DATA, "s5_8a_readme_schedule.json"), "rung1_key": "40-10"}},
}

T_STEPS = 800
O_STEPS = 219
GROUP = 3
HOPS = 15
RE_STEPS = 30
RE_K = 4
RE_BETA_MIN = 64.0
ALPHAS = (0.1, 0.25, 0.5)
N_TOP = 3
N_BOOT = 2000
DRY = {"t_steps": 40, "o_steps": 24, "n": 3, "hops": 2, "re_steps": 6}


# ----------------------------------------------------------------- utilities
def save_json(path, obj):
    C.save_json(path, obj)


def save_mask(tag, binary, latent=None):
    os.makedirs(DESIGNS, exist_ok=True)
    b = binary.detach().cpu().numpy().astype(np.uint8)
    pb = os.path.join(DESIGNS, tag + "_binary.npz")
    np.savez_compressed(pb, packed=np.packbits(b, axis=1), shape=np.array(b.shape))
    files = {"binary": os.path.relpath(pb, DATA).replace("\\", "/")}
    if latent is not None:
        pl = os.path.join(DESIGNS, tag + "_latent.npy")
        np.save(pl, latent.detach().cpu().numpy().astype(np.float32))
        files["latent"] = os.path.relpath(pl, DATA).replace("\\", "/")
    return files


def load_mask_from(root, rel):
    z = np.load(os.path.join(root, rel))
    if rel.endswith(".npy"):
        return torch.from_numpy(np.asarray(z).astype("float64"))
    shape = tuple(int(v) for v in z["shape"])
    b = np.unpackbits(z["packed"], axis=1)[:, :shape[1]]
    return torch.from_numpy(b.astype("float64"))


def mix_from_for(steps, beta_end, beta_at=11.0):
    return int(round(steps * math.log(beta_at / 2.0) / math.log(beta_end / 2.0)))


def assert_eig_cpu():
    m = importlib.import_module("trustworthy_fmm.solvers.eigendecomposition")
    assert getattr(m, "EIG_DEVICE", None) == "cpu", "leak fix not active: EIG_DEVICE=%r" % getattr(m, "EIG_DEVICE", None)
    return "cpu"


def out_path(name, beta_end, dry, P):
    return os.path.join(DATA, "s7_%s%s_b%d%s.json" % (P["tag"], name, int(beta_end), "_dry" if dry else ""))


def design_tag(P, arm, beta_end, m, ident, dry):
    return "s7_%s%s_b%d_m%d_%s%s" % (P["tag"], arm, int(beta_end), m, ident, "_dry" if dry else "")


def load_store(path, kind):
    if os.path.exists(path):
        return json.load(open(path, encoding="utf-8"))
    return {"meta": {"kind": kind}, "units": {}, "top_reads": {}, "summary": {}}


def fmt(s):
    return C.fmt_s(s)


def o_ckpts(steps):
    """The S6 pool's checkpoint set: every 12 steps plus sparse-early / dense-late."""
    return sorted(set(range(0, steps + 1, 12)) | set(C.ckpt_schedule(steps)))


def e_best_by(select, deliver, N):
    """Exact expectation of the delivered value of the ticket that ranks highest
    on ``select`` among N drawn without replacement from the pool (order
    statistics by rank).  Ties in ``select`` are broken by index."""
    n = len(select)
    if N < 1 or N > n:
        return None
    order = sorted(range(n), key=lambda i: (select[i], i))        # ascending rank
    tot = 0.0
    for r, i in enumerate(order, start=1):                         # rank r = 1..n
        tot += deliver[i] * math.comb(r - 1, N - 1)
    return tot / math.comb(n, N)


def e_best_interp(select, deliver, N_float):
    lo, hi = int(math.floor(N_float)), int(math.ceil(N_float))
    a, b = e_best_by(select, deliver, lo), e_best_by(select, deliver, hi)
    if a is None or b is None:
        return None
    if hi == lo:
        return a
    return a + (b - a) * (N_float - lo)


def boot_ci(fn, n, seed=0, reps=N_BOOT):
    """Percentile 95% interval of fn(idx) under resampling of n items with replacement."""
    rng = np.random.default_rng(seed)
    vals = []
    for _ in range(reps):
        v = fn(rng.integers(0, n, n))
        if v is not None:
            vals.append(v)
    if not vals:
        return None
    return [float(np.percentile(vals, 2.5)), float(np.percentile(vals, 97.5))]


# ------------------------------------------------------------------ tickets T
def run_tickets_T(targets, beta_end, n_override, dry, device, P):
    path = out_path("T", beta_end, dry, P)
    store = load_store(path, "T")
    cfg = P["cfg"]()
    steps = DRY["t_steps"] if dry else T_STEPS
    beta_fn = C.beta_geometric(2.0, beta_end)
    store["meta"].update({"script": os.path.basename(__file__), "problem": P["physics"], "steps": steps, "beta": "2 -> %g" % beta_end,
                          "schedule": "README: Adam lr 0.02 cosine, single order (rule descent), delivery = final field",
                          "seed_rule": "P2: 150000 + 1000*m + i (= S6-2d/3b MIX4 pool); P1: 50000 + 1000*m + i (= S5-7/8a)",
                          "eig_device": assert_eig_cpu(), "gpu": torch.cuda.get_device_name(0) if device == "cuda" else "cpu",
                          "instrument": "gate + descent-order binary read every t_ckpt steps; rung-1 certification of final and best"})
    save_json(path, store)
    t_start = time.perf_counter()
    for m in targets:
        n = DRY["n"] if dry else (n_override or P["n"][m])
        od = P["orders"](m, cfg)
        ctx = C.make_ctx(cfg, (m, 0), od["descent"], od["gate"], device)
        every = P["t_ckpt"][m]
        ck = sorted(set(range(0, steps + 1, every)) | {0, steps})
        for i in range(n):
            key = "m%d|T|s%02d" % (m, i)
            if key in store["units"]:
                continue
            seed = P["seed"](m, i)
            ev: List[Dict] = []
            t0 = time.perf_counter()
            d = C.GapDescent(ctx, seed, steps, beta_fn, ck, ev, beta_final=beta_end)
            r = d.finish()
            tag = design_tag(P, "T", beta_end, m, "s%02d" % i, dry)
            deliv = {}
            t_cert = 0.0
            for name in ("final", "best"):
                dd = r[name]
                sha = C.sha1_of(dd["binary"])
                if name == "best" and sha == deliv["final"]["sha1"]:
                    e1 = deliv["final"]["eta_rung1"]
                else:
                    tc = time.perf_counter()
                    e1 = C.eta(dd["binary"], od["rung1"], ctx)
                    t_cert += time.perf_counter() - tc
                deliv[name] = {"step": dd["step"], "eta_gate": dd["eta_gate"], "eta_rung1": e1,
                               "gate_optimism": dd["eta_gate"] - e1, "sha1": sha,
                               "files": save_mask(tag + "_" + name, dd["binary"], dd["latent"] if name == "final" else None)}
            last = r["checkpoints"][-1]
            ebd = last.get("eta_binary_descent")          # final hard binary at T's own order (instrument, free)
            rep = r["reported_continuous"]
            store["units"][key] = {
                "target": [m, 0], "arm": "T", "index": i, "seed": seed, "steps": steps, "beta_end": beta_end,
                "descent": list(od["descent"]), "gate": list(od["gate"]), "rung1": list(od["rung1"]), "top": list(od["top"]),
                "reported": rep, "eta_binary_descent_final": ebd,
                "relaxation": (rep - ebd) if ebd is not None else None,
                "truncation": (ebd - deliv["final"]["eta_rung1"]) if ebd is not None else None,
                "deliver_final": deliv["final"], "deliver_best": deliv["best"],
                "inflation_reported_minus_rung1": rep - deliv["final"]["eta_rung1"],
                "best_minus_final_rung1": deliv["best"]["eta_rung1"] - deliv["final"]["eta_rung1"],
                "collapse_step": r["collapse_step"], "checkpoints": r["checkpoints"], "n_ckpt": r["n_ckpt"], "ckpt_every": every,
                "trajectory": r["trajectory"],
                "wall_descent_s": r["wall_descent_s"],            # T's own cost
                "instrument_wall_s": r["wall_gate_s"] + t_cert,   # checkpoint reads + certification: charged to nobody
                "unit_wall_s": time.perf_counter() - t0, "grad_events": ev,
            }
            save_json(path, store)
            print("  m=%d T s%02d | reported %.4f (relax %+.4f trunc %+.4f) | final r1 %.4f | best ckpt@%d r1 %.4f | collapse %s | descent %s (instr %s)  [%s]"
                  % (m, i, rep, store["units"][key]["relaxation"] or 0.0, store["units"][key]["truncation"] or 0.0,
                     deliv["final"]["eta_rung1"], deliv["best"]["step"], deliv["best"]["eta_rung1"],
                     r["collapse_step"], fmt(r["wall_descent_s"]), fmt(store["units"][key]["instrument_wall_s"]),
                     fmt(time.perf_counter() - t_start)), flush=True)
    store["meta"]["last_run_wall_s"] = time.perf_counter() - t_start
    save_json(path, store)
    return store


# ------------------------------------------------------------------ tickets O
def run_tickets_O(targets, beta_end, n_override, dry, device, P):
    """P2 at beta_end = 2000 (not dry): reference the S6 pool; otherwise run MIX4 here."""
    path = out_path("O", beta_end, dry, P)
    store = load_store(path, "O")
    cfg = P["cfg"]()
    steps = DRY["o_steps"] if dry else O_STEPS
    reuse = (P["o_pool"] is not None) and (int(beta_end) == 2000) and not dry
    store["meta"].update({"script": os.path.basename(__file__), "problem": P["physics"], "steps": steps, "beta": "2 -> %g" % beta_end,
                          "ticket": "MIX4: every 4th gradient at the gate order from beta ~ 11; delivery = best gate checkpoint",
                          "source": "S6 pool (2d first 24 / 3b all 12)" if reuse else "run here",
                          "checkpoints": "every 12 steps + sparse-early/dense-late (the S6 pool's 30 points); priced as 12 gate reads",
                          "seed_rule": "P2: 150000 + 1000*m + i; P1: 50000 + 1000*m + i", "eig_device": assert_eig_cpu()})
    save_json(path, store)
    t_start = time.perf_counter()
    for m in targets:
        n = DRY["n"] if dry else (n_override or P["n"][m])
        od = P["orders"](m, cfg)
        gate_read = P["gate_fwd"][m]
        if reuse:
            pool = json.load(open(os.path.join(S6DATA, P["o_pool"][m]), encoding="utf-8"))
            for i in range(n):
                key = "m%d|O|s%02d" % (m, i)
                if key in store["units"]:
                    continue
                u = pool["units"]["m%d|MIX4|s%02d" % (m, i)]
                assert u["seed"] == P["seed"](m, i) and u["steps"] == O_STEPS
                store["units"][key] = {
                    "target": [m, 0], "arm": "O", "index": i, "seed": u["seed"], "steps": u["steps"], "beta_end": beta_end,
                    "descent": u["descent"], "gate": u["gate"], "rung1": u["rung1"], "top": u["top"],
                    "source": {"file": P["o_pool"][m], "key": "m%d|MIX4|s%02d" % (m, i), "root": "S6"},
                    "deliver_best": u["deliver_best"], "deliver_final": u["deliver_final"],
                    "reported_continuous": u.get("reported_continuous"),
                    "beta_star": C.beta_geometric(2.0, beta_end)(u["deliver_best"]["step"], u["steps"]),
                    "collapse_step": u["collapse_step"], "n_high_order_steps": u["n_high_order_steps"], "n_ckpt": u.get("n_ckpt"),
                    "wall_descent_s": u["wall_descent_s"], "wall_high_order_s": u["wall_high_order_s"],
                    "gate_read_s": gate_read, "wall_gate12_s": 12 * gate_read,
                    "ticket_cost_s": u["wall_descent_s"] + 12 * gate_read,
                    "ticket_cost_selected_s": u["wall_descent_s"] + (u.get("n_ckpt") or 12) * gate_read,
                    "measured_opt_wall_s": u["opt_wall_s"],
                }
            save_json(path, store)
            print("  m=%d O: referenced %d MIX4 tickets from %s" % (m, n, P["o_pool"][m]), flush=True)
            continue
        ctx = C.make_ctx(cfg, (m, 0), od["descent"], od["gate"], device)
        beta_fn = C.beta_geometric(2.0, beta_end)
        mf = mix_from_for(steps, beta_end)
        ck = o_ckpts(steps)
        for i in range(n):
            key = "m%d|O|s%02d" % (m, i)
            if key in store["units"]:
                continue
            seed = P["seed"](m, i)
            ev: List[Dict] = []
            t0 = time.perf_counter()
            d = C.MixedDescent(ctx, seed, steps, beta_fn, ck, ev, beta_final=beta_end, k=4, mix_from=mf)
            r = d.finish()
            tag = design_tag(P, "O", beta_end, m, "s%02d" % i, dry)
            deliv = {}
            t_cert = 0.0
            for name in ("best", "final"):
                dd = r[name]
                sha = C.sha1_of(dd["binary"])
                if name == "final" and sha == deliv["best"]["sha1"]:
                    e1 = deliv["best"]["eta_rung1"]
                else:
                    tc = time.perf_counter()
                    e1 = C.eta(dd["binary"], od["rung1"], ctx)
                    t_cert += time.perf_counter() - tc
                deliv[name] = {"step": dd["step"], "eta_gate": dd["eta_gate"], "eta_rung1": e1,
                               "gate_optimism": dd["eta_gate"] - e1, "sha1": sha,
                               "files": save_mask(tag + "_" + name, dd["binary"], dd["latent"] if name == "best" else None)}
            store["units"][key] = {
                "target": [m, 0], "arm": "O", "index": i, "seed": seed, "steps": steps, "beta_end": beta_end, "mix_from": mf, "k": 4,
                "descent": list(od["descent"]), "gate": list(od["gate"]), "rung1": list(od["rung1"]), "top": list(od["top"]),
                "source": {"root": "S7"},
                "deliver_best": deliv["best"], "deliver_final": deliv["final"],
                "reported_continuous": r["reported_continuous"],
                "beta_star": beta_fn(deliv["best"]["step"], steps),
                "collapse_step": r["collapse_step"], "checkpoints": r["checkpoints"], "n_ckpt": r["n_ckpt"],
                "n_high_order_steps": r["n_high_order_steps"], "wall_descent_s": r["wall_descent_s"],
                "wall_high_order_s": r["wall_high_order_s"], "gate_read_s": gate_read, "wall_gate12_s": 12 * gate_read,
                "ticket_cost_s": r["wall_descent_s"] + 12 * gate_read,
                "ticket_cost_selected_s": r["wall_descent_s"] + r["n_ckpt"] * gate_read,
                "measured_opt_wall_s": r["wall_descent_s"] + r["wall_gate_s"],
                "instrument_wall_s": t_cert, "unit_wall_s": time.perf_counter() - t0, "grad_events": ev,
            }
            save_json(path, store)
            print("  m=%d O s%02d | best@%d gate %.4f r1 %.4f | final r1 %.4f | beta* %.0f | high %d | cost %s  [%s]"
                  % (m, i, deliv["best"]["step"], deliv["best"]["eta_gate"], deliv["best"]["eta_rung1"], deliv["final"]["eta_rung1"],
                     store["units"][key]["beta_star"], r["n_high_order_steps"], fmt(store["units"][key]["ticket_cost_s"]),
                     fmt(time.perf_counter() - t_start)), flush=True)
    store["meta"]["last_run_wall_s"] = time.perf_counter() - t_start
    save_json(path, store)
    return store


# ----------------------------------------------------------------------- chain
def redescend_mixed(rho0, ctx, steps, beta, k, events):
    """S5-1's redescend_guarded with the gradient order switched to the gate
    order every k-th step from step 0 (k = 0 -> single order).  Same Adam,
    same cosine lr(t/steps), same guard.  Returns the latent, the last finite
    continuous value, and the wall split."""
    rho = rho0.clone()
    adam = C.AppAdam(rho.shape, ctx.cfg, ctx.mode, ctx.device)
    n_high, t_high, t_low = 0, 0.0, 0.0
    v_last = None
    for t in range(steps):
        lr = C.cosine_lr(t / steps, ctx.cfg)
        high = (k > 0) and (t % k == 0)
        level = ctx.gate if high else ctx.level_d
        t0 = time.perf_counter()
        v, g = C.guarded_value_grad(rho, level, beta, ctx, events, t)
        dt = time.perf_counter() - t0
        if high:
            n_high, t_high = n_high + 1, t_high + dt
        else:
            t_low += dt
        if g is not None:
            rho = adam.step(rho, g, lr)
            v_last = float(v)
    return rho, v_last, {"n_high": n_high, "t_high": t_high, "t_low": t_low}


def run_chain(targets, beta_end, dry, device, P, which="best", re_beta="star"):
    """which = 'best': chain the best-by-gate ticket of each triple (the pipeline);
    'worst': chain the worst-by-gate ticket (the repair arm).  re_beta = 'star'
    (the parent's delivery beta, floored at 64) or a fixed value (e.g. 64, the
    shipped protocol).  Same store; keys m|chain|g, m|repair|g, and with a
    fixed beta m|chain_b64|g, m|repair_b64|g."""
    path = out_path("chain", beta_end, dry, P)
    store = load_store(path, "chain")
    o_store = load_store(out_path("O", beta_end, dry, P), "O")
    cfg = P["cfg"]()
    hops = DRY["hops"] if dry else HOPS
    re_steps = DRY["re_steps"] if dry else RE_STEPS
    fixed_beta = None if re_beta == "star" else float(re_beta)
    kind = ("chain" if which == "best" else "repair") + ("" if fixed_beta is None else "_b%g" % fixed_beta)
    store["meta"].update({"script": os.path.basename(__file__), "hops": hops, "re_steps": re_steps, "re_k": RE_K,
                          "alphas": list(ALPHAS), "re_beta": "beta* of the parent (delivery beta), floored at %g" % RE_BETA_MIN,
                          "acceptance": "gate reading, monotone", "group": GROUP,
                          "arms": {"chain": "parent = best of the group by gate", "repair": "parent = worst of the group by gate"},
                          "noise_seed_rule": "%d + 10000*m + 100*group + jump (shared by chain and repair of a group)" % P["noise_base"],
                          "problem": P["physics"], "eig_device": assert_eig_cpu()})
    save_json(path, store)
    t_start = time.perf_counter()
    for m in targets:
        od = P["orders"](m, cfg)
        ctx = C.make_ctx(cfg, (m, 0), od["descent"], od["gate"], device)
        units = sorted([v for v in o_store["units"].values() if v["target"][0] == m], key=lambda v: v["index"])
        n_groups = len(units) // GROUP
        for gi in range(n_groups):
            key = "m%d|%s|g%02d" % (m, kind, gi)
            if key in store["units"]:
                continue
            members = units[gi * GROUP:(gi + 1) * GROUP]
            pick = max if which == "best" else min
            parent = pick(members, key=lambda v: v["deliver_best"]["eta_gate"])
            root = S6DATA if parent.get("source", {}).get("root") == "S6" else DATA
            lat = torch.from_numpy(np.load(os.path.join(root, parent["deliver_best"]["files"]["latent"])).astype(np.float64))
            if device != "cpu":
                lat = lat.to(device)
            inc_lat = lat
            inc_bin = app_hard_binary(inc_lat.detach().cpu(), cfg, ctx.mode)
            assert C.sha1_of(inc_bin) == parent["deliver_best"]["sha1"], "parent latent does not reproduce its binary"
            inc_gate = parent["deliver_best"]["eta_gate"]
            inc_r1 = parent["deliver_best"]["eta_rung1"]
            beta_raw = float(parent["beta_star"])
            beta_star = max(beta_raw, RE_BETA_MIN) if fixed_beta is None else fixed_beta
            ev: List[Dict] = []
            t0 = time.perf_counter()
            t_low = t_high = t_gate = t_instr = 0.0
            jumps = []
            inc_curve = [{"jump": -1, "eta_gate": inc_gate, "eta_rung1": inc_r1}]
            n_accept = 0
            for j in range(hops):
                alpha = ALPHAS[j % len(ALPHAS)]
                nseed = P["noise_base"] + 10000 * m + 100 * gi + j
                noise = filtered_noise(nseed, cfg)
                if device != "cpu":
                    noise = noise.to(device)
                pert = _sym((inc_lat + alpha * cfg.init_scale * noise).clamp(0.0, 1.0), ctx.mode)
                rho, v_last, w = redescend_mixed(pert, ctx, re_steps, beta_star, RE_K, ev)
                t_low += w["t_low"]
                t_high += w["t_high"]
                b = app_hard_binary(rho.detach().cpu(), cfg, ctx.mode)
                n_flip = int((b != inc_bin).sum())
                tg = time.perf_counter()
                sc = C.eta(b, ctx.gate, ctx)
                t_gate += time.perf_counter() - tg
                ti = time.perf_counter()
                sd = C.eta(b, ctx.level_d, ctx)                     # candidate at the descent order (instrument)
                t_instr += time.perf_counter() - ti
                acc = bool(sc > inc_gate)
                row = {"jump": j, "alpha": alpha, "noise_seed": nseed, "cand_gate": sc, "cand_descent": sd,
                       "cand_continuous_last": v_last, "cand_minus_inc_gate": sc - inc_gate, "n_flipped": n_flip,
                       "accepted": acc, "n_high": w["n_high"]}
                if acc:
                    ti = time.perf_counter()
                    r1 = C.eta(b, od["rung1"], ctx)                  # rung-1 read at every accept (instrument)
                    t_instr += time.perf_counter() - ti
                    row.update({"inc_rung1_before": inc_r1, "cand_rung1": r1, "false_accept": bool(r1 < inc_r1)})
                    inc_lat, inc_bin, inc_gate, inc_r1 = rho, b, sc, r1
                    n_accept += 1
                jumps.append(row)
                inc_curve.append({"jump": j, "eta_gate": inc_gate, "eta_rung1": inc_r1})
            chain_cost = t_low + t_high + t_gate
            tag = design_tag(P, kind, beta_end, m, "g%02d" % gi, dry)
            files = save_mask(tag + "_final", inc_bin, inc_lat)
            store["units"][key] = {
                "target": [m, 0], "kind": kind, "group": gi, "members": [v["index"] for v in members],
                "member_gate": [v["deliver_best"]["eta_gate"] for v in members],
                "member_rung1": [v["deliver_best"]["eta_rung1"] for v in members],
                "member_cost_s": [v["ticket_cost_s"] for v in members],
                "parent_index": parent["index"], "parent_eta_gate": parent["deliver_best"]["eta_gate"],
                "parent_eta_rung1": parent["deliver_best"]["eta_rung1"], "parent_step": parent["deliver_best"]["step"],
                "parent_sha1": parent["deliver_best"]["sha1"],
                "beta_star_raw": beta_raw, "beta_star": beta_star, "re_beta_rule": re_beta, "hops": hops, "re_steps": re_steps, "re_k": RE_K,
                "n_accept": n_accept, "accept_jumps": [r["jump"] for r in jumps if r["accepted"]],
                "n_false_accept": int(sum(1 for r in jumps if r.get("false_accept"))),
                "final_eta_gate": inc_gate, "final_eta_rung1": inc_r1,
                "gain_rung1": inc_r1 - parent["deliver_best"]["eta_rung1"],
                "final_sha1": C.sha1_of(inc_bin), "files": files,
                "jumps": jumps, "incumbent_curve": inc_curve,
                "wall_low_s": t_low, "wall_high_s": t_high, "wall_gate_s": t_gate, "chain_cost_s": chain_cost,
                "instrument_wall_s": t_instr, "unit_wall_s": time.perf_counter() - t0, "grad_events": ev,
            }
            save_json(path, store)
            print("  m=%d %s g%02d | parent s%02d gate %.4f r1 %.4f beta* %.0f | accepts %d (false %d) | final r1 %.4f (%+.4f) | cand-inc med %+.3f | %s  [%s]"
                  % (m, kind, gi, parent["index"], parent["deliver_best"]["eta_gate"], parent["deliver_best"]["eta_rung1"], beta_star,
                     n_accept, store["units"][key]["n_false_accept"], inc_r1, inc_r1 - parent["deliver_best"]["eta_rung1"],
                     float(np.median([r["cand_minus_inc_gate"] for r in jumps])), fmt(chain_cost), fmt(time.perf_counter() - t_start)), flush=True)
    store["meta"]["last_run_wall_s"] = time.perf_counter() - t_start
    save_json(path, store)
    return store


# -------------------------------------------------------------------- analysis
def analyze(targets, beta_end, dry, device, P):
    cfg = P["cfg"]()
    T = load_store(out_path("T", beta_end, dry, P), "T")
    O = load_store(out_path("O", beta_end, dry, P), "O")
    CH = load_store(out_path("chain", beta_end, dry, P), "chain")
    path = out_path("analysis", beta_end, dry, P)
    A = load_store(path, "analysis")
    A["meta"].update({"beta_end": beta_end, "group": GROUP, "problem": P["physics"], "eig_device": assert_eig_cpu(),
                      "generated_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                      "notes": ["'T + ckpt rule' and 'T by gate' use gate reads that T's workflow does not pay for; the equal-wall row "
                                "prices the ckpt rule separately (t_cost_ckpt = descent + n_ckpt x gate read).",
                                "Pool E[best of 3] uses exact order statistics on all tickets; intervals are percentile bootstraps over tickets "
                                "(arms independent) or over groups (paired rows)."]})
    reads = A.setdefault("top_reads", {})

    def top_eta(level, sha, root, rel, ctx):
        rk = "%d-%d|%s" % (tuple(level) + (sha,))
        if rk not in reads:
            reads[rk] = C.eta(load_mask_from(root, rel), tuple(level), ctx)
        return reads[rk]

    for m in targets:
        od = P["orders"](m, cfg)
        ctx = C.make_ctx(cfg, (m, 0), od["descent"], od["gate"], device)
        tu = sorted([v for v in T["units"].values() if v["target"][0] == m], key=lambda v: v["index"])
        ou = sorted([v for v in O["units"].values() if v["target"][0] == m], key=lambda v: v["index"])
        cu = {v["group"]: v for v in CH["units"].values() if v["target"][0] == m and v.get("kind", "chain") == "chain"}
        ru = {v["group"]: v for v in CH["units"].values() if v["target"][0] == m and v.get("kind") == "repair"}
        if not tu or not ou:
            continue
        n = min(len(tu), len(ou))
        n_groups = n // GROUP
        gate_read = P["gate_fwd"][m]
        # --- per-group deliveries
        rows = []
        for gi in range(n_groups):
            tm = tu[gi * GROUP:(gi + 1) * GROUP]
            om = ou[gi * GROUP:(gi + 1) * GROUP]
            t_own = max(tm, key=lambda v: v["reported"])                       # T picks by its own number
            t_gate = max(tm, key=lambda v: v["deliver_final"]["eta_gate"])     # T picked by gate (our reading, their delivery)
            t_ckpt = max(tm, key=lambda v: v["deliver_best"]["eta_gate"])      # T + our checkpoint rule (unpriced reads)
            o_par = max(om, key=lambda v: v["deliver_best"]["eta_gate"])
            o_worst = min(om, key=lambda v: v["deliver_best"]["eta_gate"])
            ch, rp = cu.get(gi), ru.get(gi)
            o_final = ch["final_eta_rung1"] if ch else None
            rows.append({
                "group": gi,
                "T_reported_best": t_own["reported"],
                "T_own_rule_rung1": t_own["deliver_final"]["eta_rung1"],
                "T_by_gate_rung1": t_gate["deliver_final"]["eta_rung1"],
                "T_ckpt_rule_rung1": t_ckpt["deliver_best"]["eta_rung1"],
                "T_cost_s": sum(v["wall_descent_s"] for v in tm),
                "O_ticket_rung1": o_par["deliver_best"]["eta_rung1"],
                "O_ticket_gate": o_par["deliver_best"]["eta_gate"],
                "O_tickets_cost_s": sum(v["ticket_cost_s"] for v in om),
                "O_chain_rung1": o_final,
                "O_chain_gain": ch["gain_rung1"] if ch else None,
                "O_accepts": ch["n_accept"] if ch else None,
                "O_false_accepts": ch["n_false_accept"] if ch else None,
                "O_chain_cost_s": ch["chain_cost_s"] if ch else None,
                "O_pipeline_cost_s": (sum(v["ticket_cost_s"] for v in om) + ch["chain_cost_s"]) if ch else None,
                "O_minus_T_own": (o_final - t_own["deliver_final"]["eta_rung1"]) if ch else None,
                "O_minus_T_gate": (o_final - t_gate["deliver_final"]["eta_rung1"]) if ch else None,
                "O_ticket_minus_T_own": o_par["deliver_best"]["eta_rung1"] - t_own["deliver_final"]["eta_rung1"],
                "O_ticket_minus_T_gate": o_par["deliver_best"]["eta_rung1"] - t_gate["deliver_final"]["eta_rung1"],
                "group_min_rung1_O": min(v["deliver_best"]["eta_rung1"] for v in om),
                "group_min_rung1_T": min(v["deliver_final"]["eta_rung1"] for v in tm),
                "repair_parent_rung1": o_worst["deliver_best"]["eta_rung1"],
                "repair_parent_gate": o_worst["deliver_best"]["eta_gate"],
                "repair_final_rung1": rp["final_eta_rung1"] if rp else None,
                "repair_gain": rp["gain_rung1"] if rp else None,
                "repair_accepts": rp["n_accept"] if rp else None,
                "repair_false_accepts": rp["n_false_accept"] if rp else None,
                "repair_cost_s": rp["chain_cost_s"] if rp else None,
            })
        # --- pools
        t_rep = [v["reported"] for v in tu[:n]]
        t_fin = [v["deliver_final"]["eta_rung1"] for v in tu[:n]]
        t_fin_gate = [v["deliver_final"]["eta_gate"] for v in tu[:n]]
        t_best = [v["deliver_best"]["eta_rung1"] for v in tu[:n]]
        t_best_gate = [v["deliver_best"]["eta_gate"] for v in tu[:n]]
        t_cost = float(np.median([v["wall_descent_s"] for v in tu[:n]]))
        t_cost_ckpt = float(np.median([v["wall_descent_s"] + (v.get("n_ckpt") or 0) * gate_read for v in tu[:n]]))
        o_r1 = [v["deliver_best"]["eta_rung1"] for v in ou[:n]]
        o_gate = [v["deliver_best"]["eta_gate"] for v in ou[:n]]
        o_cost = float(np.median([v["ticket_cost_s"] for v in ou[:n]]))
        cap = n // 2
        e3 = {"T_own": e_best_by(t_rep, t_fin, 3), "T_gate": e_best_by(t_fin_gate, t_fin, 3), "T_ckpt": e_best_by(t_best_gate, t_best, 3),
              "T_oracle": C.e_max(t_fin, 3), "O_gate": e_best_by(o_gate, o_r1, 3), "O_oracle": C.e_max(o_r1, 3)}
        # bootstrap over tickets (arms independent)
        def _e3_diff(sel_t, del_t, sel_o, del_o):
            def f(idx):
                jdx = np.random.default_rng(int(idx[0]) + 7919).integers(0, n, n)
                a = e_best_by([sel_o[i] for i in jdx], [del_o[i] for i in jdx], 3)
                b = e_best_by([sel_t[i] for i in idx], [del_t[i] for i in idx], 3)
                return None if a is None or b is None else a - b
            return f
        ci = {"O_gate_minus_T_own": boot_ci(_e3_diff(t_rep, t_fin, o_gate, o_r1), n, seed=1),
              "O_gate_minus_T_gate": boot_ci(_e3_diff(t_fin_gate, t_fin, o_gate, o_r1), n, seed=2),
              "O_gate": boot_ci(lambda idx: e_best_by([o_gate[i] for i in idx], [o_r1[i] for i in idx], 3), n, seed=3),
              "T_own": boot_ci(lambda idx: e_best_by([t_rep[i] for i in idx], [t_fin[i] for i in idx], 3), n, seed=4),
              "T_gate": boot_ci(lambda idx: e_best_by([t_fin_gate[i] for i in idx], [t_fin[i] for i in idx], 3), n, seed=5)}
        # equal-wall T: only when every group has its chain
        eq = None
        full = all(gi in cu for gi in range(n_groups)) and n_groups > 0
        if full:
            o_pipe_cost = float(np.median([r["O_pipeline_cost_s"] for r in rows]))
            N_pipe = o_pipe_cost / t_cost
            N_tix = 3.0 * o_cost / t_cost
            eq = {"O_pipeline_cost_s": o_pipe_cost, "N_pipeline": N_pipe, "N_pipeline_used": min(N_pipe, float(cap)), "capped": N_pipe > cap,
                  "T_own_rule": e_best_interp(t_rep, t_fin, min(N_pipe, cap)),
                  "T_by_gate": e_best_interp(t_fin_gate, t_fin, min(N_pipe, cap)),
                  "T_ckpt_rule_priced": e_best_interp(t_best_gate, t_best, min(o_pipe_cost / t_cost_ckpt, cap)),
                  "N_ckpt_priced": o_pipe_cost / t_cost_ckpt,
                  "N_tickets_only": N_tix,
                  "T_own_rule_vs_tickets_only": e_best_interp(t_rep, t_fin, min(N_tix, cap)),
                  "T_by_gate_vs_tickets_only": e_best_interp(t_fin_gate, t_fin, min(N_tix, cap))}
        else:
            eq = {"reason": "chain incomplete: %d/%d groups" % (len(cu), n_groups)}
        # --- top-rung reads for the best 3 deliveries per arm (cached by level|sha1)
        def _top(cands):
            out = []
            for r1, k, sha, root, rel in sorted(cands, key=lambda x: x[0], reverse=True)[:N_TOP]:
                out.append({"key": k, "eta_rung1": r1, "eta_top": top_eta(od["top"], sha, root, rel, ctx)})
            return out
        top_T = _top([(v["deliver_final"]["eta_rung1"], "s%02d" % v["index"], v["deliver_final"]["sha1"], DATA, v["deliver_final"]["files"]["binary"]) for v in tu[:n]])
        top_O = _top([(v["deliver_best"]["eta_rung1"], "s%02d" % v["index"], v["deliver_best"]["sha1"],
                       S6DATA if v.get("source", {}).get("root") == "S6" else DATA, v["deliver_best"]["files"]["binary"]) for v in ou[:n]])
        top_C = _top([(v["final_eta_rung1"], "g%02d" % v["group"], v["final_sha1"], DATA, v["files"]["binary"]) for v in cu.values()]) if cu else []
        top_R = _top([(v["final_eta_rung1"], "g%02d" % v["group"], v["final_sha1"], DATA, v["files"]["binary"]) for v in ru.values()]) if ru else []
        # --- replication against 8a (P1 m=3): same seeds, eig device changed
        repl = None
        if P.get("replicate") and os.path.exists(P["replicate"]["file"]):
            R = json.load(open(P["replicate"]["file"], encoding="utf-8"))
            by_seed = {v["seed"]: v for v in R["units"].values() if v["target"][0] == m}
            rk = P["replicate"]["rung1_key"]
            repl = []
            for v in tu[:n]:
                r = by_seed.get(v["seed"])
                if not r:
                    continue
                tr0, tr1 = v.get("trajectory") or [], r.get("trajectory") or []
                k_div = next((i for i in range(min(len(tr0), len(tr1))) if tr0[i] is not None and tr1[i] is not None and abs(tr0[i] - tr1[i]) > 1e-3), None)
                repl.append({"seed": v["seed"], "S7_final_rung1": v["deliver_final"]["eta_rung1"], "8a_final_rung1": r["deliver_final"]["final_ladder"].get(rk),
                             "S7_reported": v["reported"], "8a_reported": r["deliver_final"].get("reported_continuous"),
                             "S7_best_step": v["deliver_best"]["step"], "8a_best_step": r["deliver_best"]["step"],
                             "S7_best_rung1": v["deliver_best"]["eta_rung1"], "8a_best_rung1": r["deliver_best"]["final_ladder"].get(rk),
                             "first_divergence_step_gt_1e-3": k_div, "S7_wall_descent_s": v["wall_descent_s"], "8a_wall_descent_s": r.get("wall_descent_s")})
        # --- summary
        def gq(k):
            return C.q([r[k] for r in rows if r.get(k) is not None])
        paired_keys = ("T_own_rule_rung1", "T_by_gate_rung1", "T_ckpt_rule_rung1", "O_ticket_rung1", "O_chain_rung1", "O_chain_gain",
                       "O_minus_T_own", "O_minus_T_gate", "O_ticket_minus_T_own", "O_ticket_minus_T_gate", "T_cost_s", "O_pipeline_cost_s",
                       "group_min_rung1_O", "group_min_rung1_T", "repair_parent_rung1", "repair_final_rung1", "repair_gain", "repair_cost_s")
        gstats = {k: gq(k) for k in paired_keys}
        for k in ("O_minus_T_own", "O_minus_T_gate", "O_ticket_minus_T_own", "O_ticket_minus_T_gate", "repair_gain"):
            vals = [r[k] for r in rows if r.get(k) is not None]
            if vals and gstats[k]:
                gstats[k]["n_pos"] = int(sum(v > 0 for v in vals))
                gstats[k]["n_neg"] = int(sum(v < 0 for v in vals))
                gstats[k]["ci_median"] = boot_ci(lambda idx: float(np.median([vals[i] for i in idx])), len(vals), seed=11)
        summ = {
            "n_tickets": n, "n_groups": n_groups,
            "T_pool": {"reported": C.q(t_rep), "final_rung1": C.q(t_fin), "best_ckpt_rung1": C.q(t_best),
                       "inflation": C.q([v["inflation_reported_minus_rung1"] for v in tu[:n]]),
                       "relaxation": C.q([v.get("relaxation") for v in tu[:n]]), "truncation": C.q([v.get("truncation") for v in tu[:n]]),
                       "collapses": int(sum(v["collapse_step"] is not None for v in tu[:n])),
                       "cliffs_best_minus_final_gt_0p1": int(sum(v["best_minus_final_rung1"] > 0.1 for v in tu[:n])),
                       "ticket_cost_s": C.q([v["wall_descent_s"] for v in tu[:n]]), "ticket_cost_ckpt_priced_s": t_cost_ckpt,
                       "e_best_of_3": {"own_rule": e3["T_own"], "by_gate": e3["T_gate"], "ckpt_rule": e3["T_ckpt"], "oracle": e3["T_oracle"]}},
            "O_pool": {"ticket_rung1": C.q(o_r1), "gate_optimism": C.q([v["deliver_best"]["gate_optimism"] for v in ou[:n]]),
                       "collapses": int(sum(v["collapse_step"] is not None for v in ou[:n])),
                       "ticket_cost_s": C.q([v["ticket_cost_s"] for v in ou[:n]]),
                       "ticket_cost_selected_s": C.q([v.get("ticket_cost_selected_s") for v in ou[:n]]),
                       "e_best_of_3": {"by_gate": e3["O_gate"], "oracle": e3["O_oracle"]}},
            "e_best_of_3_ci": ci,
            "groups": rows, "group_stats": gstats,
            "chain": {"n": len(cu), "accepts_total": int(sum(v["n_accept"] for v in cu.values())) if cu else None,
                      "false_accepts_total": int(sum(v["n_false_accept"] for v in cu.values())) if cu else None,
                      "gain_rung1": C.q([v["gain_rung1"] for v in cu.values()]) if cu else None,
                      "n_gain_gt_0p01": int(sum(v["gain_rung1"] > 0.01 for v in cu.values())) if cu else None,
                      "n_below_parent": int(sum(v["gain_rung1"] < -1e-9 for v in cu.values())) if cu else None,
                      "chain_cost_s": C.q([v["chain_cost_s"] for v in cu.values()]) if cu else None,
                      "cand_minus_inc_gate_median": C.q([float(np.median([j["cand_minus_inc_gate"] for j in v["jumps"]])) for v in cu.values()]) if cu else None},
            "repair": {"n": len(ru), "accepts_total": int(sum(v["n_accept"] for v in ru.values())) if ru else None,
                       "false_accepts_total": int(sum(v["n_false_accept"] for v in ru.values())) if ru else None,
                       "parent_rung1": C.q([v["parent_eta_rung1"] for v in ru.values()]) if ru else None,
                       "final_rung1": C.q([v["final_eta_rung1"] for v in ru.values()]) if ru else None,
                       "gain_rung1": C.q([v["gain_rung1"] for v in ru.values()]) if ru else None,
                       "n_gain_gt_0p01": int(sum(v["gain_rung1"] > 0.01 for v in ru.values())) if ru else None,
                       "n_below_parent": int(sum(v["gain_rung1"] < -1e-9 for v in ru.values())) if ru else None,
                       "chain_cost_s": C.q([v["chain_cost_s"] for v in ru.values()]) if ru else None,
                       "cand_minus_inc_gate_median": C.q([float(np.median([j["cand_minus_inc_gate"] for j in v["jumps"]])) for v in ru.values()]) if ru else None},
            "equal_wall_T": eq,
            "top_rung": {"T_final": top_T, "O_ticket": top_O, "O_chain": top_C, "O_repair": top_R},
            "replication_vs_8a": repl,
        }
        # --- other chain variants present in the store (e.g. fixed re-descent beta), per kind
        variants = {}
        for v in CH["units"].values():
            k = v.get("kind", "chain")
            if v["target"][0] == m and k not in ("chain", "repair"):
                variants.setdefault(k, []).append(v)
        summ["variants"] = {k: {"n": len(vs), "accepts_total": int(sum(v["n_accept"] for v in vs)),
                                "false_accepts_total": int(sum(v["n_false_accept"] for v in vs)),
                                "parent_rung1": C.q([v["parent_eta_rung1"] for v in vs]), "final_rung1": C.q([v["final_eta_rung1"] for v in vs]),
                                "gain_rung1": C.q([v["gain_rung1"] for v in vs]), "n_gain_gt_0p01": int(sum(v["gain_rung1"] > 0.01 for v in vs)),
                                "n_below_parent": int(sum(v["gain_rung1"] < -1e-9 for v in vs)),
                                "chain_cost_s": C.q([v["chain_cost_s"] for v in vs]),
                                "cand_minus_inc_gate_median": C.q([float(np.median([j["cand_minus_inc_gate"] for j in v["jumps"]])) for v in vs]),
                                "per_group": sorted([{"group": v["group"], "parent": v["parent_eta_rung1"], "final": v["final_eta_rung1"],
                                                      "accepts": v["n_accept"], "beta": v["beta_star"]} for v in vs], key=lambda d: d["group"])}
                            for k, vs in variants.items()}
        A["summary"]["m%d" % m] = summ
        save_json(path, A)
        # --- print
        def _q(k):
            v = gstats.get(k)
            if not v:
                return "—"
            s = "%.3f [%.3f, %.3f]" % (v["median"], v["min"], v["max"])
            if "n_pos" in v:
                s += " +%d/−%d" % (v["n_pos"], v["n_neg"])
            return s
        def _ci(k):
            c = ci.get(k)
            return ("[%.3f, %.3f]" % tuple(c)) if c else "—"
        print("=" * 100)
        print("m=%d  %s  beta_end %g  | tickets %d per arm, %d groups of %d" % (m, P["physics"], beta_end, n, n_groups, GROUP))
        tp, op = summ["T_pool"], summ["O_pool"]
        print("  T single ticket: reported med %.3f ; final rung1 med %.3f ; inflation med %+.3f (relax %+.3f, trunc %+.3f) ; collapses %d ; cliffs %d ; ticket %s"
              % (tp["reported"]["median"], tp["final_rung1"]["median"], tp["inflation"]["median"],
                 (tp["relaxation"] or {}).get("median", float("nan")), (tp["truncation"] or {}).get("median", float("nan")),
                 tp["collapses"], tp["cliffs_best_minus_final_gt_0p1"], fmt(tp["ticket_cost_s"]["median"])))
        print("  O single ticket: rung1 med %.3f ; collapses %d ; ticket %s (selected-reads priced %s)"
              % (op["ticket_rung1"]["median"], op["collapses"], fmt(op["ticket_cost_s"]["median"]),
                 fmt(op["ticket_cost_selected_s"]["median"]) if op["ticket_cost_selected_s"] else "—"))
        print("  pool E[best of 3]: T own %.3f %s | T gate %.3f %s | T+ckpt %.3f | O %.3f %s | O−T(own) %s | O−T(gate) %s"
              % (e3["T_own"], _ci("T_own"), e3["T_gate"], _ci("T_gate"), e3["T_ckpt"], e3["O_gate"], _ci("O_gate"),
                 _ci("O_gate_minus_T_own"), _ci("O_gate_minus_T_gate")))
        print("  per group (rung1), median [min, max]:")
        print("    T own rule      %s   cost %s" % (_q("T_own_rule_rung1"), fmt(gstats["T_cost_s"]["median"]) if gstats.get("T_cost_s") else "—"))
        print("    T by gate       %s" % _q("T_by_gate_rung1"))
        print("    T + ckpt rule   %s   (unpriced reads; priced ticket %s)" % (_q("T_ckpt_rule_rung1"), fmt(t_cost_ckpt)))
        print("    O ticket        %s   O ticket − T(own) %s" % (_q("O_ticket_rung1"), _q("O_ticket_minus_T_own")))
        print("    O + chain       %s   pipeline cost %s" % (_q("O_chain_rung1"), fmt(gstats["O_pipeline_cost_s"]["median"]) if gstats.get("O_pipeline_cost_s") else "—"))
        print("    O − T(own)      %s ;  O − T(gate) %s" % (_q("O_minus_T_own"), _q("O_minus_T_gate")))
        print("    group min       T %s | O %s" % (_q("group_min_rung1_T"), _q("group_min_rung1_O")))
        c = summ["chain"]
        if c["n"]:
            print("  chain (best of group): accepts total %d (false %d), gain rung1 med %+.4f [%+.4f, %+.4f], >0.01: %d/%d, below parent: %d, cand−inc med %+.3f, cost med %s"
                  % (c["accepts_total"], c["false_accepts_total"], c["gain_rung1"]["median"], c["gain_rung1"]["min"], c["gain_rung1"]["max"],
                     c["n_gain_gt_0p01"], c["n"], c["n_below_parent"], c["cand_minus_inc_gate_median"]["median"], fmt(c["chain_cost_s"]["median"])))
        r_ = summ["repair"]
        if r_["n"]:
            print("  repair (worst of group): parent rung1 med %.3f [%.3f, %.3f] -> final %.3f [%.3f, %.3f]; gain med %+.4f [%+.4f, %+.4f], >0.01: %d/%d, below parent %d, accepts %d (false %d), cand−inc med %+.3f, cost med %s"
                  % (r_["parent_rung1"]["median"], r_["parent_rung1"]["min"], r_["parent_rung1"]["max"], r_["final_rung1"]["median"], r_["final_rung1"]["min"], r_["final_rung1"]["max"],
                     r_["gain_rung1"]["median"], r_["gain_rung1"]["min"], r_["gain_rung1"]["max"], r_["n_gain_gt_0p01"], r_["n"], r_["n_below_parent"],
                     r_["accepts_total"], r_["false_accepts_total"], r_["cand_minus_inc_gate_median"]["median"], fmt(r_["chain_cost_s"]["median"])))
        for k, vv in summ["variants"].items():
            print("  %s: n %d, parent med %.3f -> final med %.3f; gain med %+.4f [%+.4f, %+.4f], >0.01: %d/%d, below parent %d, accepts %d (false %d), cand−inc med %+.3f, cost med %s | per group %s"
                  % (k, vv["n"], vv["parent_rung1"]["median"], vv["final_rung1"]["median"], vv["gain_rung1"]["median"], vv["gain_rung1"]["min"], vv["gain_rung1"]["max"],
                     vv["n_gain_gt_0p01"], vv["n"], vv["n_below_parent"], vv["accepts_total"], vv["false_accepts_total"], vv["cand_minus_inc_gate_median"]["median"],
                     fmt(vv["chain_cost_s"]["median"]), ["g%d %.3f->%.3f(%d)" % (d["group"], d["parent"], d["final"], d["accepts"]) for d in vv["per_group"]]))
        if eq and "N_pipeline" in eq:
            print("  equal-wall T vs O pipeline (N = %.2f%s): own rule %.3f | by gate %.3f | ckpt rule priced (N %.2f) %.3f ;  vs O tickets only (N = %.2f): own %.3f | gate %.3f"
                  % (eq["N_pipeline"], " capped %g" % eq["N_pipeline_used"] if eq["capped"] else "", eq["T_own_rule"] or float("nan"), eq["T_by_gate"] or float("nan"),
                     eq["N_ckpt_priced"], eq["T_ckpt_rule_priced"] or float("nan"), eq["N_tickets_only"], eq["T_own_rule_vs_tickets_only"] or float("nan"),
                     eq["T_by_gate_vs_tickets_only"] or float("nan")))
        elif eq:
            print("  equal-wall T: not computed (%s)" % eq["reason"])
        print("  top rung (best %d): T %s | O ticket %s | O chain %s | O repair %s" % (
            N_TOP, ["%.3f->%.3f" % (r["eta_rung1"], r["eta_top"]) for r in top_T], ["%.3f->%.3f" % (r["eta_rung1"], r["eta_top"]) for r in top_O],
            ["%.3f->%.3f" % (r["eta_rung1"], r["eta_top"]) for r in top_C], ["%.3f->%.3f" % (r["eta_rung1"], r["eta_top"]) for r in top_R]))
        if repl:
            print("  replication vs 8a (same seeds, CPU vs native eig): " + "; ".join(
                "seed %d final r1 %.3f vs %.3f (best %.3f@%d vs %.3f@%d, diverge@%s)" % (
                    r["seed"], r["S7_final_rung1"], r["8a_final_rung1"] or float("nan"), r["S7_best_rung1"], r["S7_best_step"],
                    r["8a_best_rung1"] or float("nan"), r["8a_best_step"], r["first_divergence_step_gt_1e-3"]) for r in repl), flush=True)
    save_json(path, A)
    return A


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--phase", type=str, default="all", choices=["all", "tickets_T", "tickets_O", "chain", "analyze"])
    ap.add_argument("--targets", type=str, default="1,2")
    ap.add_argument("--beta-end", type=float, default=2000.0)
    ap.add_argument("--n", type=int, default=None, help="tickets per arm per target (default per problem)")
    ap.add_argument("--problem", type=str, default="P2", choices=list(PROBLEMS))
    ap.add_argument("--chain-on", type=str, default="both", choices=["best", "worst", "both"])
    ap.add_argument("--re-beta", type=str, default="star", help="chain re-descent beta: 'star' (parent delivery beta, floored at 64) or a number, e.g. 64")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()
    device = C.setup_runtime()
    P = PROBLEMS[args.problem]
    targets = [int(t) for t in args.targets.split(",") if t.strip()]
    assert all(m in P["n"] for m in targets), "targets not configured for %s" % args.problem
    os.makedirs(os.path.join(DATA, "logs"), exist_ok=True)
    print("=" * 100)
    print("s7_headtohead | %s (%s) | phase %s | targets %s | beta_end %g | chain-on %s | %s | dry=%s" % (
        args.problem, P["physics"], args.phase, targets, args.beta_end, args.chain_on,
        torch.cuda.get_device_name(0) if device == "cuda" else "cpu", args.dry_run), flush=True)
    t0 = time.perf_counter()
    if args.phase in ("all", "tickets_O"):
        run_tickets_O(targets, args.beta_end, args.n, args.dry_run, device, P)
    if args.phase in ("all", "tickets_T"):
        run_tickets_T(targets, args.beta_end, args.n, args.dry_run, device, P)
    if args.phase in ("all", "chain"):
        if args.chain_on in ("best", "both"):
            run_chain(targets, args.beta_end, args.dry_run, device, P, which="best", re_beta=args.re_beta)
        if args.chain_on in ("worst", "both"):
            run_chain(targets, args.beta_end, args.dry_run, device, P, which="worst", re_beta=args.re_beta)
    if args.phase in ("all", "analyze"):
        analyze(targets, args.beta_end, args.dry_run, device, P)
    print("done in %s" % fmt(time.perf_counter() - t0), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
