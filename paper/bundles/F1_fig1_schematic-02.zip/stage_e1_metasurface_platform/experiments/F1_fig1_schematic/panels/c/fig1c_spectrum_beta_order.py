"""
Fig. 1(c) -- permittivity spectrum of one density state vs. projection sharpness (beta)
and Fourier truncation order (M).  No text in any output figure (labels added by hand).

  eps_beta(x, y) = eps_low + P_beta(rho~) (eps_high - eps_low)      beta = inf -> binary (Q_M)
  C_M is built from eps~_beta(h_x, h_y) with |h_x| <= 2 M_x, |h_y| <= 2 M_y,
  so the order-M window is drawn at 2M on the permittivity spectrum.

  along a column (fixed M, beta grows):  the spectrum spreads past a fixed window
  along a row    (fixed beta, M grows):  the window widens over a fixed spectrum

The density state (seed, filter, eta, eps values) is read from ../../fmm_pipeline.py,
so these panels always show the same design as the pipeline panels.

Outputs, next to this script (png + svg):
  eps_b{beta}                                eps_beta(x, y), grey (eps_low white, eps_high black)
  colorbar_eps
  {grey,magma,viridis}/spec_b{beta}_M{M}     log|eps~_beta| with the order-M window (|h| <= 2M)
  {grey,magma,viridis}/spec_b{beta}_nested   all windows in one panel
  {grey,magma,viridis}/colorbar
  bandlimited/bandlimited_b{beta}_M{M}       eps_beta rebuilt from |h| <= 2M only (same grid)
  tail_vs_window, tail_vs_beta               spectral tail outside the window (no text)
  tail_vs_window_ref, tail_vs_beta_ref       same plots with axis labels (reference only)
  preview/*.png                              labelled contact sheets (not for the paper)
"""
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from matplotlib.patches import Rectangle

OUT  = os.path.dirname(os.path.abspath(__file__))
PIPE = os.path.normpath(os.path.join(OUT, "..", "..", "fmm_pipeline.py"))

# ------------------------------------------------ density state (shared) ----
_src = open(PIPE, encoding="utf-8").read()
_g = {"__name__": "fmm_pipeline_design"}
exec(compile(_src[:_src.index("# ----------------------------- plotting")], PIPE, "exec"), _g)
rho_tilde, P_beta = _g["rho_tilde"], _g["tanh_projection"]
ETA, EPS_LOW, EPS_HIGH = _g["ETA"], _g["EPS_LOW"], _g["EPS_HIGH"]
D_EPS = EPS_HIGH - EPS_LOW

# ------------------------------------------------------------- parameters ----
BETAS   = [1, 8, 32, np.inf]      # rows; beta = 8 is the value of the pipeline's panel 3
ORDERS  = [3, 7, 15]              # optimization / gate / validation order M
SHOW    = 34                      # spectrum shown for |h_x|, |h_y| <= SHOW  (> 2 max(ORDERS))
DECADES = 3.0                     # colour scale spans this many decades below |eps~_inf(0,0)|
PANEL   = 2.0                     # inches, every square panel
SCHEMES = {                       # colour map + one window colour per order (as fmm_pipeline.py)
    "grey":    ("gray_r",  ["#009E73", "#D55E00", "#0072B2"]),
    "magma":   ("magma",   ["#00e5ff", "#00ff5e", "#ffffff"]),
    "viridis": ("viridis", ["#ff2d2d", "#ff4fd8", "#ffffff"]),
}
BETA_COLS = ["#A9C1E0", "#6B93C9", "#2F5C9E", "#111111"]   # line plots: soft -> binary

# ----------------------------------------------------------------- physics ----
def eps_beta(beta):
    rb = (rho_tilde >= ETA).astype(float) if np.isinf(beta) else P_beta(rho_tilde, beta, ETA)
    return EPS_LOW + rb * D_EPS

def spectrum(e):                                  # eps~(h), centred: S[c + h_y, c + h_x]
    return np.fft.fftshift(np.fft.fft2(e)) / e.size

N = rho_tilde.shape[0]; c = N // 2
hy, hx = np.meshgrid(np.arange(N) - c, np.arange(N) - c, indexing="ij")
SHELL = np.maximum(abs(hx), abs(hy))              # |h|_inf of every harmonic

def bandlimit(S, K):                              # keep |h_x|, |h_y| <= K, same real-space grid
    return np.real(np.fft.ifft2(np.fft.ifftshift(np.where(SHELL <= K, S, 0))) * S.size)

def tail_curve(S):                                # RMS of eps outside |h| <= K, / (eps_h - eps_l)
    e_shell = np.bincount(SHELL.ravel(), weights=(abs(S) ** 2).ravel())
    beyond = np.cumsum(e_shell[::-1])[::-1]       # beyond[K] = energy with |h|_inf >= K
    return np.sqrt(np.append(beyond[1:], 0.0)) / D_EPS   # index K -> energy with |h|_inf > K

def tag(b):
    return "inf" if np.isinf(b) else f"{b:g}"

def beta_label(b):
    return "\\infty" if np.isinf(b) else f"{b:g}"

eps_b  = {b: eps_beta(b) for b in BETAS}
spec_b = {b: spectrum(e) for b, e in eps_b.items()}
REF    = abs(spectrum(eps_beta(np.inf))[c, c])    # common colour reference for every beta

def log_map(a):
    lo = np.log10(REF) - DECADES
    return np.clip((np.log10(np.maximum(a, 1e-300)) - lo) / DECADES, 0, 1)

# ---------------------------------------------------------------- drawing ----
def save(fig, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    for ext in ("png", "svg"):
        fig.savefig(f"{path}.{ext}", dpi=300, facecolor="white")
    plt.close(fig)

def square_panel():
    fig = plt.figure(figsize=(PANEL, PANEL), dpi=300)
    ax = fig.add_axes([0.03, 0.03, 0.94, 0.94])
    ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values():
        s.set_linewidth(1.5); s.set_color("black")
    return fig, ax

def colorbar(cmap, path):
    fig = plt.figure(figsize=(PANEL, 0.2), dpi=300)
    ax = fig.add_axes([0.03, 0.1, 0.94, 0.8])
    ax.imshow(np.linspace(0, 1, 256)[None, :], cmap=cmap, aspect="auto", extent=[0, 1, 0, 1])
    ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values():
        s.set_linewidth(0.8)
    save(fig, path)

EXTENT = [-SHOW - 0.5, SHOW + 0.5, -SHOW - 0.5, SHOW + 0.5]
def spectrum_panel(b, cmap):
    fig, ax = square_panel()
    ax.imshow(log_map(abs(spec_b[b][c - SHOW:c + SHOW + 1, c - SHOW:c + SHOW + 1])),
              cmap=cmap, vmin=0, vmax=1, origin="lower", interpolation="nearest", extent=EXTENT)
    return fig, ax

def window_box(ax, M, col):                       # coefficients entering C_M: |h| <= 2M
    K = 2 * M
    ax.add_patch(Rectangle((-K - 0.5, -K - 0.5), 2 * K + 1, 2 * K + 1, fc="none", ec=col, lw=1.4))

# real-space eps_beta ------------------------------------------------------------
for b in BETAS:
    fig, ax = square_panel()
    ax.imshow(eps_b[b], cmap="gray_r", vmin=EPS_LOW, vmax=EPS_HIGH, origin="lower",
              interpolation="bilinear")
    save(fig, os.path.join(OUT, f"eps_b{tag(b)}"))
colorbar("gray_r", os.path.join(OUT, "colorbar_eps"))

# spectra with windows, every colour scheme ----------------------------------------
for name, (cmap, cols) in SCHEMES.items():
    for b in BETAS:
        for M, col in zip(ORDERS, cols):
            fig, ax = spectrum_panel(b, cmap); window_box(ax, M, col)
            save(fig, os.path.join(OUT, name, f"spec_b{tag(b)}_M{M}"))
        fig, ax = spectrum_panel(b, cmap)
        for M, col in zip(ORDERS, cols):
            window_box(ax, M, col)
        save(fig, os.path.join(OUT, name, f"spec_b{tag(b)}_nested"))
    colorbar(cmap, os.path.join(OUT, name, "colorbar"))

# band-limited eps_beta: only |h| <= 2M kept, real-space grid unchanged -----------
for b in BETAS:
    for M in ORDERS:
        fig, ax = square_panel()
        ax.imshow(bandlimit(spec_b[b], 2 * M), cmap="gray_r", vmin=EPS_LOW, vmax=EPS_HIGH,
                  origin="lower", interpolation="bilinear")
        save(fig, os.path.join(OUT, "bandlimited", f"bandlimited_b{tag(b)}_M{M}"))

# line plots: spectral tail outside the window ---------------------------------------
WIN_COLS = SCHEMES["grey"][1]
K_AX = np.arange(0, SHOW + 1)
tails = {b: tail_curve(spec_b[b]) for b in BETAS}
tail_inf = tail_curve(spectrum(eps_beta(np.inf)))
BETA_SWEEP = np.geomspace(0.5, 1024, 90)
sweep = {M: np.array([tail_curve(spectrum(eps_beta(b)))[2 * M] for b in BETA_SWEEP]) for M in ORDERS}

plt.rcParams.update({"font.family": "sans-serif", "font.sans-serif": ["Arial", "DejaVu Sans"],
                     "mathtext.fontset": "stix", "svg.fonttype": "none"})

def line_axes(labelled):
    fig = plt.figure(figsize=(2.6, 2.0), dpi=300)
    ax = fig.add_axes([0.2, 0.2, 0.75, 0.74] if labelled else [0.05, 0.05, 0.9, 0.9])
    ax.tick_params(direction="in", length=3, width=0.8, top=True, right=True,
                   labelsize=7, labelbottom=labelled, labelleft=labelled)
    ax.tick_params(which="minor", direction="in", length=1.5, width=0.5, top=True, right=True)
    for s in ax.spines.values():
        s.set_linewidth(1.0)
    return fig, ax

for labelled in (False, True):
    suffix = "_ref" if labelled else ""
    # (i) tail vs window half-width K; the orders sit at K = 2M
    fig, ax = line_axes(labelled)
    for M, col in zip(ORDERS, WIN_COLS):
        ax.axvline(2 * M, color=col, lw=1.0, ls=(0, (3, 2)), zorder=1)
    for b, bc in zip(BETAS, BETA_COLS):
        ax.plot(K_AX, tails[b][K_AX], color=bc, lw=1.4, zorder=3, label=f"$\\beta={beta_label(b)}$")
        for M in ORDERS:
            if tails[b][2 * M] > 1e-4:
                ax.plot(2 * M, tails[b][2 * M], "o", ms=3.2, mfc=bc, mec="white", mew=0.6, zorder=4)
    ax.set_yscale("log"); ax.set_ylim(1e-4, 1); ax.set_xlim(0, SHOW)
    if labelled:
        ax.set_xlabel("window half-width $K$  (order $M$ at $K = 2M$)", fontsize=7)
        ax.set_ylabel("RMS of $\\varepsilon_\\beta$ outside window / $\\Delta\\varepsilon$", fontsize=7)
        ax.legend(fontsize=6, frameon=False, loc="lower right", ncol=2, columnspacing=0.8)
    save(fig, os.path.join(OUT, "tail_vs_window" + suffix))

    # (ii) tail vs beta for each order; dashed = binary limit (beta -> inf)
    fig, ax = line_axes(labelled)
    for M, col in zip(ORDERS, WIN_COLS):
        ax.plot(BETA_SWEEP, sweep[M], color=col, lw=1.4, zorder=3, label=f"$M={M}$")
        ax.axhline(tail_inf[2 * M], color=col, lw=0.9, ls=(0, (3, 2)), zorder=2)
        for b in BETAS:
            if not np.isinf(b):
                ax.plot(b, tails[b][2 * M], "o", ms=3.2, mfc=col, mec="white", mew=0.6, zorder=4)
    ax.set_xscale("log"); ax.set_xlim(BETA_SWEEP[0], BETA_SWEEP[-1])
    ax.set_ylim(0, 1.12 * max(tail_inf[2 * M] for M in ORDERS))
    if labelled:
        ax.set_xlabel("projection steepness $\\beta$  (dashed: $\\beta\\to\\infty$)", fontsize=7)
        ax.set_ylabel("RMS of $\\varepsilon_\\beta$ outside $|h|\\leq 2M$ / $\\Delta\\varepsilon$",
                      fontsize=7)
        ax.legend(fontsize=6, frameon=False, loc="upper left")
    save(fig, os.path.join(OUT, "tail_vs_beta" + suffix))

# ----------------------------------------------------------------- report ----
print("RMS of eps_beta outside |h| <= 2M, relative to eps_high - eps_low")
print("beta     " + "".join(f"M={M:<9d}" for M in ORDERS))
for b in BETAS:
    print(f"{tag(b):<8} " + "".join(f"{tails[b][2 * M]:<11.4f}" for M in ORDERS))

# -------------------------------------------- labelled previews (not paper) ----
def contact(rows, row_labels, col_labels, path):
    nr, nc = len(rows), len(rows[0])
    fig, axes = plt.subplots(nr, nc, figsize=(1.55 * nc + 0.6, 1.55 * nr + 0.35), dpi=110,
                             squeeze=False)
    for i, r in enumerate(rows):
        for j, f in enumerate(r):
            ax = axes[i][j]; ax.axis("off")
            ax.imshow(mpimg.imread(f + ".png"))
            if i == 0:
                ax.set_title(col_labels[j], fontsize=8)
        axes[i][0].text(-0.08, 0.5, row_labels[i], transform=axes[i][0].transAxes,
                        ha="right", va="center", fontsize=9)
    fig.subplots_adjust(left=0.1, right=0.995, top=0.93, bottom=0.01, wspace=0.04, hspace=0.06)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fig.savefig(path, facecolor="white"); plt.close(fig)

row_lab = [f"$\\beta={beta_label(b)}$" for b in BETAS]
for name in SCHEMES:
    contact([[os.path.join(OUT, f"eps_b{tag(b)}")] +
             [os.path.join(OUT, name, f"spec_b{tag(b)}_M{M}") for M in ORDERS] +
             [os.path.join(OUT, name, f"spec_b{tag(b)}_nested")] for b in BETAS],
            row_lab,
            ["$\\varepsilon_\\beta(x,y)$"] + [f"$M={M}$, $|h|\\leq{2 * M}$" for M in ORDERS] + ["nested"],
            os.path.join(OUT, "preview", f"grid_{name}.png"))
contact([[os.path.join(OUT, f"eps_b{tag(b)}")] +
         [os.path.join(OUT, "bandlimited", f"bandlimited_b{tag(b)}_M{M}") for M in ORDERS]
         for b in BETAS],
        row_lab,
        ["$\\varepsilon_\\beta(x,y)$"] + [f"kept $|h|\\leq{2 * M}$ ($M={M}$)" for M in ORDERS],
        os.path.join(OUT, "preview", "grid_bandlimited.png"))
fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.8), dpi=110)
for ax, f in zip(axes, ["tail_vs_window_ref", "tail_vs_beta_ref"]):
    ax.imshow(mpimg.imread(os.path.join(OUT, f + ".png"))); ax.axis("off")
fig.subplots_adjust(left=0.01, right=0.99, top=0.99, bottom=0.01, wspace=0.03)
fig.savefig(os.path.join(OUT, "preview", "plots.png"), facecolor="white"); plt.close(fig)
