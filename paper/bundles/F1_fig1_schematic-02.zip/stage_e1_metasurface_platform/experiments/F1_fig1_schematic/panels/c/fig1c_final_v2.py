"""
Fig. 1(c), v2 (2026-10-01): same data, geometry and colours as fig1c_final.py (kept unchanged); only the type is changed.

User ruling 2026-10-01: colours stay; Times New Roman, bold, larger; every text starts with a capital letter.
Type rules (the Fig. 3 / Fig. 4 recipe of the manuscript figures):
  * Times New Roman everywhere; tick labels 8.5 pt and axis labels 9.5 pt, both bold; column titles, row labels and
    the end labels of the colour strips bold; legends and annotations regular weight.
  * Bold math through the mathtext rc (rm / it / bf = Times New Roman bold), font.weight is NOT set globally, so the
    math of the regular-weight legends (set in STIX) stays regular.
  * The calligraphic P of the row label has no bold face in mathtext: it is drawn in STIX with a thin stroke.
Output: ./final_v2 (png, svg, pdf).  The old figure in ./final is left untouched.

  columns  beta = 8, 32, 128, inf        row 1  eps_beta                row 2  log10 |eps^_beta(h)| + windows W_M
  row 3    P_3 eps_beta                  right  sigma(K) vs K  /  sigma_M(beta) vs beta     (see fig1c_final.py)
"""
import os
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
from matplotlib.patches import Rectangle

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "final_v2")
PIPE = os.path.normpath(os.path.join(HERE, "..", "..", "fmm_pipeline.py"))
MARK = "# ----------------------------- plotting"


# ------------------------------------------------ density state (shared) ----
def load_design(path):
    """Run fmm_pipeline.py up to its FIRST plotting marker and return its namespace."""
    src = open(path, encoding="utf-8").read()
    if MARK not in src:
        raise RuntimeError(f"plotting marker not found in {path}")
    ns = {"__name__": "fmm_pipeline_design"}
    exec(compile(src[:src.index(MARK)], path, "exec"), ns)
    missing = [k for k in ("rho_tilde", "tanh_projection", "ETA", "EPS_LOW", "EPS_HIGH") if k not in ns]
    if missing:
        raise RuntimeError(f"fmm_pipeline.py does not define {missing} above the plotting marker")
    return ns


_d = load_design(PIPE)
rho_tilde = np.asarray(_d["rho_tilde"], dtype=float)
P_beta = _d["tanh_projection"]
ETA, EPS_B, EPS_F = _d["ETA"], _d["EPS_LOW"], _d["EPS_HIGH"]
D_EPS = EPS_F - EPS_B

# ------------------------------------------------------------- parameters ----
BETAS = [8.0, 32.0, 128.0, np.inf]
ORDERS = [3, 7, 15]
M_SEEN = ORDERS[0]
SHOW = 34
DECADES = 3.0
K_MAX = 60
BETA_SWEEP = np.geomspace(1.0, 1e5, 300)
BETA_XLIM = (1.0, 1e4)
M_COLLAPSE = [3, 5, 7, 10, 15]

N = rho_tilde.shape[0]
c = N // 2
if rho_tilde.shape != (N, N):
    raise RuntimeError("square cell expected (M_x = M_y = M)")
if N < 4 * max(ORDERS) + 1 or N < 2 * SHOW + 1 or N // 2 <= K_MAX:
    raise RuntimeError(f"grid N = {N} too coarse for ORDERS/SHOW/K_MAX")

# colours: UNCHANGED from fig1c_final.py (user ruling 2026-10-01)
SPEC_CMAP = "viridis"
WIN = {3: "#ff2d2d", 7: "#ff4fd8", 15: "#ff9f1c"}
BCOL = {8.0: "#A9C1E0", 32.0: "#6B93C9", 128.0: "#2F5C9E", np.inf: "#111111"}
GUIDE = "#8a8a8a"

# type
TLS, ALS, LGS = 8.5, 9.5, 8.0                   # tick labels, axis labels (bold) ; legend text (regular)
RC = {"font.family": "serif", "font.serif": ["Times New Roman"],
      "mathtext.fontset": "custom", "mathtext.rm": "Times New Roman:bold",
      "mathtext.it": "Times New Roman:italic:bold", "mathtext.bf": "Times New Roman:bold",
      "mathtext.fallback": "stix",                      # glyphs missing in Times (e.g. nabla) come from STIX, not Computer Modern
      "axes.labelsize": ALS, "axes.labelweight": "bold", "xtick.labelsize": TLS, "ytick.labelsize": TLS,
      "svg.fonttype": "none", "pdf.fonttype": 42, "ps.fonttype": 42}
plt.rcParams.update(RC)

# ----------------------------------------------------------------- physics ----
hy, hx = np.meshgrid(np.arange(N) - c, np.arange(N) - c, indexing="ij")
SHELL = np.maximum(np.abs(hx), np.abs(hy))


def eps_beta(beta):
    rb = (rho_tilde >= ETA).astype(float) if np.isinf(beta) else P_beta(rho_tilde, beta, ETA)
    return EPS_B + rb * D_EPS


def spectrum(e):
    return np.fft.fftshift(np.fft.fft2(e)) / e.size


def band_limit(S, K):
    return np.real(np.fft.ifft2(np.fft.ifftshift(np.where(SHELL <= K, S, 0))) * S.size)


def sigma_curve(S):
    e_shell = np.bincount(SHELL.ravel(), weights=(np.abs(S) ** 2).ravel())
    beyond = np.cumsum(e_shell[::-1])[::-1]
    return np.sqrt(np.append(beyond[1:], 0.0)) / D_EPS


def tag(b):
    return "inf" if np.isinf(b) else f"{b:g}"


def beta_tex(b):
    return r"\beta\to\infty" if np.isinf(b) else rf"\beta={b:g}"


EPS = {b: eps_beta(b) for b in BETAS}
SPEC = {b: spectrum(e) for b, e in EPS.items()}
SIG = {b: sigma_curve(S) for b, S in SPEC.items()}
SEEN = {b: band_limit(SPEC[b], 2 * M_SEEN) for b in BETAS}
REF = abs(SPEC[np.inf][c, c])
SWEEP = np.array([sigma_curve(spectrum(eps_beta(b))) for b in BETA_SWEEP])
SIG_INF = SIG[np.inf]

gy, gx = np.gradient(rho_tilde)
G_LAMBDA = float(np.median(np.hypot(gx, gy)[np.abs(rho_tilde - ETA) < 0.01]) * N)
BETA_X = {M: 2 * np.pi ** 2 * M / G_LAMBDA for M in M_COLLAPSE}


def log_map(a):
    lo = np.log10(REF) - DECADES
    return np.clip((np.log10(np.maximum(a, 1e-300)) - lo) / DECADES, 0, 1)


# ---------------------------------------------------------------- drawing ----
def save(fig, name):
    os.makedirs(OUT, exist_ok=True)
    for ext in ("png", "svg", "pdf"):
        fig.savefig(os.path.join(OUT, f"{name}.{ext}"), dpi=300, facecolor="white")
    plt.close(fig)


def frame(ax, lw=1.5):
    ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values():
        s.set_linewidth(lw); s.set_color("black")


def draw_eps(ax, e):
    ax.imshow(e, cmap="gray_r", vmin=EPS_B, vmax=EPS_F, origin="lower", interpolation="bilinear")
    frame(ax)


def draw_spec(ax, b, lw=1.1):
    ext = [-SHOW - 0.5, SHOW + 0.5, -SHOW - 0.5, SHOW + 0.5]
    ax.imshow(log_map(np.abs(SPEC[b][c - SHOW:c + SHOW + 1, c - SHOW:c + SHOW + 1])), cmap=SPEC_CMAP,
              vmin=0, vmax=1, origin="lower", interpolation="nearest", extent=ext)
    for M in ORDERS:
        K = 2 * M
        ax.add_patch(Rectangle((-K - 0.5, -K - 0.5), 2 * K + 1, 2 * K + 1, fc="none", ec=WIN[M], lw=lw))
    frame(ax)


def style_line_axes(ax, labelled):
    ax.tick_params(direction="in", length=3, width=0.8, top=True, right=True, labelsize=TLS,
                   labelbottom=labelled, labelleft=labelled)
    ax.tick_params(which="minor", direction="in", length=1.5, width=0.5, top=True, right=True)
    for s in ax.spines.values():
        s.set_linewidth(1.0)


def bold_ticks(ax):
    for t in ax.get_xticklabels(which="both") + ax.get_yticklabels(which="both"):
        t.set_fontweight("bold")


def regular_legend(ax, **kw):
    kw.setdefault("handlelength", 1.4)
    leg = ax.legend(fontsize=LGS, frameon=False, borderaxespad=0.3, **kw)
    for t in leg.get_texts():                       # regular-weight legend: math in STIX (regular)
        t.set_math_fontfamily("stix")
        t.set_fontweight("normal")
    return leg


def draw_sigma_vs_K(ax, labelled):
    K = np.arange(1, K_MAX + 1)
    for M in ORDERS:
        ax.axvline(2 * M, color=WIN[M], lw=1.0, ls=(0, (3, 2)), zorder=1)
    kg = np.arange(8, K_MAX + 1)
    ax.plot(kg, 1.6 * SIG_INF[2 * ORDERS[-1]] * (kg / (2 * ORDERS[-1])) ** -0.5,
            color=GUIDE, lw=1.0, ls=(0, (1, 1.5)), zorder=2)
    for b in BETAS:
        ax.plot(K, SIG[b][K], color=BCOL[b], lw=1.4, zorder=3, label=rf"${beta_tex(b)}$")
        for M in ORDERS:
            if SIG[b][2 * M] > 1e-4:
                ax.plot(2 * M, SIG[b][2 * M], "o", ms=3.4, mfc=BCOL[b], mec="white", mew=0.6, zorder=4)
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlim(1, K_MAX); ax.set_ylim(1e-4, 1)
    style_line_axes(ax, labelled)
    if labelled:
        ax.set_xlabel("Window half-width $K$\n(order $M$ at $K$ = 2$M$)", labelpad=2)
        ax.set_ylabel("$\\sigma$ outside\n$|h|\\leq K$", labelpad=2)
        regular_legend(ax, loc="lower left", ncol=1, labelspacing=0.25, handletextpad=0.5, handlelength=1.2)
        bold_ticks(ax)


def draw_sigma_vs_beta(ax, labelled):
    for b in BETAS[:-1]:
        ax.axvline(b, color="#c8c8c8", lw=0.6, ls=(0, (1, 1.5)), zorder=0)
    for M in ORDERS:
        ax.axhline(SIG_INF[2 * M], color=WIN[M], lw=0.9, ls=(0, (3, 2)), zorder=1)
        ax.plot(BETA_SWEEP, SWEEP[:, 2 * M], color=WIN[M], lw=1.4, zorder=3, label=rf"$M={M}$")
        for b in BETAS[:-1]:
            ax.plot(b, SIG[b][2 * M], "o", ms=3.4, mfc=WIN[M], mec="white", mew=0.6, zorder=4)
    ax.set_xscale("log"); ax.set_xlim(*BETA_XLIM)
    ax.set_ylim(0, 1.32 * SIG_INF[2 * ORDERS[0]])          # head room above the M = 3 limit for the legend
    style_line_axes(ax, labelled)
    if labelled:
        ax.set_xlabel("Projection sharpness $\\beta$\n(dashed: $\\beta\\to\\infty$)", labelpad=2)
        ax.set_ylabel("$\\sigma_M$", labelpad=2)
        regular_legend(ax, loc="upper center", ncol=3, columnspacing=0.9, handletextpad=0.5)
        bold_ticks(ax)


def draw_collapse(ax, labelled):
    for M in M_COLLAPSE:
        col = WIN.get(M, "#b0b0b0")
        ax.plot(BETA_SWEEP / BETA_X[M], SWEEP[:, 2 * M] / SIG_INF[2 * M], color=col,
                lw=1.4 if M in WIN else 0.9, zorder=3 if M in WIN else 2, label=rf"$M={M}$")
    ax.axvline(1.0, color=GUIDE, lw=0.8, ls=(0, (1, 1.5)))
    ax.set_xscale("log"); ax.set_xlim(1e-2, 1e2); ax.set_ylim(0, 1.05)
    style_line_axes(ax, labelled)
    if labelled:
        ax.set_xlabel("$\\beta/\\beta_\\times$,  $\\beta_\\times=2\\pi^2M/(|\\nabla\\tilde\\rho|\\Lambda)$", labelpad=2)
        ax.set_ylabel("$\\sigma_M(\\beta)/\\sigma_M(\\infty)$", labelpad=2)
        regular_legend(ax, loc="upper left")
        bold_ticks(ax)


def square_fig(size=2.0):
    fig = plt.figure(figsize=(size, size), dpi=300)
    return fig, fig.add_axes([0.03, 0.03, 0.94, 0.94])


# ------------------------------------------------------------- composite ----
# 180 mm wide; sizes in inches
W, H = 180 / 25.4, 3.25
S_SQ, GAP = 0.84, 0.05
X0, Y0 = 0.46, 0.10
CB_W = 0.07
PX, PW = 5.12, 1.80                                 # right-hand plots: left edge and width of the axes


def composite(labelled):
    fig = plt.figure(figsize=(W, H), dpi=300)

    def axes_in(x, y, w, h):
        return fig.add_axes([x / W, y / H, w / W, h / H])

    rows = [("eps", 2), ("spec", 1), ("seen", 0)]
    for kind, r in rows:
        y = Y0 + r * (S_SQ + GAP)
        for j, b in enumerate(BETAS):
            ax = axes_in(X0 + j * (S_SQ + GAP), y, S_SQ, S_SQ)
            if kind == "eps":
                draw_eps(ax, EPS[b])
            elif kind == "spec":
                draw_spec(ax, b)
            else:
                draw_eps(ax, SEEN[b])
            if labelled and r == 2:
                ax.set_title(rf"${beta_tex(b)}$", fontsize=ALS, fontweight="bold", pad=3)
        cax = axes_in(X0 + 4 * S_SQ + 3 * GAP + 0.06, y, CB_W, S_SQ)
        cax.imshow(np.linspace(0, 1, 256)[:, None], cmap=SPEC_CMAP if kind == "spec" else "gray_r",
                   aspect="auto", origin="lower", extent=[0, 1, 0, 1])
        cax.set_xticks([]); cax.set_yticks([])
        for sp in cax.spines.values():
            sp.set_linewidth(0.8)
        if labelled:
            lab = {"eps": r"$\varepsilon_\beta(x,y)$", "spec": r"$|\hat\varepsilon_\beta(\mathbf{h})|$",
                   "seen": None}[kind]
            ytxt = (y + S_SQ / 2) / H
            if lab is not None:
                fig.text((X0 - 0.07) / W, ytxt, lab, rotation=90, ha="right", va="center", fontsize=ALS,
                         fontweight="bold")
            else:                                         # calligraphic P: STIX (no bold face), thin stroke
                t = fig.text((X0 - 0.07) / W, ytxt, rf"$\mathcal{{P}}_{{{M_SEEN}}}\,\varepsilon_\beta$", rotation=90,
                             ha="right", va="center", fontsize=ALS, math_fontfamily="stix")
                t.set_path_effects([pe.withStroke(linewidth=0.45, foreground="black")])
            lo, hi = {"eps": (r"$\varepsilon_b$", r"$\varepsilon_f$"), "spec": (rf"$10^{{-{DECADES:g}}}$", "1"),
                      "seen": (r"$\varepsilon_b$", r"$\varepsilon_f$")}[kind]
            cax.text(1.35, 0.0, lo, transform=cax.transAxes, fontsize=TLS, fontweight="bold", va="bottom")
            cax.text(1.35, 1.0, hi, transform=cax.transAxes, fontsize=TLS, fontweight="bold", va="top")
    ax1 = axes_in(PX, 2.12, PW, 1.02)
    draw_sigma_vs_K(ax1, labelled)
    ax2 = axes_in(PX, 0.60, PW, 0.92)
    draw_sigma_vs_beta(ax2, labelled)
    save(fig, "fig1c_v2" + ("_labelled" if labelled else ""))


composite(False)
composite(True)

for fn, name in ((draw_sigma_vs_K, "plot1_sigma_vs_K"), (draw_sigma_vs_beta, "plot2_sigma_vs_beta"),
                 (draw_collapse, "SI_collapse")):
    fig = plt.figure(figsize=(3.2, 2.5), dpi=300)
    ax = fig.add_axes([0.20, 0.24, 0.76, 0.70])
    fn(ax, True)
    save(fig, name + "_labelled")

print("written to", OUT)
