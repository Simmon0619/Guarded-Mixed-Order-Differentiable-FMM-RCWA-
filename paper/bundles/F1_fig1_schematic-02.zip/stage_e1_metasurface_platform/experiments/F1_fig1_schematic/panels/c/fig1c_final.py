"""
Fig. 1(c), final version (2026-09-26).  What truncated models of three nested orders see of one
density state while the projection sharpens.  Built on fig1c_spectrum_beta_order.py; the density
state is the Fig. 1(b) design, read from ../../fmm_pipeline.py (square cell, M_x = M_y = M).

  columns  beta = 8, 32, 128, inf   (8 = the projection panel of Fig. 1(b); inf = delivered pattern)
  row 1    eps_beta(x, y)                              grey, eps_b white -> eps_f black
  row 2    log10 |eps^_beta(h)| on viridis, |h_x|,|h_y| <= SHOW, with the windows W_M = {|h|_inf <= 2M}
           of M = 3, 7, 15 (the coefficients that enter C_M)
  row 3    P_M eps_beta for the lowest order M = 3: the permittivity the order-3 model uses
           (exact for the Laurent formulation: data/f1c_pipeline_design.json, check C)
  plot 1   sigma(K) vs window half-width K (log-log), one curve per column beta; K = 2M marked;
           dotted guide ~ K^(-1/2)
  plot 2   sigma_M(beta) for M = 3, 7, 15; dashed: binary limit; dots: the column betas
           sigma_M = RMS(eps_beta - P_M eps_beta) / (eps_f - eps_b)
                   = sqrt(sum over h outside W_M of |eps^_beta(h)|^2) / (eps_f - eps_b)   (Parseval)
  SI       scaling collapse sigma_M / sigma_M(inf) vs beta / beta_x, beta_x = 2 pi^2 M / (|grad rho~| Lambda);
           band-limited binary pattern P_M eps_bin for M = 3, 7, 15 (window 2M)

Paper panels carry no text (labels are added by hand, as for Fig. 1(b)); files named *_ref or
*_labelled are labelled references only.  Outputs go to ./final (png + svg).
"""
import os
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "final")
PIPE = os.path.normpath(os.path.join(HERE, "..", "..", "fmm_pipeline.py"))
MARK = "# ----------------------------- plotting"


# ------------------------------------------------ density state (shared) ----
def load_design(path):
    """Run fmm_pipeline.py up to its FIRST plotting marker and return its namespace."""
    src = open(path, encoding="utf-8").read()
    if MARK not in src:
        raise RuntimeError(f"plotting marker not found in {path}")
    ns = {"__name__": "fmm_pipeline_design"}
    exec(compile(src[:src.index(MARK)], path, "exec"), ns)
    missing = [k for k in ("rho_tilde", "tanh_projection", "ETA", "EPS_LOW", "EPS_HIGH") if k not in ns]
    if missing:
        raise RuntimeError(f"fmm_pipeline.py does not define {missing} above the plotting marker")
    return ns


_d = load_design(PIPE)
rho_tilde = np.asarray(_d["rho_tilde"], dtype=float)
P_beta = _d["tanh_projection"]
ETA, EPS_B, EPS_F = _d["ETA"], _d["EPS_LOW"], _d["EPS_HIGH"]
D_EPS = EPS_F - EPS_B

# ------------------------------------------------------------- parameters ----
BETAS = [8.0, 32.0, 128.0, np.inf]      # columns
ORDERS = [3, 7, 15]                     # nested orders (windows at K = 2M)
M_SEEN = ORDERS[0]                      # order whose view is shown in row 3 (= the order of Fig. 1(b))
SHOW = 34                               # spectrum shown for |h_x|, |h_y| <= SHOW
DECADES = 3.0                           # spectrum grey scale: this many decades below |eps^_bin(0, 0)|
K_MAX = 60                              # plot 1 range (kept well below Nyquist N/2)
BETA_SWEEP = np.geomspace(1.0, 1e5, 300)
BETA_XLIM = (1.0, 1e4)                  # plot 2 range
M_COLLAPSE = [3, 5, 7, 10, 15]

N = rho_tilde.shape[0]
c = N // 2
if rho_tilde.shape != (N, N):
    raise RuntimeError("square cell expected (M_x = M_y = M)")
if N < 4 * max(ORDERS) + 1 or N < 2 * SHOW + 1 or N // 2 <= K_MAX:
    raise RuntimeError(f"grid N = {N} too coarse for ORDERS/SHOW/K_MAX")

# colours.  Spectrum row on viridis.  Orders (window boxes AND their curves in the plots): hues absent
# from viridis -- red (= the viridis accent of Fig. 1(b)), magenta (= pipeline stage 8), orange (replaces
# the pipeline's white so that the same colour works as a line on white).  Checked in OKLab x100:
# pairwise dE >= 10.0 under protan/deutan/tritan (20.6 normal); each box vs the viridis values it sits on
# >= 33 (red on the bright core, magenta mid, orange on the dark outer region).
SPEC_CMAP = "viridis"
WIN = {3: "#ff2d2d", 7: "#ff4fd8", 15: "#ff9f1c"}
BCOL = {8.0: "#A9C1E0", 32.0: "#6B93C9", 128.0: "#2F5C9E", np.inf: "#111111"}   # beta: one-hue ramp, black = binary
GUIDE = "#8a8a8a"

plt.rcParams.update({"font.family": "sans-serif", "font.sans-serif": ["Arial", "DejaVu Sans"],
                     "mathtext.fontset": "stix", "svg.fonttype": "none"})

# ----------------------------------------------------------------- physics ----
hy, hx = np.meshgrid(np.arange(N) - c, np.arange(N) - c, indexing="ij")
SHELL = np.maximum(np.abs(hx), np.abs(hy))          # |h|_inf of every harmonic


def eps_beta(beta):
    rb = (rho_tilde >= ETA).astype(float) if np.isinf(beta) else P_beta(rho_tilde, beta, ETA)
    return EPS_B + rb * D_EPS


def spectrum(e):                                     # eps^(h), centred: S[c + h_y, c + h_x]
    return np.fft.fftshift(np.fft.fft2(e)) / e.size


def band_limit(S, K):                                # keep |h|_inf <= K, same real-space grid
    return np.real(np.fft.ifft2(np.fft.ifftshift(np.where(SHELL <= K, S, 0))) * S.size)


def sigma_curve(S):                                  # index K -> RMS outside |h|_inf <= K, / D_EPS
    e_shell = np.bincount(SHELL.ravel(), weights=(np.abs(S) ** 2).ravel())
    beyond = np.cumsum(e_shell[::-1])[::-1]
    return np.sqrt(np.append(beyond[1:], 0.0)) / D_EPS


def tag(b):
    return "inf" if np.isinf(b) else f"{b:g}"


def beta_tex(b):
    return r"\beta\to\infty" if np.isinf(b) else rf"\beta={b:g}"


EPS = {b: eps_beta(b) for b in BETAS}
SPEC = {b: spectrum(e) for b, e in EPS.items()}
SIG = {b: sigma_curve(S) for b, S in SPEC.items()}
SEEN = {b: band_limit(SPEC[b], 2 * M_SEEN) for b in BETAS}
REF = abs(SPEC[np.inf][c, c])                        # common colour reference: |eps^_bin(0, 0)|
SWEEP = np.array([sigma_curve(spectrum(eps_beta(b))) for b in BETA_SWEEP])   # [beta, K]
SIG_INF = SIG[np.inf]

gy, gx = np.gradient(rho_tilde)
G_LAMBDA = float(np.median(np.hypot(gx, gy)[np.abs(rho_tilde - ETA) < 0.01]) * N)
BETA_X = {M: 2 * np.pi ** 2 * M / G_LAMBDA for M in M_COLLAPSE}


def log_map(a):
    lo = np.log10(REF) - DECADES
    return np.clip((np.log10(np.maximum(a, 1e-300)) - lo) / DECADES, 0, 1)


# ---------------------------------------------------------------- drawing ----
def save(fig, name, transparent=False):
    os.makedirs(OUT, exist_ok=True)
    for ext in ("png", "svg"):
        fig.savefig(os.path.join(OUT, f"{name}.{ext}"), dpi=300, facecolor="white", transparent=transparent)
    plt.close(fig)


def frame(ax, lw=1.5):
    ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values():
        s.set_linewidth(lw); s.set_color("black")


def draw_eps(ax, e):
    ax.imshow(e, cmap="gray_r", vmin=EPS_B, vmax=EPS_F, origin="lower", interpolation="bilinear")
    frame(ax)


def draw_spec(ax, b, cmap=SPEC_CMAP, cols=None, lw=1.4):
    cols = WIN if cols is None else cols
    ext = [-SHOW - 0.5, SHOW + 0.5, -SHOW - 0.5, SHOW + 0.5]
    ax.imshow(log_map(np.abs(SPEC[b][c - SHOW:c + SHOW + 1, c - SHOW:c + SHOW + 1])), cmap=cmap,
              vmin=0, vmax=1, origin="lower", interpolation="nearest", extent=ext)
    for M in ORDERS:
        K = 2 * M
        ax.add_patch(Rectangle((-K - 0.5, -K - 0.5), 2 * K + 1, 2 * K + 1, fc="none", ec=cols[M], lw=lw))
    frame(ax)


def style_line_axes(ax, labelled, fs=7):
    ax.tick_params(direction="in", length=3, width=0.8, top=True, right=True, labelsize=fs,
                   labelbottom=labelled, labelleft=labelled)
    ax.tick_params(which="minor", direction="in", length=1.5, width=0.5, top=True, right=True)
    for s in ax.spines.values():
        s.set_linewidth(1.0)


def draw_sigma_vs_K(ax, labelled, fs=7):
    K = np.arange(1, K_MAX + 1)
    for M in ORDERS:
        ax.axvline(2 * M, color=WIN[M], lw=1.0, ls=(0, (3, 2)), zorder=1)
    kg = np.arange(8, K_MAX + 1)
    ax.plot(kg, 1.6 * SIG_INF[2 * ORDERS[-1]] * (kg / (2 * ORDERS[-1])) ** -0.5,
            color=GUIDE, lw=1.0, ls=(0, (1, 1.5)), zorder=2)
    for b in BETAS:
        ax.plot(K, SIG[b][K], color=BCOL[b], lw=1.4, zorder=3, label=rf"${beta_tex(b)}$")
        for M in ORDERS:
            if SIG[b][2 * M] > 1e-4:
                ax.plot(2 * M, SIG[b][2 * M], "o", ms=3.2, mfc=BCOL[b], mec="white", mew=0.6, zorder=4)
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlim(1, K_MAX); ax.set_ylim(1e-4, 1)
    style_line_axes(ax, labelled, fs)
    if labelled:
        ax.set_xlabel(r"window half-width $K$  (order $M$ at $K=2M$)", fontsize=fs)
        ax.set_ylabel(r"$\sigma$ outside $|h|\leq K$", fontsize=fs)
        ax.legend(fontsize=fs - 1, frameon=False, loc="lower left", ncol=2, columnspacing=0.8,
                  handlelength=1.4)


def draw_sigma_vs_beta(ax, labelled, fs=7):
    for b in BETAS[:-1]:
        ax.axvline(b, color="#c8c8c8", lw=0.6, ls=(0, (1, 1.5)), zorder=0)
    for M in ORDERS:
        ax.axhline(SIG_INF[2 * M], color=WIN[M], lw=0.9, ls=(0, (3, 2)), zorder=1)
        ax.plot(BETA_SWEEP, SWEEP[:, 2 * M], color=WIN[M], lw=1.4, zorder=3, label=rf"$M={M}$")
        for b in BETAS[:-1]:
            ax.plot(b, SIG[b][2 * M], "o", ms=3.2, mfc=WIN[M], mec="white", mew=0.6, zorder=4)
    ax.set_xscale("log"); ax.set_xlim(*BETA_XLIM)
    ax.set_ylim(0, 1.1 * SIG_INF[2 * ORDERS[0]])
    style_line_axes(ax, labelled, fs)
    if labelled:
        ax.set_xlabel(r"projection sharpness $\beta$  (dashed: $\beta\to\infty$)", fontsize=fs)
        ax.set_ylabel(r"$\sigma_M$", fontsize=fs)
        ax.legend(fontsize=fs - 1, frameon=False, loc="lower right", handlelength=1.4)


def draw_collapse(ax, labelled, fs=7):
    for M in M_COLLAPSE:
        col = WIN.get(M, "#b0b0b0")
        ax.plot(BETA_SWEEP / BETA_X[M], SWEEP[:, 2 * M] / SIG_INF[2 * M], color=col,
                lw=1.4 if M in WIN else 0.9, zorder=3 if M in WIN else 2, label=rf"$M={M}$")
    ax.axvline(1.0, color=GUIDE, lw=0.8, ls=(0, (1, 1.5)))
    ax.set_xscale("log"); ax.set_xlim(1e-2, 1e2); ax.set_ylim(0, 1.05)
    style_line_axes(ax, labelled, fs)
    if labelled:
        ax.set_xlabel(r"$\beta/\beta_\times$,  $\beta_\times=2\pi^2M/(|\nabla\tilde\rho|\Lambda)$", fontsize=fs)
        ax.set_ylabel(r"$\sigma_M(\beta)/\sigma_M(\infty)$", fontsize=fs)
        ax.legend(fontsize=fs - 1, frameon=False, loc="upper left", handlelength=1.4)


def square_fig(size=2.0):
    fig = plt.figure(figsize=(size, size), dpi=300)
    return fig, fig.add_axes([0.03, 0.03, 0.94, 0.94])


def colorbar(cmap, name):
    fig = plt.figure(figsize=(2.0, 0.2), dpi=300)
    ax = fig.add_axes([0.03, 0.1, 0.94, 0.8])
    ax.imshow(np.linspace(0, 1, 256)[None, :], cmap=cmap, aspect="auto", extent=[0, 1, 0, 1])
    ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values():
        s.set_linewidth(0.8)
    save(fig, name)


# ------------------------------------------------------- individual panels ----
for b in BETAS:
    fig, ax = square_fig(); draw_eps(ax, EPS[b]); save(fig, f"row1_eps_b{tag(b)}")
    fig, ax = square_fig(); draw_spec(ax, b); save(fig, f"row2_spec_b{tag(b)}")
    fig, ax = square_fig(); draw_eps(ax, SEEN[b]); save(fig, f"row3_seen_M{M_SEEN}_b{tag(b)}")
colorbar("gray_r", "colorbar_eps")
colorbar(SPEC_CMAP, "colorbar_spec")

for labelled in (False, True):
    sfx = "_ref" if labelled else ""
    for fn, name in ((draw_sigma_vs_K, "plot1_sigma_vs_K"), (draw_sigma_vs_beta, "plot2_sigma_vs_beta"),
                     (draw_collapse, "SI_collapse")):
        fig = plt.figure(figsize=(2.6, 2.0), dpi=300)
        ax = fig.add_axes([0.2, 0.2, 0.75, 0.74] if labelled else [0.05, 0.05, 0.9, 0.9])
        fn(ax, labelled)
        save(fig, name + sfx)

for M in ORDERS:                                      # SI: what order M sees of the delivered pattern
    fig, ax = square_fig(); draw_eps(ax, band_limit(SPEC[np.inf], 2 * M)); save(fig, f"SI_seen_binary_M{M}")


# --------------------------------------------------------------- composite ----
def composite(labelled):
    W, H = 7.2, 3.62
    s, gap = 0.98, 0.06                                # square panels and gaps (in)
    x0, y0 = 0.48, 0.28
    fig = plt.figure(figsize=(W, H), dpi=300)

    def axes_in(x, y, w, h):
        return fig.add_axes([x / W, y / H, w / W, h / H])

    rows = [("eps", 2), ("spec", 1), ("seen", 0)]
    for kind, r in rows:
        y = y0 + r * (s + gap)
        for j, b in enumerate(BETAS):
            ax = axes_in(x0 + j * (s + gap), y, s, s)
            if kind == "eps":
                draw_eps(ax, EPS[b])
            elif kind == "spec":
                draw_spec(ax, b, lw=1.1)
            else:
                draw_eps(ax, SEEN[b])
            if labelled and r == 2:
                ax.set_title(rf"${beta_tex(b)}$", fontsize=8, pad=3)
        cax = axes_in(x0 + 4 * s + 3 * gap + 0.06, y, 0.07, s)
        cax.imshow(np.linspace(0, 1, 256)[:, None], cmap=SPEC_CMAP if kind == "spec" else "gray_r",
                   aspect="auto", origin="lower",
                   extent=[0, 1, 0, 1])
        cax.set_xticks([]); cax.set_yticks([])
        for sp in cax.spines.values():
            sp.set_linewidth(0.8)
        if labelled:
            lab = {"eps": r"$\varepsilon_\beta(x,y)$", "spec": r"$|\hat\varepsilon_\beta(\mathbf{h})|$",
                   "seen": rf"$\mathcal{{P}}_{{{M_SEEN}}}\,\varepsilon_\beta$"}[kind]
            fig.text((x0 - 0.08) / W, (y + s / 2) / H, lab, rotation=90, ha="right", va="center", fontsize=8)
            lo, hi = {"eps": (r"$\varepsilon_b$", r"$\varepsilon_f$"), "spec": (rf"$10^{{-{DECADES:g}}}$", "1"),
                      "seen": (r"$\varepsilon_b$", r"$\varepsilon_f$")}[kind]
            cax.text(1.4, 0.0, lo, transform=cax.transAxes, fontsize=6, va="bottom")
            cax.text(1.4, 1.0, hi, transform=cax.transAxes, fontsize=6, va="top")
    px, pw, ph = 5.45, 1.62, 1.28
    ax1 = axes_in(px, y0 + 3 * s + 2 * gap - ph, pw, ph)
    draw_sigma_vs_K(ax1, labelled, fs=6)
    ax2 = axes_in(px, y0 + 0.05, pw, ph)
    draw_sigma_vs_beta(ax2, labelled, fs=6)
    save(fig, "fig1c_composite" + ("_labelled" if labelled else ""))


composite(False)
composite(True)

# ----------------------------------------------------------------- numbers ----
report = {
    "design": "fmm_pipeline.py (Fig. 1(b) design)", "N": N, "betas": [tag(b) for b in BETAS],
    "orders": ORDERS, "M_seen": M_SEEN,
    "sigma_M_at_columns": {tag(b): {M: float(SIG[b][2 * M]) for M in ORDERS} for b in BETAS},
    "grad_rho_tilde_Lambda_median_on_contour": G_LAMBDA,
    "beta_x_pred": {M: float(BETA_X[M]) for M in M_COLLAPSE},
    "beta_half": {M: float(np.interp(0.5 * SIG_INF[2 * M], SWEEP[:, 2 * M], BETA_SWEEP)) for M in M_COLLAPSE},
    "binary_sigma_slope_K6_30": float(np.polyfit(np.log(np.arange(6, 31)), np.log(SIG_INF[6:31]), 1)[0]),
}
with open(os.path.join(OUT, "fig1c_numbers.json"), "w", encoding="utf-8") as f:
    json.dump(report, f, indent=1)
print("sigma_M at the column betas (M = " + ", ".join(map(str, ORDERS)) + "):")
for b in BETAS:
    print(f"  beta {tag(b):>4}: " + "  ".join(f"{SIG[b][2 * M]:.4f}" for M in ORDERS))
print("beta_1/2 / beta_x:", {M: round(report['beta_half'][M] / BETA_X[M], 2) for M in M_COLLAPSE},
      f"| |grad rho~| Lambda = {G_LAMBDA:.2f} | binary slope {report['binary_sigma_slope_K6_30']:.3f}")
