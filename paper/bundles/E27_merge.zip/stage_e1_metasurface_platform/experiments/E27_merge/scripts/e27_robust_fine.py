"""Part C: maximin robust chains on the fine-pixel records.

Start = 1_0_w5nm / 2_0_w5nm latents (the most fragile records, worst-ratio
0.01/0.03).  Accept score = min(eta_nominal, eta_cd+20nm) at (24,6)@native
(m<=2 safe per D-012), 40 jumps, descent (16,4)@5nm.  Final verification:
(32,8)/(40,10) nominal + full 4-scenario held-out at c128/CPU.

    python e27_robust_fine.py         # writes ../data/robust_fine.json
"""
import json
import os
import sys
import time

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.abspath(os.path.join(
    _HERE, "..", "..", "E26_fine_pixels", "scripts")))

from e26_common import (C, FINE, THREADS, eta_c128, eta_gpu,  # noqa: E402
                        filtered_noise, redescend)
from trustworthy_fmm.fabrication.process import periodic_binary_morphology  # noqa: E402

E26_DATA = os.path.abspath(os.path.join(
    _HERE, "..", "..", "E26_fine_pixels", "data"))
DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))

CFG = FINE[5]
ALPHAS = [0.1, 0.25, 0.5]
N_JUMPS = 40
CHAINS = [
    ((1, 0), "1_0_w5nm", {"nominal20_record": 0.8017,
                          "worst_now": 0.0047}),
    ((2, 0), "2_0_w5nm", {"nominal20_record": 0.8300,
                          "worst_now": 0.0278}),
]


def maximin(binary, target):
    nom = eta_gpu(binary, (24, 6), target, CFG)
    mask = binary.numpy().astype(bool)
    cd = torch.from_numpy(C.cd_bias_mask(mask, 20.0, CFG))
    worst = eta_gpu(cd, (24, 6), target, CFG)
    return min(nom, worst), nom, worst


def held_out(binary, target):
    mask = binary.numpy().astype(bool)
    nominal = eta_c128(binary, (24, 6), target, CFG)
    held = {"nominal_24_6": nominal}
    for bias in (-20.0, 20.0):
        pert = torch.from_numpy(C.cd_bias_mask(mask, bias, CFG))
        held["cd_{:+.0f}nm".format(bias)] = eta_c128(pert, (24, 6), target,
                                                     CFG)
    for op in ("opening", "closing"):
        pert = periodic_binary_morphology(mask, op, 40.0, CFG.pixel_yx)
        held["{}_40nm".format(op)] = eta_c128(
            torch.from_numpy(np.asarray(pert, dtype=np.float64)),
            (24, 6), target, CFG)
    scen = {k: v for k, v in held.items() if k != "nominal_24_6"}
    held["worst_absolute"] = min(scen.values())
    held["worst_relative"] = min(scen.values()) / max(nominal, 1e-12)
    held["worst_scenario"] = min(scen, key=scen.get)
    return held


def main():
    torch.set_num_threads(THREADS)
    os.makedirs(DATA, exist_ok=True)
    out = {"chains": {}}
    for tgt, src, refs in CHAINS:
        t0 = time.perf_counter()
        incumbent = torch.from_numpy(np.load(os.path.join(
            E26_DATA, src + "_latent.npy")).astype("float64"))
        inc_bin = C.hard_binary(incumbent, CFG)
        inc_score, inc_nom, inc_cd = maximin(inc_bin, tgt)
        start = {"score": inc_score, "nominal": inc_nom, "cd20": inc_cd}
        print("%s start: maximin %.4f (nom %.4f cd %.4f)"
              % (tgt, inc_score, inc_nom, inc_cd), flush=True)
        jumps, accepts = [], 0
        for j in range(N_JUMPS):
            alpha = ALPHAS[j % len(ALPHAS)]
            noise = filtered_noise(39100 + 1000 * tgt[0] + j, CFG)
            pert = C.symmetrize(
                (incumbent + alpha * C.DEFAULT.init_scale * noise)
                .clamp(0, 1))
            rho = redescend(pert, tgt, CFG)
            b = C.hard_binary(rho, CFG)
            score, nom, cd = maximin(b, tgt)
            acc = score > inc_score
            jumps.append({"jump": j, "alpha": alpha, "score": score,
                          "nominal": nom, "cd20": cd, "accepted": bool(acc)})
            if acc:
                incumbent, inc_bin = rho, b
                inc_score, inc_nom, inc_cd = score, nom, cd
                accepts += 1
            print("%s jump %2d a=%.2f: maximin %.4f (nom %.4f cd %.4f) "
                  "(inc %.4f) %s [%.0f s]"
                  % (tgt, j, alpha, score, nom, cd, inc_score,
                     "ACCEPT" if acc else "reject",
                     time.perf_counter() - t0), flush=True)
        tag = "%d_%d_robust5nm" % tgt
        np.save(os.path.join(DATA, tag + "_binary.npy"), inc_bin.numpy())
        np.save(os.path.join(DATA, tag + "_latent.npy"), incumbent.numpy())
        e32 = eta_gpu(inc_bin, (32, 8), tgt, CFG)
        e40 = eta_gpu(inc_bin, (40, 10), tgt, CFG)
        held = held_out(inc_bin, tgt)
        success = (held["worst_absolute"] >= 0.10
                   and e40 >= refs["nominal20_record"])
        out["chains"][str(tgt)] = {
            "source": src, "refs": refs, "start": start,
            "final": {"score": inc_score, "nominal": inc_nom,
                      "cd20": inc_cd},
            "accepts": accepts, "jumps": jumps,
            "eta_32_8": e32, "eta_40_10": e40, "held_out": held,
            "prereg_success": bool(success),
            "wall_s": time.perf_counter() - t0, "files": tag,
        }
        print("%s done: maximin %.4f -> %.4f (%d/%d) | (40,10) %.4f | "
              "held-out worst %.4f (%.2f, %s) | prereg success: %s"
              % (tgt, start["score"], inc_score, accepts, N_JUMPS, e40,
                 held["worst_absolute"], held["worst_relative"],
                 held["worst_scenario"], success), flush=True)
    with open(os.path.join(DATA, "robust_fine.json"), "w") as f:
        json.dump(out, f, indent=1)
    print("wrote robust_fine.json")


if __name__ == "__main__":
    main()
