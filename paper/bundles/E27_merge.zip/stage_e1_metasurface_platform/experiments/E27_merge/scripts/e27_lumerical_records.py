"""Part A: Lumerical RCWA cross-check of the E26 fine-pixel records.

Same pipeline as E25 (exact pixel-boundary polygons -> addpoly -> RCWA solver,
P source), generalized to the fine grids (10/5 nm pixels).

    python e27_lumerical_records.py   # writes ../data/lumerical_records.json
"""
import json
import os
import sys
import time

import numpy as np

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.append(r"C:\Program Files\Lumerical\v241\api\python")
sys.path.insert(0, _HERE)
sys.path.insert(0, os.path.abspath(os.path.join(
    _HERE, "..", "..", "E25_lumerical_xcheck", "scripts")))
sys.path.insert(0, os.path.abspath(os.path.join(
    _HERE, "..", "..", "E24_grid_field", "scripts")))

import lumapi  # noqa: E402
import torch  # noqa: E402

from e25_polygons import export  # noqa: E402
from e25_run_lumerical import (H, LAM, N_MAT, run_and_extract,  # noqa: E402
                               setup_solver)

E26_DATA = os.path.abspath(os.path.join(
    _HERE, "..", "..", "E26_fine_pixels", "data"))
DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))

RECORDS = [
    ("1_0_w5nm", (1, 0), 5.0, {"(32,8)": 0.9022, "(40,10)": 0.8952,
                               "(48,12)": 0.8875}),
    ("2_0_w5nm", (2, 0), 5.0, {"(32,8)": 0.8707, "(40,10)": 0.8564,
                               "(48,12)": 0.8462}),
    ("3_0_w10nm", (3, 0), 10.0, {"(32,8)": 0.5249, "(40,10)": 0.4943,
                                 "(48,12)": 0.4392}),
]
KVECS = [201, 401, 801]


def add_pattern_px(fdtd, mask, pixel_nm):
    outers, holes = export(mask, pixel_nm=(pixel_nm, pixel_nm))
    for i, poly in enumerate(outers):
        fdtd.addpoly()
        name = "mat_%03d" % i
        fdtd.set("name", name)
        fdtd.setnamed(name, "vertices", poly * 1e-9)
        fdtd.setnamed(name, "z min", 0.0)
        fdtd.setnamed(name, "z max", H)
        fdtd.setnamed(name, "index", N_MAT)
    for i, poly in enumerate(holes):
        fdtd.addpoly()
        name = "hole_%03d" % i
        fdtd.set("name", name)
        fdtd.setnamed(name, "vertices", poly * 1e-9)
        fdtd.setnamed(name, "z min", 0.0)
        fdtd.setnamed(name, "z max", H)
        fdtd.setnamed(name, "index", 1.0)
        fdtd.setnamed(name, "override mesh order from material database", 1)
        fdtd.setnamed(name, "mesh order", 2)
    return len(outers), len(holes)


def main():
    os.makedirs(DATA, exist_ok=True)
    out = {"kvecs": KVECS, "designs": {}}
    t0 = time.perf_counter()
    fdtd = lumapi.FDTD(hide=True)
    for name, tgt, px, ours in RECORDS:
        mask = np.load(os.path.join(E26_DATA, name + "_binary.npy"))
        rec = {"ours_native_band": ours, "pixel_nm": px, "lumerical": {}}
        for n_k in KVECS:
            fdtd.switchtolayout()
            fdtd.deleteall()
            setup_solver(fdtd, n_k)
            n_out, n_holes = add_pattern_px(fdtd, mask, px)
            t1 = time.perf_counter()
            lum = run_and_extract(fdtd, tgt)
            lum["wall_s"] = time.perf_counter() - t1
            lum["n_polygons"] = [n_out, n_holes]
            rec["lumerical"][str(n_k)] = lum
            print("%s k=%3d: eta_lum %.4f (T %.4f, %d+%d polys, %.0f s) | "
                  "ours band %s   [%.0f s]"
                  % (name, n_k, lum["eta_target_Tp"], lum["Tp_total"],
                     n_out, n_holes, lum["wall_s"], ours,
                     time.perf_counter() - t0), flush=True)
        out["designs"][name] = rec
    fdtd.close()
    with open(os.path.join(DATA, "lumerical_records.json"), "w") as f:
        json.dump(out, f, indent=1)
    print("wrote lumerical_records.json")


if __name__ == "__main__":
    main()
