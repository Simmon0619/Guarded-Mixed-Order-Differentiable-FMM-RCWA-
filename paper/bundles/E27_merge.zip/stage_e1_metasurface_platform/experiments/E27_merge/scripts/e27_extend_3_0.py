"""Part B: (3,0)@10nm chain extension (+40 jumps, (16,4) descent) and an
equal-wall (20,5)-descent variant (~20 jumps) from the same incumbent.
Gate (32,8)@native throughout; final ladder (40,10)/(48,12).

    python e27_extend_3_0.py          # writes ../data/extend_3_0.json
"""
import json
import os
import sys
import time

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.abspath(os.path.join(
    _HERE, "..", "..", "E26_fine_pixels", "scripts")))

from e26_common import (C, FINE, GATE_LEVEL, THREADS, eta_gpu,  # noqa: E402
                        filtered_noise)

E26_DATA = os.path.abspath(os.path.join(
    _HERE, "..", "..", "E26_fine_pixels", "data"))
DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))

TGT = (3, 0)
CFG = FINE[10]
ALPHAS = [0.1, 0.25, 0.5]


def redescend(rho0, level, steps=30):
    rho = rho0.to("cuda")
    adam = C.Adam(rho.shape, CFG)
    for t in range(steps):
        lr = C.cosine_lr(t / steps, CFG)
        _, g = C.value_grad_latent(rho, level, TGT, 64.0, CFG)
        rho = adam.step(rho, g, lr)
    return rho.cpu()


def run_chain(tag, lat0, bin0, eta0, level, n_jumps, seed_base):
    incumbent, inc_bin, inc_eta = lat0.clone(), bin0.clone(), eta0
    jumps, accepts = [], 0
    t0 = time.perf_counter()
    for j in range(n_jumps):
        alpha = ALPHAS[j % len(ALPHAS)]
        noise = filtered_noise(seed_base + j, CFG)
        pert = C.symmetrize(
            (incumbent + alpha * C.DEFAULT.init_scale * noise).clamp(0, 1))
        rho = redescend(pert, level)
        b = C.hard_binary(rho, CFG)
        e = eta_gpu(b, GATE_LEVEL, TGT, CFG)
        acc = e > inc_eta
        jumps.append({"jump": j, "alpha": alpha, "eta": e,
                      "accepted": bool(acc)})
        if acc:
            incumbent, inc_bin, inc_eta = rho, b, e
            accepts += 1
        print("%s jump %2d a=%.2f: gate %.4f (inc %.4f) %s [%.0f s]"
              % (tag, j, alpha, e, inc_eta, "ACCEPT" if acc else "reject",
                 time.perf_counter() - t0), flush=True)
    return {"tag": tag, "descent": list(level), "start": eta0,
            "final": inc_eta, "accepts": accepts, "n_jumps": n_jumps,
            "jumps": jumps, "wall_s": time.perf_counter() - t0,
            "latent": incumbent, "binary": inc_bin}


def main():
    torch.set_num_threads(THREADS)
    os.makedirs(DATA, exist_ok=True)
    lat0 = torch.from_numpy(np.load(os.path.join(
        E26_DATA, "3_0_w10nm_latent.npy")).astype("float64"))
    bin0 = C.hard_binary(lat0, CFG)
    eta0 = eta_gpu(bin0, GATE_LEVEL, TGT, CFG)
    print("incumbent gate: %.4f (E26 recorded 0.5249)" % eta0, flush=True)

    b1 = run_chain("B1(16,4)x40", lat0, bin0, eta0, (16, 4), 40, 19100)
    b2 = run_chain("B2(20,5)x20", lat0, bin0, eta0, (20, 5), 20, 29100)

    out = {"incumbent_gate": eta0, "arms": {}}
    for r in (b1, b2):
        e40 = eta_gpu(r["binary"], (40, 10), TGT, CFG)
        e48 = eta_gpu(r["binary"], (48, 12), TGT, CFG)
        np.save(os.path.join(DATA, "3_0_%s_binary.npy"
                             % r["tag"].split("(")[0]), r["binary"].numpy())
        np.save(os.path.join(DATA, "3_0_%s_latent.npy"
                             % r["tag"].split("(")[0]), r["latent"].numpy())
        out["arms"][r["tag"]] = {k: v for k, v in r.items()
                                 if k not in ("latent", "binary")}
        out["arms"][r["tag"]].update({"eta_40_10": e40, "eta_48_12": e48,
                                      "gain_per_ks": (r["final"] - eta0)
                                      / max(r["wall_s"], 1) * 1000})
        print("%s: gate %.4f -> %.4f (%d/%d), (40,10) %.4f, (48,12) %.4f, "
              "%.0f s" % (r["tag"], eta0, r["final"], r["accepts"],
                          r["n_jumps"], e40, e48, r["wall_s"]), flush=True)
    with open(os.path.join(DATA, "extend_3_0.json"), "w") as f:
        json.dump(out, f, indent=1)
    print("wrote extend_3_0.json")


if __name__ == "__main__":
    main()
