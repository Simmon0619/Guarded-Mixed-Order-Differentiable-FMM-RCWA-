"""Fixed/adaptive-fidelity optimization comparison.

The runner is intentionally transparent rather than optimizer-heavy.  Every
method uses the same normalized gradient step and initialization; methods differ
only in the solver fidelity and candidate acceptance policy.
"""

import math
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

import numpy as np
import torch

from trustworthy_fmm.audit.gradients import gradient_cosine, local_model_ratio
from trustworthy_fmm.fabrication.process import gaussian_smooth, tanh_projection
from trustworthy_fmm.fidelity.policy import FidelityThresholds, decide_fidelity
from trustworthy_fmm.optimization.trust_region import bounded_gradient_step
from trustworthy_fmm.solvers.rcwa_1d import solve_1d_te, solve_1d_tm


METHODS = (
    "fixed_low",
    "fixed_high",
    "forward_adaptive",
    "joint_adaptive",
    "joint_trust",
)


@dataclass(frozen=True)
class Family:
    name: str
    samples: int
    n_low: float
    n_high: float
    polarization: str
    theta_deg: float
    target_order: Tuple[int, int]
    filter_sigma_px: float
    beta: float
    initialization: str


def _families(config: Mapping[str, Any]) -> Sequence[Family]:
    return (
        Family("smooth_low_contrast_1d", 64, 1.0, 1.6, "te", 7.0, (1, 0), 2.0, 4.0, "random"),
        Family("high_index_binary_tm_1d", 64, 1.0, 3.4, "tm", 5.0, (1, 0), 0.8, 16.0, "random"),
        Family("project_candidate_119", 120, 1.0, 2.02, "tm", 0.0, (3, 0), 1.0, 12.0, "candidate_119"),
    )


def _candidate_119(workspace_root: Path) -> np.ndarray:
    asset = workspace_root / "stage_c1_topopt_freeform" / "analysis" / "freeform_1d_reduced_basis_round2_seed49_4_minus1penalty_k91" / "candidate_masks.npz"
    with np.load(str(asset), allow_pickle=False) as data:
        index = int(np.flatnonzero(data["candidate_ids"] == 119)[0])
        return data["masks"][index].astype(np.float64)


def _initialize(family: Family, seed: int, workspace_root: Path) -> torch.Tensor:
    generator = torch.Generator().manual_seed(seed)
    if family.initialization == "candidate_119":
        mask = torch.as_tensor(_candidate_119(workspace_root), dtype=torch.float64)
        raw = torch.where(mask > 0.5, torch.full_like(mask, 2.5), torch.full_like(mask, -2.5))
        return raw + 0.05 * torch.randn(raw.shape, dtype=raw.dtype, generator=generator)
    return 0.35 * torch.randn(family.samples, dtype=torch.float64, generator=generator)


def _density(raw: torch.Tensor, family: Family) -> torch.Tensor:
    density = torch.sigmoid(raw)
    density = gaussian_smooth(density, family.filter_sigma_px)
    return tanh_projection(density, family.beta)


def _objective(raw: torch.Tensor, family: Family, half_order: int) -> torch.Tensor:
    density = _density(raw, family)
    required_samples = 4 * half_order + 1
    if density.numel() < required_samples:
        repeat = int(math.ceil(required_samples / density.numel()))
        density = torch.repeat_interleave(density, repeat)
    epsilon = family.n_low ** 2 + (family.n_high ** 2 - family.n_low ** 2) * density
    solver = solve_1d_te if family.polarization == "te" else solve_1d_tm
    result = solver(
        epsilon.to(torch.complex128),
        420.0 if family.name != "project_candidate_119" else 700.0,
        660.0,
        1200.0 if family.name != "project_candidate_119" else 2400.0,
        1.0 if family.name != "project_candidate_119" else 1.46,
        1.46 if family.name != "project_candidate_119" else 1.0,
        half_order,
        family.theta_deg,
    )
    return result.transmitted_power(family.target_order)


def _value_gradient(raw: torch.Tensor, family: Family, half_order: int) -> Tuple[float, torch.Tensor]:
    work = raw.detach().clone().requires_grad_(True)
    value = _objective(work, family, half_order)
    gradient = torch.autograd.grad(value, work)[0]
    return float(value.detach()), gradient.detach()


def optimize_one(
    family: Family,
    method: str,
    seed: int,
    workspace_root: Path,
    *,
    iterations: int,
    low_order: int,
    validation_order: int,
    order_increment: int,
    audit_interval: int,
    initial_radius: float,
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    if method not in METHODS:
        raise ValueError("unknown method {}".format(method))
    raw = _initialize(family, seed, workspace_root)
    initial = raw.clone()
    current_order = validation_order if method == "fixed_high" else low_order
    trust_radius = initial_radius
    high_calls = 0
    solver_calls = 0
    gradient_calls = 0
    rejected = 0
    trace: List[Dict[str, Any]] = []
    started = time.perf_counter()
    thresholds = FidelityThresholds(
        order_increment=order_increment,
        max_fourier_order=validation_order,
    )
    for iteration in range(iterations):
        value, gradient = _value_gradient(raw, family, current_order)
        solver_calls += 1
        gradient_calls += 1
        high_calls += int(current_order == validation_order)
        proposed_step = bounded_gradient_step(gradient, trust_radius, maximize=True)
        candidate = torch.clamp(raw + proposed_step, -6.0, 6.0)
        forward_error = float("nan")
        cosine = float("nan")
        ratio = float("nan")
        action = "accept_fixed"
        accepted = True
        audit_due = (iteration + 1) % audit_interval == 0
        if method in ("forward_adaptive", "joint_adaptive", "joint_trust") and audit_due:
            check_order = min(current_order + order_increment, validation_order)
            high_value, high_gradient = _value_gradient(raw, family, check_order)
            solver_calls += 1
            gradient_calls += 1
            high_calls += 1
            forward_error = abs(high_value - value) / max(abs(high_value), 1e-12)
            cosine = gradient_cosine(gradient, high_gradient)
            decision = decide_fidelity(
                fourier_order=current_order,
                trust_radius=trust_radius,
                forward_error=forward_error,
                gradient_cosine=None if method == "forward_adaptive" else cosine,
                local_ratio=None,
                thresholds=thresholds,
            )
            action = decision.action
            trust_radius = decision.trust_radius
            if decision.fourier_order != current_order:
                current_order = decision.fourier_order
                value, gradient = _value_gradient(raw, family, current_order)
                solver_calls += 1
                gradient_calls += 1
                high_calls += int(current_order == validation_order)
                proposed_step = bounded_gradient_step(gradient, trust_radius, maximize=True)
                candidate = torch.clamp(raw + proposed_step, -6.0, 6.0)
            if method == "joint_trust":
                candidate_value = float(_objective(candidate, family, check_order).detach())
                solver_calls += 1
                high_calls += 1
                ratio = local_model_ratio(high_value, candidate_value, high_gradient, candidate - raw)
                trust_decision = decide_fidelity(
                    fourier_order=current_order,
                    trust_radius=trust_radius,
                    forward_error=0.0,
                    gradient_cosine=1.0,
                    local_ratio=ratio,
                    thresholds=thresholds,
                )
                action = action + "+" + trust_decision.action
                accepted = trust_decision.accepted
                trust_radius = trust_decision.trust_radius
        if accepted:
            raw = candidate.detach()
        else:
            rejected += 1
        trace.append(
            {
                "family": family.name,
                "method": method,
                "seed": seed,
                "iteration": iteration,
                "fourier_order": current_order,
                "training_value": value,
                "forward_error": forward_error,
                "gradient_cosine": cosine,
                "local_ratio": ratio,
                "trust_radius": trust_radius,
                "accepted": accepted,
                "action": action,
            }
        )
    initial_validation = float(_objective(initial, family, validation_order).detach())
    final_training = float(_objective(raw, family, current_order).detach())
    final_validation = float(_objective(raw, family, validation_order).detach())
    solver_calls += 3
    high_calls += 2 + int(current_order == validation_order)
    runtime = time.perf_counter() - started
    summary = {
        "family": family.name,
        "method": method,
        "seed": seed,
        "iterations": iterations,
        "initial_validation": initial_validation,
        "final_training": final_training,
        "final_validation": final_validation,
        "validation_gain": final_validation - initial_validation,
        "training_validation_gap": final_training - final_validation,
        "false_optimum": final_training - final_validation >= 0.02,
        "final_order": current_order,
        "high_fidelity_calls": high_calls,
        "solver_calls": solver_calls,
        "gradient_calls": gradient_calls,
        "rejected_steps": rejected,
        "runtime_seconds": runtime,
        "final_raw": raw.detach().cpu().numpy(),
        "final_density": _density(raw, family).detach().cpu().numpy(),
    }
    return trace, summary


def run_false_optimum_campaign(
    config: Mapping[str, Any],
    workspace_root: Path,
    *,
    smoke: bool = False,
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], Dict[str, Any]]:
    optimization = config["optimization"]
    fidelities = config["fidelities"]
    iterations = min(5, optimization["iterations"]) if smoke else int(optimization["iterations"])
    seeds = config["seeds"][:1] if smoke else config["seeds"]
    families = _families(config)[:1] if smoke else _families(config)
    methods = METHODS[:2] if smoke else METHODS
    traces: List[Dict[str, Any]] = []
    summaries: List[Dict[str, Any]] = []
    for family in families:
        for seed in seeds:
            for method in methods:
                trace, summary = optimize_one(
                    family,
                    method,
                    int(seed),
                    workspace_root,
                    iterations=iterations,
                    low_order=int(fidelities["low_half_order"]),
                    validation_order=int(fidelities["validation_half_order"]),
                    order_increment=int(fidelities["order_increment"]),
                    audit_interval=int(optimization["audit_interval"]),
                    initial_radius=float(
                        optimization.get("trust_radius", optimization.get("learning_rate", 0.03))
                    ),
                )
                traces.extend(trace)
                summaries.append(summary)
    false_count = sum(bool(row["false_optimum"]) for row in summaries)
    method_summary: Dict[str, Dict[str, Any]] = {}
    for method in methods:
        selected = [row for row in summaries if row["method"] == method]
        method_summary[method] = {
            "runs": len(selected),
            "mean_final_validation": float(np.mean([row["final_validation"] for row in selected])),
            "mean_runtime_seconds": float(np.mean([row["runtime_seconds"] for row in selected])),
            "false_optimum_rate": float(np.mean([row["false_optimum"] for row in selected])),
            "mean_high_fidelity_calls": float(np.mean([row["high_fidelity_calls"] for row in selected])),
        }
    family_go: Dict[str, Dict[str, Any]] = {}
    required = int(config["go_thresholds"]["initializations_required"])
    for family in families:
        fixed_low = [
            row for row in summaries
            if row["family"] == family.name and row["method"] == "fixed_low"
        ]
        drop_count = sum(bool(row["false_optimum"]) for row in fixed_low)
        ranking_reversal = False
        if len(fixed_low) >= 2:
            low_rank = [row["seed"] for row in sorted(fixed_low, key=lambda x: x["final_training"], reverse=True)]
            high_rank = [row["seed"] for row in sorted(fixed_low, key=lambda x: x["final_validation"], reverse=True)]
            ranking_reversal = low_rank != high_rank
        family_go[family.name] = {
            "fixed_low_runs": len(fixed_low),
            "drop_at_least_0p02_count": drop_count,
            "ranking_reversal": ranking_reversal,
            "go": drop_count >= required or ranking_reversal,
        }
    fixed_high = method_summary.get("fixed_high")
    fixed_low_summary = method_summary.get("fixed_low")
    method_advantage: Dict[str, Dict[str, Any]] = {}
    if fixed_high:
        for method in methods:
            if method in ("fixed_low", "fixed_high"):
                continue
            row = method_summary[method]
            runtime_reduction = 1.0 - row["mean_runtime_seconds"] / max(fixed_high["mean_runtime_seconds"], 1e-12)
            false_reduction = (
                0.0
                if not fixed_low_summary or fixed_low_summary["false_optimum_rate"] == 0.0
                else 1.0 - row["false_optimum_rate"] / fixed_low_summary["false_optimum_rate"]
            )
            fom_gain = row["mean_final_validation"] - fixed_high["mean_final_validation"]
            method_advantage[method] = {
                "runtime_reduction": runtime_reduction,
                "false_optimum_reduction": false_reduction,
                "iteration_matched_high_fidelity_fom_gain": fom_gain,
                "same_budget_fom_gain_evaluable": False,
                "passes_any_frozen_threshold": (
                    runtime_reduction >= 0.30 or false_reduction >= 0.50
                ),
            }
    report = {
        "smoke": smoke,
        "runs": len(summaries),
        "false_optimum_runs": false_count,
        "false_optimum_rate": false_count / max(len(summaries), 1),
        "gate_evaluable": not smoke and len(families) == 3 and len(seeds) >= 5,
        "family_go": family_go,
        "method_summary": method_summary,
        "method_advantage": method_advantage,
        "goal4a_go": any(row["go"] for row in family_go.values()),
        "goal5_pass": any(row["passes_any_frozen_threshold"] for row in method_advantage.values()),
    }
    return traces, summaries, report
