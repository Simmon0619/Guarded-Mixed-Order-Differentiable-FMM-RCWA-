"""E24 wiring: grid-refinement tests and field/phase extraction.

Same conventions as E20: fast paths on, GPU/c64 for scans, c128/CPU where
amplitude/phase fidelity is reported; delivered binaries are piecewise-constant
on the frozen 35x120 grid, k-x block replication is the exact same physical
structure with a different DFT aliasing sum.
"""
import os
import sys

import numpy as np
import torch

THREADS = int(os.environ.get("P0_THREADS", "3"))
torch.set_num_threads(THREADS)

_HERE = os.path.dirname(os.path.abspath(__file__))
_E16_SCRIPTS = os.path.abspath(os.path.join(
    _HERE, "..", "..", "E16_inherited_baseline", "scripts"))
if _E16_SCRIPTS not in sys.path:
    sys.path.insert(0, _E16_SCRIPTS)

import e10_common as C  # noqa: E402
import trustworthy_fmm.fourier.convolution as _conv  # noqa: E402
import trustworthy_fmm.solvers.vector_2d as _v2d  # noqa: E402
from trustworthy_fmm.solvers.vector_2d import solve_multilayer_vector_2d  # noqa: E402

_conv.VECTORIZED_CONV = True
_v2d.FAST_DIAGNOSTICS = True

E16_DESIGNS = os.path.abspath(os.path.join(
    _HERE, "..", "..", "E16_inherited_baseline", "data", "main", "designs"))
E22_DATA = os.path.abspath(os.path.join(
    _HERE, "..", "..", "E22_power_bh_vs_rs", "data"))
DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
FIG = os.path.abspath(os.path.join(_HERE, "..", "..", "..", "notes", "figures"))

# The three incumbent-best delivered binaries (per diffraction order target)
INCUMBENTS = {
    (1, 0): ("e22", "1_0_rs_rep4_binary.npy"),
    (2, 0): ("e22", "2_0_bh_rep11_binary.npy"),
    (3, 0): ("frozen", "3_0_2029_torcwa_M12_latent.npy"),
}
PARENTS = {
    (1, 0): "1_0_2031_certified_screened_latent.npy",
    (2, 0): "2_0_2030_torcwa_M12_latent.npy",
    (3, 0): "3_0_2029_torcwa_M12_latent.npy",
}


def load_binary(kind, name):
    if kind == "e22":
        return torch.from_numpy(
            np.load(os.path.join(E22_DATA, name)).astype("float64"))
    lat = torch.from_numpy(
        np.load(os.path.join(E16_DESIGNS, name)).astype("float64"))
    return C.hard_binary(lat, C.DEFAULT)


def upsample(mask, k):
    return torch.repeat_interleave(
        torch.repeat_interleave(mask, k, dim=0), k, dim=1)


def solve(density, level, dtype, device):
    eps = (C.EPS_BG + (C.EPS_FEAT - C.EPS_BG) * density).to(dtype).to(device)
    return solve_multilayer_vector_2d(
        [eps], [C.THICK], C.WL, C.LATTICE, C.N_IN, C.N_OUT, tuple(level),
        incident_jones=C.DEFAULT.incident_jones)


def eta(density, level, target, dtype=torch.complex64, device="cuda"):
    with torch.no_grad():
        r = solve(density, level, dtype, device)
        return float(r.power_t[r.orders.index(tuple(target))])
