"""Per-order amplitude/phase tables and real-space E/H field maps for the
three incumbent designs.

The solver already returns the full transverse E amplitudes per transmitted
order (fields["tangential_t"], components (Ex, Ey) in order space).  Each
propagating order is a plane wave, so the remaining components follow exactly:
    Ez = -(kx Ex + ky Ey)/kz,          H = (n_out/Z0) khat x E.
Real-space maps at the exit plane are the finite plane-wave sums over
propagating transmitted orders (evanescent orders excluded and reported).

Reference precision: (28,7)@1x, c128/CPU (phase fidelity; a c64 cross-check
column is included).

    python e24_field_analysis.py      # writes ../data/field_analysis.json,
                                      # notes/figures/fig_orders_phase.png,
                                      # notes/figures/fig_field_maps.png
"""
import json
import os
import time

import numpy as np
import torch

from e24_common import (C, DATA, FIG, INCUMBENTS, THREADS, load_binary, solve)

LEVEL = (28, 7)
NXP, NYP = 480, 140          # real-space plot grid


def analyze(b1, target):
    with torch.no_grad():
        r = solve(b1, LEVEL, torch.complex128, "cpu")
    orders = [tuple(o) for o in r.orders]
    et = r.fields["tangential_t"].numpy()          # [2N? -> (count,2)] (Ex,Ey)
    power = r.power_t.numpy()
    # propagating transmitted orders: kz real in air
    lam, (Lx, Ly) = C.WL, C.LATTICE
    rows = []
    for i, (m, n) in enumerate(orders):
        kx = m * lam / Lx
        ky = n * lam / Ly
        kz2 = 1.0 - kx * kx - ky * ky              # units of k0^2, n_out=1
        if kz2 <= 0:
            continue
        ex, ey = et[i, 0], et[i, 1]
        kz = np.sqrt(kz2)
        ez = -(kx * ex + ky * ey) / kz
        amp = np.sqrt(abs(ex) ** 2 + abs(ey) ** 2 + abs(ez) ** 2)
        rows.append({
            "order": [m, n], "power": float(power[i]),
            "Ex_amp": abs(ex), "Ex_phase_deg": float(np.degrees(np.angle(ex))),
            "Ey_amp": abs(ey), "Ey_phase_deg": float(np.degrees(np.angle(ey))),
            "E_amp": float(amp),
            "theta_deg": float(np.degrees(np.arcsin(np.hypot(kx, ky)))),
            "kx": kx, "ky": ky, "kz": float(kz),
            "ex": ex, "ey": ey, "ez": ez,
        })
    rows.sort(key=lambda x: -x["power"])
    return rows, float(r.total_T), float(r.total_R)


def field_maps(rows):
    """Plane-wave sums at the exit plane (z = 0+, transmitted side, n_out=1)."""
    lam, (Lx, Ly) = C.WL, C.LATTICE
    x = np.linspace(0, Lx, NXP, endpoint=False)
    y = np.linspace(0, Ly, NYP, endpoint=False)
    X, Y = np.meshgrid(x, y)
    k0 = 2 * np.pi / lam
    Ex = np.zeros((NYP, NXP), complex)
    Ey = np.zeros_like(Ex)
    Ez = np.zeros_like(Ex)
    Hx = np.zeros_like(Ex)
    Hy = np.zeros_like(Ex)
    for r in rows:
        ph = np.exp(1j * k0 * (r["kx"] * X + r["ky"] * Y))
        E = np.array([r["ex"], r["ey"], r["ez"]])
        khat = np.array([r["kx"], r["ky"], r["kz"]])          # |khat|=1 (n=1)
        H = np.cross(khat, E)                                 # units of E/Z0
        Ex += E[0] * ph
        Ey += E[1] * ph
        Ez += E[2] * ph
        Hx += H[0] * ph
        Hy += H[1] * ph
    return x, y, Ex, Ey, Ez, Hx, Hy


def main():
    torch.set_num_threads(THREADS)
    t0 = time.perf_counter()
    out = {"level": list(LEVEL), "designs": {}}
    maps = {}
    for tgt, (kind, name) in INCUMBENTS.items():
        b1 = load_binary(kind, name)
        rows, tot_t, tot_r = analyze(b1, tgt)
        ser = [{k: v for k, v in r.items() if k not in ("ex", "ey", "ez")}
               for r in rows]
        out["designs"][str(tgt)] = {
            "source": name, "total_T": tot_t, "total_R": tot_r,
            "n_propagating_t": len(rows), "orders": ser,
        }
        maps[tgt] = field_maps(rows)
        top = rows[0]
        print("%s: total_T %.4f  total_R %.4f | top order %s  P=%.4f  "
              "|Ex|=%.3f  arg(Ex)=%+.1f deg  theta=%.1f deg   [%.0f s]"
              % (tgt, tot_t, tot_r, top["order"], top["power"], top["Ex_amp"],
                 top["Ex_phase_deg"], top["theta_deg"],
                 time.perf_counter() - t0), flush=True)
    with open(os.path.join(DATA, "field_analysis.json"), "w") as f:
        json.dump(out, f, indent=1)

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams["font.family"] = ["Microsoft YaHei", "SimHei", "sans-serif"]

    # ---- figure 1: per-order power + phase (n=0 row) -----------------------
    fig, axes = plt.subplots(1, 3, figsize=(11.5, 3.9))
    for ax, tgt in zip(axes, [(1, 0), (2, 0), (3, 0)]):
        d = out["designs"][str(tgt)]
        row0 = [r for r in d["orders"] if r["order"][1] == 0]
        ms = [r["order"][0] for r in row0]
        ps = [r["power"] for r in row0]
        phs = [r["Ex_phase_deg"] for r in row0]
        idx = np.argsort(ms)
        ms = np.array(ms)[idx]; ps = np.array(ps)[idx]; phs = np.array(phs)[idx]
        bars = ax.bar(ms, ps, color=["#1f77b4" if m == tgt[0] else "#bbbbbb"
                                     for m in ms], zorder=3)
        for m, p, ph in zip(ms, ps, phs):
            if p > 0.02:
                ax.text(m, p + 0.015, "%.0f°" % ph, ha="center", fontsize=7)
        ax.set_title("现任 %s   total_T=%.3f" % (tgt, d["total_T"]),
                     fontsize=10)
        ax.set_xlabel("透射级 m（n=0 行）", fontsize=9)
        ax.set_ylim(0, 0.95)
        ax.grid(axis="y", alpha=0.3)
    axes[0].set_ylabel("级次功率（占入射）", fontsize=9)
    fig.suptitle("各透射级的功率与 Ex 相位（(28,7)@1×，c128；柱上角度 = arg(Ex)）",
                 fontsize=11)
    fig.tight_layout(rect=[0, 0, 1, 0.91])
    fig.savefig(os.path.join(FIG, "fig_orders_phase.png"), dpi=220)
    plt.close(fig)

    # ---- figure 2: real-space field maps ----------------------------------
    fig, axes = plt.subplots(3, 3, figsize=(12, 7.2))
    for i, tgt in enumerate([(1, 0), (2, 0), (3, 0)]):
        x, y, Ex, Ey, Ez, Hx, Hy = maps[tgt]
        Emag = np.sqrt(abs(Ex) ** 2 + abs(Ey) ** 2 + abs(Ez) ** 2)
        Hmag = np.sqrt(abs(Hx) ** 2 + abs(Hy) ** 2)
        for j, (F, title, cm) in enumerate([
                (Emag, "|E|（出射面，传播级合成）", "inferno"),
                (np.angle(Ex), "arg(Ex)（rad）", "twilight"),
                (Hmag, "|H|·Z₀", "viridis")]):
            ax = axes[i, j]
            im = ax.imshow(F, origin="lower", extent=[0, 2400, 0, 700],
                           aspect="equal", cmap=cm)
            plt.colorbar(im, ax=ax, fraction=0.024, pad=0.02)
            if i == 0:
                ax.set_title(title, fontsize=9)
            if j == 0:
                ax.set_ylabel("现任 %s\ny (nm)" % (tgt,), fontsize=8)
            if i == 2:
                ax.set_xlabel("x (nm)", fontsize=8)
            ax.tick_params(labelsize=7)
    fig.suptitle("现任设计的出射面场图（透射侧，传播级平面波合成；H 由每级 k̂×E 精确给出）",
                 fontsize=11)
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    fig.savefig(os.path.join(FIG, "fig_field_maps.png"), dpi=220)
    print("wrote field_analysis.json + fig_orders_phase.png + fig_field_maps.png"
          "  (%.0f s)" % (time.perf_counter() - t0))


if __name__ == "__main__":
    main()
