"""Grid-refinement test: what happens to the evaluated efficiency when the
sampling grid is refined (k-x block replication, identical physical
structure)?

Two separable effects, measured separately:
  (i)  at FIXED truncation order, refining the grid changes only the DFT
       aliasing sum -> the "grid-sampling effect"; it must converge as k grows;
  (ii) a finer grid ADMITS higher orders (n >= 4m+1), which is the reference-
       order axis measured in E20 -- not re-measured here.

Scan: 6 designs (3 incumbents + 3 frozen parents) x k in {1,2,3,4} at
(24,6) and (28,7); plus k in {2,3} at (40,10) for the two champions.
GPU/c64 with one c128 spot check.

    python e24_grid_refinement.py     # writes ../data/grid_refinement.json
                                      # and notes/figures/fig_grid_refinement.png
"""
import json
import os
import time

import torch

from e24_common import (DATA, FIG, INCUMBENTS, PARENTS, THREADS, eta,
                        load_binary, upsample)

KS = [1, 2, 3, 4]
LEVELS = [(24, 6), (28, 7)]
HI_LEVEL = (40, 10)


def main():
    torch.set_num_threads(THREADS)
    t0 = time.perf_counter()
    designs = []
    for tgt, (kind, name) in INCUMBENTS.items():
        designs.append(("incumbent %s" % (tgt,), tgt, load_binary(kind, name)))
    for tgt, name in PARENTS.items():
        designs.append(("parent %s" % (tgt,), tgt, load_binary("frozen", name)))

    rows = []
    for label, tgt, b1 in designs:
        rec = {"label": label, "target": list(tgt), "eta": {}}
        for k in KS:
            bk = upsample(b1, k)
            for lv in LEVELS:
                rec["eta"]["%s@k%d" % (lv, k)] = eta(bk, lv, tgt)
        rows.append(rec)
        print("%-18s " % label + "  ".join(
            "%s@k%d %.4f" % (lv, k, rec["eta"]["%s@k%d" % (lv, k)])
            for lv in LEVELS for k in KS), flush=True)

    # high-order grid check for the two champions
    hi = {}
    for tgt in [(1, 0), (2, 0)]:
        kind, name = INCUMBENTS[tgt]
        b1 = load_binary(kind, name)
        hi[str(tgt)] = {
            "k2": eta(upsample(b1, 2), HI_LEVEL, tgt),
            "k3": eta(upsample(b1, 3), HI_LEVEL, tgt),
        }
        print("hi-order %s (40,10): k2 %.4f  k3 %.4f"
              % (tgt, hi[str(tgt)]["k2"], hi[str(tgt)]["k3"]), flush=True)

    # c128 spot check at the most refined point
    b1 = load_binary(*INCUMBENTS[(2, 0)])
    v64 = eta(upsample(b1, 4), (28, 7), (2, 0))
    v128 = eta(upsample(b1, 4), (28, 7), (2, 0),
               dtype=torch.complex128, device="cpu")
    spot = {"eta_c64": v64, "eta_c128": v128,
            "rel": abs(v64 - v128) / max(v128, 1e-12)}
    print("spot c128 (2,0)@k4 (28,7): c64 %.6f vs c128 %.6f (rel %.1e)"
          % (v64, v128, spot["rel"]))

    out = {"rows": rows, "hi_order": hi, "spot_c128": spot,
           "wall_s": time.perf_counter() - t0}
    with open(os.path.join(DATA, "grid_refinement.json"), "w") as f:
        json.dump(out, f, indent=1)

    # figure
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    plt.rcParams["font.family"] = ["Microsoft YaHei", "SimHei", "sans-serif"]
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.2))
    for ax, lv in zip(axes, LEVELS):
        for rec in rows:
            vals = [rec["eta"]["%s@k%d" % (lv, k)] for k in KS]
            style = "-o" if rec["label"].startswith("incumbent") else "--^"
            ax.plot(KS, vals, style, ms=4,
                    label=rec["label"].replace("incumbent", "现任")
                    .replace("parent", "父本"))
        ax.set_xticks(KS)
        ax.set_xlabel("网格细化倍数 k（像素 20/k nm，同一物理结构）", fontsize=9)
        ax.set_title("固定阶 %s 下的网格采样效应" % (lv,), fontsize=10)
        ax.grid(alpha=0.3)
    axes[0].set_ylabel("η（GPU/c64 实测）", fontsize=9)
    axes[1].legend(fontsize=7.5, loc="center right")
    fig.suptitle("网格细化测试（E24）：固定截断阶、精确同构的 k× 细网格重表示", fontsize=11)
    fig.tight_layout(rect=[0, 0, 1, 0.92])
    fig.savefig(os.path.join(FIG, "fig_grid_refinement.png"), dpi=220)
    print("wrote grid_refinement.json + fig_grid_refinement.png  (%.0f s)"
          % (time.perf_counter() - t0))


if __name__ == "__main__":
    main()
