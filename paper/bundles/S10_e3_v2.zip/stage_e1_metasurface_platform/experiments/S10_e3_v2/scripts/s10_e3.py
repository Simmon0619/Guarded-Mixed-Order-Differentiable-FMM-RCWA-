"""S10 -- E3 v2: single-knob ladder of mixed-order descent variants on P2, m=4
(and B at m=3), 6 tickets per arm (user: half the seeds), plus the pipeline's
selection / certification / numeric repair trigger on each group of 3.

Arms (each differs from its parent by ONE knob):
  Aprime  MIX4 exactly as the S6-3b pool (k=4 from step 54 = beta 11, Adam lr
          cosine in t, no guards) with the guards INSTRUMENTED but inactive:
          contemporaneous control + trigger base rate + step-level attribution.
  B       Aprime + guards ACTIVE + mixing starts at beta >= 16.
  MIX8    B with k = 8.
  D1      B + adaptive cadence under a fixed high-order budget (42 steps/ticket,
          MIX4's): k in {2,4,8} set from the cosine between the low-order and the
          high-order gradient at the same latent (a paid low-order probe at every
          high step; the free lagged proxy is logged next to it), two agreeing
          checks to change k, an isolated cos < 0.5 marks the high gradient as
          suspect (the probe is used instead, logged).
  D2      D1 + online rung rise: when two consecutive probe cosines are < 0.85
          the descent order moves one rung up the ladder (capped at the gate).
  E       D1 + beta-ramp reallocation: 25 % of the 219 steps in beta 2-16, 45 %
          in 16-128, 30 % in 128-2000 (uniform in log beta is 30/30/40); the
          cosine lr is indexed by the log-beta fraction so only the density
          changes.

Guards (B and up; instrumented in Aprime).  The gap scans (S8 data_m4,
2026-09-16) showed that the minimum eigenvalue gap does NOT predict the wrong
gradients (the x17 spike at (28,4) beta 198 sits at gap 3.9e-4, above the
median, while 5 % of healthy steps have gaps < 2e-5), so the gap is LOGGED as a
covariate and the active guards are the two observables that do discriminate:
  norm       |g| above 3x the median of the last 8 same-order norms (warm-up 4,
             beta >= 8) is a TRIGGER only; the decision is the S8 statistic: the
             gradient is recomputed at beta*(1 + 1 %) (then +3 %) and the ORIGINAL
             is kept if it is stable under that change (cos >= 0.9 and norm ratio
             in [0.5, 2] -- natural growth), replaced by the recompute if it is not
             (a c64 artifact: S8 showed cos ~0 and x12-21 at such points).
  direction  cos(g, previous same-order gradient) < DIR_COS_MIN (descent order,
             beta >= 8) -> the same stability test with the +-1 % recomputes.
  suspect    at a high step, cos(g_high, low-order probe at the same latent) < 0.5
             -> the same stability test on the high gradient (one +1 % recompute,
             ~12 s at (44,6)); a stable high gradient is kept even though it
             disagrees with the low order (S8: that disagreement is often genuine),
             an unstable one is replaced by its recompute.  The cadence / rise
             decisions use the probe cosine only when the high gradient was stable.
  raise / non-finite: the +-1 %, +-3 % ladder, then one complex128 CPU gradient at
             the descent order (cap 6 per ticket); at the high order a descent step.
  A true positive is a trigger whose recompute replaced the original (unstable);
  rates are per 100 evaluations per order.  Aprime logs the would-trigger counts
  and the descent-order cos / norm tails (used to calibrate DIR_COS_MIN and
  NORM_FACTOR via data/guard_cfg.json before B runs) but never recomputes.

Per step: beta, order, high?, value, |g|, gap, action, cos to the previous
same-order gradient, cos(Adam m, g); at high steps the probe cosine, the lagged
proxy cosine and k.  Delivery = best gate checkpoint (the pool's rule), rung-1
certified; the descent-order binary is read at both the original and the
current descent order at every checkpoint (terminal gap comparable to A).

Pipeline on each group of 3: select by gate; certify at rung1 and top; repair
chain on the DELIVERED ticket only if rung1 < pool median - 0.05 (m=4: 0.683;
m=3 pool median 0.80 -> 0.75) and gate optimism < 0.05, at beta = max(beta*,
64), 15 hops, stop after 12 consecutive rejections, re-descent under the same
guards (k = 4 fixed).

Descriptive; GPU / complex64, eig on CPU.  Resumable per ticket.
  python s10_e3.py --arm B --m 4 [--n 6] [--seeds ...]
  python s10_e3.py --arm Aprime,B,MIX8,D1,D2,E --m 4
"""
import argparse
import gc
import hashlib
import importlib
import json
import math
import os
import sys
import time
from typing import Dict, List, Optional

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
_S7 = os.path.abspath(os.path.join(_HERE, "..", "..", "S7_headtohead", "scripts"))
_S8 = os.path.abspath(os.path.join(_HERE, "..", "..", "S8_order_beta_map", "scripts"))
sys.path.insert(0, _S7)
sys.path.insert(0, _S8)
os.environ.setdefault("TFMM_GAP_ONLY_DIAGNOSTICS", "1")
import s7_headtohead as S7                                            # noqa: E402
C = S7.C
from workbench.app import _sym, filtered_noise, app_hard_binary, app_projected, solve_density   # noqa: E402
import trustworthy_fmm.solvers.vector_2d as V                         # noqa: E402

DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
DESIGNS = os.path.join(DATA, "designs")
LOGS = os.path.join(DATA, "logs")

STEPS, BETA_END = 219, 2000.0
N_DEFAULT = 6
SEEDS = {4: [154000 + i for i in range(12)], 3: [153000 + i for i in range(12)]}    # = S6-3b MIX4 pool seeds
POOL_MEDIAN_RUNG1 = {4: 0.733, 3: 0.838}          # rung-1 medians of the S6-3b MIX4 pools (12 tickets each)
OPTIMISM_MAX = 0.05
HIGH_BUDGET = 42                                  # overwritten per ramp: the parent's (k=4 from beta>=16) realised high-step count
JITTERS = (0.01, -0.01, 0.03, -0.03)
NORM_FACTOR, NORM_WINDOW, NORM_WARMUP, NORM_BETA_MIN = 3.0, 8, 4, 8.0
C128_CAP = 6
DIR_COS_MIN = 0.5                                 # direction guard (descent order only): trigger below (calibrated from Aprime)
STAB_COS, STAB_RATIO = 0.9, (0.5, 2.0)            # stability test: original kept if cos(orig, recompute) >= 0.9 and norm ratio in [0.5, 2]
SUSPECT_COS = 0.5                                 # high step: probe cosine below this -> stability test on the high gradient
JITTERS_DIR = (0.01, -0.01)                       # the direction guard's shorter ladder (a genuine change is not 'fixed' by jitter)
GUARD_CFG = {}                                    # data/guard_cfg.json overrides (calibrated from Aprime's logs before B runs)
TAU_DEFAULT = 1e-4                                # gap covariate only (logged): 'small gap' flag threshold, from data/tau.json when present
LADDER = [(16, 2), (20, 3), (24, 3), (28, 4), (32, 5), (36, 5), (40, 6), (44, 6), (52, 7), (60, 9), (64, 9)]
CHAIN_HOPS, CHAIN_STOP, RE_STEPS, RE_K = 15, 12, 30, 4
ALPHAS = (0.1, 0.25, 0.5)
NOISE_BASE = 330000

ARMS = {
    "Aprime": dict(guards=False, mix_from_beta=None, mix_from_step=54, k=4, adaptive=False, rise=False, ramp="uniform", lr_index="step"),
    "B":      dict(guards=True, mix_from_beta=16.0, k=4, adaptive=False, rise=False, ramp="uniform", lr_index="step"),
    "MIX8":   dict(guards=True, mix_from_beta=16.0, k=8, adaptive=False, rise=False, ramp="uniform", lr_index="step"),
    "D1":     dict(guards=True, mix_from_beta=16.0, k=4, adaptive=True, rise=False, ramp="uniform", lr_index="step"),
    "D2":     dict(guards=True, mix_from_beta=16.0, k=4, adaptive=True, rise=True, ramp="uniform", lr_index="step"),
    "E":      dict(guards=True, mix_from_beta=16.0, k=4, adaptive=True, rise=False, ramp="realloc", lr_index="beta"),
}
RAMP_REALLOC = [(2.0, 16.0, 0.25), (16.0, 128.0, 0.45), (128.0, 2000.0, 0.30)]


# ------------------------------------------------------------------ utilities
def assert_eig_cpu():
    mod = importlib.import_module("trustworthy_fmm.solvers.eigendecomposition")
    assert getattr(mod, "EIG_DEVICE", None) == "cpu", "leak fix not active"
    assert V.GAP_ONLY_DIAGNOSTICS, "GAP_ONLY_DIAGNOSTICS must be on (TFMM_GAP_ONLY_DIAGNOSTICS=1)"
    return "cpu"


def log(msg, fh=None):
    line = time.strftime("%Y-%m-%d %H:%M:%S ") + msg
    print(line, flush=True)
    if fh:
        fh.write(line + "\n")
        fh.flush()


def cosine(a, b):
    a = a.flatten().double()
    b = b.flatten().double()
    return float(a @ b / (a.norm() * b.norm()).clamp_min(1e-300))


def save_mask(tag, binary, latent=None):
    os.makedirs(DESIGNS, exist_ok=True)
    b = binary.detach().cpu().numpy().astype(np.uint8)
    pb = os.path.join(DESIGNS, tag + "_binary.npz")
    np.savez_compressed(pb, packed=np.packbits(b, axis=1), shape=np.array(b.shape))
    files = {"binary": "designs/" + tag + "_binary.npz"}
    if latent is not None:
        pl = os.path.join(DESIGNS, tag + "_latent.npy")
        np.save(pl, latent.detach().cpu().numpy().astype(np.float64))
        files["latent"] = "designs/" + tag + "_latent.npy"
    return files


def load_tau():
    """data/guard_cfg.json: {"tau": {"28-4": 8e-6, ...}, "dir_cos_min": 0.5, "norm_factor": 3.0}; calibrated from Aprime."""
    global DIR_COS_MIN, NORM_FACTOR, SUSPECT_COS, GUARD_CFG
    p = os.path.join(DATA, "guard_cfg.json")
    if not os.path.exists(p):
        return {}
    GUARD_CFG = json.load(open(p, encoding="utf-8"))
    DIR_COS_MIN = float(GUARD_CFG.get("dir_cos_min", DIR_COS_MIN))
    NORM_FACTOR = float(GUARD_CFG.get("norm_factor", NORM_FACTOR))
    SUSPECT_COS = float(GUARD_CFG.get("suspect_cos", SUSPECT_COS))
    return {tuple(int(x) for x in k.split("-")): float(v) for k, v in GUARD_CFG.get("tau", {}).items()}


# ------------------------------------------------------------------ the ramp
def make_ramp(kind):
    """beta(t) for t in 0..STEPS and u(t) = log-beta fraction in [0,1]."""
    if kind == "uniform":
        fn = C.beta_geometric(2.0, BETA_END)
        return (lambda t: fn(t, STEPS)), (lambda t: t / STEPS)
    # piecewise geometric: segment i spans a fraction f_i of the steps
    bounds, fr = [], 0.0
    for lo, hi, f in RAMP_REALLOC:
        bounds.append((fr * STEPS, (fr + f) * STEPS, lo, hi))
        fr += f

    def beta(t):
        t = float(min(max(t, 0), STEPS))
        for t0, t1, lo, hi in bounds:
            if t <= t1 + 1e-9:
                return lo * (hi / lo) ** ((t - t0) / max(t1 - t0, 1e-9))
        return BETA_END
    return beta, (lambda t: math.log(beta(t) / 2.0) / math.log(BETA_END / 2.0))


# ------------------------------------------------------------- the gradient policy
class GradPolicy:
    """Order choice, cadence, guards and logging shared by tickets and chain re-descents."""

    def __init__(self, ctx, od, arm, tau, fh=None):
        self.ctx, self.od, self.arm, self.fh = ctx, od, arm, fh
        self.cfg, self.mode, self.device = ctx.cfg, ctx.mode, ctx.device
        self.tau = tau
        self.level_d0 = tuple(od["descent"])
        self.level_d = tuple(od["descent"])
        self.level_g = tuple(od["gate"])
        self.rise_ladder = [l for l in LADDER if LADDER.index(l) > LADDER.index(self.level_d0) and LADDER.index(l) <= LADDER.index(self.level_g)]
        self.k = int(arm["k"])
        self.high_budget = HIGH_BUDGET
        self.hop = None
        self.high_used = 0
        self.next_high = None
        self.probe_hist: List[float] = []
        self.norms: Dict[tuple, List[float]] = {}
        self.prev_g: Dict[tuple, torch.Tensor] = {}
        self.prev_low_g: Optional[torch.Tensor] = None
        self.c128_used = 0
        self.rise_step = None
        self.k_history: List[Dict] = []
        self.rows: List[Dict] = []
        self.events: List[Dict] = []
        self.stats = {"n_eval": {}, "n_trigger": {"direction": 0, "norm": 0, "raise": 0, "nonfinite": 0},
                      "n_true_positive": {"direction": 0, "norm": 0, "raise": 0, "nonfinite": 0},
                      "n_would_trigger": {"direction": 0, "norm": 0}, "n_small_gap": 0, "n_c128": 0, "n_skip_high": 0,
                      "n_kept_original": 0, "n_suspect_high": 0, "n_suspect_unstable": 0, "n_rise_complete": 0,
                      "wall_recompute_s": 0.0, "wall_probe_s": 0.0, "wall_c128_s": 0.0, "wall_suspect_s": 0.0}

    # ---- one forward + backward, gap read in between
    def _fwd_bwd(self, latent, level, beta, dtype=None, device=None):
        dtype = dtype or self.ctx.dtype
        device = device or self.device
        x = latent.detach().clone().to(device).requires_grad_(True)
        try:
            dens = app_projected(x, float(beta), self.cfg, self.mode)
            r = solve_density(dens, tuple(level), self.cfg, self.ctx.theta, self.ctx.phi, dtype, device)
            gap = float(torch.as_tensor(r.diagnostics["min_eigen_gap"]).detach().real)
            j = r.power_t[r.orders.index(tuple(self.ctx.target))]
            j.backward()
            v = float(j.detach())
            g = x.grad.detach()
            del r, j, dens
        except RuntimeError as exc:
            return None, None, float("nan"), "raise: " + str(exc)[:120]
        finally:
            del x
        if not (math.isfinite(v) and bool(torch.isfinite(g).all())):
            return None, None, gap, "nonfinite"
        if device != self.device:
            g = g.to(self.device)
        return v, g.to(self.cfg.latent_dtype), gap, None

    def _norm_check(self, level, norm):
        w = self.norms.get(level, [])
        if len(w) < NORM_WARMUP:
            return False, None
        med = float(np.median(w[-NORM_WINDOW:]))
        return norm > NORM_FACTOR * med, med

    def gradient(self, latent, level, beta, t, is_high, adam=None):
        """Guarded value + gradient at ``level``.  Returns (v, g, row); g is None only
        when a high-order gradient is refused (caller takes a descent step)."""
        guards = self.arm["guards"]
        level = tuple(level)
        tau = self.tau.get(level, TAU_DEFAULT)
        self.stats["n_eval"][str(level)] = self.stats["n_eval"].get(str(level), 0) + 1
        t0 = time.perf_counter()
        v, g, gap, err = self._fwd_bwd(latent, level, beta)
        row = {"t": t, "hop": self.hop, "beta": round(float(beta), 3), "level": list(level), "high": bool(is_high), "value": v,
               "norm": float(g.norm()) if g is not None else None, "gap": gap if gap == gap else None, "action": "ok", "n_recompute": 0}
        if gap == gap and gap < tau:
            self.stats["n_small_gap"] += 1
            row["small_gap"] = True
        pg = self.prev_g.get(level)
        cos_prev = cosine(pg, g) if (pg is not None and g is not None) else None
        row["cos_prev_same_order"] = cos_prev
        reason = None
        if err is not None:
            reason = "raise" if err.startswith("raise") else "nonfinite"
        elif beta >= NORM_BETA_MIN:
            trip, med = self._norm_check(level, row["norm"])
            if trip:
                reason = "norm"
            elif (not is_high) and cos_prev is not None and cos_prev < DIR_COS_MIN:
                reason = "direction"          # high-order direction anomalies are handled by the probe test in run_to
        if reason in ("norm", "direction") and not guards:
            self.stats["n_would_trigger"][reason] += 1
            row["action"] = "log_only_" + reason
            reason = None
        if reason is not None:
            self.stats["n_trigger"][reason] += 1
            g_orig, v_orig = g, v
            t1 = time.perf_counter()
            decided = False
            row["recomputes"] = []
            ladder = JITTERS_DIR if reason in ("direction", "norm") else JITTERS
            for j in ladder:
                b2 = float(beta) * (1.0 + j)
                v2, g2, gap2, err2 = self._fwd_bwd(latent, level, b2)
                row["n_recompute"] += 1
                rr = {"beta_used": round(b2, 4), "err": err2}
                if err2 is not None:
                    row["recomputes"].append(rr)
                    continue
                if g_orig is None:                                   # raise / non-finite: first finite recompute wins
                    v, g, gap, decided = v2, g2, gap2, True
                    row.update({"action": "jitter", "beta_used": round(b2, 4)})
                    row["recomputes"].append(rr)
                    break
                cs, ratio = cosine(g_orig, g2), float(g_orig.norm() / g2.norm().clamp_min(1e-300))
                rr.update({"cos_orig": cs, "ratio_orig_over_recomputed": ratio})
                row["recomputes"].append(rr)
                stable = (cs >= STAB_COS) and (STAB_RATIO[0] <= ratio <= STAB_RATIO[1])
                if stable:                                           # the original survives a 1 % beta change: keep it
                    v, g = v_orig, g_orig
                    row["action"] = "kept_original"
                    self.stats["n_kept_original"] += 1
                else:                                                # unstable: a c64 artifact; the recompute replaces it
                    v, g, gap = v2, g2, gap2
                    row.update({"action": "jitter", "beta_used": round(b2, 4), "cos_orig_recomputed": cs,
                                "norm_ratio_orig_over_recomputed": ratio, "true_positive": True})
                    self.stats["n_true_positive"][reason] += 1
                decided = True
                break
            if not decided:
                if g_orig is not None:                               # every recompute raised: keep what we have
                    v, g = v_orig, g_orig
                    row["action"] = "kept_original_no_recompute"
                elif is_high:
                    self.stats["n_skip_high"] += 1
                    row["action"] = "skip_high"
                    v, g = None, None
                elif self.c128_used < C128_CAP:
                    t2 = time.perf_counter()
                    v3, g3, gap3, err3 = self._fwd_bwd(latent, level, beta, dtype=torch.complex128, device="cpu")
                    self.stats["wall_c128_s"] += time.perf_counter() - t2
                    self.c128_used += 1
                    self.stats["n_c128"] += 1
                    if err3 is None:
                        v, g, gap = v3, g3, gap3
                        row["action"] = "c128"
                    else:
                        row["action"] = "skipped_update"
                        v, g = None, None
                else:
                    row["action"] = "skipped_update"
                    v, g = None, None
            self.stats["wall_recompute_s"] += time.perf_counter() - t1
            self.events.append({"t": t, "hop": self.hop, "beta": float(beta), "level": list(level), "high": bool(is_high), "reason": reason,
                                "gap": gap if gap == gap else None, "action": row["action"], "cos_prev_orig": cos_prev,
                                "cos": row.get("cos_orig_recomputed"), "ratio": row.get("norm_ratio_orig_over_recomputed"),
                                "recomputes": row["recomputes"]})
        if g is not None:
            row["norm"] = float(g.norm())
            self.prev_g[level] = g
            self.norms.setdefault(level, []).append(row["norm"])
            if adam is not None and adam.t > 0:
                row["cos_m_g"] = cosine(adam.m, g)
        row["wall_s"] = time.perf_counter() - t0
        self.rows.append(row)
        return v, g, row

    def stability_test(self, latent, level, beta, g_orig, t):
        """One +1 % recompute; returns (stable, v2, g2, info)."""
        t0 = time.perf_counter()
        b2 = float(beta) * 1.01
        v2, g2, gap2, err2 = self._fwd_bwd(latent, level, b2)
        info = {"beta_used": round(b2, 4), "err": err2}
        if err2 is None:
            cs, ratio = cosine(g_orig, g2), float(g_orig.norm() / g2.norm().clamp_min(1e-300))
            info.update({"cos_orig": cs, "ratio_orig_over_recomputed": ratio})
            stable = (cs >= STAB_COS) and (STAB_RATIO[0] <= ratio <= STAB_RATIO[1])
        else:
            stable, v2, g2 = True, None, None                        # cannot test: keep the original
        self.stats["wall_suspect_s"] += time.perf_counter() - t0
        self.events.append({"t": t, "hop": self.hop, "beta": float(beta), "level": list(level), "high": True, "reason": "suspect",
                            "stable": bool(stable), "action": "kept_original" if stable else "recompute", "recomputes": [info]})
        return stable, v2, g2, info

    # ---- cadence
    def is_high_step(self, t, beta):
        a = self.arm
        if a.get("mix_from_beta") is None:
            start_ok = t >= a["mix_from_step"]
        else:
            start_ok = beta >= a["mix_from_beta"]
        if not start_ok:
            return False
        if not a["adaptive"]:
            t0 = a.get("mix_from_step") if a.get("mix_from_beta") is None else self._first_step_at(a["mix_from_beta"])
            return (t - t0) % self.k == 0
        if self.high_used >= self.high_budget or (a["rise"] and self.level_d == self.level_g):
            return False
        if self.next_high is None:
            self.next_high = t
        return t >= self.next_high

    def _first_step_at(self, beta_target):
        if not hasattr(self, "_t_start"):
            self._t_start = next(t for t in range(STEPS + 1) if self.beta_fn(t) >= beta_target)
        return self._t_start

    def after_high(self, t, cos_probe, cos_proxy, checked):
        """Update k on two agreeing checks (only checks where the high gradient was
        available and stable count), the rung rise, and the next high step.  The
        high-order budget is a CAP: is_high_step stops at the budget, k is never
        stretched to pace it (running out early is itself a measurable outcome)."""
        self.high_used += 1
        a = self.arm
        if not a["adaptive"]:
            return
        if checked and cos_probe is not None:
            self.probe_hist.append(cos_probe)
        h = self.probe_hist[-2:]
        changed = None
        if checked and cos_probe is not None and len(h) == 2:
            if min(h) > 0.95 and self.k < 8:
                self.k, changed = min(self.k * 2, 8), "up"
            elif max(h) < 0.85:
                if self.k > 2:
                    self.k, changed = max(self.k // 2, 2), "down"
                if a["rise"] and self.rise_ladder and self.level_d != self.level_g:
                    nxt = self.rise_ladder.pop(0)
                    self.level_d, self.rise_step = nxt, t
                    self.k_history.append({"t": t, "rise_to": list(nxt)})
                    changed = (changed or "") + "+rise"
                    if self.level_d == self.level_g:
                        self.stats["n_rise_complete"] += 1
                        self.events.append({"t": t, "reason": "rise_complete", "level": list(nxt)})
            if changed:
                self.probe_hist = []
        self.next_high = t + self.k
        self.k_history.append({"t": t, "k": self.k, "cos_probe": cos_probe, "cos_proxy": cos_proxy, "checked": bool(checked),
                               "changed": changed, "high_used": self.high_used})


# ------------------------------------------------------------- the descent
class PolicyDescent(C.GapDescent):
    """GapDescent whose gradient / order / cadence come from a GradPolicy."""

    def __init__(self, ctx, seed, steps, beta_fn, u_fn, ckpt_steps, events, policy, lr_index):
        self.policy = policy
        self.u_fn = u_fn
        self.lr_index = lr_index
        policy.beta_fn = lambda t: beta_fn(t, steps)
        self.level_series = []
        self.traj_descent = []
        super().__init__(ctx, seed, steps, beta_fn, ckpt_steps, events, beta_final=BETA_END, record_trajectory=True)

    def _checkpoint(self, step):
        eg = C.Descent._checkpoint(self, step)
        b = self.last["binary"]
        t0 = time.perf_counter()
        ed0 = C.eta(b, self.policy.level_d0, self.ctx)
        ed = ed0 if self.policy.level_d == self.policy.level_d0 else C.eta(b, self.policy.level_d, self.ctx)
        self.t_gate += time.perf_counter() - t0
        self.ckpts[-1].update({"eta_binary_descent": ed0, "gap_descent_minus_gate": ed0 - eg,
                               "eta_binary_descent_current": ed, "level_d_current": list(self.policy.level_d)})
        return eg

    def run_to(self, step):
        P = self.policy
        end = min(int(step), self.steps)
        while self.t < end:
            t = self.t
            beta = self.beta_fn(t, self.steps)
            prog = self.u_fn(t) if self.lr_index == "beta" else t / max(self.steps - 1, 1)
            lr = C.cosine_lr(prog, self.ctx.cfg)
            high = P.is_high_step(t, beta)
            level = P.level_g if high else P.level_d
            t0 = time.perf_counter()
            v, g, row = P.gradient(self.latent, level, beta, t, high, adam=self.adam)
            dt_high = time.perf_counter() - t0
            v_desc = v if not high else None
            if high:
                t1 = time.perf_counter()
                vl, gl, rowl = P.gradient(self.latent, P.level_d, beta, t, False, adam=None)   # the paid probe (all arms)
                rowl["probe"] = True
                P.stats["wall_probe_s"] += time.perf_counter() - t1
                v_desc = vl
                cos_probe = cosine(gl, g) if (g is not None and gl is not None) else None
                cos_proxy = cosine(P.prev_low_g, g) if (g is not None and P.prev_low_g is not None) else None
                row.update({"cos_probe": cos_probe, "cos_proxy": cos_proxy, "k": P.k})
                checked = g is not None
                if g is not None and cos_probe is not None and cos_probe < SUSPECT_COS and P.arm["guards"]:
                    P.stats["n_suspect_high"] += 1
                    stable, v2, g2, info = P.stability_test(self.latent, level, beta, g, t)
                    row["suspect"] = info
                    if not stable:
                        P.stats["n_suspect_unstable"] += 1
                        v, g = v2, g2
                        row["fallback"] = "unstable_high_recomputed"
                        checked = False
                if g is None:
                    row["fallback"] = "descent_step"
                    v, g = vl, gl
                P.after_high(t, cos_probe, cos_proxy, checked)
            else:
                if g is not None:
                    P.prev_low_g = g
            self.t_desc += time.perf_counter() - t0
            if high:
                self.n_high = getattr(self, "n_high", 0) + 1
                self.t_high = getattr(self, "t_high", 0.0) + dt_high
            if g is not None:
                self.latent = self.adam.step(self.latent, g, lr)
                self.traj.append(round(float(v), 6) if v is not None else None)
            else:
                self.traj.append(None)
                P.events.append({"t": t, "beta": float(beta), "level": list(level), "reason": "skipped_update"})
            self.traj_descent.append(round(float(v_desc), 6) if v_desc is not None else None)
            self.level_series.append(0 if not high else 1)
            self.t = t + 1
            if self.t in self.ck:
                self._checkpoint(self.t)
        return self

    def finish(self):
        r = super().finish()
        r.update({"n_high_order_steps": getattr(self, "n_high", 0), "wall_high_order_s": getattr(self, "t_high", 0.0),
                  "level_series": self.level_series, "trajectory_descent": self.traj_descent})
        return r


# ------------------------------------------------------------- tickets
def run_arm(arm_name, m, seeds, device, fh, tau):
    arm = ARMS[arm_name]
    cfg = C.make_cfg(5)
    od = C.orders_for(m, cfg)
    ctx = C.make_ctx(cfg, (m, 0), od["descent"], od["gate"], device)
    path = os.path.join(DATA, "s10_%s_m%d.json" % (arm_name, m))
    R = json.load(open(path, encoding="utf-8")) if os.path.exists(path) else {"meta": {}, "tickets": {}, "groups": {}}
    beta_fn_t, u_fn = make_ramp(arm["ramp"])
    beta_fn = lambda t, steps: beta_fn_t(t)                                # noqa: E731
    tau = load_tau()                                                       # re-read per arm (calibrated after Aprime)
    if arm["guards"] and not GUARD_CFG:
        raise SystemExit("guards=True arm %s needs data/guard_cfg.json (calibrate from Aprime first)" % arm_name)
    t_start_mix = next(t for t in range(STEPS + 1) if beta_fn_t(t) >= 16.0) if arm.get("mix_from_beta") else arm.get("mix_from_step", 54)
    high_budget = len(range(t_start_mix, STEPS, 4))                        # the parent's (k=4) realised count on this ramp
    # E's checkpoints: the steps nearest to the uniform ramp's 30 checkpoint u-values, so the delivery rule is comparable
    if arm["ramp"] == "uniform":
        ck = S7.o_ckpts(STEPS)
    else:
        _, u_uni = make_ramp("uniform")
        targets = [u_uni(t) for t in S7.o_ckpts(STEPS)]
        ck = sorted({0, STEPS} | {min(range(STEPS + 1), key=lambda t: abs(u_fn(t) - u)) for u in targets})
    R["meta"] = {"arm": arm_name, "config": arm, "m": m, "orders": {k: list(v) for k, v in od.items()}, "steps": STEPS, "beta_end": BETA_END,
                 "high_budget": high_budget if arm["adaptive"] else None, "mix_start_step": t_start_mix, "checkpoints": ck,
                 "tau": {"%d-%d" % k: v for k, v in tau.items()}, "started": time.strftime("%Y-%m-%d %H:%M:%S"),
                 "guards": {"jitters": JITTERS, "jitters_dir": JITTERS_DIR, "norm": [NORM_FACTOR, NORM_WINDOW, NORM_WARMUP, NORM_BETA_MIN],
                            "dir_cos_min": DIR_COS_MIN, "stab_cos": STAB_COS, "stab_ratio": STAB_RATIO, "suspect_cos": SUSPECT_COS, "c128_cap": C128_CAP, "guard_cfg": GUARD_CFG},
                 "ramp": arm["ramp"], "beta_at_steps": {str(t): round(beta_fn_t(t), 3) for t in (0, 54, 66, 95, 131, 150, 200, 219)},
                 "seeds": seeds, "eig_device": assert_eig_cpu(), "gpu": torch.cuda.get_device_name(0) if device == "cuda" else "cpu",
                 "note": "Aprime replays the S6-3b MIX4 recipe with guards instrumented but inactive; contemporaneous control. "
                         "Deviation: on a raised / non-finite gradient Aprime uses the +-1 %, +-3 % ladder instead of the pool's 1e-6..1e-5 ladder. "
                         "The chain re-descends at the rule's descent order (not a risen one) with k=4 fixed."}
    gate_fwd = S7.PROBLEMS["P2"]["gate_fwd"][m]
    for i, seed in enumerate(seeds):
        key = "s%02d" % i
        if key in R["tickets"]:
            assert R["tickets"][key]["seed"] == seed, "resume mismatch: %s has seed %d, wanted %d" % (key, R["tickets"][key]["seed"], seed)
            continue
        t_start = time.perf_counter()
        pol = GradPolicy(ctx, od, arm, tau, fh)
        pol.high_budget = high_budget
        ev: List[Dict] = []
        d = PolicyDescent(ctx, seed, STEPS, beta_fn, u_fn, ck, ev, pol, arm["lr_index"])
        r = d.finish()
        tag = "s10_%s_m%d_%s" % (arm_name, m, key)
        deliv = {}
        for name in ("best", "final"):
            dd = r[name]
            sha = C.sha1_of(dd["binary"])
            if name == "final" and sha == deliv["best"]["sha1"]:
                e1 = deliv["best"]["eta_rung1"]
            else:
                e1 = C.eta(dd["binary"], od["rung1"], ctx)
            deliv[name] = {"step": dd["step"], "eta_gate": dd["eta_gate"], "eta_rung1": e1, "gate_optimism": dd["eta_gate"] - e1,
                           "sha1": sha, "files": save_mask(tag + "_" + name, dd["binary"], dd["latent"] if name == "best" else None)}
        cliff = max(c["eta_gate"] for c in r["checkpoints"]) - r["final"]["eta_gate"]
        rec = {"index": i, "seed": seed, "arm": arm_name, "m": m, "deliver_best": deliv["best"], "deliver_final": deliv["final"],
               "beta_star": beta_fn_t(deliv["best"]["step"]), "reported_continuous": r["reported_continuous"],
               "collapse_step": r["collapse_step"], "checkpoints": r["checkpoints"], "trajectory": r["trajectory"],
               "trajectory_descent": r["trajectory_descent"], "level_series": r["level_series"], "n_high_order_steps": r["n_high_order_steps"],
               "high_budget": high_budget if arm["adaptive"] else None, "k_history": pol.k_history,
               "guard_thresholds": {"dir_cos_min": DIR_COS_MIN, "norm_factor": NORM_FACTOR, "stab_cos": STAB_COS, "stab_ratio": STAB_RATIO, "suspect_cos": SUSPECT_COS},
               "rise_step": pol.rise_step, "level_d_final": list(pol.level_d),
               "cliff_gate_best_minus_final": cliff, "collapse_rung1_lt_0p1": bool(deliv["final"]["eta_rung1"] < 0.1),
               "terminal_gap_original": r["checkpoints"][-1]["gap_descent_minus_gate"],
               "terminal_gap_current": r["checkpoints"][-1]["eta_binary_descent_current"] - r["checkpoints"][-1]["eta_gate"],
               "guard_stats": pol.stats, "events": pol.events, "steps_log": pol.rows,
               "wall_descent_s": r["wall_descent_s"], "wall_gate_s": r["wall_gate_s"], "wall_high_order_s": r["wall_high_order_s"],
               "wall_probe_s": pol.stats["wall_probe_s"], "wall_recompute_s": pol.stats["wall_recompute_s"], "wall_c128_s": pol.stats["wall_c128_s"],
               "wall_suspect_s": pol.stats["wall_suspect_s"],
               "ticket_cost_s": r["wall_descent_s"] - (0.0 if arm["adaptive"] else pol.stats["wall_probe_s"]) + 12 * gate_fwd,
               "ticket_cost_selected_s": r["wall_descent_s"] - (0.0 if arm["adaptive"] else pol.stats["wall_probe_s"]) + r["n_ckpt"] * gate_fwd,
               "finished": time.strftime("%Y-%m-%d %H:%M:%S"),
               "unit_wall_s": time.perf_counter() - t_start, "grad_events_nan_guard": ev}
        R["tickets"][key] = rec
        C.save_json(path, R)
        st = pol.stats
        log("%s m=%d %s seed %d | best@%d gate %.4f r1 %.4f opt %+.4f | final r1 %.4f | cliff %.3f | high %d | norm %d/%d dir %d/%d suspect %d/%d (trig/unstable) would %s smallgap %d c128 %d skip %d | cost %s [%s]"
            % (arm_name, m, key, seed, deliv["best"]["step"], deliv["best"]["eta_gate"], deliv["best"]["eta_rung1"], deliv["best"]["gate_optimism"],
               deliv["final"]["eta_rung1"], cliff, r["n_high_order_steps"], st["n_trigger"]["norm"], st["n_true_positive"]["norm"],
               st["n_trigger"]["direction"], st["n_true_positive"]["direction"], st["n_suspect_high"], st["n_suspect_unstable"],
               st["n_would_trigger"], st["n_small_gap"], st["n_c128"], st["n_skip_high"],
               C.fmt_s(rec["ticket_cost_s"]), C.fmt_s(time.perf_counter() - t_start)), fh)
    # ---- pipeline on groups of 3: select, certify, numeric repair trigger
    tickets = [R["tickets"]["s%02d" % i] for i in range(len(seeds)) if "s%02d" % i in R["tickets"]]
    for gi in range(len(tickets) // 3):
        gkey = "g%02d" % gi
        if gkey in R["groups"]:
            continue
        members = tickets[gi * 3:(gi + 1) * 3]
        win = max(members, key=lambda t: t["deliver_best"]["eta_gate"])
        zb = np.load(os.path.join(DATA, win["deliver_best"]["files"]["binary"]))
        b = torch.from_numpy(np.unpackbits(zb["packed"], axis=1)[:, :int(zb["shape"][1])].astype(np.float64))
        assert C.sha1_of(b) == win["deliver_best"]["sha1"], "delivered binary does not reproduce its sha1"
        t_read = time.perf_counter()
        e_top = C.eta(b, od["top"], ctx)
        t_read = time.perf_counter() - t_read
        bar = POOL_MEDIAN_RUNG1[m] - 0.05
        trig = (win["deliver_best"]["eta_rung1"] < bar) and (win["deliver_best"]["gate_optimism"] < OPTIMISM_MAX)
        grp = {"members": [t["index"] for t in members], "winner": win["index"], "eta_gate": win["deliver_best"]["eta_gate"],
               "eta_rung1": win["deliver_best"]["eta_rung1"], "eta_top": e_top, "rung1_minus_top": win["deliver_best"]["eta_rung1"] - e_top,
               "gate_optimism": win["deliver_best"]["gate_optimism"], "repair_bar": bar, "repair_triggered": bool(trig), "repair": None,
               "instrument_wall_s": t_read}
        if trig:
            grp["repair"] = run_chain(win, m, gi, ctx, od, arm, tau, device, fh, arm_name)
        R["groups"][gkey] = grp
        C.save_json(path, R)
        log("%s m=%d %s | winner s%02d gate %.4f r1 %.4f top %.4f | repair %s" % (arm_name, m, gkey, win["index"], grp["eta_gate"], grp["eta_rung1"], e_top,
                                                                                 ("%d accepts -> r1 %.4f" % (grp["repair"]["n_accept"], grp["repair"]["final_eta_rung1"])) if grp["repair"] else "not triggered"), fh)
    return R


def run_chain(parent, m, gi, ctx, od, arm, tau, device, fh, arm_name):
    cfg = ctx.cfg
    lat = torch.from_numpy(np.load(os.path.join(DATA, parent["deliver_best"]["files"]["latent"])).astype(np.float64))
    inc_lat = lat.to(device) if device != "cpu" else lat
    inc_bin = app_hard_binary(inc_lat.detach().cpu(), cfg, ctx.mode)
    assert C.sha1_of(inc_bin) == parent["deliver_best"]["sha1"], "parent latent does not reproduce its binary"
    inc_gate, inc_r1 = parent["deliver_best"]["eta_gate"], parent["deliver_best"]["eta_rung1"]
    beta_re = max(float(parent["beta_star"]), 64.0)
    pol = GradPolicy(ctx, od, dict(arm, adaptive=False, rise=False, k=RE_K, mix_from_beta=None, mix_from_step=0), tau, fh)
    pol.beta_fn = lambda t: beta_re
    jumps, curve, n_acc, rejects = [], [{"jump": -1, "eta_gate": inc_gate, "eta_rung1": inc_r1}], 0, 0
    t0 = time.perf_counter()
    for j in range(CHAIN_HOPS):
        alpha = ALPHAS[j % len(ALPHAS)]
        noise = filtered_noise(NOISE_BASE + 10000 * m + 100 * gi + j, cfg)
        if device != "cpu":
            noise = noise.to(device)
        rho = _sym((inc_lat + alpha * cfg.init_scale * noise).clamp(0.0, 1.0), ctx.mode)
        adam = C.AppAdam(rho.shape, cfg, ctx.mode, device)
        pol.hop, pol.prev_g, pol.norms, pol.prev_low_g = j, {}, {}, None        # per-latent guard state restarts at every hop
        for t in range(RE_STEPS):
            lr = C.cosine_lr(t / RE_STEPS, cfg)
            high = (t % RE_K == 0)
            v, g, row = pol.gradient(rho, pol.level_g if high else pol.level_d, beta_re, t, high, adam=adam)
            if g is None and high:
                v, g, row = pol.gradient(rho, pol.level_d, beta_re, t, False, adam=adam)
            if g is not None:
                rho = adam.step(rho, g, lr)
        cb = app_hard_binary(rho.detach().cpu(), cfg, ctx.mode)
        sc = C.eta(cb, od["gate"], ctx)
        acc = bool(sc > inc_gate)
        row = {"jump": j, "alpha": alpha, "cand_gate": sc, "cand_minus_inc": sc - inc_gate, "n_flipped": int((cb != inc_bin).sum()), "accepted": acc}
        if acc:
            r1 = C.eta(cb, od["rung1"], ctx)
            row.update({"cand_rung1": r1, "false_accept": bool(r1 < inc_r1)})
            inc_lat, inc_bin, inc_gate, inc_r1, n_acc, rejects = rho, cb, sc, r1, n_acc + 1, 0
        else:
            rejects += 1
        jumps.append(row)
        curve.append({"jump": j, "eta_gate": inc_gate, "eta_rung1": inc_r1})
        log("    chain hop %2d a=%.2f cand %.4f (%+.4f) flips %d %s" % (j, alpha, sc, sc - inc_gate, row["n_flipped"], "ACCEPT r1 %.4f" % inc_r1 if acc else "reject"), fh)
        if rejects >= CHAIN_STOP:
            break
    files = save_mask("s10_%s_m%d_g%02d_chain" % (arm_name, m, gi), inc_bin, inc_lat)
    return {"parent": parent["index"], "beta_re": beta_re, "hops_run": len(jumps), "n_accept": n_acc,
            "n_false_accept": int(sum(1 for x in jumps if x.get("false_accept"))), "final_eta_gate": inc_gate, "final_eta_rung1": inc_r1,
            "gain_rung1": inc_r1 - parent["deliver_best"]["eta_rung1"], "jumps": jumps, "incumbent_curve": curve,
            "guard_stats": pol.stats, "events": pol.events, "steps_log": pol.rows, "wall_s": time.perf_counter() - t0, "files": files}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arm", default="B")
    ap.add_argument("--m", type=int, default=4)
    ap.add_argument("--n", type=int, default=N_DEFAULT)
    ap.add_argument("--seeds", default="")
    ap.add_argument("--dry", action="store_true", help="30-step smoke test into data_dry/")
    a = ap.parse_args()
    if a.dry:
        global STEPS, HIGH_BUDGET, DATA, DESIGNS, LOGS, CHAIN_HOPS, RE_STEPS
        STEPS, HIGH_BUDGET, CHAIN_HOPS, RE_STEPS = 30, 6, 2, 4
        DATA = os.path.abspath(os.path.join(_HERE, "..", "data_dry"))
        DESIGNS, LOGS = os.path.join(DATA, "designs"), os.path.join(DATA, "logs")
        ARMS["Aprime"]["mix_from_step"] = 8
    os.makedirs(LOGS, exist_ok=True)
    V.GAP_ONLY_DIAGNOSTICS = True
    device = C.setup_runtime()
    assert_eig_cpu()
    fh = open(os.path.join(LOGS, "s10_e3.log"), "a", encoding="utf-8")
    tau = load_tau()
    seeds = [int(s) for s in a.seeds.split(",") if s.strip()] or SEEDS[a.m][:a.n]
    log("S10 start | arms %s | m=%d | n=%d | tau %s | dir_cos_min %.2f norm_factor %.1f suspect_cos %.2f | device %s"
        % (a.arm, a.m, len(seeds), tau or "default %g" % TAU_DEFAULT, DIR_COS_MIN, NORM_FACTOR, SUSPECT_COS, device), fh)
    t0 = time.perf_counter()
    for arm in a.arm.split(","):
        assert arm in ARMS, arm
        run_arm(arm, a.m, seeds, device, fh, tau)
    log("S10 done in %s" % C.fmt_s(time.perf_counter() - t0), fh)


if __name__ == "__main__":
    main()
