"""S10 -- analysis of the E3 v2 arms (no solves).

Delivery level (per arm): delivered / final rung1 distributions, E[best of 3]
by gate with ticket bootstrap, cliffs (gate best - final > 0.1), collapses
(final rung1 < 0.1), terminal gap, high-order steps, cost (priced and
measured), guard counts and true-positive rates per 100 evaluations per order.
Step level: drop events (> 0.05 fall of the descent-order continuous value
between consecutive low-order steps) and their timing relative to (i) the
preceding update being a high-order step and (ii) a guard trigger / would-
trigger within the previous 10 steps -- enrichment ratios per arm.
Comparisons: each arm vs Aprime (unpaired, bootstrap), and the S7 equal-wall
comparison against T (the published workflow) at the arm's 3-ticket cost.
Writes data/s10_summary.json and figures/*.png.
"""
import json
import math
import os
import sys

import numpy as np

_HERE = os.path.dirname(os.path.abspath(__file__))
_S7 = os.path.abspath(os.path.join(_HERE, "..", "..", "S7_headtohead", "scripts"))
sys.path.insert(0, _S7)
DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
FIG = os.path.abspath(os.path.join(_HERE, "..", "figures"))
S7DATA = os.path.abspath(os.path.join(_HERE, "..", "..", "S7_headtohead", "data"))
ARMS = ["Aprime", "B", "MIX8", "D1", "D2", "E"]
DROP = 0.05
WINDOW_AFTER_TRIGGER = 10


def e_best_by(select, deliver, N):
    n = len(select)
    if N < 1 or N > n:
        return None
    order = sorted(range(n), key=lambda i: (select[i], i))
    return sum(deliver[i] * math.comb(r - 1, N - 1) for r, i in enumerate(order, start=1)) / math.comb(n, N)


def e_best_interp(select, deliver, Nf):
    lo, hi = int(math.floor(Nf)), int(math.ceil(Nf))
    a, b = e_best_by(select, deliver, lo), e_best_by(select, deliver, hi)
    if a is None or b is None:
        return None
    return a if hi == lo else a + (b - a) * (Nf - lo)


def q(v):
    v = [x for x in v if x is not None and x == x]
    if not v:
        return None
    a = np.array(v, float)
    return {"n": len(a), "median": float(np.median(a)), "q1": float(np.percentile(a, 25)), "q3": float(np.percentile(a, 75)),
            "min": float(a.min()), "max": float(a.max()), "mean": float(a.mean())}


def boot(fn, n, reps=2000, seed=0):
    rng = np.random.default_rng(seed)
    vals = [fn(rng.integers(0, n, n)) for _ in range(reps)]
    vals = [v for v in vals if v is not None]
    return [float(np.percentile(vals, 2.5)), float(np.percentile(vals, 97.5))] if vals else None


def load_arm(arm, m):
    p = os.path.join(DATA, "s10_%s_m%d.json" % (arm, m))
    return json.load(open(p, encoding="utf-8")) if os.path.exists(p) else None


def step_events(t):
    """Drop events between consecutive low-order (non-probe) rows; annotate."""
    rows = [r for r in t["steps_log"] if not r.get("probe")]
    by_t = {r["t"]: r for r in rows}
    low = [r for r in rows if not r["high"] and r["value"] is not None]
    trig_steps = [r["t"] for r in rows if r["action"] not in ("ok", "log_only_direction")]   # norm (would-)triggers and real guard actions
    tp_steps = [r["t"] for r in rows if r.get("true_positive")]
    events = []
    for a, b in zip(low, low[1:]):
        d = a["value"] - b["value"]
        if d > DROP:
            prev_high = any(by_t.get(s, {}).get("high") for s in range(a["t"], b["t"]))   # the updates between the two low reads
            recent_trig = any(a["t"] - WINDOW_AFTER_TRIGGER <= s <= b["t"] for s in trig_steps)
            recent_tp = any(a["t"] - WINDOW_AFTER_TRIGGER <= s <= b["t"] for s in tp_steps)
            events.append({"t": b["t"], "beta": b["beta"], "drop": round(d, 4), "from": a["value"], "to": b["value"],
                           "update_was_high": bool(prev_high), "trigger_within_10": bool(recent_trig), "tp_within_10": bool(recent_tp)})
    n_low_pairs = max(len(low) - 1, 1)
    n_high_pairs = sum(1 for a, b in zip(low, low[1:]) if any(by_t.get(s, {}).get("high") for s in range(a["t"], b["t"])))
    return events, {"n_low_pairs": n_low_pairs, "n_pairs_after_high": n_high_pairs, "n_triggers": len(trig_steps), "n_tp": len(tp_steps)}


def guard_rates(t):
    st = t["guard_stats"]
    out = {}
    for lv, n in st["n_eval"].items():
        out[lv] = {"n_eval": n}
    ev = t.get("events", [])
    for lv in out:
        trig = [e for e in ev if str(tuple(e["level"])) == lv and e.get("reason") in ("norm", "direction", "raise", "nonfinite", "suspect")]
        tp = [e for e in trig if e.get("action") in ("jitter", "recompute", "c128") and (e.get("cos") is not None and e["cos"] < 0.9 or (e.get("ratio") is not None and not 0.5 <= e["ratio"] <= 2.0) or e.get("reason") == "suspect" and e.get("stable") is False)]
        out[lv].update({"n_trigger": len(trig), "n_true_positive": len(tp), "tp_per_100_eval": 100.0 * len(tp) / max(out[lv]["n_eval"], 1)})
    return out


def analyze_arm(arm, m):
    R = load_arm(arm, m)
    if not R or not R["tickets"]:
        return None
    T = [R["tickets"][k] for k in sorted(R["tickets"])]
    gate = [t["deliver_best"]["eta_gate"] for t in T]
    r1 = [t["deliver_best"]["eta_rung1"] for t in T]
    fin = [t["deliver_final"]["eta_rung1"] for t in T]
    cliffs = [t["cliff_gate_best_minus_final"] for t in T]
    n = len(T)
    ev_all, ev_stats = [], {"n_low_pairs": 0, "n_pairs_after_high": 0, "n_drops": 0, "n_drops_after_high": 0, "n_drops_after_trigger": 0, "n_drops_after_tp": 0, "n_triggers": 0, "n_tp": 0}
    for t in T:
        ev, st = step_events(t)
        ev_all.append(ev)
        ev_stats["n_low_pairs"] += st["n_low_pairs"]
        ev_stats["n_pairs_after_high"] += st["n_pairs_after_high"]
        ev_stats["n_triggers"] += st["n_triggers"]
        ev_stats["n_tp"] += st["n_tp"]
        ev_stats["n_drops"] += len(ev)
        ev_stats["n_drops_after_high"] += sum(e["update_was_high"] for e in ev)
        ev_stats["n_drops_after_trigger"] += sum(e["trigger_within_10"] for e in ev)
        ev_stats["n_drops_after_tp"] += sum(e["tp_within_10"] for e in ev)
    p_high = ev_stats["n_pairs_after_high"] / max(ev_stats["n_low_pairs"], 1)
    p_drop_high = ev_stats["n_drops_after_high"] / max(ev_stats["n_drops"], 1)
    ev_stats["enrichment_high"] = (p_drop_high / p_high) if p_high > 0 else None
    out = {"arm": arm, "m": m, "n": n, "config": R["meta"].get("config"), "high_budget": R["meta"].get("high_budget"),
           "delivered_rung1": q(r1), "final_rung1": q(fin), "gate": q(gate), "cliff": q(cliffs),
           "n_cliff_gt_0p1": int(sum(c > 0.1 for c in cliffs)), "n_collapse": int(sum(f < 0.1 for f in fin)),
           "terminal_gap_original": q([t["terminal_gap_original"] for t in T]),
           "terminal_gap_current": q([t.get("terminal_gap_current") for t in T]),
           "n_high_order_steps": q([t["n_high_order_steps"] for t in T]),
           "ticket_cost_min": q([t["ticket_cost_s"] / 60 for t in T]), "unit_wall_min": q([t["unit_wall_s"] / 60 for t in T]),
           "wall_probe_min": q([t.get("wall_probe_s", 0) / 60 for t in T]), "wall_recompute_min": q([t.get("wall_recompute_s", 0) / 60 for t in T]),
           "e_best_of_3_by_gate": e_best_by(gate, r1, 3) if n >= 3 else None,
           "e_best_of_3_ci": boot(lambda idx: e_best_by([gate[i] for i in idx], [r1[i] for i in idx], 3), n) if n >= 3 else None,
           "rise_steps": [t.get("rise_step") for t in T], "level_d_final": [t.get("level_d_final") for t in T],
           "k_final": [(t["k_history"][-1]["k"] if t.get("k_history") and "k" in t["k_history"][-1] else None) for t in T],
           "guard": {"n_trigger": {}, "n_true_positive": {}, "n_would": {}, "n_c128": 0, "n_skip_high": 0, "n_kept_original": 0, "n_suspect": 0, "n_suspect_unstable": 0},
           "guard_rates_by_order": {}, "drop_events": ev_stats, "events_per_ticket": ev_all,
           "groups": R.get("groups", {})}
    for t in T:
        st = t["guard_stats"]
        for k, v in st["n_trigger"].items():
            out["guard"]["n_trigger"][k] = out["guard"]["n_trigger"].get(k, 0) + v
        for k, v in st["n_true_positive"].items():
            out["guard"]["n_true_positive"][k] = out["guard"]["n_true_positive"].get(k, 0) + v
        for k, v in st.get("n_would_trigger", {}).items():
            out["guard"]["n_would"][k] = out["guard"]["n_would"].get(k, 0) + v
        out["guard"]["n_c128"] += st.get("n_c128", 0)
        out["guard"]["n_skip_high"] += st.get("n_skip_high", 0)
        out["guard"]["n_kept_original"] += st.get("n_kept_original", 0)
        out["guard"]["n_suspect"] += st.get("n_suspect_high", 0)
        out["guard"]["n_suspect_unstable"] += st.get("n_suspect_unstable", 0)
        for lv, d in guard_rates(t).items():
            g = out["guard_rates_by_order"].setdefault(lv, {"n_eval": 0, "n_trigger": 0, "n_true_positive": 0})
            g["n_eval"] += d["n_eval"]
            g["n_trigger"] += d.get("n_trigger", 0)
            g["n_true_positive"] += d.get("n_true_positive", 0)
    for lv, g in out["guard_rates_by_order"].items():
        g["tp_per_100_eval"] = 100.0 * g["n_true_positive"] / max(g["n_eval"], 1)
    return out, gate, r1


def equal_wall_T(m, cost3_min):
    """S7's T pool at this m: E[best of N] for N = cost3 / T ticket cost (own rule and by gate)."""
    p = os.path.join(S7DATA, "s7_T_b2000.json")
    if not os.path.exists(p):
        return None
    U = [v for v in json.load(open(p, encoding="utf-8"))["units"].values() if v["target"][0] == m]
    if not U:
        return None
    rep = [v["reported"] for v in U]
    fin = [v["deliver_final"]["eta_rung1"] for v in U]
    gate_final = [v["deliver_final"]["eta_gate"] if "eta_gate" in v["deliver_final"] else v["gate"][1] if isinstance(v.get("gate"), list) else v["reported"] for v in U]
    cost = float(np.median([v["wall_descent_s"] for v in U])) / 60
    N = cost3_min / cost
    return {"T_ticket_cost_min": cost, "N_equal_wall": N, "T_own_rule": e_best_interp(rep, fin, min(N, len(U) / 2)),
            "T_by_gate": e_best_interp(gate_final, fin, min(N, len(U) / 2)), "capped_at": len(U) / 2, "n_T": len(U)}


def main():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    os.makedirs(FIG, exist_ok=True)
    summary = {}
    for m in (4, 3):
        arms = {}
        raw = {}
        for arm in ARMS:
            res = analyze_arm(arm, m)
            if res:
                arms[arm], raw[arm] = res[0], (res[1], res[2])
        if not arms:
            continue
        # unpaired comparisons vs Aprime
        if "Aprime" in raw:
            ga, ra = raw["Aprime"]
            for arm in arms:
                if arm == "Aprime":
                    continue
                gb, rb = raw[arm]
                def diff_med(idx_a, idx_b):
                    return float(np.median([rb[i] for i in idx_b]) - np.median([ra[i] for i in idx_a]))
                rng = np.random.default_rng(1)
                dm = [diff_med(rng.integers(0, len(ra), len(ra)), rng.integers(0, len(rb), len(rb))) for _ in range(2000)]
                de = []
                for _ in range(2000):
                    ia, ib = rng.integers(0, len(ra), len(ra)), rng.integers(0, len(rb), len(rb))
                    a = e_best_by([ga[i] for i in ia], [ra[i] for i in ia], 3)
                    b = e_best_by([gb[i] for i in ib], [rb[i] for i in ib], 3)
                    if a is not None and b is not None:
                        de.append(b - a)
                arms[arm]["vs_Aprime"] = {"median_diff": float(np.median(rb) - np.median(ra)), "median_diff_ci": [float(np.percentile(dm, 2.5)), float(np.percentile(dm, 97.5))],
                                          "e_best3_diff": (arms[arm]["e_best_of_3_by_gate"] or 0) - (arms["Aprime"]["e_best_of_3_by_gate"] or 0),
                                          "e_best3_diff_ci": [float(np.percentile(de, 2.5)), float(np.percentile(de, 97.5))] if de else None,
                                          "cliffs": "%d/%d vs %d/%d" % (arms[arm]["n_cliff_gt_0p1"], arms[arm]["n"], arms["Aprime"]["n_cliff_gt_0p1"], arms["Aprime"]["n"]),
                                          "cost_ratio_median": arms[arm]["ticket_cost_min"]["median"] / arms["Aprime"]["ticket_cost_min"]["median"]}
        for arm in arms:
            arms[arm]["equal_wall_T"] = equal_wall_T(m, 3 * arms[arm]["ticket_cost_min"]["median"])
        summary["m%d" % m] = arms
        # --- console
        print("\n=== m=%d ===" % m)
        print("arm    n  deliv r1 med [q1,q3]     min   max | final med | cliffs coll | E3(gate)  CI            | gap0    | high | cost min (unit) | trig: norm tp / would | TP/100 by order | vs A': dmed [CI]  dE3 [CI]")
        for arm in ARMS:
            if arm not in arms:
                continue
            a = arms[arm]
            d, f = a["delivered_rung1"], a["final_rung1"]
            g = a["guard"]
            tp = " ".join("%s:%.1f" % (lv.replace("(", "").replace(")", "").replace(", ", "-"), v["tp_per_100_eval"]) for lv, v in a["guard_rates_by_order"].items())
            va = a.get("vs_Aprime")
            print("%-6s %d  %.3f [%.3f,%.3f] %.3f %.3f | %.3f     | %d/%d  %d/%d | %s  %s | %+.3f | %4.0f | %5.1f (%5.1f) | %d %d / %s | %s | %s"
                  % (arm, a["n"], d["median"], d["q1"], d["q3"], d["min"], d["max"], f["median"], a["n_cliff_gt_0p1"], a["n"], a["n_collapse"], a["n"],
                     ("%.3f" % a["e_best_of_3_by_gate"]) if a["e_best_of_3_by_gate"] is not None else "  -  ",
                     ("[%.3f,%.3f]" % tuple(a["e_best_of_3_ci"])) if a["e_best_of_3_ci"] else "", a["terminal_gap_original"]["median"],
                     a["n_high_order_steps"]["median"], a["ticket_cost_min"]["median"], a["unit_wall_min"]["median"],
                     g["n_trigger"].get("norm", 0), g["n_true_positive"].get("norm", 0), g["n_would"], tp,
                     ("%+.3f [%+.3f,%+.3f]  %+.3f [%+.3f,%+.3f]" % (va["median_diff"], *va["median_diff_ci"], va["e_best3_diff"], *(va["e_best3_diff_ci"] or [0, 0]))) if va else ""))
            ds = a["drop_events"]
            print("        drops>%.2f: %d in %d low pairs; after a high update %d (pairs after high %d, enrichment %s); within 10 steps after a trigger %d, after a TP %d; ew T: %s"
                  % (DROP, ds["n_drops"], ds["n_low_pairs"], ds["n_drops_after_high"], ds["n_pairs_after_high"],
                     ("%.2f" % ds["enrichment_high"]) if ds["enrichment_high"] else "-", ds["n_drops_after_trigger"], ds["n_drops_after_tp"],
                     ("N=%.1f own %.3f gate %.3f" % (a["equal_wall_T"]["N_equal_wall"], a["equal_wall_T"]["T_own_rule"] or 0, a["equal_wall_T"]["T_by_gate"] or 0)) if a["equal_wall_T"] else "-"))
            for gk, gr in a["groups"].items():
                print("        %s: winner s%02d gate %.3f r1 %.3f top %.3f | repair %s" % (gk, gr["winner"], gr["eta_gate"], gr["eta_rung1"], gr["eta_top"],
                      ("%d accepts r1 %.3f" % (gr["repair"]["n_accept"], gr["repair"]["final_eta_rung1"])) if gr.get("repair") else "not triggered"))
        # --- figure: delivered and final rung1 per arm
        fig, ax = plt.subplots(figsize=(9, 4))
        xs = [arm for arm in ARMS if arm in arms]
        for i, arm in enumerate(xs):
            r1 = raw[arm][1]
            fin = [t["deliver_final"]["eta_rung1"] for t in [load_arm(arm, m)["tickets"][k] for k in sorted(load_arm(arm, m)["tickets"])]]
            ax.scatter([i - 0.12] * len(r1), r1, s=28, color="#1f4e79", label="delivered (best gate ckpt)" if i == 0 else None)
            ax.scatter([i + 0.12] * len(fin), fin, s=28, color="#9db7d5", marker="s", label="final field" if i == 0 else None)
            if arms[arm]["e_best_of_3_by_gate"] is not None:
                ax.plot([i - 0.3, i + 0.3], [arms[arm]["e_best_of_3_by_gate"]] * 2, color="0.2", lw=1.2)
        ax.set_xticks(range(len(xs)))
        ax.set_xticklabels(xs)
        ax.set_ylabel("rung-1 efficiency (m=%d)" % m)
        ax.set_ylim(0, 1)
        ax.grid(axis="y", alpha=0.3)
        ax.legend(fontsize=8, loc="lower right")
        ax.set_title("E3 v2 arms, m=%d: tickets (dots), final field (squares), E[best of 3] by gate (bar)" % m, fontsize=9)
        fig.tight_layout()
        fig.savefig(os.path.join(FIG, "s10_arms_m%d.png" % m), dpi=160)
        plt.close(fig)
    json.dump(summary, open(os.path.join(DATA, "s10_summary.json"), "w", encoding="utf-8"), indent=1, default=lambda o: None)
    print("\nwritten", os.path.join(DATA, "s10_summary.json"))


if __name__ == "__main__":
    main()
