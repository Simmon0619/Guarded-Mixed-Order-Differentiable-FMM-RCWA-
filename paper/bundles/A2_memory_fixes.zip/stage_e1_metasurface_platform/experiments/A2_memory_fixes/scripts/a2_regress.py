"""A2 regression: re-certify the three frozen records at (48,12), plus first
gradient availability at (48,12) on the record designs.

References (frozen, not re-derived here):
  (1,0) 1_0_w5nm  140x480  eta_48_12 = 0.8874827027320862   E26 check_48_12.json
  (2,0) 2_0_w5nm  140x480  eta_48_12 = 0.8462339043617249   E26 check_48_12.json
  (3,0) 3_0_ext205 70x240  eta_48_12 = 0.69443279504776     E28 extend205.json
Certification convention is E26's: native fine grid, GPU/c64, no_grad.

Two arms per record:
  offload  -- untouched solver under save_on_cpu (memory-layout only,
              values expected bitwise-identical to the stored numbers)
  me       -- MEMORY_EFFICIENT solver (exact algebra, reordered floats,
              expected within ~1e-5 relative; E17 tolerance 1e-4 governs)
The gradient arm runs MEMORY_EFFICIENT + save_on_cpu at (48,12) (the best
deployed config from a2_accept batch C; checkpoint brushes the 12 GB wall
during backward recompute) and reports (2N, peak, time) -- the first (48,12)
gradients on this GPU.

Run:  python a2_regress.py
Writes experiments/A2_memory_fixes/data/a2_regress_<timestamp>.json
"""
import json
import os
import sys
import time

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
for rel in (("..", "..", "E26_fine_pixels", "scripts"),
            ("..", "..", "E20_high_order", "scripts")):
    path = os.path.abspath(os.path.join(_HERE, *rel))
    if path not in sys.path:
        sys.path.insert(0, path)
import e26_common as F  # noqa: E402  (sets VECTORIZED_CONV / FAST_DIAGNOSTICS)
import trustworthy_fmm.solvers.vector_2d as _v2d  # noqa: E402

DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
GIB = 2.0 ** 30
LEVEL = (48, 12)

RECORDS = [
    {"tag": "1_0_w5nm", "target": (1, 0), "pixel": 5,
     "path": os.path.join(F.DATA, "1_0_w5nm_binary.npy"),
     "reference": 0.8874827027320862, "source": "E26 check_48_12.json"},
    {"tag": "2_0_w5nm", "target": (2, 0), "pixel": 5,
     "path": os.path.join(F.DATA, "2_0_w5nm_binary.npy"),
     "reference": 0.8462339043617249, "source": "E26 check_48_12.json"},
    {"tag": "3_0_ext205", "target": (3, 0), "pixel": 10,
     "path": os.path.join(F.DATA, "..", "..", "E28_frontier", "data",
                          "3_0_ext205_binary.npy"),
     "reference": 0.69443279504776, "source": "E28 extend205.json"},
]


def certify(density, target, cfg, memory_efficient, offload):
    _v2d.MEMORY_EFFICIENT = memory_efficient
    _v2d.CHECKPOINT_SMATRIX = False
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats()
    torch.cuda.synchronize()
    t0 = time.time()
    if offload:
        # no_grad certification never stores autograd state; save_on_cpu is a
        # no-op here but kept for a faithful "deployed configuration" timing
        with torch.autograd.graph.save_on_cpu(pin_memory=True):
            eta = F.eta_gpu(density, LEVEL, target, cfg)
    else:
        eta = F.eta_gpu(density, LEVEL, target, cfg)
    torch.cuda.synchronize()
    result = {"eta": eta, "s": time.time() - t0,
              "peak_GiB": torch.cuda.max_memory_allocated() / GIB}
    _v2d.MEMORY_EFFICIENT = False
    return result


def gradient(density, target, cfg):
    _v2d.MEMORY_EFFICIENT = True
    _v2d.CHECKPOINT_SMATRIX = False
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats()
    torch.cuda.synchronize()
    t0 = time.time()
    x = density.detach().clone().requires_grad_(True)
    with torch.autograd.graph.save_on_cpu(pin_memory=True):
        r = F.solve_density(x, LEVEL, torch.complex64, "cuda", cfg)
        j = r.power_t[r.orders.index(tuple(target))]
        j.backward()
    torch.cuda.synchronize()
    result = {"eta": float(j.detach()), "s": time.time() - t0,
              "peak_GiB": torch.cuda.max_memory_allocated() / GIB,
              "grad_norm": float(x.grad.norm()),
              "grad_abs_max": float(x.grad.abs().max())}
    _v2d.MEMORY_EFFICIENT = False
    _v2d.CHECKPOINT_SMATRIX = False
    return result


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", nargs="*", default=None,
                    help="run only these record tags (default: all)")
    args = ap.parse_args()
    records = [r for r in RECORDS
               if args.only is None or r["tag"] in args.only]
    report = {"gpu": torch.cuda.get_device_name(0), "torch": torch.__version__,
              "level": list(LEVEL), "records": []}
    for record in records:
        cfg = F.FINE[record["pixel"]]
        density = torch.from_numpy(
            np.load(record["path"]).astype("float64"))
        n = (2 * LEVEL[0] + 1) * (2 * LEVEL[1] + 1)
        row = {"tag": record["tag"], "target": list(record["target"]),
               "grid": [cfg.ny, cfg.nx], "two_n": 2 * n,
               "reference": record["reference"], "source": record["source"]}
        print(f"\n== {record['tag']}  grid {cfg.ny}x{cfg.nx}  2N={2*n}", flush=True)
        for arm, me in (("offload", False), ("me", True)):
            out = certify(density, record["target"], cfg, me, offload=(arm == "offload"))
            out["abs_diff_vs_reference"] = abs(out["eta"] - record["reference"])
            out["rel_diff_vs_reference"] = (
                out["abs_diff_vs_reference"] / abs(record["reference"]))
            row[arm] = out
            print(f"   {arm:<8s} eta={out['eta']:.12f}  "
                  f"ref={record['reference']:.12f}  "
                  f"rel_diff={out['rel_diff_vs_reference']:.3e}  "
                  f"{out['s']:6.1f} s  peak {out['peak_GiB']:.2f} GiB", flush=True)
        row["gradient_me_offload"] = gradient(density, record["target"], cfg)
        g = row["gradient_me_offload"]
        print(f"   grad     eta={g['eta']:.12f}  |g|={g['grad_norm']:.3e}  "
              f"{g['s']:6.1f} s  peak {g['peak_GiB']:.2f} GiB", flush=True)
        report["records"].append(row)
        os.makedirs(DATA, exist_ok=True)
        out_path = os.path.join(DATA, "a2_regress_latest.json")
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2)
    final = os.path.join(DATA, time.strftime("a2_regress_%Y%m%d_%H%M%S.json"))
    os.replace(out_path, final)
    print("\nsaved", final)


if __name__ == "__main__":
    main()
