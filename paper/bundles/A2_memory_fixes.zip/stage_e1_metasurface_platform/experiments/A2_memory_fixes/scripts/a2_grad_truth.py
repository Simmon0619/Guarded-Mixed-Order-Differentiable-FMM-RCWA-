"""A2 gradient-truth arbitration: which c64 gradient is closer to fp64 truth?

At (32,8)@2x (fits everywhere) compute three gradients of eta(1,0) wrt the
seed-0 random density:
  truth    -- GPU/c128, untouched solver (the fp64 reference)
  base_c64 -- GPU/c64, untouched solver
  me_c64   -- GPU/c64, MEMORY_EFFICIENT solver
and report cosines/relative-L2 of each c64 gradient against truth, plus
me_c128 vs truth (transform exactness in fp64).

Run:  python a2_grad_truth.py [--level 32,8]
Writes experiments/A2_memory_fixes/data/a2_grad_truth_<timestamp>.json
"""
import argparse
import json
import os
import sys
import time

import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
_E20 = os.path.abspath(os.path.join(_HERE, "..", "..", "E20_high_order", "scripts"))
if _E20 not in sys.path:
    sys.path.insert(0, _E20)
import e20_common as E  # noqa: E402
import trustworthy_fmm.solvers.vector_2d as _v2d  # noqa: E402

DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))


def one(density, level, target, dtype, memory_efficient):
    _v2d.MEMORY_EFFICIENT = memory_efficient
    _v2d.CHECKPOINT_SMATRIX = False
    torch.cuda.empty_cache()
    t0 = time.time()
    eta, grad = E.ours_eta_grad(density, level, target, dtype, "cuda")
    torch.cuda.synchronize()
    _v2d.MEMORY_EFFICIENT = False
    return eta, grad.flatten().double(), time.time() - t0


def against(grad, truth):
    return {
        "cos": float(torch.dot(grad, truth) / (grad.norm() * truth.norm())),
        "rel_l2": float((grad - truth).norm() / truth.norm()),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--level", default="32,8")
    ap.add_argument("--grid", type=int, default=2)
    ap.add_argument("--target", default="1,0")
    args = ap.parse_args()
    level = tuple(int(v) for v in args.level.split(","))
    target = tuple(int(v) for v in args.target.split(","))
    torch.manual_seed(0)
    density = E.upsample((torch.rand(35, 120) > 0.5).double(), args.grid)

    eta_truth, g_truth, s_truth = one(density, level, target, torch.complex128, False)
    eta_me128, g_me128, s_me128 = one(density, level, target, torch.complex128, True)
    eta_base, g_base, s_base = one(density, level, target, torch.complex64, False)
    eta_me, g_me, s_me = one(density, level, target, torch.complex64, True)

    report = {
        "level": list(level), "target": list(target),
        "eta": {"truth_c128": eta_truth, "me_c128": eta_me128,
                "base_c64": eta_base, "me_c64": eta_me},
        "value_abs_err_vs_truth": {
            "me_c128": abs(eta_me128 - eta_truth),
            "base_c64": abs(eta_base - eta_truth),
            "me_c64": abs(eta_me - eta_truth)},
        "grad_vs_truth": {
            "me_c128": against(g_me128, g_truth),
            "base_c64": against(g_base, g_truth),
            "me_c64": against(g_me, g_truth)},
        "grad_me_c64_vs_base_c64": against(g_me, g_base),
        "seconds": {"truth_c128": s_truth, "me_c128": s_me128,
                    "base_c64": s_base, "me_c64": s_me},
    }
    print(json.dumps(report, indent=2))
    os.makedirs(DATA, exist_ok=True)
    out = os.path.join(DATA, time.strftime("a2_grad_truth_%Y%m%d_%H%M%S.json"))
    with open(out, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
    print("saved", out)


if __name__ == "__main__":
    main()
