"""A2 acceptance: opt-in memory path vs the untouched solver (E17 tolerances).

Toggles (module attributes of trustworthy_fmm.solvers.vector_2d, default OFF):
  MEMORY_EFFICIENT    -- P/Q/V assembly from kx/ky vectors, direct interface
                         rhs, fused Redheffer LU reuse, elementwise
                         propagation star (exact algebra, reordered floats)
  CHECKPOINT_SMATRIX  -- recompute S-matrix steps in backward instead of
                         storing LU factors + solutions (eig never recomputed)
plus the caller-level ``torch.autograd.graph.save_on_cpu(pin_memory=True)``.

Modes (combine as level:dtype:mode):
  base_fwd, base_grad, base_grad_offload   -- untouched solver
  me_fwd, me_grad, me_grad_offload         -- MEMORY_EFFICIENT
  me_ckpt_grad, me_ckpt_grad_offload       -- MEMORY_EFFICIENT + CHECKPOINT
  cpu128_parity                            -- CPU/c128 (12,3) native grid,
                                              baseline vs ME in one row
Reference per (level, dtype): base_grad if it ran, else base_grad_offload
(save_on_cpu round-trips the same tensors, bitwise-identical values).
Acceptance (PROMPT A2): (48,12)@2x c64 value+grad inside 12 GB; total time
<= 1.3x untouched forward-only; value rel err <= 1e-4; grad cosine >= 0.9999.

Run:  python a2_accept.py [--configs ...] [--grid 2]
Writes experiments/A2_memory_fixes/data/a2_accept_<timestamp>.json
"""
import argparse
import json
import os
import subprocess
import sys
import threading
import time

import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
_E20 = os.path.abspath(os.path.join(_HERE, "..", "..", "E20_high_order", "scripts"))
if _E20 not in sys.path:
    sys.path.insert(0, _E20)
import e20_common as E  # noqa: E402  (sets VECTORIZED_CONV / FAST_DIAGNOSTICS)
import trustworthy_fmm.solvers.vector_2d as _v2d  # noqa: E402

DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
GIB = 2.0 ** 30


class SmiSampler:
    def __init__(self, interval_s=0.3):
        self.interval = interval_s
        self.max_mib = 0
        self._stop = threading.Event()
        self._thread = None

    @staticmethod
    def _read():
        try:
            out = subprocess.run(
                ["nvidia-smi", "--query-gpu=memory.used",
                 "--format=csv,noheader,nounits"],
                capture_output=True, text=True, timeout=5)
            return int(out.stdout.strip().splitlines()[0])
        except Exception:
            return -1

    def __enter__(self):
        self.max_mib = 0
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        return self

    def _loop(self):
        while not self._stop.is_set():
            value = self._read()
            if value > self.max_mib:
                self.max_mib = value
            self._stop.wait(self.interval)

    def __exit__(self, *exc):
        self._stop.set()
        self._thread.join(timeout=5)
        return False


def set_flags(mode):
    _v2d.MEMORY_EFFICIENT = mode.startswith("me")
    # "me_ckpt_*" AND the checkpoint-only fallback "ckpt_*" (bitwise forward,
    # backward recomputes the identical kernels)
    _v2d.CHECKPOINT_SMATRIX = "ckpt" in mode


def one_run(density, level, target, dtype, device, mode):
    set_flags(mode)
    torch.cuda.empty_cache()
    torch.cuda.reset_peak_memory_stats()
    run = {"mode": mode}
    grad = None
    try:
        with SmiSampler() as smi:
            torch.cuda.synchronize()
            t0 = time.time()
            if mode.endswith("_fwd"):
                run["eta"] = E.ours_eta(density, level, target, dtype, device)
            elif mode.endswith("_offload"):
                with torch.autograd.graph.save_on_cpu(pin_memory=True):
                    run["eta"], grad = E.ours_eta_grad(
                        density, level, target, dtype, device)
            else:
                run["eta"], grad = E.ours_eta_grad(
                    density, level, target, dtype, device)
            torch.cuda.synchronize()
        run["s"] = time.time() - t0
        run["peak_GiB"] = torch.cuda.max_memory_allocated() / GIB
        run["smi_max_MiB"] = smi.max_mib
        print(f"   {mode:<22s} {run['s']:7.1f} s  peak {run['peak_GiB']:6.2f} GiB"
              f"  smi {run['smi_max_MiB']:5d} MiB  eta={run['eta']:.9f}", flush=True)
    except RuntimeError as error:
        if "out of memory" not in str(error).lower():
            raise
        run["oom"] = True
        run["oom_message"] = str(error).splitlines()[0]
        torch.cuda.empty_cache()
        print(f"   {mode:<22s} OOM", flush=True)
    finally:
        set_flags("base")
    return run, grad


def compare(run, grad, reference_run, reference_grad):
    if reference_run is None or "eta" not in run:
        return
    run["value_rel_err"] = abs(run["eta"] - reference_run["eta"]) / max(
        abs(reference_run["eta"]), 1e-30)
    if grad is not None and reference_grad is not None:
        a = grad.flatten().double()
        b = reference_grad.flatten().double()
        run["grad_cosine"] = float(
            torch.dot(a, b) / (a.norm() * b.norm()))
        run["grad_rel_l2"] = float((a - b).norm() / b.norm())
        print(f"      vs ref: value_rel_err={run['value_rel_err']:.3e}  "
              f"grad_cos={run['grad_cosine']:.8f}  "
              f"grad_rel_l2={run['grad_rel_l2']:.3e}", flush=True)
    else:
        print(f"      vs ref: value_rel_err={run['value_rel_err']:.3e}", flush=True)


def cpu128_parity(target):
    density = (torch.rand(35, 120) > 0.5).double()
    level, dtype, device = (12, 3), torch.complex128, "cpu"
    set_flags("base")
    t0 = time.time()
    eta_base, grad_base = E.ours_eta_grad(density, level, target, dtype, device)
    base_s = time.time() - t0
    set_flags("me")
    t0 = time.time()
    eta_me, grad_me = E.ours_eta_grad(density, level, target, dtype, device)
    me_s = time.time() - t0
    set_flags("base")
    a, b = grad_me.flatten(), grad_base.flatten()
    row = {
        "mode": "cpu128_parity", "level": [12, 3], "dtype": "c128",
        "base_s": base_s, "me_s": me_s,
        "eta_base": eta_base, "eta_me": eta_me,
        "value_rel_err": abs(eta_me - eta_base) / max(abs(eta_base), 1e-30),
        "grad_cosine": float(torch.dot(a, b) / (a.norm() * b.norm())),
        "grad_rel_l2": float((a - b).norm() / b.norm()),
    }
    print(f"   cpu128_parity (12,3): value_rel_err={row['value_rel_err']:.3e}  "
          f"grad_cos={row['grad_cosine']:.15f}  grad_rel_l2={row['grad_rel_l2']:.3e}",
          flush=True)
    return row


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--grid", type=int, default=2)
    ap.add_argument("--target", default="1,0")
    ap.add_argument("--configs", nargs="+", default=[
        "cpu128",
        "32,8:c64:base_grad",
        "32,8:c64:me_grad",
        "32,8:c64:me_ckpt_grad",
        "40,10:c64:base_fwd",
        "40,10:c64:base_grad",
        "40,10:c64:me_fwd",
        "40,10:c64:me_grad",
        "40,10:c64:me_ckpt_grad",
        "40,10:c64:me_grad_offload",
        "40,10:c64:me_ckpt_grad_offload",
        "48,12:c64:base_fwd",
        "48,12:c64:base_grad_offload",
        "48,12:c64:me_fwd",
        "48,12:c64:me_ckpt_grad",
        "48,12:c64:me_grad_offload",
        "48,12:c64:me_ckpt_grad_offload",
        "56,14:c64:me_fwd",
        "56,14:c64:me_ckpt_grad_offload",
    ])
    args = ap.parse_args()
    target = tuple(int(v) for v in args.target.split(","))
    torch.manual_seed(0)
    density = E.upsample((torch.rand(35, 120) > 0.5).double(), args.grid)
    report = {"gpu": torch.cuda.get_device_name(0), "torch": torch.__version__,
              "grid": list(density.shape), "target": list(target), "runs": []}
    references = {}  # (level, dtype) -> (run, grad)

    for spec in args.configs:
        if spec == "cpu128":
            print("\n== cpu128 parity", flush=True)
            report["runs"].append(cpu128_parity(target))
            continue
        lv, dt, mode = spec.split(":")
        level = tuple(int(v) for v in lv.split(","))
        dtype = torch.complex64 if dt == "c64" else torch.complex128
        n = (2 * level[0] + 1) * (2 * level[1] + 1)
        print(f"\n== {spec}  2N={2*n}", flush=True)
        run, grad = one_run(density, level, target, dtype, "cuda", mode)
        run.update({"level": list(level), "two_n": 2 * n, "dtype": dt})
        key = (level, dt)
        if mode.startswith("base") and "eta" in run:
            if mode == "base_grad" or key not in references:
                references[key] = (run, grad)
        if not mode.startswith("base"):
            reference = references.get(key, (None, None))
            compare(run, grad, reference[0], reference[1])
        report["runs"].append(run)
        os.makedirs(DATA, exist_ok=True)
        out = os.path.join(DATA, "a2_accept_latest.json")
        with open(out, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2)
    final = os.path.join(DATA, time.strftime("a2_accept_%Y%m%d_%H%M%S.json"))
    os.replace(out, final)
    print("\nsaved", final)


if __name__ == "__main__":
    main()
