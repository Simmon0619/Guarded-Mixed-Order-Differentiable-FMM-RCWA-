"""Cross-check the incumbent designs in Ansys Lumerical's RCWA solver.

Route (mirrors stage_c1's freeform_2d_polygon_example): binary mask ->
exact pixel-boundary polygons (e25_polygons, bitwise raster round-trip
verified) -> addpoly extruded z=0..H, substrate rect below, RCWA solver
object, grating_power result.

Physics identical to the frozen protocol: 660 nm, 2400x700 nm cell, H=800 nm,
features n=3.2 in air background, substrate n=1.46 (incidence side, forward
propagation), air output.  Our x-polarized source = Lumerical's P source at
theta=phi=0 (plane of incidence = x-z); the y-mirror symmetry of every design
makes (m,0) orders co-polarized, so Tp_power(m,0) is directly comparable with
our power_t.

Sanity gate: uniform n=3.2 slab must reproduce our solver's total T/R before
any pattern is scored.  Truncation scan: max number k vectors in
{201, 401, 801}.

    python e25_run_lumerical.py       # writes ../data/lumerical_xcheck.json
"""
import json
import os
import sys
import time

import numpy as np

sys.path.append(r"C:\Program Files\Lumerical\v241\api\python")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.abspath(os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "..", "..", "E24_grid_field", "scripts")))

import lumapi  # noqa: E402
import torch  # noqa: E402

from e24_common import C, INCUMBENTS, load_binary, solve  # noqa: E402
from e25_polygons import export  # noqa: E402

LAM = 660e-9
LX, LY = 2400e-9, 700e-9
H = 800e-9
N_SUB, N_MAT = 1.46, 3.2
KVECS = [201, 401, 801]
DATA = os.path.abspath(os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "..", "data"))


def setup_solver(fdtd, n_k):
    fdtd.addrcwa()
    fdtd.set("name", "RCWA")
    for k, v in [("propagation axis", "z"), ("propagation direction", "forward"),
                 ("simulation region", "3D"), ("incident angle", "single"),
                 ("angle theta", 0.0), ("angle phi", 0.0),
                 ("x span", LX), ("y span", LY),
                 ("z min", -0.8 * LAM), ("z max", H + LAM),
                 ("background material", "<Object defined dielectric>"),
                 ("index", 1.0), ("interface position", "absolute"),
                 ("minimum wavelength", LAM), ("maximum wavelength", LAM),
                 ("frequency points", 1),
                 ("max number k vectors", float(n_k)),
                 ("report grating orders", 1), ("report grating power", 1),
                 ("report field amplitudes", 1)]:
        fdtd.setnamed("RCWA", k, v)
    fdtd.setnamed("RCWA", "interface absolute positions", np.array([0.0, H]))
    fdtd.addrect()
    fdtd.set("name", "substrate")
    for k, v in [("x", 0.0), ("y", 0.0), ("x span", LX), ("y span", LY),
                 ("z min", -0.8 * LAM), ("z max", 0.0), ("index", N_SUB)]:
        fdtd.setnamed("substrate", k, v)


def add_pattern(fdtd, mask):
    outers, holes = export(mask)          # raises unless bitwise exact
    for i, poly in enumerate(outers):
        fdtd.addpoly()
        name = "mat_%02d" % i
        fdtd.set("name", name)
        fdtd.setnamed(name, "vertices", poly * 1e-9)
        fdtd.setnamed(name, "z min", 0.0)
        fdtd.setnamed(name, "z max", H)
        fdtd.setnamed(name, "index", N_MAT)
    for i, poly in enumerate(holes):
        fdtd.addpoly()
        name = "hole_%02d" % i
        fdtd.set("name", name)
        fdtd.setnamed(name, "vertices", poly * 1e-9)
        fdtd.setnamed(name, "z min", 0.0)
        fdtd.setnamed(name, "z max", H)
        fdtd.setnamed(name, "index", 1.0)
        fdtd.setnamed(name, "override mesh order from material database", 1)
        fdtd.setnamed(name, "mesh order", 2)   # lower order wins -> hole cuts
    return len(outers), len(holes)


def run_and_extract(fdtd, target):
    fdtd.run()
    gp = fdtd.getresult("RCWA", "grating_power")
    te = fdtd.getresult("RCWA", "total_energy")
    n = np.asarray(gp["n"]).ravel().astype(int)     # x-axis orders
    m = np.asarray(gp["m"]).ravel().astype(int)     # y-axis orders
    tp = np.asarray(gp["Tp_power"])[0, 0]           # [len(n), len(m)]
    ts = np.asarray(gp["Ts_power"])[0, 0]
    i_m0 = int(np.where(m == 0)[0][0])
    row_p = {int(nn): float(tp[i, i_m0]) for i, nn in enumerate(n)}
    eta = row_p.get(int(target[0]), float("nan"))
    return {
        "Tp_total": float(np.asarray(te["Tp"]).ravel()[0]),
        "Rp_total": float(np.asarray(te["Rp"]).ravel()[0]),
        "Ts_total": float(np.asarray(te["Ts"]).ravel()[0]),
        "eta_target_Tp": eta,
        "row_m0_Tp": row_p,
        "row_m0_Ts": {int(nn): float(ts[i, i_m0]) for i, nn in enumerate(n)},
    }


def ours_reference(mask, target):
    """Our solver on the same structure: (28,7)@1x c128 + slab totals."""
    with torch.no_grad():
        r = solve(mask, (28, 7), torch.complex128, "cpu")
    row = {}
    for i, o in enumerate(r.orders):
        if tuple(o)[1] == 0:
            row[int(o[0])] = float(r.power_t[i])
    return {"eta_target": float(r.power_t[r.orders.index(tuple(target))]),
            "total_T": float(r.total_T), "total_R": float(r.total_R),
            "row_m0": row}


def main():
    torch.set_num_threads(3)
    os.makedirs(DATA, exist_ok=True)
    out = {"kvecs": KVECS, "designs": {}}
    t0 = time.perf_counter()

    fdtd = lumapi.FDTD(hide=True)

    # ---- sanity gate: uniform slab ----------------------------------------
    fdtd.switchtolayout()
    fdtd.deleteall()
    setup_solver(fdtd, 201)
    fdtd.addrect()
    fdtd.set("name", "slab")
    for k, v in [("x", 0.0), ("y", 0.0), ("x span", LX), ("y span", LY),
                 ("z min", 0.0), ("z max", H), ("index", N_MAT)]:
        fdtd.setnamed("slab", k, v)
    lum_slab = run_and_extract(fdtd, (0, 0))
    ours_slab = ours_reference(torch.ones(35, 120, dtype=torch.float64), (0, 0))
    out["sanity_slab"] = {
        "lumerical_T": lum_slab["Tp_total"], "ours_T": ours_slab["total_T"],
        "abs_diff": abs(lum_slab["Tp_total"] - ours_slab["total_T"])}
    print("sanity slab: T lum %.6f vs ours %.6f (diff %.1e)"
          % (lum_slab["Tp_total"], ours_slab["total_T"],
             out["sanity_slab"]["abs_diff"]), flush=True)
    assert out["sanity_slab"]["abs_diff"] < 1e-3, "slab sanity failed"

    # ---- patterned designs -------------------------------------------------
    for tgt, (kind, name) in INCUMBENTS.items():
        mask = load_binary(kind, name)
        ours = ours_reference(mask, tgt)
        rec = {"source": name, "ours_28_7_c128": ours, "lumerical": {}}
        for n_k in KVECS:
            fdtd.switchtolayout()
            fdtd.deleteall()
            setup_solver(fdtd, n_k)
            n_out, n_holes = add_pattern(fdtd, mask.numpy())
            t1 = time.perf_counter()
            lum = run_and_extract(fdtd, tgt)
            lum["wall_s"] = time.perf_counter() - t1
            lum["n_polygons"] = [n_out, n_holes]
            rec["lumerical"][str(n_k)] = lum
            print("%s  k=%3d: eta_lum %.4f (T %.4f R %.4f, %.0f s) | "
                  "ours(28,7) %.4f   [%.0f s total]"
                  % (tgt, n_k, lum["eta_target_Tp"], lum["Tp_total"],
                     lum["Rp_total"], lum["wall_s"], ours["eta_target"],
                     time.perf_counter() - t0), flush=True)
        best = rec["lumerical"][str(KVECS[-1])]
        rec["rel_diff_at_max_k"] = (best["eta_target_Tp"]
                                    - ours["eta_target"]) / ours["eta_target"]
        out["designs"][str(tgt)] = rec

    fdtd.close()
    with open(os.path.join(DATA, "lumerical_xcheck.json"), "w") as f:
        json.dump(out, f, indent=1)
    print("wrote lumerical_xcheck.json  (%.0f s)" % (time.perf_counter() - t0))


if __name__ == "__main__":
    main()
