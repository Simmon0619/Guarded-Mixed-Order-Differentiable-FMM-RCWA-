"""F31 -- data for Fig. 4(c) of manuscript Sec. 3.1: a finite-but-wrong complex64
gradient and its complex128 counterpart.

Design state: S8's m1_s00_st095 (P2, target (1,0), latent after 95 steps of a
single-order run); order (28,4); CPU, as in S8's fine beta scan (which found
|g| x12.5 of the scan median at beta = 363.45, orthogonal to its neighbours).

1. Dense local scan of beta around 363.45 in complex64 and complex128:
   value, latent-gradient norm, cosine between the two precisions, cosine to
   the previous beta.
2. Finite differences of the objective along the complex64 gradient direction
   d64 and along the complex128 direction d128 (complex128 forward values,
   central differences, several step sizes), at the anomalous beta and at a
   neighbouring healthy beta.

Descriptive.  CPU; eigendecomposition on the host.
"""
import json
import math
import os
import sys
import time

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
_EXP = os.path.abspath(os.path.join(_HERE, "..", ".."))
sys.path.insert(0, os.path.join(_EXP, "S8_order_beta_map", "scripts"))
import s8_map as S                                                     # noqa: E402
C = S.C
from workbench.app import app_projected, solve_density                 # noqa: E402

DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
GEOM = "m1_s00_st095"
LEVEL = (28, 4)
SCAN_GRID = np.exp(np.linspace(math.log(2.0), math.log(2000.0), 240))   # S8 fine-scan grid
BETA_SPIKE = float(SCAN_GRID[180])     # 363.45: |g| x12.5 of the scan median in S8
BETA_HEALTHY = float(SCAN_GRID[179])   # 353.1: its healthy neighbour
HS = [1e-2, 3e-3, 1e-3, 3e-4, 1e-4]


def value_grad(lat, beta, ctx):
    x = lat.detach().clone().requires_grad_(True)
    dens = app_projected(x, float(beta), ctx.cfg, ctx.mode)
    r = solve_density(dens, LEVEL, ctx.cfg, ctx.theta, ctx.phi, ctx.dtype, ctx.device)
    j = r.power_t[r.orders.index(tuple(ctx.target))]
    j.backward()
    return float(j.detach()), x.grad.detach().double().flatten()


def value(lat, beta, ctx):
    with torch.no_grad():
        dens = app_projected(lat, float(beta), ctx.cfg, ctx.mode)
        r = solve_density(dens, LEVEL, ctx.cfg, ctx.theta, ctx.phi, ctx.dtype, ctx.device)
        return float(r.power_t[r.orders.index(tuple(ctx.target))])


def cos(a, b):
    return float(a @ b / (a.norm() * b.norm()).clamp_min(1e-300))


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--threads", type=int, default=int(os.environ.get("FMM_THREADS", "3")))
    ap.add_argument("--disk-dtype", action="store_true",
                    help="complex64 path uses the latent as stored on disk (S8's scan did); default: float64")
    ap.add_argument("--out", default="f31_fig4c.json")
    a = ap.parse_args()
    torch.set_num_threads(a.threads)
    C.setup_runtime()
    torch.set_num_threads(a.threads)
    S.assert_eig_cpu()
    os.makedirs(DATA, exist_ok=True)
    G = json.load(open(os.path.join(S.DATA, "s8_geoms.json"), encoding="utf-8"))["geoms"][GEOM]
    cfg = C.make_cfg(5)
    od = {k: tuple(v) for k, v in G["orders"].items()}
    ctx64 = C.make_ctx(cfg, (G["m"], 0), od["descent"], od["gate"], "cpu")
    ctx128 = C.make_ctx(cfg, (G["m"], 0), od["descent"], od["gate"], "cpu", dtype=torch.complex128)
    lat_raw = torch.from_numpy(np.load(os.path.join(S.DATA, G["latent"])))
    lat = lat_raw.to(torch.float64)
    lat64 = lat_raw if a.disk_dtype else lat
    scan = json.load(open(os.path.join(S.DATA, "s8_beta_scan_%s.json" % GEOM), encoding="utf-8"))
    grid = [b for b in scan["meta"]["betas"] if 330.0 <= b <= 400.0]
    dense = list(np.round(np.linspace(355.0, 372.0, 35), 3))
    betas = sorted(set([float(b) for b in grid] + [float(x) for x in dense]))
    out = {"meta": {"geom": GEOM, "level": list(LEVEL), "latent_dtype_on_disk": str(lat_raw.dtype),
                    "c64_latent_dtype": str(lat64.dtype),
                    "device": "cpu", "threads": torch.get_num_threads(), "beta_spike": BETA_SPIKE,
                    "beta_healthy": BETA_HEALTHY, "hs": HS}, "scan": [], "fd": {}}
    path = os.path.join(DATA, a.out)
    prev = {"c64": None, "c128": None}
    t_all = time.perf_counter()
    grads = {}
    for b in betas:
        t0 = time.perf_counter()
        v64, g64 = value_grad(lat64, b, ctx64)
        v128, g128 = value_grad(lat, b, ctx128)
        row = {"beta": b, "value_c64": v64, "value_c128": v128, "norm_c64": float(g64.norm()),
               "norm_c128": float(g128.norm()), "cos_c64_c128": cos(g64, g128),
               "cos_prev_c64": cos(prev["c64"], g64) if prev["c64"] is not None else None,
               "cos_prev_c128": cos(prev["c128"], g128) if prev["c128"] is not None else None,
               "wall_s": time.perf_counter() - t0}
        out["scan"].append(row)
        prev = {"c64": g64, "c128": g128}
        if b in (BETA_SPIKE, BETA_HEALTHY):
            grads[b] = (g64, g128)
        print("beta %8.3f | v64 %.6f v128 %.6f | |g64| %.4f |g128| %.4f cos %.4f  (%.0f s)"
              % (b, v64, v128, row["norm_c64"], row["norm_c128"], row["cos_c64_c128"], time.perf_counter() - t_all), flush=True)
        C.save_json(path, out)
    for b, (g64, g128) in grads.items():
        rec = {}
        for name, g in (("d64", g64), ("d128", g128)):
            d = g / g.norm()
            fd = []
            for h in HS:
                jp = value(lat + h * d.reshape(lat.shape), b, ctx128)
                jm = value(lat - h * d.reshape(lat.shape), b, ctx128)
                fd.append({"h": h, "slope_fd_c128": (jp - jm) / (2 * h)})
            rec[name] = {"ad_c64_along": float(g64 @ d), "ad_c128_along": float(g128 @ d), "fd": fd}
            print("beta %.3f dir %s | AD64 %.5f AD128 %.5f | FD %s" % (b, name, rec[name]["ad_c64_along"], rec[name]["ad_c128_along"],
                  ", ".join("%.0e:%.5f" % (x["h"], x["slope_fd_c128"]) for x in fd)), flush=True)
        out["fd"]["%.4f" % b] = rec
        C.save_json(path, out)
    out["meta"]["wall_s"] = time.perf_counter() - t_all
    C.save_json(path, out)
    print("done in %.0f s" % out["meta"]["wall_s"], flush=True)


if __name__ == "__main__":
    main()
