"""F31 -- Figures 2, 3, 4 of manuscript Sec. 3.1 (one design task: P2, target (1,0)).

Fig. 2  the conventional workflow on this task (S7 T run m=1 s14, replayed bitwise)
  (a) the delivered pattern evaluated with more and more harmonics; the value the run reports
  (b) the same run step by step: smooth objective at M_d; binary pattern at M_d, M_g, M_r
  (c) all 24 runs of the task: reported value, binary at M_d, binary at M_r
Fig. 3  a frozen mid-run design state, beta varied (S8 m1_s00_st095)
  (a) error of the smooth objective, J_M - J_ref      (b) alignment with the reference gradient
Fig. 4  finite-but-wrong single-precision gradients
  (a) every gradient of the Fig. 2 run recomputed in double precision
  (b) the same run with ONE gradient replaced (counterfactual replays)
  (c) the frozen state of Fig. 3 scanned finely in beta: single vs double precision
  (d) slopes along each gradient: automatic differentiation vs finite differences

Colours: dataviz reference palette, categorical slots 1-3 (validated all-pairs on
white): M_d blue, M_g orange, M_r aqua; double precision / counterfactual: dark
neutral; other orders: light grey.  Aqua is below 3:1 on white: its marks are
direct-labelled.
"""
import json
import math
import os
import sys

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                        # noqa: E402
from matplotlib.gridspec import GridSpec                               # noqa: E402
from matplotlib.patches import Patch                                   # noqa: E402

_HERE = os.path.dirname(os.path.abspath(__file__))
_EXP = os.path.abspath(os.path.join(_HERE, "..", ".."))
DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
FIG = os.path.abspath(os.path.join(_HERE, "..", "figures"))
S8 = os.path.join(_EXP, "S8_order_beta_map")
sys.path.insert(0, os.path.join(S8, "scripts"))

BLUE, ORANGE, AQUA = "#2a78d6", "#eb6834", "#1baf7a"
INK, INK2, GREY, GREY_L = "#0b0b0b", "#52514e", "#8c8b86", "#c9c8c3"
DARK = "#3b3a37"
FILL_BIN, FILL_TRUNC, BAND = "#dbe8f8", "#d8efe5", "#f0efec"
MM = 1 / 25.4
FULL_W = 180 * MM

plt.rcParams.update({
    "font.family": "sans-serif", "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
    "font.size": 7.5, "axes.titlesize": 7.5, "axes.labelsize": 7.5, "xtick.labelsize": 7,
    "ytick.labelsize": 7, "legend.fontsize": 7, "axes.linewidth": 0.6,
    "xtick.major.width": 0.6, "ytick.major.width": 0.6, "xtick.minor.width": 0.4, "ytick.minor.width": 0.4,
    "xtick.major.size": 3, "ytick.major.size": 3, "xtick.minor.size": 1.8, "ytick.minor.size": 1.8,
    "axes.edgecolor": INK2, "axes.labelcolor": INK, "xtick.color": INK2, "ytick.color": INK2,
    "text.color": INK, "axes.spines.top": False, "axes.spines.right": False,
    "legend.frameon": False, "savefig.dpi": 300, "pdf.fonttype": 42, "ps.fonttype": 42,
    "mathtext.fontset": "custom", "mathtext.it": "Arial:italic", "mathtext.rm": "Arial",
})

LAB_MD, LAB_MG, LAB_MR = r"$M_d$", r"$M_g$", r"$M_r$"
BETA_TICKS = [2, 10, 100, 1000]


def panel(ax, s, x=-0.14, y=1.04):
    ax.text(x, y, "(%s)" % s, transform=ax.transAxes, fontsize=8.5, fontweight="bold", va="bottom", ha="left")


def order_label(lv):
    return "(%d,%d)" % tuple(lv)


def beta_axis(ax, steps=800):
    top = ax.secondary_xaxis("top", functions=(lambda s: s, lambda s: s))
    top.set_xticks([steps * math.log(b / 2) / math.log(1000) for b in BETA_TICKS])
    top.set_xticklabels([str(b) for b in BETA_TICKS])
    top.set_xlabel(r"projection sharpness $\beta$", labelpad=2)
    top.tick_params(length=2.5)
    return top


def save(fig, name):
    os.makedirs(FIG, exist_ok=True)
    for ext in ("png", "pdf"):
        fig.savefig(os.path.join(FIG, "%s.%s" % (name, ext)), bbox_inches="tight", pad_inches=0.02)
    plt.close(fig)
    print("saved", name)


# ------------------------------------------------------------------ Fig. 2
def fig2():
    D = json.load(open(os.path.join(DATA, "f31_fig2.json"), encoding="utf-8"))
    od = D["meta"]["orders"]
    md, mg, mr = tuple(od["descent"]), tuple(od["gate"]), tuple(od["top"])
    p1, p2, p3 = D["part1"], D["part2"], D["part3"]
    reported = p1["reported"]

    fig = plt.figure(figsize=(FULL_W, 122 * MM))
    gs = GridSpec(2, 2, figure=fig, width_ratios=[0.82, 1.3], height_ratios=[1.0, 0.8], hspace=0.66, wspace=0.3)

    # (a) the delivered pattern with more and more harmonics ----------------
    ax = fig.add_subplot(gs[0, 0])
    lad = p2["final"]["ladder"]
    nt = np.array([r["n_terms"] for r in lad], float)
    eta = np.array([r["eta"] for r in lad])
    lv = [tuple(r["level"]) for r in lad]
    ax.axhline(reported, color=BLUE, lw=0.9, ls=(0, (4, 2)), zorder=0)
    ax.text(nt[0], reported + 0.012, "value reported by the run", color=BLUE, fontsize=6.8, va="bottom", ha="left")
    ax.plot(nt, eta, "-", color=GREY, lw=0.9, zorder=1)
    ax.scatter(nt, eta, s=9, color=GREY, zorder=2, linewidths=0)
    for l, col in ((md, BLUE), (mg, ORANGE), (mr, AQUA)):
        i = lv.index(l)
        ax.scatter([nt[i]], [eta[i]], s=36, color=col, zorder=3, edgecolors="white", linewidths=0.8)
    i_d, i_g, i_r = lv.index(md), lv.index(mg), lv.index(mr)
    ax.text(nt[i_d] * 0.86, eta[i_d] - 0.02, LAB_MD + " " + order_label(md), fontsize=7, color=BLUE, va="top", ha="right")
    ax.text(nt[i_g] * 1.12, eta[i_g] + 0.01, LAB_MG + " " + order_label(mg), fontsize=7, color=ORANGE, va="bottom", ha="left")
    ax.text(nt[i_r], eta[i_r] + 0.03, LAB_MR + " " + order_label(mr), fontsize=7, color=INK, va="bottom", ha="center")
    ax.set_xscale("log")
    ax.set_xlabel("number of retained harmonics $N$")
    ax.set_ylabel("efficiency of the delivered pattern")
    ax.set_ylim(0.36, 1.02)
    ax.set_xlim(nt[0] * 0.75, nt[-1] * 1.3)
    panel(ax, "a", x=-0.2)
    b = np.load(os.path.join(DATA, "f31_final_binary.npy")).astype(float)
    tile = np.vstack([b, b])
    ins = ax.inset_axes([0.34, 0.035, 0.64, 0.17])
    ins.imshow(1 - tile, cmap="gray", vmin=-0.4, vmax=1.0, origin="lower", aspect="auto",
               extent=[0, 3.0, 0, 1.0], interpolation="nearest")
    ins.set_xticks([]); ins.set_yticks([])
    for s in ins.spines.values():
        s.set_visible(True); s.set_color(INK2); s.set_linewidth(0.5)
    ins.text(0.5, 1.06, "delivered pattern (3 µm × 2 periods)", transform=ins.transAxes, fontsize=6.2,
             color=INK2, ha="center", va="bottom")

    # (b) the same run, step by step ----------------------------------------
    ax = fig.add_subplot(gs[0, 1])
    traj = np.array([np.nan if v is None else v for v in p1["trajectory"]] + [reported])
    steps = np.arange(len(traj))
    ck = p1["checkpoints"]
    cs = np.array([c["step"] for c in ck])
    jd = traj[cs]
    qd = np.array([c["Q_descent"] for c in ck])
    qg = np.array([c["Q_gate"] for c in ck])
    qr = np.array([c["Q_top"] for c in ck])
    ax.fill_between(cs, qd, jd, where=jd >= qd, color=FILL_BIN, lw=0, zorder=0, interpolate=True)
    ax.fill_between(cs, qr, qd, where=qd >= qr, color=FILL_TRUNC, lw=0, zorder=0, interpolate=True)
    ax.plot(steps, traj, color=BLUE, lw=1.2, zorder=3)
    ax.plot(cs, qd, "o", ms=2.6, mfc="white", mec=BLUE, mew=0.8, zorder=4)
    ax.plot(cs, qg, "-s", color=ORANGE, lw=0.8, ms=2.2, mew=0, zorder=2)
    ax.plot(cs, qr, "-D", color=AQUA, lw=1.0, ms=2.3, mew=0, zorder=2)
    ax.text(95, 0.66, "binarization\ngap", fontsize=6.5, color="#27558f", ha="center", va="center")
    ax.text(640, 0.77, "truncation gap", fontsize=6.5, color="#157a55", ha="center", va="center")
    for s0, xt, yt in ((166, 215, 0.36), (429, 452, 0.42)):
        ax.annotate("collapse", (s0, traj[s0]), xytext=(xt, yt), fontsize=6.3, color=INK2, ha="left", va="center",
                    arrowprops=dict(arrowstyle="-", color=INK2, lw=0.5, shrinkA=1, shrinkB=1))
    xr = 808
    ax.text(xr, traj[-1], "objective (line) and\npattern (o) at " + LAB_MD, color=BLUE, fontsize=6.6,
            va="center", ha="left")
    ax.text(xr, qg[-1] + 0.01, "pattern at " + LAB_MG, color=ORANGE, fontsize=6.6, va="center", ha="left")
    ax.text(xr, qr[-1] - 0.03, "pattern at " + LAB_MR, color=INK, fontsize=6.6, va="center", ha="left")
    ax.set_xlim(0, 800)
    ax.set_ylim(0, 1.0)
    ax.set_xlabel("optimization step")
    ax.set_ylabel("efficiency")
    beta_axis(ax)
    panel(ax, "b", x=-0.1)

    # (c) all 24 runs of the task -------------------------------------------
    ax = fig.add_subplot(gs[1, :])
    runs = sorted(p3["runs"], key=lambda r: r["Q_top"])
    x = np.arange(len(runs))
    rep = np.array([r["reported"] for r in runs])
    qdd = np.array([r["Q_descent"] for r in runs])
    qrr = np.array([r["Q_top"] for r in runs])
    k = [i for i, r in enumerate(runs) if r["index"] == p1["run_index"]][0]
    ax.axvspan(k - 0.45, k + 0.45, color=BAND, zorder=0)
    for i in range(len(runs)):
        ax.plot([x[i], x[i]], [qrr[i], max(rep[i], qdd[i])], color=GREY_L, lw=1.6, zorder=1, solid_capstyle="butt")
    ax.scatter(x, rep, s=28, facecolors="none", edgecolors=BLUE, linewidths=0.9, zorder=3, label="value reported by the run")
    ax.scatter(x, qdd, s=7, color=BLUE, zorder=4, linewidths=0, label="delivered pattern at " + LAB_MD)
    ax.scatter(x, qrr, s=17, marker="D", color=AQUA, zorder=4, linewidths=0, label="delivered pattern at " + LAB_MR)
    ax.text(k, 0.035, "run of\n(a, b)", ha="center", va="bottom", fontsize=6, color=INK2)
    ax.set_xticks([])
    ax.set_xlim(-0.8, len(runs) - 0.2)
    ax.set_ylim(0, 1.05)
    ax.set_xlabel("24 runs from different random initial designs, sorted by delivered efficiency")
    ax.set_ylabel("efficiency")
    ax.legend(loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=3, handletextpad=0.3, columnspacing=1.6, borderaxespad=0.2)
    panel(ax, "c", x=-0.055)
    save(fig, "fig2_conventional_workflow")


# ------------------------------------------------------------------ Fig. 3
def fig3():
    import s8_plot as P
    A, G = P.load()
    key = "m1_s00_st095"
    betas, cl, cd, E, Q, pts = P.grids(A, key)
    lad = [tuple(x) for x in A["meta"]["ladder"]]
    orders = G[key]["orders"]
    md, mg = tuple(orders["descent"]), tuple(orders["gate"])
    i_d, i_g = lad.index(md), lad.index(mg)
    shown = [j for j in range(i_d, len(lad) - 1)]
    bl = A["binary_ladder"][key]["ladder"]
    ref_b = bl["%d-%d" % lad[-1]]["eta"]
    gap = {j: bl["%d-%d" % lad[j]]["eta"] - ref_b for j in shown}
    B = np.array(betas)
    ok = np.array([not P.ref_flag(p) for p in pts])

    fig, axs = plt.subplots(1, 2, figsize=(FULL_W, 64 * MM), gridspec_kw={"wspace": 0.42})
    ax = axs[0]
    ax.axvspan(16, 128, color=BAND, zorder=0)
    for j in shown:
        if j not in (i_d, i_g):
            ax.plot(B, E[:, j], color=GREY_L, lw=0.8, zorder=1)
    for j, col in ((i_d, BLUE), (i_g, ORANGE)):
        ax.plot(B, E[:, j], "-o", color=col, lw=1.3, ms=2.6, mew=0, zorder=3)
        ax.plot([2900], [gap[j]], marker="<", color=col, ms=4.5, mew=0, clip_on=False, zorder=3)
    ax.text(420, E[-1, i_d] + 0.008, LAB_MD + " (16,2)", color=BLUE, fontsize=7, ha="center", va="bottom")
    ax.text(420, E[-1, i_g] + 0.006, LAB_MG + " (28,4)", color=ORANGE, fontsize=7, ha="center", va="bottom")
    ax.text(260, 0.087, "other orders between\n(20,3) and (48,7)", color=GREY, fontsize=6.3, ha="center", va="bottom")
    ax.axhline(0, color=INK2, lw=0.5)
    ax.set_xscale("log")
    ax.set_xlim(1.7, 2000 * 1.12)
    ax.set_xlabel(r"projection sharpness $\beta$ (design frozen)")
    ax.set_ylabel(r"error of the objective, $J_M-J_{\rm ref}$")
    ax.text(45, 0.162, "error switches on", fontsize=6.5, color=INK2, ha="center")
    ax.plot([140], [-0.024], marker="<", color=INK2, ms=4, mew=0)
    ax.text(170, -0.024, "value for the binary pattern", fontsize=6.3, color=INK2, va="center", ha="left")
    ax.set_ylim(-0.035, 0.172)
    panel(ax, "a", x=-0.17)

    ax = axs[1]
    for j in shown:
        if j not in (i_d, i_g):
            ax.plot(B[ok], cl[ok, j], color=GREY_L, lw=0.8, zorder=1)
    for j, col in ((i_d, BLUE), (i_g, ORANGE)):
        ax.plot(B[ok], cl[ok, j], "-o", color=col, lw=1.3, ms=2.6, mew=0, zorder=3)
    ax.text(1400, cl[-1, i_g] - 0.03, LAB_MG + " (28,4)", color=ORANGE, fontsize=7, ha="center", va="top")
    ax.text(1400, cl[-1, i_d] - 0.035, LAB_MD + " (16,2)", color=BLUE, fontsize=7, ha="center", va="top")
    ax.axhline(1, color=INK2, lw=0.5)
    ax.set_xscale("log")
    ax.set_xlim(1.7, 2000 * 1.12)
    ax.set_ylim(0.3, 1.04)
    ax.set_xlabel(r"projection sharpness $\beta$ (design frozen)")
    ax.set_ylabel("alignment with the reference\ngradient (cosine)")
    panel(ax, "b", x=-0.2)
    save(fig, "fig3_frozen_state")


# ------------------------------------------------------------------ Fig. 4
def rel_err(n64, n128, c):
    r = n64 / max(n128, 1e-300)
    return math.sqrt(max(r * r + 1.0 - 2.0 * r * c, 0.0))


def fig4(zoom_file="f31_fig4c_s8set.json"):
    A = json.load(open(os.path.join(DATA, "f31_cliff_audit.json"), encoding="utf-8"))
    CF = json.load(open(os.path.join(DATA, "f31_counterfactual.json"), encoding="utf-8"))
    Z = json.load(open(os.path.join(DATA, zoom_file), encoding="utf-8"))
    fig = plt.figure(figsize=(FULL_W, 112 * MM))
    gs = GridSpec(2, 2, figure=fig, height_ratios=[0.9, 1.0], width_ratios=[1.5, 1.0], hspace=0.62, wspace=0.3)

    # (a) every gradient of the Fig. 2 run, recomputed in double precision -----
    ax = fig.add_subplot(gs[0, 0])
    st = np.array([s["step"] for s in A["steps"]])
    err = np.array([rel_err(s["norm_c64"], s["norm_c128"], s["cos"]) for s in A["steps"]])
    ratio = np.array([s["norm_c64"] / s["norm_c128"] for s in A["steps"]])
    ax.semilogy(st, err, color=BLUE, lw=0.6, alpha=0.9)
    big = np.where(ratio >= 5)[0]
    ax.scatter(st[big], err[big], s=13, color=BLUE, zorder=3, linewidths=0)
    for s0, xt in ((162, 185), (426, 445)):
        i = int(np.where(st == s0)[0][0])
        ax.annotate("step %d\n(collapse next)" % s0, (st[i], err[i]), xytext=(xt, 90), fontsize=6.3,
                    color=INK2, ha="left", va="bottom",
                    arrowprops=dict(arrowstyle="-", color=INK2, lw=0.5, shrinkA=1, shrinkB=2))
    ax.text(795, 4e-5, r"dots: gradient $\geq5\times$ too large", fontsize=6.3, color=INK2, ha="right", va="bottom")
    ax.set_xlim(0, 800)
    ax.set_ylim(3e-5, 2e3)
    ax.set_xlabel("optimization step (the run of Fig. 2)")
    ax.set_ylabel("error of the single-precision\ngradient (relative)")
    beta_axis(ax)
    panel(ax, "a", x=-0.11)

    # (b) the same run with ONE gradient replaced --------------------------------
    from matplotlib.gridspec import GridSpecFromSubplotSpec
    CF4 = json.load(open(os.path.join(DATA, "f31_counterfactual_426.json"), encoding="utf-8"))
    sub = GridSpecFromSubplotSpec(1, 2, subplot_spec=gs[0, 1], wspace=0.12)
    orig = np.array(CF["runs"]["original"]["trajectory"])
    windows = ((162, np.array(CF["runs"]["c128_162"]["trajectory"])), (426, np.array(CF4["runs"]["c128_426"]["trajectory"])))
    for wi, (s0, alt) in enumerate(windows):
        ax = fig.add_subplot(sub[0, wi])
        s = np.arange(s0 - 12, s0 + 36)
        ax.axvline(s0, color=GREY_L, lw=0.6, zorder=0)
        ax.plot(s, orig[s], color=BLUE, lw=1.3, label="as run")
        ax.plot(s, alt[s], color=DARK, lw=1.1, label="that gradient in\ndouble precision")
        ax.set_xlim(s[0], s[-1])
        ax.set_ylim(0.4, 1.0)
        ax.set_xticks([s0, s0 + 30])
        ax.set_xlabel("step")
        ax.text(s0 + 1, 0.995, "step %d replaced" % s0, fontsize=6.0, color=INK2, ha="left", va="top")
        if wi == 0:
            ax.set_ylabel(r"smooth objective at $M_d$")
            panel(ax, "b", x=-0.5)
        else:
            ax.tick_params(labelleft=False)
            ax.legend(loc="lower right", fontsize=6.0, handlelength=1.4, borderaxespad=0.1)

    # (c) one event up close: frozen design state, fine beta scan -----------------
    ax = fig.add_subplot(gs[1, 0])
    rows = Z["scan"]
    b = np.array([r["beta"] for r in rows])
    n64 = np.array([r["norm_c64"] for r in rows])
    n128 = np.array([r["norm_c128"] for r in rows])
    ax.semilogy(b, n64, "-o", color=ORANGE, lw=0.9, ms=2.4, mew=0)
    ax.semilogy(b, n128, "-s", color=DARK, lw=0.9, ms=2.2, mew=0)
    ib = int(np.argmax(n64))
    ax.text(b[ib] + 1.0, n64[ib], "single precision", color=ORANGE, fontsize=7, va="center", ha="left")
    ax.text(b[0] + 1, n128[0] * 1.35, "double precision", color=DARK, fontsize=7, va="bottom", ha="left")
    bs = Z["meta"]["beta_spike"]
    ax.axvline(bs, color=GREY, lw=0.6, ls=(0, (2, 2)), zorder=0)
    ax.text(bs + 0.6, 3e2, "(d)", fontsize=6.5, color=INK2, ha="left", va="center")
    ax.set_xlim(b[0] - 2, b[-1] + 2)
    ax.set_xlabel(r"projection sharpness $\beta$ (design state of Fig. 3, frozen)")
    ax.set_ylabel(r"gradient norm at $M_g$")
    panel(ax, "c", x=-0.11)

    # (d) which one is right ------------------------------------------------------
    ax = fig.add_subplot(gs[1, 1])
    fd = Z["fd"]["%.4f" % Z["meta"]["beta_spike"]]
    lab = ["along the single-\nprecision gradient", "along the double-\nprecision gradient"]
    w = 0.25
    for gi, key in enumerate(("d64", "d128")):
        rec = fd[key]
        fdv = float(np.median([x["slope_fd_c128"] for x in rec["fd"]]))
        vals = [(rec["ad_c64_along"], ORANGE, None), (rec["ad_c128_along"], DARK, None), (fdv, "white", "////")]
        for kk, (v, col, hatch) in enumerate(vals):
            ax.bar(gi + (kk - 1) * w, v, width=w * 0.9, color=col, edgecolor=(INK2 if hatch else col), linewidth=0.7, hatch=hatch)
            if abs(v) < 5e-3:
                ax.text(gi + (kk - 1) * w, 0.02, "0", ha="center", va="bottom", fontsize=6.3, color=INK2)
    ax.axhline(0, color=INK2, lw=0.5)
    ax.set_xticks([0, 1]); ax.set_xticklabels(lab, fontsize=6.6)
    ax.set_ylabel("slope of the objective")
    ax.text(0.62, 1.7, r"frozen state, $\beta=363.45$," + "\n" + r"order $M_g$", fontsize=6.5, color=INK2, ha="left", va="center")
    ax.legend(handles=[Patch(color=ORANGE, label="single precision (AD)"), Patch(color=DARK, label="double precision (AD)"),
                       Patch(facecolor="white", edgecolor=INK2, hatch="////", label="finite difference")],
              loc="upper right", handlelength=1.2, fontsize=6.3)
    panel(ax, "d", x=-0.24)
    save(fig, "fig4_wrong_gradients")


if __name__ == "__main__":
    which = sys.argv[1:] or ["2", "3", "4"]
    if "2" in which:
        fig2()
    if "3" in which:
        fig3()
    if "4" in which:
        fig4()
