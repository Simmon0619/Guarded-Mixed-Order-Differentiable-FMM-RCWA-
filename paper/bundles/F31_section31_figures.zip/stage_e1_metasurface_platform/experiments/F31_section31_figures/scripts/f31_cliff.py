"""F31 -- is the one-step drop at step 163 of the Fig. 2 run a finite-but-wrong gradient?

Replays the same conventional-workflow run (S7 T, P2 m=1, seed 151014; GPU
complex64, host eigendecomposition; bitwise identical to S7, see f31_fig2.log)
and, at every step, recomputes the gradient of the same latent at the same beta
in complex128 on the CPU.  Records per step: beta, the complex64 value and
gradient norm the optimizer used, the complex128 value and gradient norm, and
the cosine between the two gradients.  The optimizer itself is untouched.

Descriptive.
"""
import json
import os
import sys
import time

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
_EXP = os.path.abspath(os.path.join(_HERE, "..", ".."))
sys.path.insert(0, os.path.join(_EXP, "S6_lottery_pricing", "scripts"))
import s6_common as C                                                  # noqa: E402
from workbench.app import value_grad                                   # noqa: E402

DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
S7DATA = os.path.join(_EXP, "S7_headtohead", "data")
M, RUN_INDEX, SEED, STEPS, BETA_END = 1, 14, 151014, 800, 2000.0


class Audited(C.Descent):
    def run_to(self, step):
        cfg = self.ctx.cfg
        end = min(int(step), self.steps)
        while self.t < end:
            t = self.t
            beta = self.beta_fn(t, self.steps)
            lr = C.cosine_lr(t / max(self.steps - 1, 1), cfg)
            lat_cpu = self.latent.detach().cpu().clone()
            v, g = C.guarded_value_grad(self.latent, self.ctx.level_d, beta, self.ctx, self.events, t)
            v2, g2 = value_grad(lat_cpu, self.ctx.level_d, self.ctx.target, beta, cfg, self.ctx.mode,
                                self.ctx.theta, self.ctx.phi, torch.complex128, "cpu", False)
            g_cpu = g.detach().double().cpu().flatten()
            g2 = g2.detach().double().cpu().flatten()
            self.audit.append({"step": t, "beta": beta, "value_c64": float(v), "value_c128": float(v2),
                               "norm_c64": float(g_cpu.norm()), "norm_c128": float(g2.norm()),
                               "cos": float(g_cpu @ g2 / (g_cpu.norm() * g2.norm()).clamp_min(1e-300))})
            if t % 50 == 0 or self.audit[-1]["cos"] < 0.9:
                a = self.audit[-1]
                print("step %3d beta %7.2f | v64 %.5f v128 %.5f | |g64| %.4g |g128| %.4g cos %+.4f"
                      % (t, beta, a["value_c64"], a["value_c128"], a["norm_c64"], a["norm_c128"], a["cos"]), flush=True)
            if g is not None:
                self.latent = self.adam.step(self.latent, g, lr)
                if self.record:
                    self.traj.append(round(float(v), 6))
            elif self.record:
                self.traj.append(None)
            self.t = t + 1
            if self.t in self.ck:
                self._checkpoint(self.t)
        return self


def main():
    device = C.setup_runtime()
    em = __import__("importlib").import_module("trustworthy_fmm.solvers.eigendecomposition")
    assert em.EIG_DEVICE == "cpu"
    cfg = C.make_cfg(5)
    od = C.orders_for(M, cfg)
    ctx = C.make_ctx(cfg, (M, 0), od["descent"], od["gate"], device)
    s7 = json.load(open(os.path.join(S7DATA, "s7_T_b2000.json"), encoding="utf-8"))["units"]["m%d|T|s%02d" % (M, RUN_INDEX)]
    ev = []
    t0 = time.perf_counter()
    d = Audited.__new__(Audited)
    d.audit = []
    Audited.__init__(d, ctx, SEED, STEPS, C.beta_geometric(2.0, BETA_END), [0, STEPS], ev, beta_final=BETA_END)
    r = d.finish()
    diff = max(abs(a - b) for a, b in zip(r["trajectory"], s7["trajectory"]))
    print("replay max|diff| vs S7 = %g; %d steps audited in %.0f s" % (diff, len(d.audit), time.perf_counter() - t0), flush=True)
    out = {"meta": {"seed": SEED, "run_index": RUN_INDEX, "level": list(od["descent"]), "device_c64": device,
                    "c128": "cpu", "replay_max_abs_diff": diff, "events": ev}, "steps": d.audit}
    C.save_json(os.path.join(DATA, "f31_cliff_audit.json"), out)
    print("done", flush=True)


if __name__ == "__main__":
    main()
