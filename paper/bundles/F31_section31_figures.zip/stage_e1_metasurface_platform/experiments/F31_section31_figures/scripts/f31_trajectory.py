"""F31 -- data for Fig. 2 of manuscript Sec. 3.1 (one design task: P2, target (1,0)).

1. Replays one conventional-workflow run of S7 (README Example-6 schedule: 800
   steps, beta 2 -> 2000 geometric, Adam lr 0.02 cosine, single order = rule
   descent order (16,2), final field delivered) -- run index 14, seed 151014 --
   with the same code path (s6_common.Descent) and runtime flags, and checks it
   reproduces S7's stored continuous trajectory and gate checkpoints.
   Checkpoint reads are no-grad and do not touch the optimizer, so the replay
   is the same run.  At every checkpoint (every 25 steps) the hard binary is
   read at the descent (16,2), gate (28,4), rung-1 (40,6) and top (48,7)
   orders, and the smooth objective is also read at (40,6).
2. Convergence ladder (4,1) ... (64,9) of the delivered (final) pattern and of
   the best-by-gate pattern.
3. For all 24 S7 T runs at m = 1: the final binary read at the descent order
   (the relaxation / truncation split S7's v1 store did not record) and at the
   top order (48,7).

Descriptive.  GPU complex64, eigendecomposition on the host (TFMM_EIG_DEVICE=cpu).

    python f31_trajectory.py            # all parts
    python f31_trajectory.py --part 3   # one part
"""
import argparse
import json
import os
import sys
import time

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
_EXP = os.path.abspath(os.path.join(_HERE, "..", ".."))
sys.path.insert(0, os.path.join(_EXP, "S6_lottery_pricing", "scripts"))
import s6_common as C                                                  # noqa: E402
from workbench.app import app_filtered                                 # noqa: E402
from trustworthy_fmm.fabrication.process import tanh_projection        # noqa: E402

DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
S7DATA = os.path.join(_EXP, "S7_headtohead", "data")
M = 1
RUN_INDEX = 14
SEED = 151014
STEPS = 800
EVERY = 25
BETA_END = 2000.0
LADDER = [(4, 1), (8, 1), (12, 2), (16, 2), (20, 3), (24, 3), (28, 4), (32, 5), (36, 5),
          (40, 6), (44, 6), (48, 7), (52, 7), (56, 8), (60, 9), (64, 9)]


def log(msg, fh):
    line = time.strftime("%H:%M:%S ") + msg
    print(line, flush=True)
    fh.write(line + "\n")
    fh.flush()


def save(path, obj):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=1)
    os.replace(tmp, path)


def load_s7_binary(rel):
    z = np.load(os.path.join(S7DATA, rel))
    shape = tuple(int(v) for v in z["shape"])
    b = np.unpackbits(z["packed"], axis=1)[:, :shape[1]]
    return torch.from_numpy(b.astype("float64"))


class Recorder(C.Descent):
    """C.Descent that also keeps every checkpoint latent (read-only copies)."""

    def _checkpoint(self, step):
        eg = super()._checkpoint(step)
        if not hasattr(self, "lat_store"):
            self.lat_store = {}
        self.lat_store[int(step)] = self.last["latent"].clone()
        return eg


def part1(ctx, od, cfg, s7unit, out, fh):
    ev = []
    ck = sorted(set(range(0, STEPS + 1, EVERY)) | {0, STEPS})
    t0 = time.perf_counter()
    d = Recorder(ctx, SEED, STEPS, C.beta_geometric(2.0, BETA_END), ck, ev, beta_final=BETA_END)
    r = d.finish()
    log("replay done in %.0f s, events %d" % (time.perf_counter() - t0, len(ev)), fh)
    traj = r["trajectory"]
    ref = s7unit["trajectory"]
    diff = max(abs(a - b) for a, b in zip(traj, ref)) if len(traj) == len(ref) else None
    gate_diff = max(abs(a["eta_gate"] - b["eta_gate"]) for a, b in zip(r["checkpoints"], s7unit["checkpoints"]))
    log("replay check: trajectory max|diff| = %s, gate max|diff| = %.3g, reported %.6f vs S7 %.6f"
        % (diff, gate_diff, r["reported_continuous"], s7unit["reported"]), fh)
    rows = []
    for c in r["checkpoints"]:
        s = int(c["step"])
        lat = d.lat_store[s]
        b = C.app_hard_binary(lat, cfg, ctx.mode)
        beta = c["beta"] if s < STEPS else BETA_END
        dens = tanh_projection(app_filtered(lat, cfg, ctx.mode), float(beta), cfg.threshold)
        row = {"step": s, "beta": beta,
               "J_descent": (traj[s] if s < len(traj) else r["reported_continuous"]),
               "Q_descent": C.eta(b, od["descent"], ctx), "Q_gate": c["eta_gate"],
               "Q_rung1": C.eta(b, od["rung1"], ctx), "Q_top": C.eta(b, od["top"], ctx),
               "J_rung1": C.eta(dens, od["rung1"], ctx), "sha1": C.sha1_of(b)}
        rows.append(row)
        log("  step %3d beta %7.1f | J_d %.4f Q_d %.4f Q_g %.4f Q_r1 %.4f Q_top %.4f J_r1 %.4f"
            % (s, beta, row["J_descent"], row["Q_descent"], row["Q_gate"], row["Q_rung1"], row["Q_top"], row["J_rung1"]), fh)
    out["part1"] = {"seed": SEED, "run_index": RUN_INDEX, "steps": STEPS, "every": EVERY,
                    "orders": {k: list(v) for k, v in od.items()},
                    "replay_trajectory_max_abs_diff": diff, "replay_gate_max_abs_diff": gate_diff,
                    "reported": r["reported_continuous"], "s7_reported": s7unit["reported"],
                    "trajectory": traj, "checkpoints": rows,
                    "best_step_by_gate": r["best"]["step"], "events": ev}
    np.save(os.path.join(DATA, "f31_final_latent.npy"), d.lat_store[STEPS].numpy().astype(np.float64))
    np.save(os.path.join(DATA, "f31_best_latent.npy"), d.lat_store[int(r["best"]["step"])].numpy().astype(np.float64))
    return d, r


def part2(ctx, cfg, lat_final, lat_best, best_step, out, fh):
    res = {}
    for name, lat in (("final", lat_final), ("best", lat_best)):
        b = C.app_hard_binary(lat, cfg, ctx.mode)
        lad = []
        for lv in LADDER:
            t0 = time.perf_counter()
            q = C.eta(b, lv, ctx)
            lad.append({"level": list(lv), "n_terms": (2 * lv[0] + 1) * (2 * lv[1] + 1), "eta": q,
                        "wall_s": time.perf_counter() - t0})
            log("  ladder %s %s eta %.5f (%.1f s)" % (name, lv, q, lad[-1]["wall_s"]), fh)
        res[name] = {"sha1": C.sha1_of(b), "ladder": lad}
        np.save(os.path.join(DATA, "f31_%s_binary.npy" % name), b.numpy().astype(np.uint8))
    res["best"]["step"] = best_step
    out["part2"] = res


def part3(ctx, od, cfg, s7, out, fh):
    rows = []
    for key, u in sorted(s7["units"].items()):
        if u["target"][0] != M:
            continue
        b = load_s7_binary(u["deliver_final"]["files"]["binary"])
        qd = C.eta(b, od["descent"], ctx)
        qt = C.eta(b, od["top"], ctx)
        row = {"index": u["index"], "seed": u["seed"], "reported": u["reported"], "Q_descent": qd,
               "Q_rung1": u["deliver_final"]["eta_rung1"], "Q_top": qt,
               "relaxation": u["reported"] - qd, "truncation_rung1": qd - u["deliver_final"]["eta_rung1"],
               "best_step": u["deliver_best"]["step"], "best_rung1": u["deliver_best"]["eta_rung1"]}
        rows.append(row)
        log("  run %2d reported %.4f Q_d %.4f Q_r1 %.4f Q_top %.4f | relax %+.4f trunc %+.4f"
            % (row["index"], row["reported"], qd, row["Q_rung1"], qt, row["relaxation"], row["truncation_rung1"]), fh)
    out["part3"] = {"target": [M, 0], "runs": rows}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--part", default="1,2,3")
    a = ap.parse_args()
    parts = {int(x) for x in a.part.split(",")}
    os.makedirs(DATA, exist_ok=True)
    device = C.setup_runtime()
    em = __import__("importlib").import_module("trustworthy_fmm.solvers.eigendecomposition")
    assert em.EIG_DEVICE == "cpu", em.EIG_DEVICE
    cfg = C.make_cfg(5)
    od = C.orders_for(M, cfg)
    ctx = C.make_ctx(cfg, (M, 0), od["descent"], od["gate"], device)
    s7 = json.load(open(os.path.join(S7DATA, "s7_T_b2000.json"), encoding="utf-8"))
    s7unit = s7["units"]["m%d|T|s%02d" % (M, RUN_INDEX)]
    assert s7unit["seed"] == SEED
    path = os.path.join(DATA, "f31_fig2.json")
    out = json.load(open(path, encoding="utf-8")) if os.path.exists(path) else {}
    out["meta"] = {"script": os.path.basename(__file__), "device": device,
                   "gpu": torch.cuda.get_device_name(0) if device == "cuda" else "cpu",
                   "eig_device": em.EIG_DEVICE, "dtype": "complex64", "problem": "P2 3000x500 nm, 300 nm, 5 nm",
                   "orders": {k: list(v) for k, v in od.items()}}
    fh = open(os.path.join(DATA, "f31_fig2.log"), "a", encoding="utf-8")
    log("start parts %s on %s" % (sorted(parts), out["meta"]["gpu"]), fh)
    if 1 in parts:
        d, r = part1(ctx, od, cfg, s7unit, out, fh)
        save(path, out)
    if 2 in parts:
        lat_f = torch.from_numpy(np.load(os.path.join(DATA, "f31_final_latent.npy")).astype("float64"))
        lat_b = torch.from_numpy(np.load(os.path.join(DATA, "f31_best_latent.npy")).astype("float64"))
        part2(ctx, cfg, lat_f, lat_b, out["part1"]["best_step_by_gate"], out, fh)
        save(path, out)
    if 3 in parts:
        part3(ctx, od, cfg, s7, out, fh)
        save(path, out)
    log("done", fh)


if __name__ == "__main__":
    main()
