"""F31 -- counterfactual replays of the Fig. 2 run around its one-step collapse.

The audit (f31_cliff.py, bitwise replay of S7 T m=1 s14) found the complex64
gradient at step 162 (beta 8.1) 14.5x the complex128 one (cosine 0.64), and the
run's largest one-step drop at step 163.  Here the SAME run is replayed with a
single change at step 162 (and, in one variant, also at 171):

  original   -- unchanged (control; must equal S7 bitwise)
  c128_162   -- step 162 uses the complex128 gradient of the same latent/beta
  retry_162  -- step 162 uses a complex64 recomputation at beta*1.01 (what the
                norm guard of the proposed workflow would try first)
  c128_both  -- steps 162 and 171 use complex128 gradients

Everything else (Adam state, schedules, all other gradients in complex64 on the
GPU) is untouched.  Records the continuous trajectory and the hard binary at
the reference order (48,7) at steps 150, 175, 200, 250, 450, 800.

Descriptive.  GPU complex64, eigendecomposition on the host, 3 threads (as S7).
"""
import json
import os
import sys
import time

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
_EXP = os.path.abspath(os.path.join(_HERE, "..", ".."))
sys.path.insert(0, os.path.join(_EXP, "S6_lottery_pricing", "scripts"))
import s6_common as C                                                  # noqa: E402
from workbench.app import value_grad                                   # noqa: E402

DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
S7DATA = os.path.join(_EXP, "S7_headtohead", "data")
M, RUN_INDEX, SEED, STEPS, BETA_END = 1, 14, 151014, 800, 2000.0
READ_AT = [150, 175, 200, 250, 450, 800]
VARIANTS = {"original": {}, "c128_162": {162: "c128"}, "retry_162": {162: "retry"},
            "c128_both": {162: "c128", 171: "c128"}}
VARIANTS_426 = {"c128_426": {426: "c128"}, "retry_426": {426: "retry"}}


class Counterfactual(C.Descent):
    def setup(self, changes):
        self.changes = changes
        self.swaps = []
        return self

    def run_to(self, step):
        cfg = self.ctx.cfg
        end = min(int(step), self.steps)
        while self.t < end:
            t = self.t
            beta = self.beta_fn(t, self.steps)
            lr = C.cosine_lr(t / max(self.steps - 1, 1), cfg)
            v, g = C.guarded_value_grad(self.latent, self.ctx.level_d, beta, self.ctx, self.events, t)
            how = self.changes.get(t)
            if how is not None:
                n_old = float(g.norm())
                if how == "c128":
                    v2, g2 = value_grad(self.latent.detach().cpu().clone(), self.ctx.level_d, self.ctx.target, beta, cfg,
                                        self.ctx.mode, self.ctx.theta, self.ctx.phi, torch.complex128, "cpu", False)
                else:
                    v2, g2 = C.guarded_value_grad(self.latent, self.ctx.level_d, beta * 1.01, self.ctx, self.events, t)
                g2 = g2.to(device=g.device, dtype=g.dtype)
                c = float((g.flatten() @ g2.flatten()) / (g.norm() * g2.norm()))
                self.swaps.append({"step": t, "how": how, "norm_c64": n_old, "norm_used": float(g2.norm()), "cos_to_c64": c})
                g = g2
            if g is not None:
                self.latent = self.adam.step(self.latent, g, lr)
                if self.record:
                    self.traj.append(round(float(v), 6))
            elif self.record:
                self.traj.append(None)
            self.t = t + 1
            if self.t in self.ck:
                self._checkpoint(self.t)
        return self


def main():
    global VARIANTS, READ_AT
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--set", default="162")
    a = ap.parse_args()
    out_name = "f31_counterfactual.json"
    if a.set == "426":
        VARIANTS, READ_AT, out_name = VARIANTS_426, [425, 430, 450, 500, 800], "f31_counterfactual_426.json"
    device = C.setup_runtime()
    em = __import__("importlib").import_module("trustworthy_fmm.solvers.eigendecomposition")
    assert em.EIG_DEVICE == "cpu"
    cfg = C.make_cfg(5)
    od = C.orders_for(M, cfg)
    ctx = C.make_ctx(cfg, (M, 0), od["descent"], od["gate"], device)
    s7 = json.load(open(os.path.join(S7DATA, "s7_T_b2000.json"), encoding="utf-8"))["units"]["m%d|T|s%02d" % (M, RUN_INDEX)]
    out = {"meta": {"seed": SEED, "run_index": RUN_INDEX, "orders": {k: list(v) for k, v in od.items()},
                    "read_at": READ_AT, "variants": {k: {str(s): h for s, h in v.items()} for k, v in VARIANTS.items()}},
           "runs": {}}
    path = os.path.join(DATA, out_name)
    for name, changes in VARIANTS.items():
        t0 = time.perf_counter()
        ev = []
        d = Counterfactual(ctx, SEED, STEPS, C.beta_geometric(2.0, BETA_END), [0, STEPS], ev, beta_final=BETA_END).setup(changes)
        reads = {}
        for s in READ_AT:
            d.run_to(s)
            lat = d.latent.detach().cpu().clone()
            b = C.app_hard_binary(lat, cfg, ctx.mode)
            reads[str(s)] = {"Q_descent": C.eta(b, od["descent"], ctx), "Q_top": C.eta(b, od["top"], ctx)}
        r = d.finish()
        diff = max(abs(a - b) for a, b in zip(r["trajectory"], s7["trajectory"]))
        out["runs"][name] = {"trajectory": r["trajectory"], "reported": r["reported_continuous"], "reads": reads,
                             "swaps": d.swaps, "max_abs_diff_to_s7": diff, "events": ev, "wall_s": time.perf_counter() - t0}
        tr = r["trajectory"]
        k1, k2, k3, k4 = (160, 163, 170, 190) if a.set != "426" else (424, 427, 430, 450)
        print("%-10s | diff-to-S7 %.3g | J@%d %.3f J@%d %.3f J@%d %.3f J@%d %.3f | Q_top@450 %.3f @800 %.3f | swaps %s  (%.0f s)"
              % (name, diff, k1, tr[k1], k2, tr[k2], k3, tr[k3], k4, tr[k4], reads["450"]["Q_top"], reads["800"]["Q_top"],
                 [(w["step"], round(w["norm_c64"] / w["norm_used"], 2), round(w["cos_to_c64"], 3)) for w in d.swaps],
                 time.perf_counter() - t0), flush=True)
        C.save_json(path, out)
    print("done", flush=True)


if __name__ == "__main__":
    main()
