"""
F31 -- Fig. 2 of manuscript Sec. 3.1 as separate panels (2026-10-03).  Data, colours and content as in f31_plot_v2.fig2()
(unchanged); what changes is the type and the delivery.

User rulings 2026-10-03 (Fig. 2 check):
  * the colour key (truncation order) applies to several panels, so it is its own strip, to be placed first;
  * type as in Fig. 1(c) v2: Times New Roman, tick labels 8.5 pt and axis labels 9.5 pt, both bold (bold math through
    the mathtext rc, font.weight left normal); annotations and legends 8 pt regular (math in STIX); every text starts
    with a capital letter;
  * one file per panel, no panel letters (the author arranges them by hand); png + svg only, no pdf.

Sizes are 1 : 1 with a 180 mm wide page: the axes of every panel keep the size they would have in the assembled figure,
the canvas is cropped to the labels (bbox tight), so placing the files at 100 % keeps the type at its nominal size.

Output: manuscript_cpc/figures/fig2_parts/   fig2_legend_orders, fig2_a_ladder, fig2_b_run, fig2_c_runs24,
        fig2_d_error, fig2_e_alignment   (each .png and .svg)
"""
import json
import math
import os
import sys

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                        # noqa: E402
from matplotlib.lines import Line2D                                    # noqa: E402

_HERE = os.path.dirname(os.path.abspath(__file__))
_EXP = os.path.abspath(os.path.join(_HERE, "..", ".."))
DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
OUT = os.path.abspath(os.path.join(_EXP, "..", "..", "stage_d3_landscape_scheduling", "manuscript", "manuscript_cpc",
                                   "figures", "fig2_parts"))
sys.path.insert(0, os.path.join(_EXP, "S8_order_beta_map", "scripts"))

# ---- colours: UNCHANGED (plasma 0-0.75, one colour per truncation order) --------------------------------------------
ORDERS = [(16, 2), (20, 3), (24, 3), (28, 4), (32, 5), (40, 6), (48, 7)]
RAMP = ["#0d0887", "#4c02a1", "#7e03a8", "#aa2395", "#cc4778", "#e66c5c", "#f89540"]
OC = dict(zip(ORDERS, RAMP))
MD, MG, MR = (16, 2), (28, 4), (48, 7)
INK, INK2, GREY, GREY_L = "#0b0b0b", "#52514e", "#8c8b86", "#c9c8c3"
FILL_BIN, FILL_TRUNC, BAND = "#e2e1f1", "#fdeadb", "#f0efec"
LAB = {MD: r"$M_d$", MG: r"$M_g$", MR: r"$M_r$"}
BETA_TICKS = [2, 10, 100, 1000]

# ---- type ------------------------------------------------------------------------------------------------------------
TLS, ALS, ANS = 8.5, 9.5, 8.0                    # tick labels, axis labels (bold) ; annotations and legends (regular)
RC = {"font.family": "serif", "font.serif": ["Times New Roman"],
      "mathtext.fontset": "custom", "mathtext.rm": "Times New Roman:bold",
      "mathtext.it": "Times New Roman:italic:bold", "mathtext.bf": "Times New Roman:bold",
      "mathtext.fallback": "stix",
      "axes.labelsize": ALS, "axes.labelweight": "bold", "xtick.labelsize": TLS, "ytick.labelsize": TLS,
      "axes.linewidth": 0.6, "xtick.major.width": 0.6, "ytick.major.width": 0.6,
      "xtick.minor.width": 0.4, "ytick.minor.width": 0.4, "xtick.major.size": 3, "ytick.major.size": 3,
      "xtick.minor.size": 1.8, "ytick.minor.size": 1.8,
      "axes.edgecolor": INK2, "axes.labelcolor": INK, "xtick.color": INK2, "ytick.color": INK2, "text.color": INK,
      "axes.spines.top": False, "axes.spines.right": False, "legend.frameon": False,
      "svg.fonttype": "none", "savefig.dpi": 300}
plt.rcParams.update(RC)
MM = 1 / 25.4


def note(ax, x, y, s, **kw):
    """Annotation: regular weight, 8 pt, math in STIX."""
    kw.setdefault("fontsize", ANS)
    kw.setdefault("color", INK2)
    return ax.text(x, y, s, fontweight="normal", math_fontfamily="stix", **kw)


def reg_legend(ax_or_fig, **kw):
    leg = ax_or_fig.legend(frameon=False, **kw)
    for t in leg.get_texts():
        t.set_fontweight("normal"); t.set_math_fontfamily("stix"); t.set_fontsize(ANS)
    if leg.get_title() is not None:
        leg.get_title().set_fontweight("normal"); leg.get_title().set_math_fontfamily("stix")
        leg.get_title().set_fontsize(ANS)
    return leg


def bold_ticks(*axes):
    for a in axes:
        for t in a.get_xticklabels(which="both") + a.get_yticklabels(which="both"):
            t.set_fontweight("bold")


def olab(lv):
    return "(%d,%d)" % tuple(lv)


def canvas(w_mm, h_mm, left=17, bottom=14, right=2, top=2):
    """Figure whose axes are exactly w_mm x h_mm; margins in mm (the saved file is cropped afterwards)."""
    W, H = (left + w_mm + right) * MM, (bottom + h_mm + top) * MM
    fig = plt.figure(figsize=(W, H))
    ax = fig.add_axes([left * MM / W, bottom * MM / H, w_mm * MM / W, h_mm * MM / H])
    return fig, ax


def save(fig, name):
    os.makedirs(OUT, exist_ok=True)
    for ext in ("png", "svg"):                      # no pdf (user ruling 2026-10-03)
        fig.savefig(os.path.join(OUT, "%s.%s" % (name, ext)), bbox_inches="tight", pad_inches=0.03, facecolor="white")
    plt.close(fig)
    print("saved", name)


D = json.load(open(os.path.join(DATA, "f31_fig2.json"), encoding="utf-8"))
p1, p2, p3 = D["part1"], D["part2"], D["part3"]
REPORTED = p1["reported"]


# ---- colour key (placed first in the assembled figure) ---------------------------------------------------------------
def legend_orders():
    handles = []
    for l in ORDERS:
        big = l in (MD, MG)
        name = olab(l) + ("  " + LAB[l] if l in LAB else "")
        handles.append(Line2D([0], [0], color=OC[l], lw=(1.4 if big else 0.9), marker="o", ms=(2.6 if big else 1.8),
                              mew=0, label=name))
    # key information of the figure: larger and bold (user ruling 2026-10-05); bold math through the mathtext rc
    KS = 10.0
    fig = plt.figure(figsize=(180 * MM, 15 * MM))
    leg = fig.legend(handles=handles, loc="center", bbox_to_anchor=(0.5, 0.48), ncol=7, frameon=False,
                     title="Truncation order (color in all panels)", handlelength=1.5, handletextpad=0.5,
                     columnspacing=0.9, borderaxespad=0.0)
    for t in leg.get_texts():
        t.set_fontweight("bold"); t.set_fontsize(KS)
    leg.get_title().set_fontweight("bold"); leg.get_title().set_fontsize(KS + 0.5)
    save(fig, "fig2_legend_orders")


# ---- (a) the delivered pattern evaluated with more and more harmonics ------------------------------------------------
def panel_a():
    fig, ax = canvas(50, 48, left=18)
    lad = p2["final"]["ladder"]
    nt = np.array([r["n_terms"] for r in lad], float)
    eta = np.array([r["eta"] for r in lad])
    lv = [tuple(r["level"]) for r in lad]
    ax.axhline(REPORTED, color=OC[MD], lw=0.9, ls=(0, (4, 2)), zorder=0)
    note(ax, nt[0], REPORTED + 0.013, "Value reported by the run", va="bottom", ha="left")
    ax.plot(nt, eta, "-", color=GREY_L, lw=0.9, zorder=1)
    for i, l in enumerate(lv):
        if l in OC:
            big = l in (MD, MG, MR)
            ax.scatter([nt[i]], [eta[i]], s=(40 if big else 18), color=OC[l], zorder=3, edgecolors="white", linewidths=0.7)
        else:
            ax.scatter([nt[i]], [eta[i]], s=9, color=GREY, zorder=2, linewidths=0)
    i_d, i_g, i_r = lv.index(MD), lv.index(MG), lv.index(MR)
    note(ax, nt[i_d] * 0.86, eta[i_d] - 0.02, LAB[MD] + " " + olab(MD), color=INK, va="top", ha="right")
    note(ax, nt[i_g] * 1.13, eta[i_g] + 0.012, LAB[MG] + " " + olab(MG), color=INK, va="bottom", ha="left")
    note(ax, nt[i_r], eta[i_r] + 0.034, LAB[MR] + " " + olab(MR), color=INK, va="bottom", ha="center")
    ax.set_xscale("log")
    ax.set_xlabel("Number of retained harmonics $N$")
    ax.set_ylabel("Efficiency of the delivered pattern")
    ax.set_ylim(0.36, 1.02)
    ax.set_xlim(nt[0] * 0.75, nt[-1] * 1.3)
    # delivered pattern: 3 um x 1 um (one period along x, two along y) drawn at its true aspect ratio (3 : 1)
    b = np.load(os.path.join(DATA, "f31_final_binary.npy")).astype(float)
    wi = 0.54                                       # inset width, axes fraction
    hi = wi * 50.0 / 3.0 / 48.0                     # height for a 3 : 1 aspect on a 50 x 48 mm axes
    ins = ax.inset_axes([0.44, 0.04, wi, hi])
    ins.imshow(1 - np.vstack([b, b]), cmap="gray", vmin=-0.4, vmax=1.0, origin="lower", aspect="auto",
               extent=[0, 3.0, 0, 1.0], interpolation="nearest")
    ins.set_xticks([]); ins.set_yticks([])
    for s in ins.spines.values():
        s.set_visible(True); s.set_color(INK2); s.set_linewidth(0.5)
    note(ax, 0.425, 0.04 + hi / 2, "Delivered pattern\n(3 µm × 1 µm)", transform=ax.transAxes, ha="right", va="center",
         linespacing=1.0)                              # left of the inset: the area above it holds the ladder points
    bold_ticks(ax)
    save(fig, "fig2_a_ladder")


# ---- (b) the same run, step by step ----------------------------------------------------------------------------------
def panel_b():
    fig, ax = canvas(70, 48, left=15, top=11)
    traj = np.array([np.nan if v is None else v for v in p1["trajectory"]] + [REPORTED])
    steps = np.arange(len(traj))
    ck = p1["checkpoints"]
    cs = np.array([c["step"] for c in ck])
    jd = traj[cs]
    qd = np.array([c["Q_descent"] for c in ck])
    qg = np.array([c["Q_gate"] for c in ck])
    qr = np.array([c["Q_top"] for c in ck])
    ax.fill_between(cs, qd, jd, where=jd >= qd, color=FILL_BIN, lw=0, zorder=0, interpolate=True)
    ax.fill_between(cs, qr, qd, where=qd >= qr, color=FILL_TRUNC, lw=0, zorder=0, interpolate=True)
    ax.plot(steps, traj, color=OC[MD], lw=1.2, zorder=3)
    ax.plot(cs, qd, "o", ms=2.7, mfc="white", mec=OC[MD], mew=0.8, zorder=4)
    ax.plot(cs, qg, "-s", color=OC[MG], lw=0.8, ms=2.3, mew=0, zorder=2)
    ax.plot(cs, qr, "-D", color=OC[MR], lw=1.0, ms=2.4, mew=0, zorder=2)
    note(ax, 62, 0.55, "Binarization gap", ha="center", va="center", rotation=90)     # first blue region is narrow: vertical
    note(ax, 640, 0.775, "Truncation gap", ha="center", va="center")
    xr = 812
    note(ax, xr, traj[-1] + 0.02, "Objective (line) and\npattern (o) at " + LAB[MD], color=INK, va="center", ha="left")
    note(ax, xr, qg[-1] + 0.01, "Pattern at " + LAB[MG], color=INK, va="center", ha="left")
    note(ax, xr, qr[-1] - 0.045, "Pattern at " + LAB[MR], color=INK, va="center", ha="left")
    ax.set_xlim(0, 800)
    ax.set_ylim(0, 1.0)
    ax.set_xlabel("Optimization step")
    ax.set_ylabel("Efficiency")
    top = ax.secondary_xaxis("top", functions=(lambda s: s, lambda s: s))
    top.set_xticks([800 * math.log(bb / 2) / math.log(1000) for bb in BETA_TICKS])
    top.set_xticklabels([str(bb) for bb in BETA_TICKS])
    top.set_xlabel("Projection sharpness $\\beta$", labelpad=2)
    top.tick_params(length=2.5)
    bold_ticks(ax, top)
    save(fig, "fig2_b_run")


# ---- (c) all 24 runs of the task -------------------------------------------------------------------------------------
def panel_c():
    fig, ax = canvas(160, 34, left=15, top=8)
    runs = sorted(p3["runs"], key=lambda r: r["Q_top"])
    x = np.arange(len(runs))
    rep = np.array([r["reported"] for r in runs])
    qdd = np.array([r["Q_descent"] for r in runs])
    qrr = np.array([r["Q_top"] for r in runs])
    k = [i for i, r in enumerate(runs) if r["index"] == p1["run_index"]][0]
    ax.axvspan(k - 0.45, k + 0.45, color=BAND, zorder=0)
    for i in range(len(runs)):
        ax.plot([x[i], x[i]], [qrr[i], max(rep[i], qdd[i])], color=GREY_L, lw=1.6, zorder=1, solid_capstyle="butt")
    ax.scatter(x, rep, s=28, facecolors="none", edgecolors=OC[MD], linewidths=0.9, zorder=3, label="Value reported by the run")
    ax.scatter(x, qdd, s=7, color=OC[MD], zorder=4, linewidths=0, label="Delivered pattern at " + LAB[MD])
    ax.scatter(x, qrr, s=18, marker="D", color=OC[MR], zorder=4, linewidths=0, label="Delivered pattern at " + LAB[MR])
    note(ax, k, 0.035, "Run of\n(a, b)", ha="center", va="bottom", linespacing=1.0)
    ax.set_xticks([])
    ax.set_xlim(-0.8, len(runs) - 0.2)
    ax.set_ylim(0, 1.05)
    ax.set_xlabel("Runs from 24 different random initial designs, sorted by delivered efficiency")
    ax.set_ylabel("Efficiency")
    reg_legend(ax, loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=3, handletextpad=0.3, columnspacing=1.6,
               borderaxespad=0.2)
    bold_ticks(ax)
    save(fig, "fig2_c_runs24")


# ---- (d), (e) a frozen mid-run design state --------------------------------------------------------------------------
def _frozen():
    import s8_plot as s8p
    A, G = s8p.load()
    key = "m1_s00_st095"
    betas, cl, cd, E, Q, pts = s8p.grids(A, key)
    ladd = [tuple(v) for v in A["meta"]["ladder"]]
    B = np.array(betas)
    ok = np.array([not s8p.ref_flag(p) for p in pts])
    bl = A["binary_ladder"][key]["ladder"]
    ref_b = bl["%d-%d" % ladd[-1]]["eta"]
    return B, cl, E, ladd, ok, bl, ref_b


def panel_d():
    B, cl, E, ladd, ok, bl, ref_b = _frozen()
    fig, ax = canvas(66, 50, left=17)
    ax.axvspan(16, 128, color=BAND, zorder=0)
    for l in ORDERS:
        j = ladd.index(l)
        big = l in (MD, MG)
        ax.plot(B, E[:, j], "-o", color=OC[l], lw=(1.4 if big else 0.9), ms=(2.6 if big else 1.8), mew=0, zorder=(3 if big else 2))
        ax.plot([2950], [bl["%d-%d" % l]["eta"] - ref_b], marker="<", color=OC[l], ms=4, mew=0, clip_on=False, zorder=3)
    ax.axhline(0, color=INK2, lw=0.5)
    ax.set_xscale("log")
    ax.set_xlim(1.7, 2000 * 1.12)
    ax.set_ylim(-0.035, 0.172)
    ax.set_xlabel("Projection sharpness $\\beta$ (design frozen)")
    ax.set_ylabel("Error of the objective, $J_M-J_{\\rm ref}$")
    note(ax, 45, 0.163, "Error switches on", ha="center")
    ax.plot([150], [-0.025], marker="<", color=INK2, ms=4, mew=0)
    note(ax, 185, -0.025, "Binary pattern", va="center", ha="left")
    bold_ticks(ax)
    save(fig, "fig2_d_error")


def panel_e():
    B, cl, E, ladd, ok, bl, ref_b = _frozen()
    fig, ax = canvas(66, 50, left=17)
    for l in ORDERS:
        j = ladd.index(l)
        big = l in (MD, MG)
        ax.plot(B[ok], cl[ok, j], "-o", color=OC[l], lw=(1.4 if big else 0.9), ms=(2.6 if big else 1.8), mew=0, zorder=(3 if big else 2))
    ax.axhline(1, color=INK2, lw=0.5)
    note(ax, 1500, cl[-1, ladd.index(MG)] - 0.028, LAB[MG], color=INK, ha="center", va="top")
    note(ax, 1500, cl[-1, ladd.index(MD)] - 0.03, LAB[MD], color=INK, ha="center", va="top")
    ax.set_xscale("log")
    ax.set_xlim(1.7, 2000 * 1.12)
    ax.set_ylim(0.3, 1.04)
    ax.set_xlabel("Projection sharpness $\\beta$ (design frozen)")
    ax.set_ylabel("Alignment with the reference\ngradient (cosine)")
    bold_ticks(ax)
    save(fig, "fig2_e_alignment")


if __name__ == "__main__":
    legend_orders()
    panel_a()
    panel_b()
    panel_c()
    panel_d()
    panel_e()
    print("written to", OUT)
