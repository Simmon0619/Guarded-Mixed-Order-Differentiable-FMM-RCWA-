"""S8 supplement -- a fine beta scan of the gradient at low orders, one geometry.

Motivation: in the (N, beta) map the (60,9) density gradient of m1_s00_st095 at
beta = 256 carries a spurious high-frequency component (norm x4, 42 % of its
energy outside the (48,7) band; the value is unaffected) -- the signature of a
near-degenerate eigenvalue pair in the backward pass.  If the same happens at
the DESCENT order at particular betas, the ramp walks through such betas and a
finite-but-wrong gradient step is a cliff candidate.  This scan samples beta
densely (log-spaced) at cheap orders and records, per beta: value, |g|, |h|,
the fraction of the density gradient's energy outside the order's own band and
the cosine of consecutive gradients (the fine-grained beta drift).

Descriptive; CPU is enough for these orders (the big sweep owns the GPU).
"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import s8_map as S                                                    # noqa: E402
C = S.C


def band_fraction_outside(h_flat, shape, level):
    H = h_flat.reshape(shape).numpy()
    F = np.abs(np.fft.rfft2(H)) ** 2
    ky = np.abs(np.fft.fftfreq(shape[0]) * shape[0])[:, None]
    kx = np.arange(F.shape[1])[None, :]
    inside = (ky <= level[1]) & (kx <= level[0])
    return float(1.0 - F[inside].sum() / max(F.sum(), 1e-300))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--geom", default="m1_s00_st095")
    ap.add_argument("--levels", default="16,2;28,4")
    ap.add_argument("--n", type=int, default=240)
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--threads", type=int, default=2)
    a = ap.parse_args()
    torch.set_num_threads(a.threads)
    C.setup_runtime()
    torch.set_num_threads(a.threads)
    S.assert_eig_cpu()
    G = json.load(open(os.path.join(S.DATA, "s8_geoms.json"), encoding="utf-8"))["geoms"][a.geom]
    cfg = C.make_cfg(5)
    od = {k: tuple(v) for k, v in G["orders"].items()}
    ctx = C.make_ctx(cfg, (G["m"], 0), od["descent"], od["gate"], a.device)
    lat = torch.from_numpy(np.load(os.path.join(S.DATA, G["latent"])))
    shape = tuple(lat.shape)
    betas = np.exp(np.linspace(math.log(2.0), math.log(2000.0), a.n)).tolist()
    out_path = os.path.join(S.DATA, "s8_beta_scan_%s.json" % a.geom)
    out = json.load(open(out_path, encoding="utf-8")) if os.path.exists(out_path) else {"meta": {}, "scans": {}}
    out["meta"] = {"geom": a.geom, "n": a.n, "betas": betas, "device": a.device, "eig_device": "cpu",
                   "columns": "value, norm_lat, norm_den, frac_outside_band, cos_prev_lat, cos_prev_den, beta_used, wall_s"}
    for lv_s in a.levels.split(";"):
        lv = tuple(int(x) for x in lv_s.split(","))
        key = "%d-%d" % lv
        if key in out["scans"] and len(out["scans"][key]["rows"]) == a.n:
            continue
        rows, events = [], []
        prev_g = prev_h = None
        t_all = time.perf_counter()
        for i, b in enumerate(betas):
            t0 = time.perf_counter()
            v, g, h, bu = S.robust_grads(lat, lv, b, ctx, events, "scan")
            hs, _ = S.sym_split(h, shape)
            row = {"beta": b, "value": v, "norm_lat": float(g.norm()), "norm_den": float(hs.norm()),
                   "frac_outside_band": band_fraction_outside(hs, shape, lv),
                   "cos_prev_lat": (S.cosine(prev_g, g) if prev_g is not None else None),
                   "cos_prev_den": (S.cosine(prev_h, hs) if prev_h is not None else None),
                   "beta_used": bu, "wall_s": time.perf_counter() - t0}
            rows.append(row)
            prev_g, prev_h = g, hs
            if i % 40 == 0:
                print("%s beta %8.2f value %.4f |g| %.3e |h| %.3e outside %.3f  (%.0f s)" % (key, b, v, row["norm_lat"], row["norm_den"], row["frac_outside_band"], time.perf_counter() - t_all), flush=True)
        out["scans"][key] = {"level": list(lv), "rows": rows, "events": events, "wall_s": time.perf_counter() - t_all}
        C.save_json(out_path, out)
        nl = np.array([r["norm_lat"] for r in rows])
        med = np.median(nl)
        spikes = [(round(r["beta"], 1), round(r["norm_lat"] / med, 2)) for r in rows if r["norm_lat"] > 2 * med]
        print("%s done in %.0f s | |g| median %.3e | spikes (>2x median): %s" % (key, time.perf_counter() - t_all, med, spikes), flush=True)


if __name__ == "__main__":
    main()
