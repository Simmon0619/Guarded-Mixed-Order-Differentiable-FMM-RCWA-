"""S8 supplement for E3 v2 -- beta scans with the layer's minimum eigenvalue gap
logged next to the gradient (GAP_ONLY_DIAGNOSTICS), to set the eigen-gap
guard's threshold tau per order: the gap distribution over the scan, the
gradient-norm ratio to the running median, and the cosine to the previous
beta, so 'bad' points (norm spike or direction flip) can be related to the
gap.  GPU / c64, eig on CPU (the production path).

  python s8_gap_scan.py --data data --geom m3_s00_st095 --levels "24,3;40,6" --n 240,120
  python s8_gap_scan.py --data data_m4 --geom m4_s00_st095 --levels "28,4;44,6" --n 240,120
"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
os.environ["TFMM_GAP_ONLY_DIAGNOSTICS"] = "1"
import s8_map as S                                                    # noqa: E402
C = S.C
from workbench.app import app_projected, solve_density                # noqa: E402
import trustworthy_fmm.solvers.vector_2d as V                         # noqa: E402


def value_grad_gap(latent, level, beta, ctx):
    x = latent.detach().clone().to(ctx.device).requires_grad_(True)
    dens = app_projected(x, float(beta), ctx.cfg, ctx.mode)
    r = solve_density(dens, tuple(level), ctx.cfg, ctx.theta, ctx.phi, ctx.dtype, ctx.device)
    gap = float(r.diagnostics["min_eigen_gap"])
    j = r.power_t[r.orders.index(tuple(ctx.target))]
    j.backward()
    v = float(j.detach())
    g = x.grad.detach().double().cpu().flatten()
    del r, j, dens, x
    return v, g, gap


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data")
    ap.add_argument("--geom", default="m3_s00_st095")
    ap.add_argument("--levels", default="24,3;40,6")
    ap.add_argument("--n", default="240,120")
    a = ap.parse_args()
    V.GAP_ONLY_DIAGNOSTICS = True
    data = os.path.abspath(os.path.join(_HERE, "..", a.data))
    device = C.setup_runtime()
    S.assert_eig_cpu()
    G = json.load(open(os.path.join(data, "s8_geoms.json"), encoding="utf-8"))["geoms"][a.geom]
    cfg = C.make_cfg(5)
    od = {k: tuple(v) for k, v in G["orders"].items()}
    ctx = C.make_ctx(cfg, (G["m"], 0), od["descent"], od["gate"], device)
    lat = torch.from_numpy(np.load(os.path.join(data, G["latent"])))
    out_path = os.path.join(data, "s8_gap_scan_%s.json" % a.geom)
    out = json.load(open(out_path, encoding="utf-8")) if os.path.exists(out_path) else {"meta": {}, "scans": {}}
    out["meta"] = {"geom": a.geom, "device": device, "eig_device": "cpu", "gap_only": True,
                   "columns": "beta, value, norm_lat, gap, cos_prev_lat, wall_s"}
    ns = [int(x) for x in a.n.split(",")]
    for lv_s, n in zip(a.levels.split(";"), ns):
        lv = tuple(int(x) for x in lv_s.split(","))
        key = "%d-%d" % lv
        if key in out["scans"] and len(out["scans"][key]["rows"]) == n:
            continue
        betas = np.exp(np.linspace(math.log(2.0), math.log(2000.0), n)).tolist()
        rows, prev = [], None
        t_all = time.perf_counter()
        for i, b in enumerate(betas):
            t0 = time.perf_counter()
            v, g, gap = value_grad_gap(lat, lv, b, ctx)
            rows.append({"beta": b, "value": v, "norm_lat": float(g.norm()), "gap": gap,
                         "cos_prev_lat": (S.cosine(prev, g) if prev is not None else None), "wall_s": time.perf_counter() - t0})
            prev = g
            if i % 40 == 0:
                print("%s beta %8.2f value %.4f |g| %.3e gap %.2e (%.0f s)" % (key, b, v, rows[-1]["norm_lat"], gap, time.perf_counter() - t_all), flush=True)
        out["scans"][key] = {"level": list(lv), "n": n, "rows": rows, "wall_s": time.perf_counter() - t_all}
        C.save_json(out_path, out)
        nl = np.array([r["norm_lat"] for r in rows]); gp = np.array([r["gap"] for r in rows]); cp = np.array([r["cos_prev_lat"] or 1.0 for r in rows])
        med = np.median(nl)
        bad = [(round(r["beta"], 1), round(r["norm_lat"] / med, 1), "%.1e" % r["gap"], round(c, 2)) for r, c in zip(rows, cp) if r["norm_lat"] > 3 * med or c < 0.7]
        print("%s done %.0f s | gap quantiles 1%%/2%%/5%%/50%%: %.1e / %.1e / %.1e / %.1e | bad points (norm>3x med or cos<0.7): %s"
              % (key, time.perf_counter() - t_all, *np.quantile(gp, [0.01, 0.02, 0.05, 0.5]), bad), flush=True)


if __name__ == "__main__":
    main()
