"""S8 -- figures and tables from data/s8_map.json (no solves).

Per geometry: three heatmaps over (N on x, beta on y, log): cos_lat(N, ref),
cos_den(N, ref) (sequential, one hue, 0..1) and E(N) = Q_N - Q_ref (diverging,
gray at 0).  The geometry's own beta is marked.  Iso-cosine tables: for each
beta the smallest ladder index whose cosine to the reference is >= c, for
c in {0.8, 0.9, 0.95}; averaged over the stage-95 geometries too.  The beta
drift D(beta) from the saved reference-order gradients, and the price ladder
(wall per order, median over points).  Writes figures/*.png and s8_summary.json.
"""
import json
import os
import sys

import numpy as np

_HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
FIG = os.path.abspath(os.path.join(_HERE, "..", "figures"))
THRESH = [0.8, 0.9, 0.95]


def load():
    A = json.load(open(os.path.join(DATA, "s8_map.json"), encoding="utf-8"))
    G = json.load(open(os.path.join(DATA, "s8_geoms.json"), encoding="utf-8"))["geoms"]
    return A, G


def ref_flag(p):
    """A (60,9) density gradient whose norm jumps against (48,7) (x1.5 either way)
    or decorrelates from it (cos < 0.8) is a contaminated reference (c64
    near-degeneracy, see record Sec. 3): the cosines of that row are then taken
    against (48,7) instead.  Values are unaffected and keep (60,9)."""
    ratio = p["norm_den_sym"][-1] / max(p["norm_den_sym"][-2], 1e-300)
    return (ratio > 1.5) or (ratio < 1 / 1.5) or (p["cos_den"][-2][-1] < 0.8)


def grids(A, key):
    betas = [b for b in A["meta"]["betas"] if "%s|b%g" % (key, b) in A["points"]]
    pts = [A["points"]["%s|b%g" % (key, b)] for b in betas]
    L = len(A["meta"]["ladder"])
    cl, cd = [], []
    for p in pts:
        j = L - 2 if ref_flag(p) else L - 1
        cl.append(np.array(p["cos_lat"])[:, j])
        cd.append(np.array(p["cos_den"])[:, j])
    cl = np.array(cl) if pts else np.zeros((0, L))
    cd = np.array(cd) if pts else np.zeros((0, L))
    E = np.array([p["value_minus_ref"] for p in pts]) if pts else np.zeros((0, L))
    Q = np.array([p["value"] for p in pts]) if pts else np.zeros((0, L))
    return betas, cl, cd, E, Q, pts


def iso(betas, M, ladder, c):
    """Per beta: 'first' = smallest ladder index with cos >= c; 'mono' = smallest
    index from which every higher rung also has cos >= c (the monotone envelope,
    what a schedule can actually use).  None if never."""
    out = []
    for i, b in enumerate(betas):
        row = M[i]
        first = next((j for j in range(len(row)) if row[j] >= c), None)
        mono = None
        for j in range(len(row) - 1, -1, -1):
            if row[j] >= c:
                mono = j
            else:
                break
        out.append({"beta": b, "first": first, "mono": mono,
                    "order_first": ladder[first] if first is not None else None,
                    "order_mono": ladder[mono] if mono is not None else None})
    return out


def drift(A, key):
    betas = [b for b in A["meta"]["betas"] if "%s|b%g" % (key, b) in A["points"]]
    gl, gd = [], []
    for b in betas:
        p = A["points"]["%s|b%g" % (key, b)]
        z = np.load(os.path.join(DATA, p["grads"]))
        i_ref = p["i_ref"]
        gl.append(z["g_lat"][i_ref].astype(np.float64))
        h = z["h_den"][i_ref].astype(np.float64)
        gd.append(h)

    def cos(a, b):
        return float(a @ b / max(np.linalg.norm(a) * np.linalg.norm(b), 1e-300))
    return [{"beta_from": betas[i], "beta_to": betas[i + 1], "D_lat": cos(gl[i], gl[i + 1]), "D_den": cos(gd[i], gd[i + 1])}
            for i in range(len(betas) - 1)]


def main():
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.colors import TwoSlopeNorm

    A, G = load()
    ladder = [tuple(l) for l in A["meta"]["ladder"]]
    nh = A["meta"]["n_harm"]
    xl = ["(%d,%d)\n%d" % (l[0], l[1], nh["%d-%d" % l]) for l in ladder]
    os.makedirs(FIG, exist_ok=True)
    summary = {"iso": {}, "drift": {}, "price_ladder_s": {}, "geoms": {}}
    walls = {l: [] for l in ladder}
    keys = [k for k in G if any(pk.startswith(k + "|") for pk in A["points"])]
    for key in keys:
        betas, cl, cd, E, Q, pts = grids(A, key)
        if not betas:
            continue
        g = G[key]
        for p in pts:
            for l, w in zip(ladder, p["wall_s"]):
                walls[l].append(w)
        summary["geoms"][key] = {"m": g["m"], "beta_own": g["beta_own"], "stage": g["stage"], "n_beta": len(betas),
                                 "binary_ladder": {k: v["eta"] for k, v in A["binary_ladder"].get(key, {}).get("ladder", {}).items()},
                                 "floor": {"%g" % p["beta"]: p["floor"] for p in pts if "floor" in p},
                                 "Q_ref_by_beta": {"%g" % b: float(Q[i, -1]) for i, b in enumerate(betas)}}
        # reference sanity: a (60,9) density gradient whose norm jumps against (48,7) or decorrelates from it
        summary["geoms"][key]["ref_check"] = [
            {"beta": p["beta"], "norm_ratio_ref_over_48_7": p["norm_den_sym"][-1] / max(p["norm_den_sym"][-2], 1e-300),
             "cos_den_48_7_vs_ref": p["cos_den"][-2][-1], "cos_lat_48_7_vs_ref": p["cos_lat"][-2][-1],
             "flag": ref_flag(p)}
            for p in pts]
        summary["iso"][key] = {"lat": {str(c): iso(betas, cl, ladder, c) for c in THRESH},
                               "den": {str(c): iso(betas, cd, ladder, c) for c in THRESH}}
        summary["drift"][key] = drift(A, key)
        # --- figure: three panels
        fig, axs = plt.subplots(1, 3, figsize=(15, 4.6), constrained_layout=True)
        for ax, M, title, kind in ((axs[0], cl, "cos(g_N, g_ref)  latent gradient", "seq"),
                                   (axs[1], cd, "cos(h_N, h_ref)  density gradient", "seq"),
                                   (axs[2], E, "Q_N - Q_ref  (projected density)", "div")):
            if kind == "seq":
                im = ax.imshow(M, origin="lower", aspect="auto", cmap="Blues", vmin=0.0, vmax=1.0)
            else:
                lim = max(1e-3, float(np.nanmax(np.abs(M))))
                im = ax.imshow(M, origin="lower", aspect="auto", cmap="RdBu_r", norm=TwoSlopeNorm(vcenter=0.0, vmin=-lim, vmax=lim))
            ax.set_xticks(range(len(ladder)))
            ax.set_xticklabels(xl, fontsize=7)
            ax.set_yticks(range(len(betas)))
            ax.set_yticklabels(["%g%s" % (b, "*" if ref_flag(p) else "") for b, p in zip(betas, pts)], fontsize=8)
            ax.set_xlabel("order (Nx,Ny) / harmonics")
            ax.set_ylabel("beta")
            ax.set_title(title, fontsize=10)
            # own-beta marker and the rule's descent / gate columns
            bo = g["beta_own"]
            yb = np.interp(np.log(bo), np.log(betas), range(len(betas)))
            ax.axhline(yb, color="0.25", lw=1, ls="--")
            for name, ls in (("descent", ":"), ("gate", "-.")):
                lv = tuple(g["orders"][name])
                if lv in ladder:
                    ax.axvline(ladder.index(lv), color="0.25", lw=1, ls=ls)
            if kind == "seq":
                for c in (0.9,):
                    ax.contour(M, levels=[c], colors=["0.1"], linewidths=1.0)
            fig.colorbar(im, ax=ax, shrink=0.85)
        fig.suptitle("%s  (target (%d,0), stage %d, beta_own %.0f; dashed: own beta; dotted/dash-dot: rule descent/gate; line: cos=0.9; beta*: cosines vs (48,7), reference contaminated)"
                     % (key, g["m"], g["stage"], g["beta_own"]), fontsize=10)
        fig.savefig(os.path.join(FIG, "s8_map_%s.png" % key), dpi=150)
        plt.close(fig)
    # --- averaged map over stage-95 geometries per m
    for m in (1, 3):
        ks = [k for k in keys if G[k]["m"] == m and G[k]["stage"] == 95]
        if not ks:
            continue
        stacks = [grids(A, k) for k in ks]
        nb = min(len(s[0]) for s in stacks)
        if nb == 0:
            continue
        betas = stacks[0][0][:nb]
        cl = np.mean([s[1][:nb] for s in stacks], axis=0)
        cd = np.mean([s[2][:nb] for s in stacks], axis=0)
        summary["iso"]["mean_m%d_st095" % m] = {"lat": {str(c): iso(betas, cl, ladder, c) for c in THRESH},
                                                "den": {str(c): iso(betas, cd, ladder, c) for c in THRESH}, "n_geoms": len(ks)}
    summary["price_ladder_s"] = {"%d-%d" % l: (float(np.median(w)) if w else None) for l, w in walls.items()}
    # --- drift figure
    fig, ax = plt.subplots(figsize=(6.5, 4))
    for key in keys:
        d = summary["drift"].get(key) or []
        if d:
            ax.plot([x["beta_to"] for x in d], [x["D_lat"] for x in d], marker="o", ms=4, lw=1.5, label=key)
    ax.set_xscale("log")
    ax.set_xlabel("beta (to; from = beta/2)")
    ax.set_ylabel("cos(g_ref(beta/2), g_ref(beta))  latent gradient")
    ax.set_ylim(0, 1.02)
    ax.grid(alpha=0.3)
    ax.legend(fontsize=7)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG, "s8_drift.png"), dpi=150)
    plt.close(fig)
    json.dump(summary, open(os.path.join(DATA, "s8_summary.json"), "w", encoding="utf-8"), indent=1)
    # --- console tables
    for key in keys:
        print("==", key, "m=%d stage %d beta_own %.0f" % (G[key]["m"], G[key]["stage"], G[key]["beta_own"]))
        betas, cl, cd, E, Q, pts = grids(A, key)
        print("beta   | Q_ref  | " + " ".join(("%d,%d" % l).rjust(6) for l in ladder) + "   <- cos_lat(N,ref)")
        for i, b in enumerate(betas):
            print("%6g | %.4f | " % (b, Q[i, -1]) + " ".join("%6.3f" % v for v in cl[i]))
        print("       |        | " + " ".join(("%d,%d" % l).rjust(6) for l in ladder) + "   <- E = Q_N - Q_ref")
        for i, b in enumerate(betas):
            print("%6g |        | " % b + " ".join("%+6.3f" % v for v in E[i]))
        flags = [r for r in summary["geoms"][key]["ref_check"] if r["flag"]]
        if flags:
            print("REF CHECK flags (norm ratio / cos_den 48,7-ref):", ["%g: %.2f / %.2f" % (r["beta"], r["norm_ratio_ref_over_48_7"], r["cos_den_48_7_vs_ref"]) for r in flags])
        for c in THRESH:
            row = summary["iso"][key]["lat"][str(c)]
            print("iso c=%.2f (lat, mono/first): " % c + " ".join("%g:%s/%s" % (r["beta"], ("%d,%d" % tuple(r["order_mono"])) if r["order_mono"] else "-",
                                                                           ("%d,%d" % tuple(r["order_first"])) if r["order_first"] else "-") for r in row))
    print("price ladder (median s):", {k: round(v, 1) for k, v in summary["price_ladder_s"].items() if v is not None})


if __name__ == "__main__":
    main()
