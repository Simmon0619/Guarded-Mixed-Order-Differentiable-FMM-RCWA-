"""S8 supplement -- does a broadened eigenvector backward remove the gradient
anomaly?  At the betas where the fine scan found a finite-but-wrong gradient
(m1_s00_st095, (28,4): beta 363.4 / 374.1, |g| x12 and orthogonal to its
neighbours) recompute the gradient with the solver's optional Lorentzian
backward (TORCWA-style, FMMAX-style scale-aware epsilon) at several epsilons,
and compare with the default backward and with the neighbouring betas.
Also records the layer's minimum eigenvalue gap (FAST_DIAGNOSTICS) per beta.

Descriptive.  CPU.
"""
import argparse
import json
import os
import sys
import time

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import s8_map as S                                                    # noqa: E402
C = S.C
from workbench.app import app_projected                               # noqa: E402
from trustworthy_fmm.solvers.vector_2d import solve_multilayer_vector_2d   # noqa: E402


def solve(dens, level, cfg, ctx, method, eps_rel, eps_abs):
    eps = (cfg.eps_background + (cfg.eps_feature - cfg.eps_background) * dens).to(ctx.dtype).to(ctx.device)
    return solve_multilayer_vector_2d([eps], [cfg.thickness_nm], cfg.wavelength_nm, cfg.lattice_nm,
                                      cfg.n_incident, cfg.n_output, tuple(level), theta_deg=0.0, phi_deg=0.0,
                                      incident_jones=cfg.incident_jones, eig_backward=method,
                                      eig_eps_relative=eps_rel, eig_eps_absolute=eps_abs)


def grad(lat, level, beta, cfg, ctx, method="default", eps_rel=1e-12, eps_abs=1e-24):
    x = lat.detach().clone().to(ctx.device).requires_grad_(True)
    dens = app_projected(x, float(beta), cfg, ctx.mode)
    dens.retain_grad()
    r = solve(dens, level, cfg, ctx, method, eps_rel, eps_abs)
    j = r.power_t[r.orders.index(tuple(ctx.target))]
    j.backward()
    diag = {}
    for k in ("min_eigen_gap", "modal_condition"):
        v = getattr(r, k, None)
        if v is None and hasattr(r, "diagnostics"):
            v = r.diagnostics.get(k)
        if v is not None:
            diag[k] = float(torch.as_tensor(v).detach().real)
    return float(j.detach()), x.grad.detach().double().cpu().flatten(), dens.grad.detach().double().cpu().flatten(), diag


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--geom", default="m1_s00_st095")
    ap.add_argument("--level", default="28,4")
    ap.add_argument("--betas", default="340,356,363.4,374.1,390")
    ap.add_argument("--eps", default="1e-10,1e-8,1e-6,1e-4")
    ap.add_argument("--device", default="cpu")
    ap.add_argument("--threads", type=int, default=2)
    a = ap.parse_args()
    C.setup_runtime()
    torch.set_num_threads(a.threads)
    S.assert_eig_cpu()
    G = json.load(open(os.path.join(S.DATA, "s8_geoms.json"), encoding="utf-8"))["geoms"][a.geom]
    cfg = C.make_cfg(5)
    od = {k: tuple(v) for k, v in G["orders"].items()}
    ctx = C.make_ctx(cfg, (G["m"], 0), od["descent"], od["gate"], a.device)
    lat = torch.from_numpy(np.load(os.path.join(S.DATA, G["latent"])))
    shape = tuple(lat.shape)
    level = tuple(int(x) for x in a.level.split(","))
    betas = [float(b) for b in a.betas.split(",")]
    epss = [float(e) for e in a.eps.split(",")]
    out = {"geom": a.geom, "level": list(level), "betas": betas, "eps_relative": epss, "rows": []}
    ref_dir = {}
    print("level", level, "betas", betas, flush=True)
    for b in betas:
        t0 = time.perf_counter()
        v, g, h, diag = grad(lat, level, b, cfg, ctx)
        hs, _ = S.sym_split(h, shape)
        ref_dir[b] = (g, hs)
        row = {"beta": b, "method": "default", "eps": None, "value": v, "norm_lat": float(g.norm()), "norm_den": float(hs.norm()),
               "diag": diag, "wall_s": time.perf_counter() - t0}
        out["rows"].append(row)
        print("beta %7.1f default        | value %.5f |g| %.3e |h| %.3e | %s | %.0f s" % (b, v, row["norm_lat"], row["norm_den"], diag, row["wall_s"]), flush=True)
    # the non-anomalous neighbour used as direction reference = the first beta in the list
    b0 = betas[0]
    for b in betas:
        g0, h0 = ref_dir[b0]
        gd, hd = ref_dir[b]
        print("beta %7.1f default  cos to beta %g: lat %.3f den %.3f" % (b, b0, S.cosine(gd, g0), S.cosine(hd, h0)), flush=True)
        for e in epss:
            t0 = time.perf_counter()
            v, g, h, diag = grad(lat, level, b, cfg, ctx, method="lorentzian_scaled", eps_rel=e, eps_abs=1e-24)
            hs, _ = S.sym_split(h, shape)
            row = {"beta": b, "method": "lorentzian_scaled", "eps": e, "value": v, "norm_lat": float(g.norm()), "norm_den": float(hs.norm()),
                   "cos_lat_to_default_same_beta": S.cosine(g, gd), "cos_den_to_default_same_beta": S.cosine(hs, hd),
                   "cos_lat_to_default_b0": S.cosine(g, g0), "cos_den_to_default_b0": S.cosine(hs, h0), "wall_s": time.perf_counter() - t0}
            out["rows"].append(row)
            print("beta %7.1f lorentz eps %g | |g| %.3e |h| %.3e | cos to default(same beta) lat %.3f den %.3f | cos to default(beta %g) lat %.3f den %.3f"
                  % (b, e, row["norm_lat"], row["norm_den"], row["cos_lat_to_default_same_beta"], row["cos_den_to_default_same_beta"], b0,
                     row["cos_lat_to_default_b0"], row["cos_den_to_default_b0"]), flush=True)
    C.save_json(os.path.join(S.DATA, "s8_eps_test_%s_%d-%d.json" % (a.geom, level[0], level[1])), out)


if __name__ == "__main__":
    main()
