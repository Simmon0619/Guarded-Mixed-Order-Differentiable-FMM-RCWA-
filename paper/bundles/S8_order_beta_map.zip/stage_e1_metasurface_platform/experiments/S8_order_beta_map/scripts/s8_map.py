"""S8 -- the (N, beta) map at fixed geometry.

Question (plan E2, 2026-09-15): for one geometry (a latent field taken from the
middle of a real ramp), how do the truncation order N and the projection
sharpness beta together set (i) the value the optimizer sees and (ii) the
direction of the gradient it follows?  Everything is measured on the projected
(continuous) density at that beta -- the object the descent differentiates --
not on the hard binary, so the beta axis carries only edge sharpness, not
optimization history.

For every (geometry, beta) point and every order N of the ladder, one forward +
backward at the target (m, 0) gives

    Q_N(beta)      value of the projected density at order N (= the descent
                   objective workbench.app.value_grad differentiates)
    g_N(beta)      gradient w.r.t. the LATENT   (what Adam sees)
    h_N(beta)      gradient w.r.t. the DENSITY  (the physics, before the
                   projection Jacobian re-weights the edge pixels; its
                   mirror-antisymmetric part never reaches the latent under
                   the 'y' symmetry, so cosines use the symmetrized part and
                   the antisymmetric fraction is recorded as a diagnostic)

and we store the full 10 x 10 cosine matrices cos(g_N, g_N') and cos(h_N, h_N'),
the norms, the per-order wall time and GPU peak, and ALL ten rungs' gradients
(float32 npz, ~4.8 MB per point) so any other similarity can be read off later
without re-solving.  The reference column is the top order (60,9) -- the
largest that fits the gradient envelope (2N <= 4850); the S6 ladder note says
the top rung is itself not converged for m=3/4 (next-rung steps +0.004..+0.016
on binaries), so E(N) = Q_N - Q_ref is relative to an upper-bound reference,
not to truth.  A numerical floor for the cosines is measured at the reference
rung for beta in FLOOR_BETAS: the (60,9) gradient recomputed at beta*(1+1e-6)
gives cos(g_ref, g_ref') -- anything closer to 1 than that is inside c64 noise.

Geometries: SINGLE descents (P2, order rule, README ramp 2 -> 2000 in 219
steps) stopped at step 54 (beta 11.0, where mixing starts), 95 (beta 40.0, the
cliff window) and 219 (final, saturated -- the control whose map should be flat
in beta).  Seeds are a fresh block (300000 + 1000 m + i).  Each geometry's own
beta is added to its beta list.  Per geometry the hard binary's ladder Q_N[b]
(forward only), the continuous value at its own beta, the filtered field's
near-threshold fraction and the latent's sha1 (provenance) are recorded once.

Descriptive: numbers, no claims.  GPU / complex64, eigendecomposition on CPU
(the leak fix).  A raised or non-finite gradient is retried on s6_common's
jitter ladder (beta*(1 +- 1e-6, 1e-5)), never inside an except handler; if all
fail the rung is recorded as NaN with its events and the sweep continues.

Usage:
  python s8_map.py --phase geoms                 # make + save the latents (~3 min)
  python s8_map.py --phase map [--geoms KEYS]    # the sweep, resumable
  python s8_map.py --phase all
"""
import argparse
import dataclasses
import gc
import hashlib
import importlib
import json
import math
import os
import sys
import time
from typing import Dict, List

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
_S6 = os.path.abspath(os.path.join(_HERE, "..", "..", "S6_lottery_pricing", "scripts"))
sys.path.insert(0, _S6)
import s6_common as C                                                      # noqa: E402
from workbench.app import app_projected, app_filtered, app_hard_binary, solve_density   # noqa: E402

DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
DESIGNS = os.path.join(DATA, "designs")
LOGS = os.path.join(DATA, "logs")

BETAS = [2.0, 4.0, 8.0, 16.0, 32.0, 64.0, 128.0, 256.0, 512.0, 1000.0, 2000.0]
FLOOR_BETAS = {32.0, 2000.0}        # where the reference-rung jitter floor is measured
LADDER = [(8, 1), (12, 2), (16, 2), (20, 3), (24, 3), (28, 4), (32, 5), (40, 6), (48, 7), (60, 9)]
REF = (60, 9)                       # 121 x 19 = 2299 harmonics -> 2N = 4598 <= 4850 (grad envelope)
STEPS, BETA_END = 219, 2000.0       # the README ramp O uses
STAGES = [54, 95, 219]              # beta 11.0 / 40.0 / 2000
SEED_BASE = 300000                  # fresh block: S5 <= 94723, S6 <= 174205, S7 150000-152011 + noise <= 260314
# (m, seed index, stage) in the order the map is filled: mid-ramp first so a partial run is already usable
GEOMS = [(1, 0, 95), (3, 0, 95), (1, 1, 95), (3, 1, 95), (1, 0, 54), (3, 0, 54), (1, 0, 219), (3, 0, 219)]
JITTERS = C.GRAD_JITTERS            # (1e-6, -1e-6, 1e-5, -1e-5)


def assert_eig_cpu():
    mod = importlib.import_module("trustworthy_fmm.solvers.eigendecomposition")
    assert getattr(mod, "EIG_DEVICE", None) == "cpu", "leak fix not active: EIG_DEVICE=%r" % getattr(mod, "EIG_DEVICE", None)
    return "cpu"


def geom_key(m, i, stage):
    return "m%d_s%02d_st%03d" % (m, i, stage)


def n_harm(level):
    return (2 * level[0] + 1) * (2 * level[1] + 1)


def sha1_latent(lat: torch.Tensor) -> str:
    return hashlib.sha1(lat.detach().cpu().numpy().astype(np.float64).tobytes()).hexdigest()


def _plain(v):
    if isinstance(v, (list, tuple)):
        return [_plain(x) for x in v]
    if isinstance(v, dict):
        return {str(k): _plain(x) for k, x in v.items()}
    if isinstance(v, (bool, int, float, str, type(None))):
        return v
    return str(v)


def env_meta(device):
    return {"torch": torch.__version__, "gpu": torch.cuda.get_device_name(0) if device == "cuda" else "cpu",
            "cfg": _plain(dataclasses.asdict(C.make_cfg(5)))}


def log(msg, fh=None):
    line = time.strftime("%H:%M:%S ") + msg
    print(line, flush=True)
    if fh:
        fh.write(line + "\n")
        fh.flush()


# ------------------------------------------------------------------ geometries
def make_geometries(device, fh):
    """One SINGLE descent per (m, seed), latents saved at every stage in STAGES.
    Existing entries are kept (a re-descent on GPU/c64 is not bitwise
    reproducible); only their provenance fields are filled in if missing."""
    os.makedirs(DESIGNS, exist_ok=True)
    path = os.path.join(DATA, "s8_geoms.json")
    G = json.load(open(path, encoding="utf-8")) if os.path.exists(path) else {"meta": {}, "geoms": {}}
    G["meta"] = {"kind": "geoms", "steps": STEPS, "beta_end": BETA_END, "ramp": "geometric 2 -> 2000",
                 "descent": "SINGLE at the rule's descent order, Adam lr 0.02 cosine (s6_common.GapDescent)",
                 "stages": STAGES, "seed_rule": "300000 + 1000 m + i", "eig_device": assert_eig_cpu(),
                 "latent_note": "run_to(st) returns the latent BEFORE update st, i.e. trained under beta(0..st-1); beta_own = beta(st)",
                 **env_meta(device)}
    cfg = C.make_cfg(5)
    # idempotent normalisation of entries already on disk
    for key, g in G["geoms"].items():
        g["latent"] = g["latent"].replace("\\", "/")
        if "sha1_latent" not in g:
            g["sha1_latent"] = sha1_latent(torch.from_numpy(np.load(os.path.join(DATA, g["latent"]))))
        g.setdefault("continuous_prev_step", g.pop("continuous_last", None))
    want = sorted({(m, i) for m, i, _ in GEOMS})
    for m, i in want:
        stages = sorted({st for mm, ii, st in GEOMS if (mm, ii) == (m, i)})
        if all(geom_key(m, i, st) in G["geoms"] for st in stages):
            continue
        od = C.orders_for(m, cfg)
        ctx = C.make_ctx(cfg, (m, 0), od["descent"], od["gate"], device)
        seed = SEED_BASE + 1000 * m + i
        events: List[Dict] = []
        d = C.GapDescent(ctx, seed, STEPS, C.beta_geometric(2.0, BETA_END), [], events, record_trajectory=True)
        t0 = time.perf_counter()
        for st in stages:
            d.run_to(st)
            lat = d.latent.detach().cpu().clone()
            b = app_hard_binary(lat, cfg, ctx.mode)
            eg = C.eta(b, od["gate"], ctx)
            ed = C.eta(b, od["descent"], ctx)
            key = geom_key(m, i, st)
            rel = "designs/" + key + "_latent.npy"
            np.save(os.path.join(DATA, rel), lat.numpy())
            beta_own = C.beta_geometric(2.0, BETA_END)(st, STEPS)
            G["geoms"][key] = {"m": m, "target": [m, 0], "seed": seed, "index": i, "stage": st, "beta_own": beta_own,
                               "orders": {k: list(v) for k, v in od.items()},
                               "latent": rel, "sha1_latent": sha1_latent(lat), "sha1_binary": C.sha1_of(b),
                               "eta_gate_binary": eg, "eta_descent_binary": ed, "gap_binary": ed - eg,
                               "continuous_prev_step": d.continuous_now(),
                               "trajectory": list(d.traj), "events": list(events),
                               "wall_s": time.perf_counter() - t0}
            log("geom %s | beta_own %.1f | gate %.4f descent-binary %.4f gap %+.4f | cont(prev step) %.4f | %.0f s"
                % (key, beta_own, eg, ed, ed - eg, d.continuous_now() or -1, time.perf_counter() - t0), fh)
    C.save_json(path, G)
    return G


# ------------------------------------------------------------------------ map
def value_grads(latent, level, beta, ctx):
    """One forward + backward at ``level``: value, latent gradient, density gradient (CPU float64, flat)."""
    x = latent.detach().clone().to(ctx.device).requires_grad_(True)
    dens = app_projected(x, float(beta), ctx.cfg, ctx.mode)
    dens.retain_grad()
    r = solve_density(dens, tuple(level), ctx.cfg, ctx.theta, ctx.phi, ctx.dtype, ctx.device)
    j = r.power_t[r.orders.index(tuple(ctx.target))]
    j.backward()
    v = float(j.detach())
    g = x.grad.detach().double().cpu().flatten()
    h = dens.grad.detach().double().cpu().flatten()
    del r, j, dens, x
    return v, g, h


def attempt(latent, level, beta, ctx):
    """value_grads that never raises: (result, None) or (None, detail)."""
    try:
        v, g, h = value_grads(latent, level, beta, ctx)
    except RuntimeError as exc:                     # OOM, _LinAlgError, linalg_eig_backward gauge check
        return None, str(exc)[:160]
    if math.isfinite(v) and bool(torch.isfinite(g).all()) and bool(torch.isfinite(h).all()):
        return (v, g, h), None
    del g, h
    return None, "non-finite"


def robust_grads(latent, level, beta, ctx, events, tag):
    """attempt() on beta, then on s6_common's jitter ladder; retries run OUTSIDE any
    except handler so the failed attempt's graph is released first.  Returns
    (v, g, h, beta_used); NaN-filled if every attempt fails."""
    res, detail = attempt(latent, level, beta, ctx)
    b_used = float(beta)
    if res is None:
        for j in JITTERS:
            events.append({"level": list(level), "beta": beta, "tag": tag, "detail": detail, "jitter_next": j})
            gc.collect()
            if ctx.device == "cuda":
                torch.cuda.empty_cache()
            b_used = float(beta) * (1.0 + j)
            res, detail = attempt(latent, level, b_used, ctx)
            if res is not None:
                break
    if res is None:
        events.append({"level": list(level), "beta": beta, "tag": tag, "detail": "all attempts failed: " + str(detail)})
        n = latent.numel()
        nan = torch.full((n,), float("nan"), dtype=torch.float64)
        return float("nan"), nan, nan.clone(), float("nan")
    v, g, h = res
    return v, g, h, b_used


def sym_split(h_flat, shape):
    """Mirror-symmetric part of a density gradient under mode 'y' (flip along axis 0)
    and the antisymmetric fraction ||h - h_flip|| / ||h + h_flip||."""
    H = h_flat.reshape(shape)
    Hs = 0.5 * (H + H.flip(0))
    Ha = 0.5 * (H - H.flip(0))
    frac = float(Ha.norm() / Hs.norm().clamp_min(1e-300))
    return Hs.flatten(), frac


def cos_matrix(vs: List[torch.Tensor]):
    M = torch.stack(vs)
    n = M.norm(dim=1, keepdim=True).clamp_min(1e-300)
    Mn = M / n
    return (Mn @ Mn.T).numpy(), n.flatten().numpy()


def cosine(a, b):
    return float(a @ b / (a.norm() * b.norm()).clamp_min(1e-300))


def run_map(device, fh, only=None):
    path = os.path.join(DATA, "s8_map.json")
    G = json.load(open(os.path.join(DATA, "s8_geoms.json"), encoding="utf-8"))["geoms"]
    A = json.load(open(path, encoding="utf-8")) if os.path.exists(path) else {"meta": {}, "binary_ladder": {}, "points": {}}
    A["meta"] = {"kind": "map", "betas": BETAS, "floor_betas": sorted(FLOOR_BETAS), "ladder": [list(l) for l in LADDER], "ref": list(REF),
                 "n_harm": {"%d-%d" % l: n_harm(l) for l in LADDER},
                 "value": "eta at target (m,0) of the projected continuous density tanh_projection(app_filtered(latent), beta) "
                          "at order N = the descent objective (workbench.app.value_grad); binary_ladder is the same at the hard binary",
                 "gradients": "g = d eta / d latent (Adam's), h = d eta / d density (projected, at beta); cos_den uses the "
                              "mirror-symmetric part of h (mode 'y'); h_asym_frac = ||h_a|| / ||h_s||",
                 "cos": "cos_lat[i][j] = cos(g_Ni, g_Nj); cos_den likewise; row/col order = ladder",
                 "floor": "at the reference rung and beta in floor_betas: cos(g_ref(beta), g_ref(beta*(1+1e-6))) -- the c64 noise floor",
                 "grads_npz": "g_lat / h_den: (10, n_pixels) float32, row order = ladder; h_den is the raw (unsymmetrized) density gradient",
                 "eig_device": assert_eig_cpu(), "dtype": "complex64 on " + device,
                 "ref_note": "top rung not converged for m=3/4 on binaries (S6 note: next-rung +0.004..+0.016); E(N) is relative to (60,9)",
                 **env_meta(device)}
    cfg = C.make_cfg(5)
    keys = [geom_key(*g) for g in GEOMS]
    if only:
        unknown = set(only) - set(keys)
        if unknown:
            raise SystemExit("unknown geometry keys: %s" % sorted(unknown))
        keys = [k for k in keys if k in only]
    for key in keys:
        if key not in G:
            log("WARNING geometry %s not in s8_geoms.json -- skipped" % key, fh)
            continue
        g = G[key]
        m = g["m"]
        od = {k: tuple(v) for k, v in g["orders"].items()}
        ctx = C.make_ctx(cfg, (m, 0), od["descent"], od["gate"], device)
        lat = torch.from_numpy(np.load(os.path.join(DATA, g["latent"].replace("\\", "/"))))
        sha = sha1_latent(lat)
        if g.get("sha1_latent") and g["sha1_latent"] != sha:
            raise SystemExit("latent provenance mismatch for %s: geoms %s vs file %s" % (key, g["sha1_latent"], sha))
        shape = tuple(lat.shape)
        i_ref = LADDER.index(REF)
        # --- once per geometry: the hard binary's ladder, own-beta continuous value, filtered near-threshold fraction
        if key not in A["binary_ladder"]:
            b = app_hard_binary(lat, cfg, ctx.mode)
            row = {"sha1_latent": sha, "sha1_binary": C.sha1_of(b), "ladder": {}}
            for lv in LADDER:
                t0 = time.perf_counter()
                row["ladder"]["%d-%d" % lv] = {"eta": C.eta(b, lv, ctx), "wall_s": time.perf_counter() - t0}
            with torch.no_grad():
                filt = app_filtered(lat, cfg, ctx.mode)
                row["frac_filtered_within_0p1"] = float(((filt - cfg.threshold).abs() < 0.1).double().mean())
                row["frac_latent_within_0p1"] = float(((lat - 0.5).abs() < 0.1).double().mean())
                dens_own = app_projected(lat.to(device), float(g["beta_own"]), cfg, ctx.mode)
                row["continuous_at_own_beta_descent"] = C.eta(dens_own, od["descent"], ctx)
                row["continuous_at_own_beta_gate"] = C.eta(dens_own, od["gate"], ctx)
                del dens_own
            A["binary_ladder"][key] = row
            C.save_json(path, A)
            log("binary ladder %s: " % key + " ".join("%s=%.3f" % (k, v["eta"]) for k, v in row["ladder"].items())
                + " | cont@own(desc/gate) %.3f/%.3f | filt<0.1 %.3f" % (row["continuous_at_own_beta_descent"],
                                                                        row["continuous_at_own_beta_gate"], row["frac_filtered_within_0p1"]), fh)
        # --- the sweep (grid betas plus the geometry's own beta)
        for beta in sorted(set(BETAS) | {float(g["beta_own"])}):
            pk = "%s|b%g" % (key, beta)
            if pk in A["points"]:
                continue
            vals, gs, hs, hsym, asym, walls, mems, b_useds, events = [], [], [], [], [], [], [], [], []
            t_pt = time.perf_counter()
            for lv in LADDER:
                gc.collect()
                if device == "cuda":
                    torch.cuda.empty_cache()
                    torch.cuda.reset_peak_memory_stats()
                t0 = time.perf_counter()
                v, gg, hh, b_used = robust_grads(lat, lv, beta, ctx, events, "rung")
                if device == "cuda":
                    torch.cuda.synchronize()
                walls.append(time.perf_counter() - t0)
                mems.append(torch.cuda.max_memory_allocated() / 1e9 if device == "cuda" else None)
                hs_, fr = sym_split(hh, shape)
                vals.append(v)
                gs.append(gg)
                hs.append(hh)
                hsym.append(hs_)
                asym.append(fr)
                b_useds.append(b_used)
            cos_lat, norm_lat = cos_matrix(gs)
            cos_den, norm_den = cos_matrix(hsym)
            rec = {"geom": key, "m": m, "stage": g["stage"], "seed": g["seed"], "orders": g["orders"],
                   "i_desc": LADDER.index(od["descent"]), "i_gate": LADDER.index(od["gate"]), "i_ref": i_ref,
                   "beta": beta, "beta_own": g["beta_own"], "is_own_beta": abs(beta - g["beta_own"]) < 1e-9,
                   "ladder": [list(l) for l in LADDER], "beta_used": b_useds,
                   "value": vals, "value_minus_ref": [v - vals[i_ref] for v in vals],
                   "norm_lat": norm_lat.tolist(), "norm_den_sym": norm_den.tolist(), "h_asym_frac": asym,
                   "cos_lat": cos_lat.tolist(), "cos_den": cos_den.tolist(),
                   "cos_lat_ref": cos_lat[:, i_ref].tolist(), "cos_den_ref": cos_den[:, i_ref].tolist(),
                   "wall_s": walls, "gpu_peak_gb": mems, "events": events, "point_wall_s": time.perf_counter() - t_pt}
            # --- the c64 noise floor at the reference rung
            if beta in FLOOR_BETAS and math.isfinite(vals[i_ref]):
                gc.collect()
                if device == "cuda":
                    torch.cuda.empty_cache()
                t0 = time.perf_counter()
                v2, g2, h2, b2 = robust_grads(lat, REF, float(beta) * (1.0 + 1e-6), ctx, events, "floor")
                if math.isfinite(v2):
                    h2s, _ = sym_split(h2, shape)
                    rec["floor"] = {"beta_used": b2, "value": v2, "value_diff": v2 - vals[i_ref],
                                    "cos_lat": cosine(gs[i_ref], g2), "cos_den": cosine(hsym[i_ref], h2s),
                                    "wall_s": time.perf_counter() - t0}
                del g2, h2
            # --- all rungs' gradients, float32
            os.makedirs(DESIGNS, exist_ok=True)
            relg = "designs/s8_grads_%s_b%g.npz" % (key, beta)
            np.savez_compressed(os.path.join(DATA, relg), ladder=np.array(LADDER, dtype=np.int16),
                                beta_used=np.array(b_useds, dtype=np.float64),
                                g_lat=torch.stack(gs).numpy().astype(np.float32),
                                h_den=torch.stack(hs).numpy().astype(np.float32))
            rec["grads"] = relg
            A["points"][pk] = rec
            C.save_json(path, A)
            log("%-14s beta %7g%s | Q_ref %.4f | E(desc) %+.4f E(gate) %+.4f | cos_lat(desc,ref) %.3f (gate,ref) %.3f | "
                "cos_den(desc,ref) %.3f | asym %.0e | %.0f s | peak %.1f GB%s%s"
                % (key, beta, "*" if rec["is_own_beta"] else " ", vals[i_ref], rec["value_minus_ref"][rec["i_desc"]],
                   rec["value_minus_ref"][rec["i_gate"]], cos_lat[rec["i_desc"], i_ref], cos_lat[rec["i_gate"], i_ref],
                   cos_den[rec["i_desc"], i_ref], max(asym), rec["point_wall_s"], max(x for x in mems if x is not None) if device == "cuda" else 0,
                   " | floor %.5f/%.5f" % (rec["floor"]["cos_lat"], rec["floor"]["cos_den"]) if "floor" in rec else "",
                   "  EVENTS %d" % len(events) if events else ""), fh)
            del gs, hs, hsym
            gc.collect()
    return A


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--phase", default="all", choices=["all", "geoms", "map"])
    ap.add_argument("--geoms", default="", help="comma-separated geometry keys to restrict the map to")
    a = ap.parse_args()
    os.makedirs(LOGS, exist_ok=True)
    device = C.setup_runtime()
    assert_eig_cpu()
    fh = open(os.path.join(LOGS, "s8_map.log"), "a", encoding="utf-8")
    log("S8 start | phase %s | device %s | %s" % (a.phase, device, torch.cuda.get_device_name(0) if device == "cuda" else "cpu"), fh)
    t0 = time.perf_counter()
    try:
        if a.phase in ("all", "geoms"):
            make_geometries(device, fh)
        if a.phase in ("all", "map"):
            only = {k.strip() for k in a.geoms.split(",") if k.strip()}
            run_map(device, fh, only=only or None)
    except BaseException as exc:
        log("S8 ABORTED: %s: %s" % (type(exc).__name__, str(exc)[:300]), fh)
        raise
    log("S8 done in %s" % C.fmt_s(time.perf_counter() - t0), fh)


if __name__ == "__main__":
    main()
