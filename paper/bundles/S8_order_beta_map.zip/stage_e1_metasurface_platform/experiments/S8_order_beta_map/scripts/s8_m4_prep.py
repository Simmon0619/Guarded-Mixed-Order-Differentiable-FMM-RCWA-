"""S8 supplement for E3 v2 -- the (N, beta) map for two m=4 stage-95 geometries.

Same machinery as s8_map.py (module constants re-bound), separate data folder
``data_m4`` because the ladder differs: it carries the m=4 rule's orders
(28,4) / (44,6) / (52,7) explicitly.  Reference stays (60,9) (the gradient
envelope 2N <= 4850 excludes (64,9)).
"""
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import s8_map as S                                                    # noqa: E402

S.DATA = os.path.abspath(os.path.join(_HERE, "..", "data_m4"))
S.DESIGNS = os.path.join(S.DATA, "designs")
S.LOGS = os.path.join(S.DATA, "logs")
S.LADDER = [(16, 2), (20, 3), (24, 3), (28, 4), (32, 5), (36, 5), (40, 6), (44, 6), (52, 7), (60, 9)]
S.REF = (60, 9)
S.GEOMS = [(4, 0, 95), (4, 1, 95)]
S.STAGES = [95]
S.FLOOR_BETAS = {32.0, 2000.0}


def main():
    import time
    import torch
    os.makedirs(S.LOGS, exist_ok=True)
    device = S.C.setup_runtime()
    S.assert_eig_cpu()
    fh = open(os.path.join(S.LOGS, "s8_m4_map.log"), "a", encoding="utf-8")
    S.log("S8 m=4 prep start | device %s | ladder %s" % (device, S.LADDER), fh)
    t0 = time.perf_counter()
    S.make_geometries(device, fh)
    S.run_map(device, fh)
    S.log("S8 m=4 prep done in %s" % S.C.fmt_s(time.perf_counter() - t0), fh)


if __name__ == "__main__":
    main()
