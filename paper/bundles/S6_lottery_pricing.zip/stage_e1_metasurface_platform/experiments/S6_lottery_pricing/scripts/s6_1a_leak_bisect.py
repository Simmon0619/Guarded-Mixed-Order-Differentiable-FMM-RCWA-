"""S6-1a  Where does the host memory go?  Reproduce and bisect the growth seen
in S5-8c (~15 MB per (32,8) gradient step, ~12 GB per 800-step unit).

Each case runs the same operation N times on the CURRENT paper problem
(2400x700 nm, 10 nm grid, target (3,0)) and records the process RSS after every
iteration; the slope (MB / iteration) is the number that matters.

  eig_cuda        torch.linalg.eig on a CUDA complex64 (2N x 2N) matrix, 2N = 2210
                  -- the forward eigendecomposition exactly as the solver calls it
  eig_cuda_gc     same, plus gc.collect() + torch.cuda.empty_cache() each time
  eig_cpu         the same matrix decomposed on the CPU (LAPACK, no MAGMA)
  fwd_gate_32_8   one full forward solve at (32,8) (gate_eval), no autograd
  vg_32_8_ME      value_grad at (32,8), MEMORY_EFFICIENT on (the S5 setting)
  vg_32_8_noME    value_grad at (32,8), MEMORY_EFFICIENT off
  vg_20_5_ME      value_grad at (20,5) for the size scaling of the slope

    python s6_1a_leak_bisect.py [--n 30] [--cases eig_cuda,eig_cpu,...]
"""
import argparse
import gc
import json
import os
import sys
import time

import numpy as np
import psutil
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
_WB = os.path.abspath(os.path.join(_HERE, "..", "..", "..", "fmm_workbench"))
sys.path.insert(0, _WB)
from workbench.protocol import DEFAULT, n_terms                    # noqa: E402
from workbench.app import (                                        # noqa: E402
    value_grad, app_initial_latent, app_hard_binary, gate_eval,
)
import trustworthy_fmm.solvers.vector_2d as _v2d                   # noqa: E402
import trustworthy_fmm.fourier.convolution as _conv                # noqa: E402

DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
CASES = ("eig_cuda", "eig_cuda_gc", "eig_cpu", "fwd_gate_32_8",
         "vg_32_8_ME", "vg_32_8_noME", "vg_20_5_ME")


def rss_mb():
    return psutil.Process().memory_info().rss / 2 ** 20


def run_case(name, fn, n):
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.synchronize()
    fn(-1)                                   # warm-up, excluded
    gc.collect()
    r0 = rss_mb()
    rs, t0 = [], time.perf_counter()
    for i in range(n):
        fn(i)
        if torch.cuda.is_available():
            torch.cuda.synchronize()
        rs.append(rss_mb())
    dt = (time.perf_counter() - t0) / n
    slope = float(np.polyfit(np.arange(n), rs, 1)[0]) if n > 1 else 0.0
    row = {"case": name, "n": n, "rss_start_mb": r0, "rss_end_mb": rs[-1],
           "slope_mb_per_iter": slope, "s_per_iter": dt, "rss_trace_mb": rs,
           "cuda_alloc_end_mb": (torch.cuda.memory_allocated() / 2 ** 20
                                 if torch.cuda.is_available() else None)}
    print("  %-14s n=%2d  rss %6.0f -> %6.0f MB  slope %+7.1f MB/iter  %.2f s/iter"
          % (name, n, r0, rs[-1], slope, dt), flush=True)
    return row


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--n", type=int, default=30)
    ap.add_argument("--cases", type=str, default=",".join(CASES))
    args = ap.parse_args()
    torch.set_num_threads(int(os.environ.get("FMM_THREADS", "3")))
    _conv.VECTORIZED_CONV = True
    _v2d.FAST_DIAGNOSTICS = True
    _v2d.MEMORY_EFFICIENT = True
    device = "cuda" if torch.cuda.is_available() else "cpu"
    dtype = torch.complex64
    cfg = DEFAULT.variant(ny=70, nx=240)
    mode, target = "y", (3, 0)
    latent = app_initial_latent(53003, cfg, mode, device)
    binary = app_hard_binary(latent.detach().cpu(), cfg, mode)
    ctx = type("C", (), {})()
    ctx.cfg, ctx.mode, ctx.theta, ctx.phi = cfg, mode, 0.0, 0.0
    ctx.target, ctx.dtype, ctx.device, ctx.offload = target, dtype, device, False
    two_n = 2 * n_terms((32, 8))
    g = torch.Generator(device="cpu").manual_seed(0)
    M = (torch.randn(two_n, two_n, generator=g) + 1j * torch.randn(two_n, two_n, generator=g)).to(dtype)
    M_cuda = M.to(device)
    M_cpu = M.clone()

    def eig_cuda(i):
        w, v = torch.linalg.eig(M_cuda)
        del w, v

    def eig_cuda_gc(i):
        w, v = torch.linalg.eig(M_cuda)
        del w, v
        gc.collect()
        torch.cuda.empty_cache()

    def eig_cpu(i):
        w, v = torch.linalg.eig(M_cpu)
        del w, v

    def fwd_gate(i):
        gate_eval(binary, (32, 8), ctx)

    def vg(level, me):
        def f(i):
            old = _v2d.MEMORY_EFFICIENT
            _v2d.MEMORY_EFFICIENT = me
            try:
                v, gr = value_grad(latent, level, target, 64.0, cfg, mode, 0.0, 0.0,
                                   dtype, device, False)
                del gr
            finally:
                _v2d.MEMORY_EFFICIENT = old
        return f

    table = {"eig_cuda": eig_cuda, "eig_cuda_gc": eig_cuda_gc, "eig_cpu": eig_cpu,
             "fwd_gate_32_8": fwd_gate, "vg_32_8_ME": vg((32, 8), True),
             "vg_32_8_noME": vg((32, 8), False), "vg_20_5_ME": vg((20, 5), True)}
    want = [c.strip() for c in args.cases.split(",") if c.strip()]
    print("=" * 74)
    print("s6_1a_leak_bisect | %s | torch %s | 2N(32,8)=%d | n=%d"
          % (torch.cuda.get_device_name(0) if device == "cuda" else "cpu",
             torch.__version__, two_n, args.n), flush=True)
    out = {"meta": {"torch": torch.__version__, "cuda": torch.version.cuda,
                    "gpu": torch.cuda.get_device_name(0) if device == "cuda" else "cpu",
                    "two_n_32_8": two_n, "n": args.n,
                    "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())},
           "cases": []}
    for c in want:
        out["cases"].append(run_case(c, table[c], args.n))
        os.makedirs(DATA, exist_ok=True)
        with open(os.path.join(DATA, "s6_1a_leak_bisect.json"), "w", encoding="utf-8") as f:
            json.dump(out, f, indent=1)
    print("=" * 74)
    print("wrote data/s6_1a_leak_bisect.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
