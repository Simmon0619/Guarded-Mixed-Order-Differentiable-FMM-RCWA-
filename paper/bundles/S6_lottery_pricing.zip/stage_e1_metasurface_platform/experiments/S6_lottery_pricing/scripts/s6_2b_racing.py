"""S6-2b  Racing (successive halving of tickets) against plain restarts at equal
budget, on the second problem (plan 16 v2 Sec. 4; parameters from pre-study 0b).

One budget unit:
  racing   K = 4 tickets started from 4 seeds.  At f0 = 0.30 any ticket whose
           continuous value is below 0.1 is killed (collapse).  At f1 = 0.50 the
           survivors are ranked by their gate reading and the top 2 continue; at
           f2 = 0.75 the top 1 continues to the end.  Delivery = the best gate
           checkpoint over everything the arm paid for, certified at the first
           rung.  Cost = the measured descent + gate wall of all four.
  plain    full tickets from the SAME first seeds, run one after another; two
           deliveries are recorded: plain2 (the first two tickets, inside the
           racing arm's nominal 2.75-ticket cost) and plain3 (three tickets, the
           ceiling of that cost).  Each ticket delivers its best gate checkpoint;
           the arm delivers the best by gate, certified at the first rung.

Tickets are the README schedule (219 steps, B = 2 -> 2000) with the sparse-early /
dense-late checkpoints plus checkpoints at f0, f1, f2.  Descriptive.

    python s6_2b_racing.py --targets 1,2 --n 48
    python s6_2b_racing.py --dry-run
"""
import argparse
import json
import os
import sys
import time

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import s6_common as C                                              # noqa: E402

SEED_BASE = 130000
STEPS = 219
BETA_END = 2000.0
K, F0, F1, F2, KEEP1, KEEP2 = 4, 0.30, 0.50, 0.75, 2, 1
COLLAPSE_LEVEL = 0.1
N_TOP = 5
DRY = {"steps": 12, "n": 1}


def run_unit(ctx, od, seeds, steps, args_dry=False):
    beta_fn = C.beta_geometric(2.0, BETA_END)
    s0, s1, s2 = int(round(F0 * steps)), int(round(F1 * steps)), int(round(F2 * steps))
    ck = sorted(set(C.ckpt_schedule(steps)) | {s0, s1, s2})
    events = {s: [] for s in seeds}
    t_unit = time.perf_counter()
    # ---- racing arm ----------------------------------------------------------
    D = {s: C.Descent(ctx, s, steps, beta_fn, ck, events[s], beta_final=BETA_END) for s in seeds}
    log = {s: {"seed": s, "killed_at": None, "reason": None} for s in seeds}
    alive = list(seeds)
    for s in alive:
        D[s].run_to(s0)
    still = []
    for s in alive:
        c = D[s].continuous_now()
        if c is not None and c < COLLAPSE_LEVEL:
            log[s].update({"killed_at": s0, "reason": "collapse", "continuous_at_f0": c})
        else:
            log[s]["continuous_at_f0"] = c
            still.append(s)
    alive = still
    for s in alive:
        D[s].run_to(s1)
    ranked = sorted(alive, key=lambda s: -D[s].gate_now())
    for s in ranked[KEEP1:]:
        log[s].update({"killed_at": s1, "reason": "rank@f1", "gate_at_f1": D[s].gate_now()})
    for s in ranked[:KEEP1]:
        log[s]["gate_at_f1"] = D[s].gate_now()
    alive = ranked[:KEEP1]
    for s in alive:
        D[s].run_to(s2)
    ranked = sorted(alive, key=lambda s: -D[s].gate_now())
    for s in ranked[KEEP2:]:
        log[s].update({"killed_at": s2, "reason": "rank@f2", "gate_at_f2": D[s].gate_now()})
    for s in ranked[:KEEP2]:
        log[s]["gate_at_f2"] = D[s].gate_now()
    alive = ranked[:KEEP2]
    fin = {s: D[s].finish() for s in alive}
    # delivery: best gate checkpoint over all four descents (everything paid for)
    best_seed = max(seeds, key=lambda s: D[s].best["eta_gate"])
    bd = D[best_seed].best
    e1 = C.eta(bd["binary"], od["rung1"], ctx)
    racing = {
        "tickets": [{**log[s], "steps_run": D[s].t, "best_gate": D[s].best["eta_gate"], "best_step": D[s].best["step"],
                     "wall_descent_s": D[s].t_desc, "wall_gate_s": D[s].t_gate, "n_ckpt": len(D[s].ckpts),
                     "checkpoints": D[s].ckpts, "grad_events": events[s],
                     "final_reported": fin[s]["reported_continuous"] if s in fin else None,
                     "collapse_step": fin[s]["collapse_step"] if s in fin else None} for s in seeds],
        "winner_seed": alive[0] if alive else None, "delivery_seed": best_seed,
        "delivery_step": bd["step"], "delivery_gate": bd["eta_gate"], "delivery_rung1": e1,
        "delivery_binary": bd["binary"],
        "wall_descent_s": sum(D[s].t_desc for s in seeds), "wall_gate_s": sum(D[s].t_gate for s in seeds),
    }
    racing["opt_wall_s"] = racing["wall_descent_s"] + racing["wall_gate_s"]
    racing["cost_tickets_nominal"] = sum(D[s].t for s in seeds) / steps
    # ---- plain arm: three full tickets from the same first three seeds ----------------
    plain_t = []
    for s in seeds[:3]:
        ev = []
        r = C.ticket(ctx, s, steps, beta_fn, C.ckpt_schedule(steps), ev, beta_final=BETA_END)
        e1p = C.eta(r["best"]["binary"], od["rung1"], ctx)
        plain_t.append({"seed": s, "best_gate": r["best"]["eta_gate"], "best_step": r["best"]["step"],
                        "best_rung1": e1p, "final_gate": r["final"]["eta_gate"],
                        "reported": r["reported_continuous"], "collapse_step": r["collapse_step"],
                        "wall_descent_s": r["wall_descent_s"], "wall_gate_s": r["wall_gate_s"],
                        "opt_wall_s": r["wall_descent_s"] + r["wall_gate_s"], "grad_events": ev,
                        "_binary": r["best"]["binary"]})
    def pick(ts):
        b = max(ts, key=lambda t: t["best_gate"])
        return {"seed": b["seed"], "gate": b["best_gate"], "rung1": b["best_rung1"], "_binary": b["_binary"],
                "opt_wall_s": sum(t["opt_wall_s"] for t in ts)}
    plain = {"tickets": plain_t, "plain2": pick(plain_t[:2]), "plain3": pick(plain_t)}
    return racing, plain, time.perf_counter() - t_unit


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--targets", type=str, default="1,2")
    ap.add_argument("--n", type=int, default=48)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--out", type=str, default=None)
    args = ap.parse_args()
    device = C.setup_runtime()
    targets = [int(t) for t in args.targets.split(",") if t.strip()]
    n = DRY["n"] if args.dry_run else args.n
    steps = DRY["steps"] if args.dry_run else STEPS
    out = args.out or os.path.join(C.DATA, "s6_2b_racing%s.json" % ("_dry" if args.dry_run else ""))
    store = {"meta": {}, "units": {}, "top_reads": {}, "summary": {}}
    if args.resume and os.path.exists(out):
        store = json.load(open(out, encoding="utf-8"))
        print("resuming: %d units" % len(store["units"]), flush=True)
    cfg = C.make_cfg(5)
    store["meta"].update({
        "script": os.path.basename(__file__), "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "gpu": torch.cuda.get_device_name(0) if device == "cuda" else "cpu",
        "steps": steps, "beta": "2 -> %g geometric" % BETA_END, "K": K, "f0_f1_f2": [F0, F1, F2],
        "keep": [KEEP1, KEEP2], "collapse_level": COLLAPSE_LEVEL, "seed_rule": "%d + 1000*m + 10*unit + j" % SEED_BASE,
        "orders": {str(m): {k: list(v) for k, v in C.orders_for(m, cfg).items()} for m in targets},
        "reading_notes": [
            "racing delivers the best gate checkpoint over all K descents (killed ones included -- their "
            "checkpoints were paid for); plain2/plain3 deliver the best-by-gate ticket of the first 2 / 3 full "
            "tickets from the same seeds.  All deliveries certified at the first rung; the top rung is read for "
            "the best %d per arm and target." % N_TOP,
            "Equal budget by measured wall: racing's opt_wall_s (descent+gate of all four) beside plain2's and "
            "plain3's; nominal racing cost is 2.75 tickets when nothing is killed at f0.",
        ],
    })
    C.save_json(out, store)
    t_start = time.perf_counter()
    print("=" * 78)
    print("s6_2b_racing | %s | targets %s | n=%d | K=%d f=%s keep=%s" % (store["meta"]["gpu"], targets, n, K,
          store["meta"]["f0_f1_f2"], store["meta"]["keep"]), flush=True)
    for m in targets:
        od = C.orders_for(m, cfg)
        ctx = C.make_ctx(cfg, (m, 0), od["descent"], od["gate"], device)
        for u in range(n):
            key = "m%d|u%02d" % (m, u)
            if key in store["units"]:
                continue
            seeds = [SEED_BASE + 1000 * m + 10 * u + j for j in range(K)]
            racing, plain, wall = run_unit(ctx, od, seeds, steps)
            tag = "s6_2b_m%d_u%02d" % (m, u)
            rf = C.save_mask(tag + "_racing", racing.pop("delivery_binary"))
            p2 = C.save_mask(tag + "_plain2", plain["plain2"].pop("_binary"))
            p3 = C.save_mask(tag + "_plain3", plain["plain3"].pop("_binary"))
            for t in plain["tickets"]:
                t.pop("_binary", None)
            racing["files"], plain["plain2"]["files"], plain["plain3"]["files"] = rf, p2, p3
            store["units"][key] = {"target": [m, 0], "unit": u, "seeds": seeds, "steps": steps,
                                   "descent": list(od["descent"]), "gate": list(od["gate"]), "rung1": list(od["rung1"]),
                                   "racing": racing, "plain": plain,
                                   "racing_minus_plain2": racing["delivery_rung1"] - plain["plain2"]["rung1"],
                                   "racing_minus_plain3": racing["delivery_rung1"] - plain["plain3"]["rung1"],
                                   "unit_wall_s": wall}
            C.save_json(out, store)
            print("  m=%d u%02d | racing r1 %.4f (seed %d, cost %.2f tk, %s; killed %s) | plain2 %.4f plain3 %.4f (%s / %s) | d2 %+.4f d3 %+.4f  [%s]"
                  % (m, u, racing["delivery_rung1"], racing["delivery_seed"], racing["cost_tickets_nominal"],
                     C.fmt_s(racing["opt_wall_s"]), [t["reason"] for t in racing["tickets"] if t["killed_at"] is not None],
                     plain["plain2"]["rung1"], plain["plain3"]["rung1"], C.fmt_s(plain["plain2"]["opt_wall_s"]),
                     C.fmt_s(plain["plain3"]["opt_wall_s"]), racing["delivery_rung1"] - plain["plain2"]["rung1"],
                     racing["delivery_rung1"] - plain["plain3"]["rung1"], C.fmt_s(time.perf_counter() - t_start)), flush=True)
        # top-rung reads for the best 5 deliveries per arm
        for arm in ("racing", "plain2", "plain3"):
            def val(v):
                return v["racing"]["delivery_rung1"] if arm == "racing" else v["plain"][arm]["rung1"]
            def files(v):
                return v["racing"]["files"] if arm == "racing" else v["plain"][arm]["files"]
            rows = sorted([(val(v), k) for k, v in store["units"].items() if v["target"][0] == m], reverse=True)[:N_TOP]
            for r1, k in rows:
                tk = "%s|%s" % (k, arm)
                if tk in store["top_reads"]:
                    continue
                b = C.load_mask(files(store["units"][k])["binary"])
                et = C.eta(b, od["top"], ctx)
                store["top_reads"][tk] = {"arm": arm, "eta_top": et, "eta_rung1": r1, "rung1_minus_top": r1 - et}
        rs = [v for v in store["units"].values() if v["target"][0] == m]
        if rs:
            d2 = [v["racing_minus_plain2"] for v in rs]
            d3 = [v["racing_minus_plain3"] for v in rs]
            s = {"n": len(rs), "racing_rung1": C.q([v["racing"]["delivery_rung1"] for v in rs]),
                 "plain2_rung1": C.q([v["plain"]["plain2"]["rung1"] for v in rs]),
                 "plain3_rung1": C.q([v["plain"]["plain3"]["rung1"] for v in rs]),
                 "racing_minus_plain2": {**C.q(d2), "n_pos": int(sum(x > 0 for x in d2)), "n_neg": int(sum(x < 0 for x in d2))},
                 "racing_minus_plain3": {**C.q(d3), "n_pos": int(sum(x > 0 for x in d3)), "n_neg": int(sum(x < 0 for x in d3))},
                 "racing_wall_s": C.q([v["racing"]["opt_wall_s"] for v in rs]),
                 "plain2_wall_s": C.q([v["plain"]["plain2"]["opt_wall_s"] for v in rs]),
                 "plain3_wall_s": C.q([v["plain"]["plain3"]["opt_wall_s"] for v in rs]),
                 "racing_cost_tickets": C.q([v["racing"]["cost_tickets_nominal"] for v in rs]),
                 "kills_at_f0": int(sum(sum(1 for t in v["racing"]["tickets"] if t["reason"] == "collapse") for v in rs)),
                 "delivery_from_killed": int(sum(1 for v in rs if any(t["seed"] == v["racing"]["delivery_seed"] and t["killed_at"] is not None for t in v["racing"]["tickets"])))}
            store["summary"]["m%d" % m] = s
            print("  --> m=%d n=%d | racing med %.4f | plain2 %.4f | plain3 %.4f | racing-plain2 med %+.4f (+%d/-%d) | racing-plain3 %+.4f (+%d/-%d) | walls %s / %s / %s | f0 kills %d | delivery from a killed ticket %d"
                  % (m, s["n"], s["racing_rung1"]["median"], s["plain2_rung1"]["median"], s["plain3_rung1"]["median"],
                     s["racing_minus_plain2"]["median"], s["racing_minus_plain2"]["n_pos"], s["racing_minus_plain2"]["n_neg"],
                     s["racing_minus_plain3"]["median"], s["racing_minus_plain3"]["n_pos"], s["racing_minus_plain3"]["n_neg"],
                     C.fmt_s(s["racing_wall_s"]["median"]), C.fmt_s(s["plain2_wall_s"]["median"]), C.fmt_s(s["plain3_wall_s"]["median"]),
                     s["kills_at_f0"], s["delivery_from_killed"]), flush=True)
            C.save_json(out, store)
    store["meta"]["total_wall_s"] = time.perf_counter() - t_start
    store["meta"]["finished_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    C.save_json(out, store)
    print("=" * 78)
    print("wrote %s (%d units, %s)" % (out, len(store["units"]), C.fmt_s(store["meta"]["total_wall_s"])))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
