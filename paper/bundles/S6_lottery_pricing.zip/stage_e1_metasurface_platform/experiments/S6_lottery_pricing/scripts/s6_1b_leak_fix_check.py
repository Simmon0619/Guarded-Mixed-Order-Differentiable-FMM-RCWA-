"""S6-1b  Verify the eigendecomposition-device fix: no host growth, same numbers,
what it costs.

  1. slope   value_grad at (32,8) x N: RSS slope with TFMM_EIG_DEVICE=cpu (the
             fix) -- compare with s6_1a's +15 MB/step.
  2. parity  eta of five delivered S5 masks at (24,6), (32,8), (40,10): cpu eig
             vs native (CUDA/MAGMA) eig, |d eta| against the S5-2 resolution
             floor (median 7.2e-5, max 8.5e-4).
  3. price   forward and value+grad wall at the orders both problems use, cpu
             vs native, 3 reps each (grid-independent, so measured on the
             current 70x240 problem).

    python s6_1b_leak_fix_check.py [--n 20]
"""
import argparse
import gc
import json
import os
import sys
import time

import numpy as np
import psutil
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
_WB = os.path.abspath(os.path.join(_HERE, "..", "..", "..", "fmm_workbench"))
S5 = os.path.abspath(os.path.join(_HERE, "..", "..", "S5_method_control", "data"))
sys.path.insert(0, _WB)
from workbench.protocol import DEFAULT, n_terms                    # noqa: E402
from workbench.app import value_grad, app_initial_latent, gate_eval  # noqa: E402
import trustworthy_fmm.solvers.vector_2d as _v2d                   # noqa: E402
import trustworthy_fmm.fourier.convolution as _conv                # noqa: E402
import importlib                                                   # noqa: E402
# NOT ``import trustworthy_fmm.solvers.eigendecomposition as _eig``: the package
# re-exports the *function* of the same name, so that statement binds the
# function, and setting EIG_DEVICE on it does nothing (this bit the first run).
_eig = importlib.import_module("trustworthy_fmm.solvers.eigendecomposition")
assert hasattr(_eig, "EIG_DEVICE"), "patched eigendecomposition module not in use"

DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
MASKS = ["designs/s5_8a_3_0_s03_final_binary.npy", "designs/s5_8a_1_0_s05_final_binary.npy",
         "designs/s5_8a_2_0_s05_final_binary.npy", "designs/s5_7_TREADMED_1_0_s04_binary.npy",
         "designs/s5_4_3_0_t00_binary.npy"]
FWD_LEVELS = [(16, 2), (12, 3), (24, 3), (28, 4), (20, 5), (24, 6), (40, 6), (32, 8), (48, 7), (52, 7), (40, 10), (60, 9), (48, 12)]
VG_LEVELS = [(16, 2), (12, 3), (24, 3), (28, 4), (20, 5), (32, 8), (40, 6)]


def rss_mb():
    return psutil.Process().memory_info().rss / 2 ** 20


def timed(fn, reps=3):
    fn()
    torch.cuda.synchronize()
    ts = []
    for _ in range(reps):
        torch.cuda.synchronize()
        t0 = time.perf_counter()
        fn()
        torch.cuda.synchronize()
        ts.append(time.perf_counter() - t0)
    return float(np.median(ts))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=20)
    args = ap.parse_args()
    torch.set_num_threads(int(os.environ.get("FMM_THREADS", "3")))
    _conv.VECTORIZED_CONV = True
    _v2d.FAST_DIAGNOSTICS = True
    _v2d.MEMORY_EFFICIENT = True
    device, dtype = "cuda", torch.complex64
    cfg = DEFAULT.variant(ny=70, nx=240)
    mode = "y"
    ctx = type("C", (), {})()
    ctx.cfg, ctx.mode, ctx.theta, ctx.phi = cfg, mode, 0.0, 0.0
    ctx.target, ctx.dtype, ctx.device, ctx.offload = (3, 0), dtype, device, False
    out = {"meta": {"eig_device_default": getattr(_eig, "EIG_DEVICE", None),
                    "torch": torch.__version__,
                    "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}}
    print("=" * 74)
    print("s6_1b_leak_fix_check | EIG_DEVICE default = %r" % out["meta"]["eig_device_default"], flush=True)

    # ---- 1. slope with the fix -------------------------------------------------
    latent = app_initial_latent(53003, cfg, mode, device)
    for dev in ("cpu", "native"):
        _eig.EIG_DEVICE = dev
        gc.collect()
        v, g = value_grad(latent, (32, 8), (3, 0), 64.0, cfg, mode, 0.0, 0.0, dtype, device, False)
        del g
        torch.cuda.synchronize()
        r0, rs, t0 = rss_mb(), [], time.perf_counter()
        n = args.n if dev == "cpu" else max(5, args.n // 4)
        for i in range(n):
            v, g = value_grad(latent, (32, 8), (3, 0), 64.0, cfg, mode, 0.0, 0.0, dtype, device, False)
            del g
            torch.cuda.synchronize()
            rs.append(rss_mb())
        slope = float(np.polyfit(np.arange(n), rs, 1)[0])
        out["slope_%s" % dev] = {"n": n, "rss_start": r0, "rss_end": rs[-1], "slope_mb_per_step": slope,
                                 "s_per_step": (time.perf_counter() - t0) / n}
        print("  1. value_grad (32,8) with eig on %-6s: n=%d rss %.0f -> %.0f MB  slope %+.1f MB/step  %.2f s/step"
              % (dev, n, r0, rs[-1], slope, out["slope_%s" % dev]["s_per_step"]), flush=True)

    # ---- 2. parity ---------------------------------------------------------------
    rows = []
    for rel in MASKS:
        p = os.path.join(S5, rel)
        if not os.path.exists(p):
            continue
        b = torch.from_numpy(np.load(p).astype("float64"))
        tgt = (int(rel.split("_")[-4]) if "TREADMED" not in rel else 1, 0)
        c2 = type("C", (), {})()
        c2.__dict__.update(ctx.__dict__)
        c2.target = tgt
        for lv in [(24, 6), (32, 8), (40, 10)]:
            e = {}
            for dev in ("cpu", "native"):
                _eig.EIG_DEVICE = dev
                e[dev] = gate_eval(b, lv, c2)
            rows.append({"mask": rel, "target": list(tgt), "level": list(lv), "cpu": e["cpu"],
                         "native": e["native"], "abs_diff": abs(e["cpu"] - e["native"])})
    d = [r["abs_diff"] for r in rows]
    out["parity"] = {"rows": rows, "median_abs": float(np.median(d)), "max_abs": float(max(d))}
    print("  2. parity cpu vs native eig over %d (mask, level): |d eta| median %.2e max %.2e  (S5-2 floor: median 7.2e-5, max 8.5e-4)"
          % (len(rows), out["parity"]["median_abs"], out["parity"]["max_abs"]), flush=True)

    # ---- 3. price ----------------------------------------------------------------
    b = torch.from_numpy(np.load(os.path.join(S5, MASKS[0])).astype("float64"))
    price = {}
    print("  3. price (s)      %-9s %6s  %8s %8s %6s" % ("level", "2N", "cpu", "native", "ratio"))
    for lv in FWD_LEVELS:
        if not cfg.supports(lv):
            continue
        t = {}
        for dev in ("cpu", "native"):
            _eig.EIG_DEVICE = dev
            t[dev] = timed(lambda: gate_eval(b, lv, ctx), reps=3 if 2 * n_terms(lv) < 4000 else 2)
        price["fwd|%d-%d" % lv] = {"two_n": 2 * n_terms(lv), **t, "ratio": t["cpu"] / t["native"]}
        print("     fwd            %-9s %6d  %8.3f %8.3f %6.2f" % (str(lv), 2 * n_terms(lv), t["cpu"], t["native"], t["cpu"] / t["native"]), flush=True)
    for lv in VG_LEVELS:
        if not cfg.supports(lv):
            continue
        t = {}
        for dev in ("cpu", "native"):
            _eig.EIG_DEVICE = dev

            def f(level=lv):
                v, g = value_grad(latent, level, (3, 0), 64.0, cfg, mode, 0.0, 0.0, dtype, device, False)
                del g
            t[dev] = timed(f, reps=3)
        price["vg|%d-%d" % lv] = {"two_n": 2 * n_terms(lv), **t, "ratio": t["cpu"] / t["native"]}
        print("     value+grad     %-9s %6d  %8.3f %8.3f %6.2f" % (str(lv), 2 * n_terms(lv), t["cpu"], t["native"], t["cpu"] / t["native"]), flush=True)
    out["price"] = price
    os.makedirs(DATA, exist_ok=True)
    with open(os.path.join(DATA, "s6_1b_leak_fix_check.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, indent=1)
    print("wrote data/s6_1b_leak_fix_check.json")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
