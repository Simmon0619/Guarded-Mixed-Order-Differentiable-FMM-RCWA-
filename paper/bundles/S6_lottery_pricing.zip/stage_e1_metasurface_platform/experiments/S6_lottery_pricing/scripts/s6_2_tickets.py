"""S6-2a / S6-2e  Cells of README-style tickets on the second problem.

  2a  schedule grid   steps {100, 219, 400} x beta_end {64, 300, 2000}
                      B(t) = 2 * (beta_end/2)^(t/T); filter 60 nm, y-mirror
  2e  ceiling probe   filter {60, 40, 20} nm x symmetry {y, none}
                      219 steps, beta_end 2000

Per ticket: sparse-early/dense-late gate checkpoints (s6_common.ckpt_schedule),
both deliveries (best gate checkpoint, final field) certified at the first
rung; per cell the best 5 deliveries (by first rung) are also read at the top
rung.  Orders per target from s6_common.orders_for (calibrated table if
present, else order_rule).  Descriptive: numbers, not verdicts.

    python s6_2_tickets.py --exp 2a --targets 1,2 --n 24
    python s6_2_tickets.py --exp 2e --targets 1,2 --n 24
    python s6_2_tickets.py --exp 2a --dry-run
"""
import argparse
import json
import os
import sys
import time

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import s6_common as C                                              # noqa: E402

EXPS = {
    "2a": {"seed_base": 110000, "file": "s6_2a_schedule_grid",
           "cells": [("S%d-B%d" % (s, b), {"steps": s, "beta_end": b, "filter_nm": 60.0, "mode": "y"})
                     for s in (100, 219, 400) for b in (64, 300, 2000)]},
    "2e": {"seed_base": 120000, "file": "s6_2e_ceiling",
           "cells": [("F%d-%s" % (int(f), sym), {"steps": 219, "beta_end": 2000, "filter_nm": f, "mode": sym})
                     for f in (60.0, 40.0, 20.0) for sym in ("y", "none")]},
    # phase 3: the baseline lottery at m = 3, 4 (same ticket as 2a's S219-B2000 cell)
    "3a": {"seed_base": 160000, "file": "s6_3a_baseline_m34",
           "cells": [("S219-B2000", {"steps": 219, "beta_end": 2000, "filter_nm": 60.0, "mode": "y"})]},
    # phase 3c: the order rule's three-sided evidence at m = 4 -- start one tier lower
    # (the m<=2 tier), at the rule, and with the descent AT the gate order; the gate and
    # the rungs stay the rule's so every cell is read on the same yardstick
    "3c": {"seed_base": 170000, "file": "s6_3c_order_m4",
           "cells": [("D16G28", {"steps": 219, "beta_end": 2000, "filter_nm": 60.0, "mode": "y", "descent": (16, 2), "gate": (28, 4)}),
                     ("RULE", {"steps": 219, "beta_end": 2000, "filter_nm": 60.0, "mode": "y"}),
                     ("D44G44", {"steps": 219, "beta_end": 2000, "filter_nm": 60.0, "mode": "y", "descent": (44, 6), "gate": (44, 6)})]},
}
N_TOP = 5
DRY = {"steps": 8, "n": 1}


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--exp", type=str, required=True, choices=sorted(EXPS))
    ap.add_argument("--targets", type=str, default="1,2")
    ap.add_argument("--n", type=int, default=24)
    ap.add_argument("--cells", type=str, default=None, help="comma list of cell names to run (default all)")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--out", type=str, default=None)
    args = ap.parse_args()
    device = C.setup_runtime()
    spec = EXPS[args.exp]
    cells = spec["cells"]
    if args.cells:
        want = {c.strip() for c in args.cells.split(",")}
        cells = [c for c in cells if c[0] in want]
    targets = [int(t) for t in args.targets.split(",") if t.strip()]
    n = DRY["n"] if args.dry_run else args.n
    out = args.out or os.path.join(C.DATA, "%s%s.json" % (spec["file"], "_dry" if args.dry_run else ""))
    store = {"meta": {}, "units": {}, "top_reads": {}, "summary": {}}
    if args.resume and os.path.exists(out):
        store = json.load(open(out, encoding="utf-8"))
        print("resuming: %d units" % len(store["units"]), flush=True)
    base_cfg = C.make_cfg(5)
    store["meta"].update({
        "script": os.path.basename(__file__), "exp": args.exp,
        "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "gpu": torch.cuda.get_device_name(0) if device == "cuda" else "cpu",
        "problem": {"lattice_nm": list(C.LATTICE_NM), "thickness_nm": C.THICKNESS_NM, "pixel_nm": 5,
                    "grid": [base_cfg.ny, base_cfg.nx]},
        "cells": [{"name": nm, **p} for nm, p in cells], "n_per_cell": n, "targets": targets,
        "orders": {str(m): {k: list(v) for k, v in C.orders_for(m, base_cfg).items()} for m in targets},
        "seed_rule": "%d + 1000*m + 100*cell_index + i" % spec["seed_base"],
        "reading_notes": [
            "Two deliveries per ticket: deliver_best (best gate checkpoint) and deliver_final "
            "(final field hard-thresholded).  Both certified at the FIRST RUNG (the statistical "
            "tier); the top rung is read only for the best %d of each cell x target." % N_TOP,
            "opt_wall_s = descent + gate checkpoints; opt_wall_descent_s = descent only.  "
            "Certification reads are outside both.",
            "collapse_step: first step after which the continuous value stays below 0.05.",
        ],
    })
    C.save_json(out, store)
    t_start = time.perf_counter()
    print("=" * 78)
    print("s6_2_tickets %s | %s | cells %s | targets %s | n=%d" % (args.exp, store["meta"]["gpu"],
          [c[0] for c in cells], targets, n), flush=True)

    for m in targets:
        od = C.orders_for(m, base_cfg)
        for ci, (cname, p) in enumerate(cells):
            cfg = base_cfg.variant(filter_nm=float(p["filter_nm"]))
            od = dict(C.orders_for(m, base_cfg))
            if p.get("descent"):
                od["descent"] = tuple(p["descent"])
            if p.get("gate"):
                od["gate"] = tuple(p["gate"])
            ctx = C.make_ctx(cfg, (m, 0), od["descent"], od["gate"], device, mode=p["mode"])
            steps = DRY["steps"] if args.dry_run else int(p["steps"])
            beta_fn = C.beta_geometric(2.0, float(p["beta_end"]))
            ck = C.ckpt_schedule(steps)
            for i in range(n):
                key = "m%d|%s|s%02d" % (m, cname, i)
                if key in store["units"]:
                    continue
                seed = spec["seed_base"] + 1000 * m + 100 * ci + i
                ev = []
                t0 = time.perf_counter()
                r = C.ticket(ctx, seed, steps, beta_fn, ck, ev, beta_final=float(p["beta_end"]))
                tag = "s6_%s_m%d_%s_s%02d" % (args.exp, m, cname, i)
                deliv = {}
                for name in ("best", "final"):
                    d = r[name]
                    tc = time.perf_counter()
                    e1 = C.eta(d["binary"], od["rung1"], ctx)
                    deliv[name] = {"step": d["step"], "eta_gate": d["eta_gate"], "eta_rung1": e1,
                                   "gate_optimism": d["eta_gate"] - e1, "cert_wall_s": time.perf_counter() - tc,
                                   "sha1": C.sha1_of(d["binary"]),
                                   "files": C.save_mask(tag + "_" + name, d["binary"], d["latent"] if name == "best" else None)}
                store["units"][key] = {
                    "target": [m, 0], "cell": cname, "params": p, "index": i, "seed": seed, "steps": steps,
                    "descent": list(od["descent"]), "gate": list(od["gate"]), "rung1": list(od["rung1"]), "top": list(od["top"]),
                    "deliver_best": deliv["best"], "deliver_final": deliv["final"],
                    "best_minus_final_rung1": deliv["best"]["eta_rung1"] - deliv["final"]["eta_rung1"],
                    "same_design": deliv["best"]["sha1"] == deliv["final"]["sha1"],
                    "reported_continuous": r["reported_continuous"], "collapse_step": r["collapse_step"],
                    "checkpoints": r["checkpoints"], "trajectory": r["trajectory"], "n_ckpt": r["n_ckpt"],
                    "wall_descent_s": r["wall_descent_s"], "wall_gate_s": r["wall_gate_s"],
                    "opt_wall_s": r["wall_descent_s"] + r["wall_gate_s"], "opt_wall_descent_s": r["wall_descent_s"],
                    "unit_wall_s": time.perf_counter() - t0, "grad_events": ev,
                }
                C.save_json(out, store)
                print("  m=%d %-12s s%02d | best@%-3d gate %.4f r1 %.4f | final gate %.4f r1 %.4f | reported %.4f | collapse %s | opt %s  [%s]"
                      % (m, cname, i, deliv["best"]["step"], deliv["best"]["eta_gate"], deliv["best"]["eta_rung1"],
                         deliv["final"]["eta_gate"], deliv["final"]["eta_rung1"], r["reported_continuous"], r["collapse_step"],
                         C.fmt_s(r["wall_descent_s"] + r["wall_gate_s"]), C.fmt_s(time.perf_counter() - t_start)), flush=True)

            # top-rung reads for the best N_TOP (by first rung, best delivery) of this cell x target
            rows = sorted([(v["deliver_best"]["eta_rung1"], k) for k, v in store["units"].items()
                           if v["target"][0] == m and v["cell"] == cname], reverse=True)[:N_TOP]
            for _, k in rows:
                if k in store["top_reads"]:
                    continue
                v = store["units"][k]
                b = C.load_mask(v["deliver_best"]["files"]["binary"])
                tc = time.perf_counter()
                et = C.eta(b, od["top"], ctx)
                store["top_reads"][k] = {"eta_top": et, "eta_rung1": v["deliver_best"]["eta_rung1"],
                                         "rung1_minus_top": v["deliver_best"]["eta_rung1"] - et,
                                         "level_top": list(od["top"]), "wall_s": time.perf_counter() - tc}
            C.save_json(out, store)
            rs = [v for v in store["units"].values() if v["target"][0] == m and v["cell"] == cname]
            if rs:
                b1 = [v["deliver_best"]["eta_rung1"] for v in rs]
                f1 = [v["deliver_final"]["eta_rung1"] for v in rs]
                tops = [store["top_reads"][k]["rung1_minus_top"] for k in store["top_reads"]
                        if store["units"][k]["target"][0] == m and store["units"][k]["cell"] == cname]
                s = {"n": len(rs), "best_rung1": C.q(b1), "final_rung1": C.q(f1),
                     "best_minus_final": C.q([a - b for a, b in zip(b1, f1)]),
                     "collapses": int(sum(v["collapse_step"] is not None for v in rs)),
                     "best_steps": [v["deliver_best"]["step"] for v in rs],
                     "opt_wall_s": C.q([v["opt_wall_s"] for v in rs]),
                     "opt_wall_descent_s": C.q([v["opt_wall_descent_s"] for v in rs]),
                     "reported": C.q([v["reported_continuous"] for v in rs]),
                     "gate_optimism_best": C.q([v["deliver_best"]["gate_optimism"] for v in rs]),
                     "rung1_minus_top_best5": C.q(tops),
                     "e_max": {N: C.e_max(b1, N) for N in range(1, min(len(b1) // 2, 12) + 1)}}
                store["summary"]["m%d|%s" % (m, cname)] = s
                print("  --> m=%d %-12s n=%d | best r1 med %.4f [%.4f,%.4f] | final r1 med %.4f | best-final med %+.4f | collapses %d | opt wall med %s | r1-top (best5) med %s"
                      % (m, cname, s["n"], s["best_rung1"]["median"], s["best_rung1"]["min"], s["best_rung1"]["max"],
                         s["final_rung1"]["median"], s["best_minus_final"]["median"], s["collapses"],
                         C.fmt_s(s["opt_wall_s"]["median"]),
                         ("%+.4f" % s["rung1_minus_top_best5"]["median"]) if s["rung1_minus_top_best5"] else "--"), flush=True)
                C.save_json(out, store)

    store["meta"]["total_wall_s"] = time.perf_counter() - t_start
    store["meta"]["finished_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    C.save_json(out, store)
    print("=" * 78)
    print("wrote %s (%d units, %s)" % (out, len(store["units"]), C.fmt_s(store["meta"]["total_wall_s"])))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
