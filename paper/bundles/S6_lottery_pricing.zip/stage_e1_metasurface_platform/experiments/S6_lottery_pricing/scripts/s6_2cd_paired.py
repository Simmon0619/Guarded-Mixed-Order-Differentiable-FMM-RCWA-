"""S6-2c / S6-2d  Paired variants of the descent on the second problem.

  2c  gate-controlled beta (B): FIXED (the README ramp, gate read every 12 steps)
      vs RATCHET (same ramp, but the beta clock is held for 12 steps whenever the
      gate reading fell by more than tau = 0.05 since the previous read, active
      from beta >= 10; run ends at beta_end or 1.5x the steps).  Pre-study 0c.
  2d  mixed-order gradients (C): SINGLE (descent order) vs MIX4 / MIX8 (every
      4th / 8th gradient at the gate order from step mix_from on, = beta ~ 11,
      pre-study 0d).

All arms share seeds (paired on the initial latent), the 219-step B = 2 -> 2000
ramp, and GapDescent checkpoints that log the truncation gap (descent-order
binary minus gate) along the run.  Deliveries certified at the first rung; the
top rung for the best 5 per arm.  Descriptive.

    python s6_2cd_paired.py --exp 2c --targets 1,2 --n 48
    python s6_2cd_paired.py --exp 2d --targets 1,2 --n 48
"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import s6_common as C                                              # noqa: E402

STEPS = 219
BETA_END = 2000.0
N_TOP = 5
DRY = {"steps": 24, "n": 1}


def mix_from_for(steps, beta_at=11.0):
    return int(round(steps * math.log(beta_at / 2.0) / math.log(1000.0)))


def arms_for(exp, steps):
    if exp == "2c":
        return {"seed_base": 140000, "file": "s6_2c_ratchet",
                "arms": [("FIXED", "gap", {}), ("RATCHET", "ratchet", {"check_every": 12, "tau": 0.05, "back_off": 0})]}
    if exp == "2d":
        mf = mix_from_for(steps)
        return {"seed_base": 150000, "file": "s6_2d_mixed",
                "arms": [("SINGLE", "gap", {}), ("MIX4", "mixed", {"k": 4, "mix_from": mf}), ("MIX8", "mixed", {"k": 8, "mix_from": mf})]}
    raise SystemExit("unknown exp")


def build(kind, ctx, seed, steps, beta_fn, ck, ev, params):
    if kind == "gap":
        return C.GapDescent(ctx, seed, steps, beta_fn, ck, ev, beta_final=BETA_END)
    if kind == "ratchet":
        return C.RatchetDescent(ctx, seed, steps, beta_fn, ck, ev, beta_final=BETA_END, **params)
    if kind == "mixed":
        return C.MixedDescent(ctx, seed, steps, beta_fn, ck, ev, beta_final=BETA_END, **params)
    raise ValueError(kind)


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--exp", type=str, required=True, choices=["2c", "2d"])
    ap.add_argument("--targets", type=str, default="1,2")
    ap.add_argument("--n", type=int, default=48)
    ap.add_argument("--arms", type=str, default=None, help="comma list of arm names to run (default all; the first listed is the paired base)")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--out", type=str, default=None)
    args = ap.parse_args()
    device = C.setup_runtime()
    steps = DRY["steps"] if args.dry_run else STEPS
    n = DRY["n"] if args.dry_run else args.n
    spec = arms_for(args.exp, steps)
    if args.arms:
        want = [a.strip() for a in args.arms.split(",") if a.strip()]
        spec["arms"] = [a for a in spec["arms"] if a[0] in want]
    targets = [int(t) for t in args.targets.split(",") if t.strip()]
    out = args.out or os.path.join(C.DATA, "%s%s.json" % (spec["file"], "_dry" if args.dry_run else ""))
    store = {"meta": {}, "units": {}, "top_reads": {}, "summary": {}}
    if args.resume and os.path.exists(out):
        store = json.load(open(out, encoding="utf-8"))
        print("resuming: %d units" % len(store["units"]), flush=True)
    cfg = C.make_cfg(5)
    beta_fn = C.beta_geometric(2.0, BETA_END)
    ck = sorted(set(C.ckpt_schedule(steps)) | set(range(0, steps + 1, 12)))   # 12-step gate cadence for all arms
    store["meta"].update({
        "script": os.path.basename(__file__), "exp": args.exp, "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "gpu": torch.cuda.get_device_name(0) if device == "cuda" else "cpu", "steps": steps, "beta": "2 -> %g" % BETA_END,
        "arms": [{"name": a, "kind": k, **p} for a, k, p in spec["arms"]], "ckpt_steps": ck,
        "seed_rule": "%d + 1000*m + i" % spec["seed_base"],
        "orders": {str(m): {k: list(v) for k, v in C.orders_for(m, cfg).items()} for m in targets},
        "reading_notes": [
            "Arms are paired on the seed (same initial latent).  Every arm checkpoints every 12 steps plus the "
            "sparse-early/dense-late points; each checkpoint records gate, descent-order binary, and their gap.",
            "RATCHET: holds the beta clock 12 steps after a gate drop > tau (beta >= 10); may run up to 1.5x steps; "
            "beta_reached and steps_run are recorded, cost is measured wall.",
            "MIXk: every k-th gradient at the gate order from mix_from (beta ~ 11); wall_high_order_s is its price.",
        ],
    })
    C.save_json(out, store)
    t_start = time.perf_counter()
    print("=" * 78)
    print("s6_2cd_paired %s | %s | arms %s | targets %s | n=%d | steps %d" % (args.exp, store["meta"]["gpu"],
          [a[0] for a in spec["arms"]], targets, n, steps), flush=True)
    for m in targets:
        od = C.orders_for(m, cfg)
        ctx = C.make_ctx(cfg, (m, 0), od["descent"], od["gate"], device)
        for i in range(n):
            seed = spec["seed_base"] + 1000 * m + i
            for aname, kind, params in spec["arms"]:
                key = "m%d|%s|s%02d" % (m, aname, i)
                if key in store["units"]:
                    continue
                ev = []
                t0 = time.perf_counter()
                d = build(kind, ctx, seed, steps, beta_fn, ck, ev, params)
                r = d.finish()
                tag = "s6_%s_m%d_%s_s%02d" % (args.exp, m, aname, i)
                deliv = {}
                for name in ("best", "final"):
                    dd = r[name]
                    e1 = C.eta(dd["binary"], od["rung1"], ctx)
                    deliv[name] = {"step": dd["step"], "eta_gate": dd["eta_gate"], "eta_rung1": e1,
                                   "gate_optimism": dd["eta_gate"] - e1, "sha1": C.sha1_of(dd["binary"]),
                                   "files": C.save_mask(tag + "_" + name, dd["binary"], dd["latent"] if name == "best" else None)}
                gaps = [c.get("gap_descent_minus_gate") for c in r["checkpoints"] if c.get("gap_descent_minus_gate") is not None]
                store["units"][key] = {
                    "target": [m, 0], "arm": aname, "kind": kind, "params": params, "index": i, "seed": seed,
                    "steps": steps, "steps_run": r.get("steps_run", steps), "descent": list(od["descent"]),
                    "gate": list(od["gate"]), "rung1": list(od["rung1"]), "top": list(od["top"]),
                    "deliver_best": deliv["best"], "deliver_final": deliv["final"],
                    "best_minus_final_rung1": deliv["best"]["eta_rung1"] - deliv["final"]["eta_rung1"],
                    "reported_continuous": r["reported_continuous"], "collapse_step": r["collapse_step"],
                    "checkpoints": r["checkpoints"], "trajectory": r["trajectory"], "n_ckpt": r["n_ckpt"],
                    "gap_end": gaps[-1] if gaps else None, "gap_max": max(gaps) if gaps else None,
                    "n_gate_drops_gt_0p05": int(sum(1 for a, b in zip(r["checkpoints"][:-1], r["checkpoints"][1:])
                                                    if a["eta_gate"] - b["eta_gate"] > 0.05)),
                    "n_holds": r.get("n_holds"), "hold_log": r.get("hold_log"), "beta_reached": r.get("beta_reached"),
                    "n_high_order_steps": r.get("n_high_order_steps"), "wall_high_order_s": r.get("wall_high_order_s"),
                    "wall_descent_s": r["wall_descent_s"], "wall_gate_s": r["wall_gate_s"],
                    "opt_wall_s": r["wall_descent_s"] + r["wall_gate_s"], "unit_wall_s": time.perf_counter() - t0,
                    "grad_events": ev,
                }
                C.save_json(out, store)
                extra = ""
                if kind == "ratchet":
                    extra = " | holds %d beta_reached %.0f steps_run %d" % (r["n_holds"], r["beta_reached"], r["steps_run"])
                if kind == "mixed":
                    extra = " | high-order steps %d (%s)" % (r["n_high_order_steps"], C.fmt_s(r["wall_high_order_s"]))
                print("  m=%d %-8s s%02d | best@%-3d gate %.4f r1 %.4f | final r1 %.4f | gap end %+.4f max %+.4f | drops>0.05 %d | collapse %s | opt %s%s  [%s]"
                      % (m, aname, i, deliv["best"]["step"], deliv["best"]["eta_gate"], deliv["best"]["eta_rung1"],
                         deliv["final"]["eta_rung1"], store["units"][key]["gap_end"] or 0.0, store["units"][key]["gap_max"] or 0.0,
                         store["units"][key]["n_gate_drops_gt_0p05"], r["collapse_step"],
                         C.fmt_s(r["wall_descent_s"] + r["wall_gate_s"]), extra, C.fmt_s(time.perf_counter() - t_start)), flush=True)
        # top-rung reads and summary per arm
        for aname, kind, params in spec["arms"]:
            rows = sorted([(v["deliver_best"]["eta_rung1"], k) for k, v in store["units"].items()
                           if v["target"][0] == m and v["arm"] == aname], reverse=True)[:N_TOP]
            for r1, k in rows:
                if k in store["top_reads"]:
                    continue
                b = C.load_mask(store["units"][k]["deliver_best"]["files"]["binary"])
                et = C.eta(b, od["top"], ctx)
                store["top_reads"][k] = {"eta_top": et, "eta_rung1": r1, "rung1_minus_top": r1 - et}
        base = spec["arms"][0][0]
        for aname, kind, params in spec["arms"]:
            rs = {v["index"]: v for v in store["units"].values() if v["target"][0] == m and v["arm"] == aname}
            rb = {v["index"]: v for v in store["units"].values() if v["target"][0] == m and v["arm"] == base}
            if not rs:
                continue
            b1 = [v["deliver_best"]["eta_rung1"] for v in rs.values()]
            d = [rs[i]["deliver_best"]["eta_rung1"] - rb[i]["deliver_best"]["eta_rung1"] for i in rs if i in rb] if aname != base else []
            s = {"n": len(rs), "best_rung1": C.q(b1), "final_rung1": C.q([v["deliver_final"]["eta_rung1"] for v in rs.values()]),
                 "best_minus_final": C.q([v["best_minus_final_rung1"] for v in rs.values()]),
                 "paired_minus_%s" % base: ({**C.q(d), "n_pos": int(sum(x > 0 for x in d)), "n_neg": int(sum(x < 0 for x in d))} if d else None),
                 "collapses": int(sum(v["collapse_step"] is not None for v in rs.values())),
                 "gate_drops_gt_0p05_per_ticket": C.q([v["n_gate_drops_gt_0p05"] for v in rs.values()]),
                 "gap_end": C.q([v["gap_end"] for v in rs.values()]), "gap_max": C.q([v["gap_max"] for v in rs.values()]),
                 "opt_wall_s": C.q([v["opt_wall_s"] for v in rs.values()]),
                 "n_holds": C.q([v["n_holds"] for v in rs.values() if v["n_holds"] is not None]) if kind == "ratchet" else None,
                 "beta_reached": C.q([v["beta_reached"] for v in rs.values() if v["beta_reached"] is not None]) if kind == "ratchet" else None,
                 "e_max": {N: C.e_max(b1, N) for N in range(1, min(len(b1) // 2, 12) + 1)}}
            store["summary"]["m%d|%s" % (m, aname)] = s
            pd = s["paired_minus_%s" % base]
            print("  --> m=%d %-8s n=%d | best r1 med %.4f [%.4f,%.4f] | final r1 med %.4f | collapses %d | drops/ticket med %.0f | gap end med %+.4f | opt wall med %s%s"
                  % (m, aname, s["n"], s["best_rung1"]["median"], s["best_rung1"]["min"], s["best_rung1"]["max"],
                     s["final_rung1"]["median"], s["collapses"], s["gate_drops_gt_0p05_per_ticket"]["median"],
                     s["gap_end"]["median"] if s["gap_end"] else 0.0, C.fmt_s(s["opt_wall_s"]["median"]),
                     (" | paired - %s med %+.4f (+%d/-%d)" % (base, pd["median"], pd["n_pos"], pd["n_neg"])) if pd else ""), flush=True)
        C.save_json(out, store)
    store["meta"]["total_wall_s"] = time.perf_counter() - t_start
    store["meta"]["finished_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    C.save_json(out, store)
    print("=" * 78)
    print("wrote %s (%d units, %s)" % (out, len(store["units"]), C.fmt_s(store["meta"]["total_wall_s"])))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
