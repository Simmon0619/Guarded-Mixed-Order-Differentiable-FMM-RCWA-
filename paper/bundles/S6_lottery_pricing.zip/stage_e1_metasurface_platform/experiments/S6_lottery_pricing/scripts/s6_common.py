"""Shared pieces for the S6 scripts: the second frozen problem, a README-schedule
ticket with gate checkpoints, ladder reads that return every target's power
from one solve, and the small utilities every S5 script carried.

Everything solver-side is imported from fmm_workbench (the shipped method);
nothing here re-implements physics.
"""
import hashlib
import json
import math
import os
import sys
import time
from typing import Dict, List, Optional, Sequence

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
_WB = os.path.abspath(os.path.join(_HERE, "..", "..", "..", "fmm_workbench"))
if _WB not in sys.path:
    sys.path.insert(0, _WB)
from workbench.protocol import DEFAULT, n_terms, cosine_lr, beta_at   # noqa: E402,F401
from workbench.app import (                                           # noqa: E402
    order_rule, solve_density, app_hard_binary, app_filtered, app_initial_latent,
    value_grad, AppAdam,
)
from trustworthy_fmm.fabrication.process import tanh_projection       # noqa: E402
import trustworthy_fmm.solvers.vector_2d as _v2d                      # noqa: E402
import trustworthy_fmm.fourier.convolution as _conv                   # noqa: E402

DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
DESIGNS = os.path.join(DATA, "designs")
LOGS = os.path.join(DATA, "logs")

# ------------------------------------------------------------- the second problem
LATTICE_NM = (3000.0, 500.0)
THICKNESS_NM = 300.0
PIXEL_NM = 5
NY, NX = 100, 600                      # 5 nm
REF_NY, REF_NX = 200, 1200             # 2.5 nm-equivalent grid for grid checks
MODE = "y"
TARGETS = [(1, 0), (2, 0), (3, 0), (4, 0)]
BETA_HI_README = 1000.0                # their b; ours B = 2b
SEED_BASE = 100000                     # S6 seed space; each script takes its own block


def setup_runtime():
    torch.set_num_threads(int(os.environ.get("FMM_THREADS", "3")))
    _conv.VECTORIZED_CONV = True
    _v2d.FAST_DIAGNOSTICS = True
    _v2d.MEMORY_EFFICIENT = True
    return "cuda" if torch.cuda.is_available() else "cpu"


def make_cfg(pixel_nm: int = PIXEL_NM):
    ny = int(round(LATTICE_NM[1] / pixel_nm))
    nx = int(round(LATTICE_NM[0] / pixel_nm))
    return DEFAULT.variant(lattice_nm=LATTICE_NM, thickness_nm=THICKNESS_NM, ny=ny, nx=nx)


def orders_for(m: int, cfg) -> Dict[str, tuple]:
    """Descent / gate / first rung / top rung for target (m,0): the calibrated
    table data/s6_orders.json when it exists (written after S6-1c), else the rule."""
    p = os.path.join(DATA, "s6_orders.json")
    if os.path.exists(p):
        t = json.load(open(p, encoding="utf-8")).get(str(m))
        if t:
            return {k: tuple(int(x) for x in t[k]) for k in ("descent", "gate", "rung1", "top")}
    r = order_rule((m, 0), cfg)
    lad = [tuple(x) for x in r["ladder"]] or [tuple(r["gate"])]
    return {"descent": tuple(r["descent"]), "gate": tuple(r["gate"]), "rung1": lad[0], "top": lad[-1]}


def make_ctx(cfg, target, level_d, gate, device, dtype=torch.complex64, mode=MODE):
    c = type("Ctx", (), {})()
    c.cfg, c.mode, c.theta, c.phi = cfg, mode, 0.0, 0.0
    c.target, c.level_d, c.gate = tuple(target), tuple(level_d), tuple(gate)
    c.dtype, c.device, c.offload = dtype, device, False
    c.accept_rule, c.cd_biases = "nominal", [-20.0, 20.0]
    return c


# ---------------------------------------------------------------------- utilities
def sha1_of(t: torch.Tensor) -> str:
    return hashlib.sha1(t.detach().cpu().numpy().astype(np.uint8).tobytes()).hexdigest()


def fmt_s(s: float) -> str:
    if s < 90:
        return "%.0f s" % s
    if s < 5400:
        return "%.1f min" % (s / 60.0)
    return "%.2f h" % (s / 3600.0)


def save_json(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=1, ensure_ascii=False, default=float)
    os.replace(tmp, path)


def save_mask(tag: str, binary: torch.Tensor, latent: Optional[torch.Tensor] = None) -> Dict[str, str]:
    """Binary masks as packed bits (5 nm grid: 7.5 KB); latents only when asked."""
    os.makedirs(DESIGNS, exist_ok=True)
    b = binary.detach().cpu().numpy().astype(np.uint8)
    pb = os.path.join(DESIGNS, tag + "_binary.npz")
    np.savez_compressed(pb, packed=np.packbits(b, axis=1), shape=np.array(b.shape))
    files = {"binary": os.path.relpath(pb, DATA).replace("\\", "/")}
    if latent is not None:
        pl = os.path.join(DESIGNS, tag + "_latent.npy")
        np.save(pl, latent.detach().cpu().numpy().astype(np.float32))
        files["latent"] = os.path.relpath(pl, DATA).replace("\\", "/")
    return files


def load_mask(rel: str) -> torch.Tensor:
    z = np.load(os.path.join(DATA, rel))
    shape = tuple(int(v) for v in z["shape"])
    b = np.unpackbits(z["packed"], axis=1)[:, :shape[1]]
    return torch.from_numpy(b.astype("float64"))


def q(v):
    a = np.asarray([x for x in v if x is not None], float)
    if not a.size:
        return None
    return {"n": int(a.size), "median": float(np.median(a)), "q1": float(np.percentile(a, 25)),
            "q3": float(np.percentile(a, 75)), "min": float(a.min()), "max": float(a.max())}


def e_max(values, N):
    x = sorted(float(v) for v in values)
    n = len(x)
    if N < 1 or N > n:
        return None
    return sum(x[k - 1] * math.comb(k - 1, N - 1) for k in range(1, n + 1)) / math.comb(n, N)


# ------------------------------------------------------------------- solves
def powers(density: torch.Tensor, level: Sequence[int], ctx, targets=TARGETS) -> Dict[str, float]:
    """One forward solve; the transmitted power of every listed order, plus (0,0)."""
    with torch.no_grad():
        r = solve_density(density, tuple(level), ctx.cfg, ctx.theta, ctx.phi, ctx.dtype, ctx.device)
    out = {}
    for t in [(0, 0)] + [tuple(x) for x in targets]:
        out["%d,%d" % t] = float(r.power_t[r.orders.index(t)]) if t in r.orders else None
    return out


def eta(density, level, ctx) -> float:
    return powers(density, level, ctx, targets=[ctx.target])["%d,%d" % tuple(ctx.target)]


GRAD_JITTERS = (1e-6, -1e-6, 1e-5, -1e-5)


def guarded_value_grad(rho, level, beta, ctx, events: List[Dict], step: int):
    """S4/S5's NaN guard: retry at beta*(1 +- jitter); skip the update if all fail."""
    def call(b):
        return value_grad(rho, level, ctx.target, b, ctx.cfg, ctx.mode, ctx.theta, ctx.phi,
                          ctx.dtype, ctx.device, ctx.offload)
    try:
        v, g = call(beta)
        if bool(torch.isfinite(g).all()):
            return v, g
        del g
    except RuntimeError as exc:
        events.append({"event": "raised", "step": step, "detail": str(exc)[:160]})
    for j in GRAD_JITTERS:
        try:
            v, g = call(float(beta) * (1.0 + j))
            if bool(torch.isfinite(g).all()):
                events.append({"event": "jitter_recovered", "step": step, "jitter": j})
                return v, g
            del g
        except RuntimeError:
            continue
    events.append({"event": "skipped_update", "step": step})
    return None, None


def beta_readme(step: int, steps: int, hi: float = BETA_HI_README) -> float:
    return 2.0 * math.exp(step * math.log(hi) / steps)


def beta_frozen(step: int, steps: int) -> float:
    return beta_at(step / max(steps - 1, 1))          # 1 -> 64, the frozen protocol


def ckpt_schedule(steps: int, early_every: float = 0.25, late_from: float = 0.6, late_every: float = 0.05) -> List[int]:
    """'Sparse early, dense late' checkpoint steps (plan 16 Sec. 4), always incl. 0 and steps."""
    s = {0, steps}
    t = early_every
    while t < late_from - 1e-9:
        s.add(int(round(t * steps)))
        t += early_every
    t = late_from
    while t < 1.0 - 1e-9:
        s.add(int(round(t * steps)))
        t += late_every
    return sorted(s)


class Descent:
    """A resumable descent with hard-binary gate checkpoints.

    ``run_to(step)`` advances the optimizer to that step (so a racing driver can
    pause several descents, rank them by their gate reading, and continue only
    some); ``finish()`` runs to the end and returns the same record ``ticket``
    used to return: both deliveries (best gate checkpoint, final field), the
    gate series, the continuous trajectory at the descent order, the collapse
    step if any, and the wall-clock split.
    """

    def __init__(self, ctx, seed: int, steps: int, beta_fn, ckpt_steps: Sequence[int],
                 events: List[Dict], beta_final: Optional[float] = None,
                 record_trajectory: bool = True):
        self.ctx, self.seed, self.steps, self.beta_fn = ctx, int(seed), int(steps), beta_fn
        self.events, self.record = events, record_trajectory
        self.ck = set(int(s) for s in ckpt_steps)
        cfg, mode = ctx.cfg, ctx.mode
        self.latent = app_initial_latent(seed, cfg, mode, ctx.device)
        self.adam = AppAdam(self.latent.shape, cfg, mode, ctx.device)
        self.t = 0
        self.traj: List[Optional[float]] = []
        self.ckpts: List[Dict] = []
        self.best = self.last = None
        self.t_desc = self.t_gate = 0.0
        self.beta_final = beta_final
        self._checkpoint(0)

    def _checkpoint(self, step: int):
        cfg, mode = self.ctx.cfg, self.ctx.mode
        lat = self.latent.detach().cpu().clone()
        b = app_hard_binary(lat, cfg, mode)
        t0 = time.perf_counter()
        eg = eta(b, self.ctx.gate, self.ctx)
        self.t_gate += time.perf_counter() - t0
        self.ckpts.append({"step": step, "eta_gate": eg, "beta": self.beta_fn(step, self.steps)})
        if self.best is None or eg > self.best["eta_gate"]:
            self.best = {"eta_gate": eg, "step": step, "latent": lat, "binary": b}
        self.last = {"eta_gate": eg, "step": step, "latent": lat, "binary": b}
        return eg

    def gate_now(self) -> float:
        """Gate reading of the current latent (a checkpoint is added if the
        current step is not one already)."""
        if not self.ckpts or self.ckpts[-1]["step"] != self.t:
            self._checkpoint(self.t)
        return self.ckpts[-1]["eta_gate"]

    def continuous_now(self) -> Optional[float]:
        return self.traj[-1] if self.traj else None

    def run_to(self, step: int):
        cfg = self.ctx.cfg
        end = min(int(step), self.steps)
        while self.t < end:
            t = self.t
            beta = self.beta_fn(t, self.steps)
            lr = cosine_lr(t / max(self.steps - 1, 1), cfg)
            t0 = time.perf_counter()
            v, g = guarded_value_grad(self.latent, self.ctx.level_d, beta, self.ctx, self.events, t)
            self.t_desc += time.perf_counter() - t0
            if g is not None:
                self.latent = self.adam.step(self.latent, g, lr)
                if self.record:
                    self.traj.append(round(float(v), 6))
            elif self.record:
                self.traj.append(None)
            self.t = t + 1
            if self.t in self.ck:
                self._checkpoint(self.t)
        return self

    def collapse_step(self) -> Optional[int]:
        if not self.record or not self.traj:
            return None
        arr = np.array([x if x is not None else np.nan for x in self.traj], float)
        below = np.where(arr < 0.05)[0]
        below = below[below > 20]
        if below.size and np.nanmax(arr[below[0]:]) < 0.05:
            return int(below[0])
        return None

    def finish(self) -> Dict:
        self.run_to(self.steps)
        if self.ckpts[-1]["step"] != self.steps:
            self._checkpoint(self.steps)
        cfg, mode = self.ctx.cfg, self.ctx.mode
        bf = self.beta_final if self.beta_final is not None else self.beta_fn(self.steps, self.steps)
        dens = tanh_projection(app_filtered(self.last["latent"], cfg, mode), bf, cfg.threshold)
        reported = eta(dens, self.ctx.level_d, self.ctx)
        return {"best": self.best, "final": self.last, "checkpoints": self.ckpts,
                "trajectory": self.traj, "reported_continuous": reported,
                "collapse_step": self.collapse_step(), "wall_descent_s": self.t_desc,
                "wall_gate_s": self.t_gate, "n_ckpt": len(self.ckpts), "beta_final": bf,
                "steps_run": self.t}


def ticket(ctx, seed: int, steps: int, beta_fn, ckpt_steps: Sequence[int], events: List[Dict],
           beta_final: Optional[float] = None, record_trajectory: bool = True):
    """One full descent (see ``Descent``)."""
    return Descent(ctx, seed, steps, beta_fn, ckpt_steps, events, beta_final, record_trajectory).finish()


class GapDescent(Descent):
    """Descent whose checkpoints also read the hard binary at the DESCENT order,
    so the truncation gap (descent-order reading minus gate reading) is logged
    along the run at every checkpoint.  Base class for the 2c / 2d variants and
    their fixed-schedule controls."""

    def _checkpoint(self, step: int):
        eg = super()._checkpoint(step)
        b = self.last["binary"]
        t0 = time.perf_counter()
        ed = eta(b, self.ctx.level_d, self.ctx)
        self.t_gate += time.perf_counter() - t0
        self.ckpts[-1]["eta_binary_descent"] = ed
        self.ckpts[-1]["gap_descent_minus_gate"] = ed - eg
        return eg


class RatchetDescent(GapDescent):
    """B: gate-controlled beta continuation.  The beta clock follows the same
    geometric ramp as the fixed schedule, but every ``check_every`` steps the
    gate is read and, if it fell by more than ``tau`` since the previous check,
    the clock is HELD for the next ``check_every`` steps (optionally stepped
    back by ``back_off`` clock steps).  The run ends when the clock reaches
    ``steps`` (beta_end) or after ``max_steps`` optimizer steps."""

    def __init__(self, ctx, seed, steps, beta_fn, ckpt_steps, events, beta_final=None,
                 record_trajectory=True, check_every=12, tau=0.05, back_off=0, max_steps=None,
                 beta_min_active=10.0):
        self.check_every, self.tau, self.back_off = int(check_every), float(tau), int(back_off)
        self.max_steps = int(max_steps) if max_steps else int(round(1.5 * steps))
        self.beta_min_active = float(beta_min_active)
        self.bclock = 0
        self.hold_left = 0
        self.n_holds = 0
        self.hold_log: List[Dict] = []
        self._last_check_gate: Optional[float] = None
        super().__init__(ctx, seed, steps, beta_fn, ckpt_steps, events, beta_final, record_trajectory)
        self._last_check_gate = self.ckpts[0]["eta_gate"]

    def run_to(self, step: int):
        cfg = self.ctx.cfg
        end = min(int(step), self.max_steps)
        while self.t < end and self.bclock < self.steps:
            t = self.t
            beta = self.beta_fn(self.bclock, self.steps)
            lr = cosine_lr(self.bclock / max(self.steps - 1, 1), cfg)
            t0 = time.perf_counter()
            v, g = guarded_value_grad(self.latent, self.ctx.level_d, beta, self.ctx, self.events, t)
            self.t_desc += time.perf_counter() - t0
            if g is not None:
                self.latent = self.adam.step(self.latent, g, lr)
                if self.record:
                    self.traj.append(round(float(v), 6))
            elif self.record:
                self.traj.append(None)
            self.t = t + 1
            if self.hold_left > 0:
                self.hold_left -= 1
            else:
                self.bclock += 1
            # gate read at the same points as the fixed control (its ckpt set) plus
            # every check_every steps; the ratchet decision is taken at every read
            if self.t % self.check_every == 0 or self.t in self.ck:
                eg = self._checkpoint(self.t)
                self.ckpts[-1]["bclock"] = self.bclock
                if (self._last_check_gate is not None and beta >= self.beta_min_active
                        and eg < self._last_check_gate - self.tau):
                    self.hold_left = self.check_every
                    self.n_holds += 1
                    if self.back_off:
                        self.bclock = max(0, self.bclock - self.back_off)
                    self.hold_log.append({"step": self.t, "beta": beta, "gate_before": self._last_check_gate,
                                          "gate_now": eg, "bclock": self.bclock})
                self._last_check_gate = eg
        return self

    def finish(self) -> Dict:
        self.run_to(self.max_steps)
        r = super().finish()
        r.update({"n_holds": self.n_holds, "hold_log": self.hold_log, "beta_reached": self.beta_fn(self.bclock, self.steps),
                  "bclock_final": self.bclock, "steps_run": self.t})
        return r


class MixedDescent(GapDescent):
    """C: mixed-order gradients.  From step ``mix_from`` on, every ``k``-th
    gradient is taken at the GATE order instead of the descent order."""

    def __init__(self, ctx, seed, steps, beta_fn, ckpt_steps, events, beta_final=None,
                 record_trajectory=True, k=4, mix_from=0):
        self.k, self.mix_from = int(k), int(mix_from)
        self.n_high = 0
        self.t_high = 0.0
        super().__init__(ctx, seed, steps, beta_fn, ckpt_steps, events, beta_final, record_trajectory)

    def run_to(self, step: int):
        cfg = self.ctx.cfg
        end = min(int(step), self.steps)
        while self.t < end:
            t = self.t
            beta = self.beta_fn(t, self.steps)
            lr = cosine_lr(t / max(self.steps - 1, 1), cfg)
            high = t >= self.mix_from and (t - self.mix_from) % self.k == 0
            level = self.ctx.gate if high else self.ctx.level_d
            t0 = time.perf_counter()
            v, g = guarded_value_grad(self.latent, level, beta, self.ctx, self.events, t)
            dt = time.perf_counter() - t0
            self.t_desc += dt
            if high:
                self.n_high += 1
                self.t_high += dt
            if g is not None:
                self.latent = self.adam.step(self.latent, g, lr)
                if self.record:
                    self.traj.append(round(float(v), 6))
            elif self.record:
                self.traj.append(None)
            self.t = t + 1
            if self.t in self.ck:
                self._checkpoint(self.t)
        return self

    def finish(self) -> Dict:
        r = super().finish()
        r.update({"n_high_order_steps": self.n_high, "wall_high_order_s": self.t_high})
        return r


def beta_geometric(b0: float, b_end: float):
    """B(t) = b0 * (b_end/b0)^(t/T): the README ramp is beta_geometric(2, 2000)."""
    def fn(step: int, steps: int) -> float:
        return float(b0) * (float(b_end) / float(b0)) ** (step / steps)
    return fn
