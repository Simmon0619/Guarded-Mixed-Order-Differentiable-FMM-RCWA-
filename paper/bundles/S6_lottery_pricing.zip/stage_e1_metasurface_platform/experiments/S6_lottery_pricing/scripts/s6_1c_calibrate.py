"""S6-1c  Calibrate the second frozen problem (Lambda 3000x500 nm, t 300 nm, 5 nm
pixels): propagating orders, order-convergence ladder, unit prices, grid check,
resolution floor, and a first look at README-schedule tickets (plan 16 v2 Sec. 3.3).

Phases (resumable, each unit saved as it completes):
  A  tickets   6 README-schedule tickets per target (219 steps, B 2->2000, descent
               and gate from order_rule, sparse-early/dense-late gate checkpoints);
               both deliveries saved
  B  random    12 random-initial masks (hard-thresholded initial latents)
  C  ladder    every mask read at LEVELS (one solve gives every target's power);
               the two top rungs only on a subset
  D  grid      8 masks re-read on the 2.5 nm-equivalent grid at two levels
  E  floor     12 masks re-read with MEMORY_EFFICIENT off at (40,6)
  F  orders    list of orders with non-zero transmitted power at (28,4)
Prices come out of the wall clocks recorded in A and C.

    python s6_1c_calibrate.py --dry-run
    python s6_1c_calibrate.py [--resume]
"""
import argparse
import json
import os
import sys
import time

import numpy as np
import torch

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import s6_common as C                                              # noqa: E402
from s6_common import (                                            # noqa: E402
    order_rule, solve_density, app_hard_binary, app_initial_latent, n_terms,
)
import trustworthy_fmm.solvers.vector_2d as _v2d                   # noqa: E402
import importlib                                                   # noqa: E402
_eig = importlib.import_module("trustworthy_fmm.solvers.eigendecomposition")  # the module, not the re-exported function

LEVELS = [(16, 2), (24, 3), (28, 4), (40, 6), (44, 6), (48, 7), (52, 7), (60, 9)]
TOP_LEVELS = [(64, 9), (72, 10)]
N_TICKETS = 6
N_RANDOM = 12
STEPS = 219
SEED_TICKET = C.SEED_BASE + 1000          # 101000 + 100*m + i
SEED_RANDOM = C.SEED_BASE + 500           # 100500 + i
DRY = {"steps": 8, "tickets": 1, "random": 2, "levels": [(16, 2), (28, 4), (40, 6)], "top": [(48, 7)]}


def main():
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--eig-device", type=str, default=None, help="override TFMM_EIG_DEVICE for this run")
    ap.add_argument("--out", type=str, default=None)
    args = ap.parse_args()
    device = C.setup_runtime()
    if args.eig_device:
        _eig.EIG_DEVICE = args.eig_device
    cfg, ref = C.make_cfg(5), C.make_cfg(2.5)
    steps, n_t, n_r, levels, top = STEPS, N_TICKETS, N_RANDOM, LEVELS, TOP_LEVELS
    if args.dry_run:
        steps, n_t, n_r, levels, top = DRY["steps"], DRY["tickets"], DRY["random"], DRY["levels"], DRY["top"]
    out = args.out or os.path.join(C.DATA, "s6_1c_calibrate%s.json" % ("_dry" if args.dry_run else ""))
    store = {"meta": {}, "tickets": {}, "masks": {}, "reads": {}, "grid": {}, "floor": {}, "orders": {}}
    if args.resume and os.path.exists(out):
        store = json.load(open(out, encoding="utf-8"))
        print("resuming: %d tickets, %d masks, %d reads" % (len(store["tickets"]), len(store["masks"]), len(store["reads"])), flush=True)
    rules = {m: order_rule((m, 0), cfg) for m in (1, 2, 3, 4)}
    store["meta"].update({
        "script": os.path.basename(__file__), "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "gpu": torch.cuda.get_device_name(0) if device == "cuda" else "cpu", "eig_device": _eig.EIG_DEVICE,
        "problem": {"lattice_nm": list(C.LATTICE_NM), "thickness_nm": C.THICKNESS_NM, "pixel_nm": 5,
                    "grid": [cfg.ny, cfg.nx], "ref_grid": [ref.ny, ref.nx], "wavelength_nm": cfg.wavelength_nm,
                    "n_feature": float(cfg.eps_feature) ** 0.5, "n_incident": cfg.n_incident, "n_output": cfg.n_output},
        "rule": {m: {"descent": list(r["descent"]), "gate": list(r["gate"]), "ladder": [list(x) for x in r["ladder"]]}
                 for m, r in rules.items()},
        "levels": [list(l) for l in levels], "top_levels": [list(l) for l in top], "steps": steps,
        "n_tickets_per_target": n_t, "n_random": n_r,
    })
    C.save_json(out, store)
    t_start = time.perf_counter()
    print("=" * 78)
    print("s6_1c_calibrate | %s | eig on %s | grid %s | rule %s" % (store["meta"]["gpu"], _eig.EIG_DEVICE, (cfg.ny, cfg.nx),
          {m: (r["descent"], r["gate"]) for m, r in rules.items()}), flush=True)

    # ---- A. tickets ----------------------------------------------------------------
    for m in (1, 2, 3, 4):
        r = rules[m]
        ctx = C.make_ctx(cfg, (m, 0), r["descent"], r["gate"], device)
        for i in range(n_t):
            key = "m%d|t%02d" % (m, i)
            if key in store["tickets"]:
                continue
            seed = SEED_TICKET + 100 * m + i
            ev = []
            t0 = time.perf_counter()
            res = C.ticket(ctx, seed, steps, C.beta_readme, C.ckpt_schedule(steps), ev)
            tag = "s6_1c_m%d_t%02d" % (m, i)
            fb = C.save_mask(tag + "_final", res["final"]["binary"], res["final"]["latent"])
            bb = C.save_mask(tag + "_best", res["best"]["binary"], res["best"]["latent"])
            for name, d, files in (("final", res["final"], fb), ("best", res["best"], bb)):
                store["masks"]["%s|%s" % (key, name)] = {"kind": "ticket", "target": [m, 0], "delivery": name,
                                                          "step": d["step"], "eta_gate": d["eta_gate"],
                                                          "files": files, "sha1": C.sha1_of(d["binary"])}
            store["tickets"][key] = {
                "target": [m, 0], "seed": seed, "steps": steps, "descent": list(r["descent"]), "gate": list(r["gate"]),
                "best_step": res["best"]["step"], "eta_gate_best": res["best"]["eta_gate"],
                "eta_gate_final": res["final"]["eta_gate"], "reported_continuous": res["reported_continuous"],
                "collapse_step": res["collapse_step"], "checkpoints": res["checkpoints"],
                "trajectory": res["trajectory"], "wall_descent_s": res["wall_descent_s"],
                "wall_gate_s": res["wall_gate_s"], "s_per_step": res["wall_descent_s"] / steps,
                "n_ckpt": res["n_ckpt"], "grad_events": ev, "unit_wall_s": time.perf_counter() - t0}
            C.save_json(out, store)
            print("  A m=%d t%02d seed %d | gate best %.4f @%d final %.4f | reported %.4f | collapse %s | desc %s (%.2f s/step) gate %s  [%s]"
                  % (m, i, seed, res["best"]["eta_gate"], res["best"]["step"], res["final"]["eta_gate"],
                     res["reported_continuous"], res["collapse_step"], C.fmt_s(res["wall_descent_s"]),
                     res["wall_descent_s"] / steps, C.fmt_s(res["wall_gate_s"]), C.fmt_s(time.perf_counter() - t_start)), flush=True)

    # ---- B. random masks ------------------------------------------------------------
    for i in range(n_r):
        key = "rand|r%02d" % i
        if key in store["masks"]:
            continue
        lat = app_initial_latent(SEED_RANDOM + i, cfg, C.MODE, device).detach().cpu()
        b = app_hard_binary(lat, cfg, C.MODE)
        store["masks"][key] = {"kind": "random", "target": None, "delivery": None, "step": 0,
                               "files": C.save_mask("s6_1c_rand_r%02d" % i, b), "sha1": C.sha1_of(b),
                               "fill": float(b.mean())}
    C.save_json(out, store)
    print("  B %d random masks" % n_r, flush=True)

    # ---- F. propagating orders (one solve, all orders) -------------------------------
    if "at_28_4" not in store["orders"]:
        mk = next(v for k, v in store["masks"].items() if v["kind"] == "ticket")
        b = C.load_mask(mk["files"]["binary"])
        ctx = C.make_ctx(cfg, (1, 0), (28, 4), (28, 4), device)
        with torch.no_grad():
            rr = solve_density(b, (28, 4), cfg, 0.0, 0.0, torch.complex64, device)
        pt = {"%d,%d" % o: float(p) for o, p in zip(rr.orders, rr.power_t)}
        pr = {"%d,%d" % o: float(p) for o, p in zip(rr.orders, rr.power_r)} if hasattr(rr, "power_r") else {}
        nz = sorted([(o, p) for o, p in pt.items() if p > 1e-9], key=lambda x: -x[1])
        store["orders"]["at_28_4"] = {"mask": mk["files"]["binary"], "transmitted_nonzero": nz[:20],
                                      "sum_t": float(sum(pt.values())), "sum_r": float(sum(pr.values())) if pr else None}
        C.save_json(out, store)
        print("  F transmitted orders with power > 1e-9 at (28,4): %s | sum T %.4f%s"
              % ([(o, round(p, 4)) for o, p in nz[:12]], store["orders"]["at_28_4"]["sum_t"],
                 (" R %.4f" % store["orders"]["at_28_4"]["sum_r"]) if pr else ""), flush=True)

    # ---- C. ladder reads --------------------------------------------------------------
    ctx_all = C.make_ctx(cfg, (1, 0), (16, 2), (28, 4), device)
    # the top rungs only on: the best-gate ticket per target (final delivery) x 2 + 2 random
    subset = set()
    for m in (1, 2, 3, 4):
        tk = sorted([(v["eta_gate_best"], k) for k, v in store["tickets"].items() if v["target"][0] == m], reverse=True)[:2]
        subset.update("%s|final" % k for _, k in tk)
    subset.update(k for k in list(store["masks"])[:] if k.startswith("rand|r0"))
    subset = {k for k in subset if k in store["masks"]}
    # what each mask is read at: ticket finals -> every level; random masks -> every
    # level but the top of LEVELS (the (60,9) read costs ~85 s and random masks are
    # not what the two-tier licence is about); ticket 'best' deliveries -> only the
    # first rung of their own target (enough for best-vs-final at the statistical tier)
    todo = []
    for k, mk in store["masks"].items():
        if mk["kind"] == "ticket" and mk["delivery"] == "best":
            lvs = [tuple(rules[mk["target"][0]]["ladder"][0])]
        elif mk["kind"] == "random":
            lvs = list(levels[:-1]) if len(levels) > 1 else list(levels)
        else:
            lvs = list(levels)
        todo += [(k, tuple(lv)) for lv in lvs]
    todo += [(k, tuple(lv)) for k in sorted(subset) for lv in top]
    n_done = 0
    for k, lv in todo:
        rk = "%s|%d-%d" % (k, lv[0], lv[1])
        if rk in store["reads"]:
            continue
        b = C.load_mask(store["masks"][k]["files"]["binary"])
        torch.cuda.synchronize()
        t0 = time.perf_counter()
        pw = C.powers(b, lv, ctx_all)
        torch.cuda.synchronize()
        store["reads"][rk] = {"mask": k, "level": list(lv), "two_n": 2 * n_terms(lv), "wall_s": time.perf_counter() - t0, "powers": pw}
        n_done += 1
        if n_done % 10 == 0 or 2 * n_terms(lv) >= 4000:
            C.save_json(out, store)
            print("  C read %s @%s  %.2f s  P(1,0..4,0) = %s  [%s]" % (k, lv, store["reads"][rk]["wall_s"],
                  [round(pw["%d,0" % t], 4) for t in (1, 2, 3, 4)], C.fmt_s(time.perf_counter() - t_start)), flush=True)
    C.save_json(out, store)

    # ---- D. grid check ------------------------------------------------------------------
    ref_ctx = C.make_ctx(ref, (1, 0), (16, 2), (28, 4), device)
    gk = sorted(subset)[:8]
    for k in gk:
        for lv in ((28, 4), (48, 7)):
            rk = "%s|%d-%d" % (k, lv[0], lv[1])
            if rk in store["grid"] or rk not in store["reads"]:
                continue
            b = C.load_mask(store["masks"][k]["files"]["binary"])
            b2 = torch.repeat_interleave(torch.repeat_interleave(b, 2, 0), 2, 1)
            t0 = time.perf_counter()
            pw = C.powers(b2, lv, ref_ctx)
            store["grid"][rk] = {"mask": k, "level": list(lv), "wall_s": time.perf_counter() - t0, "powers_2p5nm": pw,
                                 "powers_5nm": store["reads"][rk]["powers"],
                                 "diff": {t: pw[t] - store["reads"][rk]["powers"][t] for t in pw if pw[t] is not None}}
    C.save_json(out, store)
    print("  D grid check on %d masks x 2 levels" % len(gk), flush=True)

    # ---- E. resolution floor ---------------------------------------------------------------
    fk = [k for k in store["masks"] if k.endswith("|final")][:12]
    for k in fk:
        rk = "%s|40-6" % k
        if rk in store["floor"] or rk not in store["reads"]:
            continue
        b = C.load_mask(store["masks"][k]["files"]["binary"])
        old = _v2d.MEMORY_EFFICIENT
        _v2d.MEMORY_EFFICIENT = False
        try:
            pw = C.powers(b, (40, 6), ctx_all)
        finally:
            _v2d.MEMORY_EFFICIENT = old
        store["floor"][rk] = {"mask": k, "powers_ME_off": pw, "powers_ME_on": store["reads"][rk]["powers"],
                              "diff": {t: pw[t] - store["reads"][rk]["powers"][t] for t in pw if pw[t] is not None}}
    C.save_json(out, store)
    print("  E resolution floor on %d masks" % len(fk), flush=True)

    # ---- summary ----------------------------------------------------------------------------
    summ = {"ladder": {}, "prices": {}, "tickets": {}}
    lv_all = [tuple(l) for l in levels] + [tuple(l) for l in top]
    for m in (1, 2, 3, 4):
        key_t = "%d,0" % m
        own = ["%s|final" % k for k, v in store["tickets"].items() if v["target"][0] == m]
        rows = {}
        for pool_name, pool in (("own", own), ("all", list(store["masks"]))):
            steps_tab = {}
            for a, bb in zip(lv_all[:-1], lv_all[1:]):
                d = []
                for k in pool:
                    ra, rb = store["reads"].get("%s|%d-%d" % (k, *a)), store["reads"].get("%s|%d-%d" % (k, *bb))
                    if ra and rb and ra["powers"][key_t] is not None and rb["powers"][key_t] is not None:
                        d.append(ra["powers"][key_t] - rb["powers"][key_t])
                if d:
                    steps_tab["%s->%s" % (a, bb)] = {"n": len(d), "median": float(np.median(d)),
                                                    "median_abs": float(np.median(np.abs(d))), "max_abs": float(np.max(np.abs(d)))}
            rows[pool_name] = steps_tab
        summ["ladder"][key_t] = rows
        tk = [v for v in store["tickets"].values() if v["target"][0] == m]
        if tk:
            tops = [store["reads"].get("m%d|t%02d|final|%d-%d" % (m, i, *rules[m]["ladder"][-1])) for i in range(len(tk))]
            tops = [r["powers"][key_t] for r in tops if r]
            one = [store["reads"].get("m%d|t%02d|final|%d-%d" % (m, i, *rules[m]["ladder"][0])) for i in range(len(tk))]
            one = [r["powers"][key_t] for r in one if r]
            summ["tickets"][key_t] = {"n": len(tk), "s_per_step": C.q([v["s_per_step"] for v in tk]),
                                      "wall_descent_s": C.q([v["wall_descent_s"] for v in tk]),
                                      "wall_gate_s": C.q([v["wall_gate_s"] for v in tk]),
                                      "reported": C.q([v["reported_continuous"] for v in tk]),
                                      "top_rung_final": C.q(tops), "first_rung_final": C.q(one),
                                      "collapses": int(sum(v["collapse_step"] is not None for v in tk)),
                                      "best_steps": [v["best_step"] for v in tk]}
    for lv in lv_all:
        w = [r["wall_s"] for r in store["reads"].values() if tuple(r["level"]) == lv]
        if w:
            summ["prices"]["fwd|%d-%d" % lv] = {"two_n": 2 * n_terms(lv), "wall_s": C.q(w)}
    store["summary"] = summ
    store["meta"]["total_wall_s"] = time.perf_counter() - t_start
    C.save_json(out, store)
    print("=" * 78)
    for lv in lv_all:
        p = summ["prices"].get("fwd|%d-%d" % lv)
        if p:
            print("  price fwd %-8s 2N=%5d  %.2f s (n=%d)" % (str(lv), p["two_n"], p["wall_s"]["median"], p["wall_s"]["n"]))
    for m in (1, 2, 3, 4):
        t = summ["tickets"].get("%d,0" % m)
        if t:
            print("  m=%d tickets: %.2f s/step, descent %s, gate %s | reported med %.3f | first rung med %s | top rung med %s | collapses %d/%d | best steps %s"
                  % (m, t["s_per_step"]["median"], C.fmt_s(t["wall_descent_s"]["median"]), C.fmt_s(t["wall_gate_s"]["median"]),
                     t["reported"]["median"], ("%.3f" % t["first_rung_final"]["median"]) if t["first_rung_final"] else "--",
                     ("%.3f" % t["top_rung_final"]["median"]) if t["top_rung_final"] else "--", t["collapses"], t["n"], t["best_steps"]))
        for pool in ("own", "all"):
            tab = summ["ladder"]["%d,0" % m][pool]
            print("  m=%d ladder (%s): " % (m, pool) + "  ".join("%s: med %+.4f |max| %.4f (n=%d)" % (k, v["median"], v["max_abs"], v["n"]) for k, v in tab.items()))
    print("wrote %s (%s)" % (out, C.fmt_s(store["meta"]["total_wall_s"])))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
