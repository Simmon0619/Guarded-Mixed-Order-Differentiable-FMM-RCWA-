"""S6-0  Zero-solve pre-studies on the S5 data (plan 16 v2, Sec. 2).

  0a  ticket price -> expected best certified value per GPU-second, per ticket type
  0b  racing: how predictive is a mid-course gate reading of the final certified
      value; when do collapses become visible; a Monte-Carlo of keep-top-q rules
  0c  cliffs in the 6-step gate series (S5-4, 8d): frequency, timing, size, recovery
  0d  artifact onset along the 100-step traces (8a, 8c)
  0e  selection fidelity: pick by descent-order value / by gate / by top rung

Reads only stage_e1/experiments/S5_method_control/data/.  Writes
data/s6_0_prestudy.json and prints the tables.  Numbers, not verdicts.
"""
import json
import math
import os
import sys

import numpy as np

_HERE = os.path.dirname(os.path.abspath(__file__))
S5 = os.path.abspath(os.path.join(_HERE, "..", "..", "S5_method_control", "data"))
DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
RNG = np.random.default_rng(20260912)


def load(name):
    p = os.path.join(S5, name)
    return json.load(open(p, encoding="utf-8")) if os.path.exists(p) else None


def q(v):
    a = np.asarray([x for x in v if x is not None], float)
    if not a.size:
        return None
    return {"n": int(a.size), "median": float(np.median(a)), "q1": float(np.percentile(a, 25)),
            "q3": float(np.percentile(a, 75)), "min": float(a.min()), "max": float(a.max())}


def e_max(values, N):
    x = sorted(float(v) for v in values)
    n = len(x)
    if N < 1 or N > n:
        return None
    return sum(x[k - 1] * math.comb(k - 1, N - 1) for k in range(1, n + 1)) / math.comb(n, N)


def spearman(a, b):
    a, b = np.asarray(a, float), np.asarray(b, float)
    if a.size < 3:
        return None
    ra, rb = a.argsort().argsort(), b.argsort().argsort()
    return float(np.corrcoef(ra, rb)[0, 1])


def beta_readme(step, T):
    return 2.0 * 1000.0 ** (step / T)


def beta_ours(step, T):
    return 64.0 ** (min(max(step / max(T - 1, 1), 0.0), 1.0))


# --------------------------------------------------------------------------- pools
def pools():
    """Ticket pools with (certified value under a delivery rule, price, gate series)."""
    U4 = load("s5_4_restart_baseline.json")["units"]
    A = load("s5_8a_readme_schedule.json")["units"]
    C = load("s5_8c_readme_gate_order.json")["units"]
    D = load("s5_8d_steps_beta.json")["units"]
    out = {}
    for m in (1, 2, 3):
        P = {}
        r4 = [v for v in U4.values() if v["target"][0] == m]
        if r4:
            P["S219-B64 ckpt6 (S5-4)"] = {
                "steps": 219, "beta": "ours64", "rule": "best-gate-ckpt",
                "top": [v["eta_top"] for v in r4],
                "price_s": [v["opt_wall_s"] for v in r4],
                "price_descent_s": [v["wall_descent_s"] for v in r4],
                "gate_series": [[(c["step"], c["eta_gate"]) for c in v["checkpoints"]] for v in r4],
                "gate_best": [v["eta_gate_best"] for v in r4], "reported": None,
                "trajectory": None}
        for cell, sched in (("S219-B64", "ours64"), ("S219-B2000", "readme"), ("S800-B64", "ours64")):
            rd = sorted([v for v in D.values() if v["target"][0] == m and v["cell"] == cell],
                        key=lambda u: u["index"])
            if rd:
                P["%s ckpt%d (8d)" % (cell, rd[0]["ckpt_every"])] = {
                    "steps": rd[0]["steps"], "beta": sched, "rule": "best-gate-ckpt",
                    "top": [v["deliver_best"]["eta_top"] for v in rd],
                    "top_final": [v["deliver_final"]["eta_top"] for v in rd],
                    "price_s": [v["opt_wall_s"] for v in rd],
                    "price_descent_s": [v["wall_descent_s"] for v in rd],
                    "gate_series": [[(c["step"], c["eta_gate"]) for c in v["checkpoints"]] for v in rd],
                    "gate_best": [v["deliver_best"]["eta_gate"] for v in rd],
                    "gate_final": [v["deliver_final"]["eta_gate"] for v in rd],
                    "reported": [v["deliver_final"]["reported_continuous"] for v in rd],
                    "trajectory": [v["trajectory"] for v in rd]}
        ra = sorted([v for v in A.values() if v["target"][0] == m], key=lambda u: u["index"])
        if ra:
            P["S800-B2000 ckpt25 (8a)"] = {
                "steps": 800, "beta": "readme", "rule": "best-gate-ckpt",
                "top": [v["deliver_best"]["eta_top"] for v in ra],
                "top_final": [v["deliver_final"]["eta_top"] for v in ra],
                "price_s": [v["opt_wall_s"] for v in ra],
                "price_descent_s": [v["wall_descent_s"] for v in ra],
                "gate_series": [[(c["step"], c["eta_gate"]) for c in v["checkpoints"]] for v in ra],
                "gate_best": [v["deliver_best"]["eta_gate"] for v in ra],
                "gate_final": [v["deliver_final"]["eta_gate"] for v in ra],
                "reported": [v["deliver_final"]["reported_continuous"] for v in ra],
                "trajectory": [v["trajectory"] for v in ra],
                "trace": [v["trace"] for v in ra]}
        if m == 3:
            rc = sorted(C.values(), key=lambda u: u["index"])
            P["S800-B2000@(32,8) ckpt100 (8c)"] = {
                "steps": 800, "beta": "readme", "rule": "best-gate-ckpt",
                "top": [v["deliver_best"]["eta_top"] for v in rc],
                "top_final": [v["deliver_final"]["eta_top"] for v in rc],
                "price_s": [v["opt_wall_s"] for v in rc],
                "price_descent_s": [v["wall_descent_s"] for v in rc],
                "gate_series": [[(c["step"], c["eta_gate"]) for c in v["checkpoints"]] for v in rc],
                "gate_best": [v["deliver_best"]["eta_gate"] for v in rc],
                "gate_final": [v["deliver_final"]["eta_gate"] for v in rc],
                "reported": [v["deliver_final"]["reported_continuous"] for v in rc],
                "trajectory": [v["trajectory"] for v in rc],
                "trace": [v["trace"] for v in rc]}
        out[m] = P
    return out


# --------------------------------------------------------------------------- 0a
def study_0a(P, m):
    grid = [30, 60, 120, 240, 480, 960] if m <= 2 else [300, 600, 1200, 2400, 4800]
    rows = []
    for name, t in P.items():
        n = len(t["top"])
        p = float(np.median(t["price_s"]))
        p_sparse = float(np.median(t["price_descent_s"])) + 8 * (1.22 if m <= 2 else 5.0)
        row = {"ticket": name, "n": n, "price_s": p, "price_sparse_gate_s": p_sparse,
               "e_max": {N: e_max(t["top"], N) for N in range(1, min(n // 2, 12) + 1)},
               "at_budget": {}, "at_budget_sparse": {}}
        for B in grid:
            for key, price in (("at_budget", p), ("at_budget_sparse", p_sparse)):
                N = int(B // price)
                cap = n // 2
                row[key][B] = {"N": N, "e_max": e_max(t["top"], min(N, cap)) if N >= 1 else None,
                               "capped": N > cap}
        rows.append(row)
    print("\n  0a  ticket -> E[max] per budget  (m=%d; * = N capped at n/2)" % m)
    print("      %-32s %3s %7s %8s | %s" % ("ticket", "n", "price", "sparse", " ".join("B=%-5d" % B for B in grid)))
    for r in rows:
        cells = []
        for B in grid:
            a = r["at_budget"][B]
            cells.append(("%.3f%s" % (a["e_max"], "*" if a["capped"] else " ")) if a["e_max"] is not None else "  --   ")
        print("      %-32s %3d %6.0fs %7.0fs | %s" % (r["ticket"], r["n"], r["price_s"], r["price_sparse_gate_s"], " ".join(cells)))
    return rows


# --------------------------------------------------------------------------- 0b
def study_0b(P, m):
    out = {}
    fr = [0.25, 0.375, 0.5, 0.625, 0.75]
    for name, t in P.items():
        gs, top, T = t["gate_series"], t["top"], t["steps"]
        n = len(top)
        if n < 4:
            continue
        # gate reading at the checkpoint nearest to fraction f of the run
        def at(series, f):
            s = f * T
            k = min(range(len(series)), key=lambda i: abs(series[i][0] - s))
            return series[k][1]
        rho = {f: spearman([at(g, f) for g in gs], top) for f in fr}
        # keep-top-q racing Monte Carlo: start K, keep ceil(qK) at f, deliver best final of survivors
        mc = {}
        K = 4
        for f in fr:
            for qk in (0.5, 0.25):
                keep = max(1, int(math.ceil(qk * K)))
                best_s, miss = [], 0
                for _ in range(4000):
                    idx = RNG.choice(n, size=K, replace=n < K)
                    g = np.array([at(gs[i], f) for i in idx])
                    surv = idx[np.argsort(-g)[:keep]]
                    b = max(top[i] for i in surv)
                    best_s.append(b)
                    if b < max(top[i] for i in idx) - 1e-9:
                        miss += 1
                cost = K * (f + (1 - f) * keep / K)          # in units of one full ticket
                mc["f=%.3f q=%.2f" % (f, qk)] = {"E_best": float(np.mean(best_s)), "miss_rate": miss / 4000,
                                                  "cost_tickets": cost, "K": K, "keep": keep,
                                                  "plain_e_max_same_cost": e_max(top, min(max(1, int(round(cost))), n // 2))}
        # collapse visibility from trajectories
        vis = []
        if t.get("trajectory"):
            for tr, tp in zip(t["trajectory"], top):
                arr = np.array([x if x is not None else np.nan for x in tr], float)
                if tp < 0.2:
                    below = np.where(arr < 0.1)[0]
                    below = below[below > 50]
                    vis.append({"final_top": tp, "first_step_below_0p1": int(below[0]) if below.size else None,
                                "frac": (float(below[0]) / T) if below.size else None})
        out[name] = {"n": n, "spearman_gate_at_f_vs_top": rho, "racing_mc": mc, "collapse_visibility": vis}
        print("\n  0b  %s (m=%d, n=%d): Spearman(gate@f, top) " % (name, m, n)
              + "  ".join("f=%.2f: %s" % (f, ("%+.2f" % r) if r is not None else "--") for f, r in rho.items()))
        for k, v in mc.items():
            print("        race %s  E[best] %.4f  miss %.2f  cost %.2f tickets  (plain E[max] at same cost %s)"
                  % (k, v["E_best"], v["miss_rate"], v["cost_tickets"],
                     ("%.4f" % v["plain_e_max_same_cost"]) if v["plain_e_max_same_cost"] is not None else "--"))
        if vis:
            print("        collapses (<0.2 final): first step with continuous < 0.1: %s"
                  % [(x["first_step_below_0p1"], "%.2f" % x["frac"] if x["frac"] is not None else None) for x in vis])
    return out


# --------------------------------------------------------------------------- 0c
def study_0c(P, m):
    out = {}
    for name, t in P.items():
        if "ckpt6" not in name:
            continue
        T, sched = t["steps"], t["beta"]
        per = []
        for series in t["gate_series"]:
            g = [v for _, v in series]
            s = [st for st, _ in series]
            drops = [(g[i] - g[i + 1], s[i + 1]) for i in range(len(g) - 1)]
            n02 = sum(1 for d, _ in drops if d > 0.02)
            n05 = sum(1 for d, _ in drops if d > 0.05)
            n10 = sum(1 for d, _ in drops if d > 0.10)
            dmax, smax = max(drops, key=lambda x: x[0])
            beta = beta_ours(smax, T) if sched == "ours64" else beta_readme(smax, T)
            # recovery after the largest drop: checkpoints until g >= pre-drop value
            i0 = [i for i in range(len(g) - 1) if s[i + 1] == smax][0]
            pre = g[i0]
            rec = next((j - i0 for j in range(i0 + 1, len(g)) if g[j] >= pre - 1e-9), None)
            # late cliffs: only where beta >= 10 (the design is no longer the washed-out init)
            bfn = beta_ours if sched == "ours64" else beta_readme
            late = [(d, st) for d, st in drops if bfn(st, T) >= 10.0]
            late05 = sum(1 for d, _ in late if d > 0.05)
            late10 = sum(1 for d, _ in late if d > 0.10)
            lmax = max(late, key=lambda x: x[0]) if late else (0.0, None)
            per.append({"n_drop_gt_0p02": n02, "n_drop_gt_0p05": n05, "n_drop_gt_0p10": n10,
                        "max_drop": dmax, "max_drop_step": smax, "max_drop_beta": beta,
                        "recovered_after_ckpts": rec, "best_before_max_drop": bool(max(g) == max(g[:i0 + 1])),
                        "late_n_drop_gt_0p05": late05, "late_n_drop_gt_0p10": late10,
                        "late_max_drop": lmax[0], "late_max_drop_step": lmax[1]})
        out[name] = {"n": len(per), "per_ticket": per,
                     "n_drop_gt_0p05": q([x["n_drop_gt_0p05"] for x in per]),
                     "max_drop": q([x["max_drop"] for x in per]),
                     "max_drop_beta": q([x["max_drop_beta"] for x in per]),
                     "frac_recovered": float(np.mean([x["recovered_after_ckpts"] is not None for x in per])),
                     "frac_best_before_max_drop": float(np.mean([x["best_before_max_drop"] for x in per])),
                     "tickets_with_drop_gt_0p10": int(sum(x["n_drop_gt_0p10"] > 0 for x in per)),
                     "late_n_drop_gt_0p05": q([x["late_n_drop_gt_0p05"] for x in per]),
                     "late_max_drop": q([x["late_max_drop"] for x in per]),
                     "late_tickets_with_drop_gt_0p05": int(sum(x["late_n_drop_gt_0p05"] > 0 for x in per)),
                     "late_tickets_with_drop_gt_0p10": int(sum(x["late_n_drop_gt_0p10"] > 0 for x in per))}
        o = out[name]
        print("\n  0c  %s (m=%d, n=%d): drops>0.05 per ticket med %.0f [%.0f,%.0f] | max drop med %.3f max %.3f "
              "at beta med %.1f [%.1f,%.1f] | recovered %.0f%% | best before max drop %.0f%% | tickets with a >0.10 drop %d"
              % (name, m, o["n"], o["n_drop_gt_0p05"]["median"], o["n_drop_gt_0p05"]["min"], o["n_drop_gt_0p05"]["max"],
                 o["max_drop"]["median"], o["max_drop"]["max"], o["max_drop_beta"]["median"], o["max_drop_beta"]["min"],
                 o["max_drop_beta"]["max"], 100 * o["frac_recovered"], 100 * o["frac_best_before_max_drop"],
                 o["tickets_with_drop_gt_0p10"]))
        print("      late (beta>=10): drops>0.05 per ticket med %.0f [%.0f,%.0f]; tickets with a late >0.05 drop %d/%d, >0.10 %d/%d; late max drop med %.3f max %.3f"
              % (o["late_n_drop_gt_0p05"]["median"], o["late_n_drop_gt_0p05"]["min"], o["late_n_drop_gt_0p05"]["max"],
                 o["late_tickets_with_drop_gt_0p05"], o["n"], o["late_tickets_with_drop_gt_0p10"], o["n"],
                 o["late_max_drop"]["median"], o["late_max_drop"]["max"]))
    return out


# --------------------------------------------------------------------------- 0d
def study_0d(P, m):
    out = {}
    for name, t in P.items():
        if not t.get("trace"):
            continue
        per = []
        for tr in t["trace"]:
            steps = [x["step"] for x in tr]
            gap = [x["eta_binary_descent"] - x["eta_trace"] for x in tr]
            cert = [x["eta_trace"] for x in tr]
            on02 = next((s for s, g in zip(steps, gap) if g > 0.02 and s > 0), None)
            on05 = next((s for s, g in zip(steps, gap) if g > 0.05 and s > 0), None)
            cmax = max(cert)
            plateau = next((s for s, c in zip(steps, cert) if c >= 0.9 * cmax), None)
            per.append({"gap_onset_0p02_step": on02, "gap_onset_0p05_step": on05, "cert_90pct_step": plateau,
                        "gap_end": gap[-1], "gap_max": max(gap)})
        out[name] = {"n": len(per), "per_run": per,
                     "gap_onset_0p02": q([x["gap_onset_0p02_step"] for x in per]),
                     "gap_onset_0p05": q([x["gap_onset_0p05_step"] for x in per]),
                     "cert_90pct_step": q([x["cert_90pct_step"] for x in per]),
                     "gap_end": q([x["gap_end"] for x in per])}
        o = out[name]
        print("\n  0d  %s (m=%d, n=%d): gap>0.02 onset step med %s | gap>0.05 onset med %s | certified reaches 90%% of its max at step med %s | gap at end med %.3f"
              % (name, m, o["n"], o["gap_onset_0p02"]["median"] if o["gap_onset_0p02"] else "--",
                 o["gap_onset_0p05"]["median"] if o["gap_onset_0p05"] else "--",
                 o["cert_90pct_step"]["median"] if o["cert_90pct_step"] else "--", o["gap_end"]["median"]))
    return out


# --------------------------------------------------------------------------- 0e
def study_0e(P, m):
    out = {}
    for name, t in P.items():
        top = np.array(t["top"])
        res = {"n": len(top), "oracle_max": float(top.max())}
        gb = np.array(t["gate_best"])
        res["pick_by_gate_top"] = float(top[int(np.argmax(gb))])
        res["loss_gate"] = res["oracle_max"] - res["pick_by_gate_top"]
        if t.get("reported") is not None and t.get("top_final") is not None:
            rep, tf = np.array(t["reported"]), np.array(t["top_final"])
            res["pick_by_descent_value_top_final"] = float(tf[int(np.argmax(rep))])
            res["oracle_final_max"] = float(tf.max())
            res["loss_descent_value"] = res["oracle_final_max"] - res["pick_by_descent_value_top_final"]
            res["spearman_reported_vs_top_final"] = spearman(rep, tf)
        out[name] = res
        print("  0e  %-32s (m=%d, n=%d): oracle %.4f | pick-by-gate %.4f (loss %.4f)%s"
              % (name, m, res["n"], res["oracle_max"], res["pick_by_gate_top"], res["loss_gate"],
                 (" | pick-by-descent-value %.4f (loss %.4f, Spearman %s)"
                  % (res["pick_by_descent_value_top_final"], res["loss_descent_value"],
                     ("%+.2f" % res["spearman_reported_vs_top_final"]) if res.get("spearman_reported_vs_top_final") is not None else "--"))
                 if "loss_descent_value" in res else ""))
    return out


def main():
    P = pools()
    res = {}
    for m in (1, 2, 3):
        print("\n" + "=" * 78 + "\nm=%d" % m)
        res[m] = {"0a": study_0a(P[m], m), "0b": study_0b(P[m], m), "0c": study_0c(P[m], m),
                  "0d": study_0d(P[m], m)}
        print()
        res[m]["0e"] = study_0e(P[m], m)
    os.makedirs(DATA, exist_ok=True)
    with open(os.path.join(DATA, "s6_0_prestudy.json"), "w", encoding="utf-8") as f:
        json.dump(res, f, indent=1, default=float)
    print("\nwrote data/s6_0_prestudy.json")
    return 0


if __name__ == "__main__":
    sys.exit(main())
