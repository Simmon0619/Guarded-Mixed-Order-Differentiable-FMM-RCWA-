"""F33 -- markdown tables for SI S3.8/S3.9 from f33_analysis.json and f33_refine.json (zero solves).

  python f33_si_tables.py > ../data/logs/f33_si_tables.md
"""
import json
import os

_HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
MR = {1: "(48,7)", 2: "(48,7)", 3: "(60,9)", 4: "(64,9)"}
MD = {1: "(16,2)", 2: "(16,2)", 3: "(24,3)", 4: "(28,4)"}
MG = {1: "(28,4)", 2: "(28,4)", 3: "(40,6)", 4: "(44,6)"}


def main():
    A = json.load(open(os.path.join(DATA, "f33_analysis.json"), encoding="utf-8"))
    print("**Table S3.13.** Per initial design: conventional workflow (reported value; delivered pattern at $M_d$ and $M_r$) and the "
          "guarded mixed-order workflow (step of the delivered checkpoint; delivered pattern at $M_g$ and $M_r$).\n")
    for m in ("1", "2", "3", "4"):
        if m not in A["m"]:
            continue
        r = A["m"][m]
        mi = int(m)
        print("\n*Channel (%s,0)*: $M_d$ %s, $M_g$ %s, $M_r$ %s.\n" % (m, MD[mi], MG[mi], MR[mi]))
        print("| run | seed | conv.: reported | conv.: $M_d$ | conv.: $M_r$ | this work: step | this work: $M_g$ | this work: $M_r$ | difference at $M_r$ |")
        print("|---:|---:|---:|---:|---:|---:|---:|---:|---:|")
        for w in r["rows"]:
            print("| %d | %d | %.3f | %.3f | %.3f | %d | %.3f | %.3f | %+.3f |" % (w["i"], w["seed"], w["T_rep"], w["T_Qd"], w["T_Qr"], w["B_step"],
                                                                             w["B_Qg"], w["B_Qr"], w["B_Qr"] - w["T_Qr"]))
    print("\n**Table S3.14.** Summary per channel (medians; quartiles in brackets).\n")
    print("| channel | $n$ | conv.: reported | conv.: delivered at $M_r$ | this work: delivered at $M_r$ | paired difference | higher / lower | "
          "this work: $M_g$ minus $M_r$ | $E$[best of 3]: conv. (own rule) / this work | cost per run: conv. / this work | equal cost: conv. $E$[best of $N$] |")
    print("|---|---:|---:|---:|---:|---|---|---:|---|---|---|")
    for m in ("1", "2", "3", "4"):
        if m not in A["m"]:
            continue
        r = A["m"][m]
        p = r["paired_B_minus_T_Mr"]
        print("| (%s,0) | %d | %.3f | %.3f [%.3f, %.3f] | %.3f [%.3f, %.3f] | %+.3f [%+.3f, %+.3f] | %d / %d | %+.3f | %.3f / %.3f | %.0f s / %.0f s | $N$=%.1f%s: %.3f |"
              % (m, r["n"], r["T_reported"]["median"], r["T_delivered_Mr"]["median"], r["T_delivered_Mr"]["q1"], r["T_delivered_Mr"]["q3"],
                 r["B_delivered_Mr"]["median"], r["B_delivered_Mr"]["q1"], r["B_delivered_Mr"]["q3"], p["median"], p["q1"], p["q3"],
                 r["paired_pos"], r["paired_neg"], r["B_gate_minus_Mr"]["median"], r["E3_T_own"], r["E3_B"], r["price_T_s"], r["price_B_s"],
                 r["equal_wall_N_T"], " (capped at %d)" % (r["n"] // 2) if r["equal_wall_capped"] else "", r["equal_wall_T_own"]))
    if "ladder_of_changes" in A:
        print("\n**Table S3.15.** One change at a time, from the conventional workflow to the guarded mixed-order workflow, on the same 24 "
              "initial designs (first rung (40,6); medians, and paired differences to the conventional workflow).\n")
        print("| workflow | (1,0): efficiency | (1,0): difference, higher/lower | (2,0): efficiency | (2,0): difference, higher/lower |")
        print("|---|---:|---|---:|---|")
        L1, L2 = A["ladder_of_changes"]["1"], A["ladder_of_changes"]["2"]
        for k in L1:
            a, b = L1[k], L2[k]
            print("| %s | %.3f | %+.3f, %d/%d | %.3f | %+.3f, %d/%d |" % (k, a["rung1"]["median"], a["paired_vs_conventional"]["median"], a["pos"], a["neg"],
                                                                     b["rung1"]["median"], b["paired_vs_conventional"]["median"], b["pos"], b["neg"]))
    p = os.path.join(DATA, "f33_refine.json")
    if os.path.exists(p):
        R = json.load(open(p, encoding="utf-8"))["chains"]
        print("\n**Table S3.16.** Refinement of delivered runs (released settings, $\\beta=64$).\n")
        print("| channel | run | group | step of delivered checkpoint | $M_g$ minus first rung | $M_r$ before | $M_r$ after | accepted hops (of which lowered the first rung) | hops run | wall time |")
        print("|---|---|---|---:|---:|---:|---:|---|---:|---:|")
        for c in sorted(R.values(), key=lambda c: (c["m"], c["label"], c["parent_Mr"] or 0)):
            print("| (%d,0) | %s | %s | %d | %+.3f | %.3f | %.3f | %d (%d) | %d | %.1f min |" % (c["m"], c["parent"], c["label"], c["parent_step"],
                                                                                         c["parent_gate"] - c["parent_rung1"], c["parent_Mr"], c["final_Mr"],
                                                                                         c["n_accept"], c["n_false_accept"], c["hops_run"], c["wall_s"] / 60))


if __name__ == "__main__":
    main()
