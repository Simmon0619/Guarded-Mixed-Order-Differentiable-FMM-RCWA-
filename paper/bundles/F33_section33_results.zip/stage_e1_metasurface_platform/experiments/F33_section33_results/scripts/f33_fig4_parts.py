"""
F33 -- Fig. 4 of manuscript Sec. 3.3 as separate panels (2026-10-06).  Same data as f33_plot.fig4(); type, sizes and
delivery as the Fig. 2 parts (f31_fig2_parts.py): Times New Roman, tick labels 8.5 pt and axis labels 9.5 pt bold,
annotations and legends 8 pt regular (math in STIX), capitalised first letters, one file per panel, no panel letters,
png + svg only; axes sized 1 : 1 for a 180 mm page and the canvas cropped to the labels.

User rulings 2026-10-06 (Fig. 4 check):
  * split like Fig. 2, no (a)-(e) letters;
  * the symbols of the 24-run panel must mean what they mean in Fig. 2(c): there the filled orange diamond is the
    conventional pattern delivered at M_r.  Fig. 2(c) shows the gap between reported and delivered values and stays
    as it is; the 24-run panel of Fig. 4 shows what the new workflow delivers instead.  So, throughout Fig. 4:
      filled orange diamond = pattern delivered by the conventional workflow, read at M_r (as in Fig. 2(c));
      orange star (ink edge) = pattern delivered by this work, read at M_r -- which is also the value it reports;
      navy dashes           = value reported by the conventional workflow (as in Fig. 2(a));
    the conventional reported values are left out of the 24-run and four-channel panels (they are Fig. 2(c));
    an arrow from diamond to star is the gain (the grey bars of Fig. 2(c) are the reported-delivered gap, not used);
  * the refinement panel has to be readable without the text: efficiency before -> after refinement (arrows) against
    the step at which the refined run peaked, the region "stopped improving before step 110" shaded, counts of improved
    runs on either side, and the range of best checkpoints of all 72 runs of this work marked under the points.

Output: manuscript_cpc/figures/fig4_parts/
  fig4_legend_orders, fig4_a_ladder, fig4_b_run, fig4_c_runs24, fig4_d_channels, fig4_e_refinement  (.png and .svg)
"""
import json
import math
import os
import sys

import numpy as np

_HERE = os.path.dirname(os.path.abspath(__file__))
_EXP = os.path.abspath(os.path.join(_HERE, "..", ".."))
sys.path.insert(0, os.path.join(_EXP, "F31_section31_figures", "scripts"))
import f31_fig2_parts as F2                                           # noqa: E402  (sets the rcParams of the parts)
import matplotlib.pyplot as plt                                      # noqa: E402
from matplotlib.lines import Line2D                                  # noqa: E402

DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
F31DATA = os.path.join(_EXP, "F31_section31_figures", "data")
S7DATA = os.path.join(_EXP, "S7_headtohead", "data")
OUT = os.path.abspath(os.path.join(_EXP, "..", "..", "stage_d3_landscape_scheduling", "manuscript", "manuscript_cpc",
                                   "figures", "fig4_parts"))

OC, ORDERS, MD, MG, MR, LAB = F2.OC, F2.ORDERS, F2.MD, F2.MG, F2.MR, F2.LAB
INK, INK2, GREY, GREY_L, BAND = F2.INK, F2.INK2, F2.GREY, F2.GREY_L, F2.BAND
note, reg_legend, bold_ticks, canvas, olab = F2.note, F2.reg_legend, F2.bold_ticks, F2.canvas, F2.olab
MM = F2.MM
STEPS, T_MIX = 219, 66

# the two workflow symbols of Fig. 4 (and the diamond of Fig. 2(c))
DIA = dict(marker="D", color=OC[MR], linewidths=0)                                  # conventional, delivered at M_r
# star edge: a darker shade of the M_r orange (user 2026-10-07: the black edge looked heavy and hid the median bars of
# the four-channel panel; a recoloured star would break colour = truncation order)
STAR_EDGE, STAR_LW = "#b9651c", 0.5                                                 # edge of the star (set_star)
STAR = dict(marker="*", color=OC[MR], edgecolors=STAR_EDGE, linewidths=STAR_LW)     # this work, delivered = reported
ARROW = INK2
MEDIAN_HALO = 1.0                                                                   # white stroke (pt) under median bars


def set_star(edge, lw):
    """Edge of the star symbol (colour or None for no edge, line width)."""
    global STAR, STAR_EDGE, STAR_LW
    STAR_EDGE, STAR_LW = edge, (lw if edge is not None else 0.0)
    STAR = dict(marker="*", color=OC[MR], edgecolors=(edge if edge is not None else "none"), linewidths=STAR_LW)


def median_bar(ax, x0, x1, v, lw=1.3):
    kw = {}
    if MEDIAN_HALO:
        import matplotlib.patheffects as pe
        kw["path_effects"] = [pe.Stroke(linewidth=lw + 2 * MEDIAN_HALO, foreground="white"), pe.Normal()]
    ax.plot([x0, x1], [v, v], color=INK, lw=lw, zorder=5, solid_capstyle="butt", **kw)

TR = json.load(open(os.path.join(DATA, "f33_traj.json"), encoding="utf-8"))
AN = json.load(open(os.path.join(DATA, "f33_analysis.json"), encoding="utf-8"))["m"]
D31 = json.load(open(os.path.join(F31DATA, "f31_fig2.json"), encoding="utf-8"))
P1, P2 = TR["part1"], TR["part2"]
CONV_REP = D31["part1"]["reported"]


def save(fig, name):
    os.makedirs(OUT, exist_ok=True)
    for ext in ("png", "svg"):                      # no pdf (user ruling 2026-10-03)
        fig.savefig(os.path.join(OUT, "%s.%s" % (name, ext)), bbox_inches="tight", pad_inches=0.03, facecolor="white")
    plt.close(fig)
    h, w = plt.imread(os.path.join(OUT, name + ".png")).shape[:2]
    print("saved %-20s %.1f x %.1f mm" % (name, w / 300 * 25.4, h / 300 * 25.4))


def h_dia(label, ms=4.2):
    return Line2D([0], [0], marker="D", ls="none", color=OC[MR], mew=0, ms=ms, label=label)


def h_star(label, ms=8.0):
    return Line2D([0], [0], marker="*", ls="none", mfc=OC[MR], mec=(STAR_EDGE if STAR_EDGE is not None else OC[MR]),
                  mew=STAR_LW, ms=ms, label=label)


def up_arrow(ax, x, y0, y1, shrink_a=3.0, shrink_b=4.5, lw=0.8, color=ARROW):
    ax.annotate("", xy=(x, y1), xytext=(x, y0), zorder=2,
                arrowprops=dict(arrowstyle="-|>", lw=lw, color=color, shrinkA=shrink_a, shrinkB=shrink_b,
                                mutation_scale=6.5))


# ---- colour key (placed first in the assembled figure; as the Fig. 2 key) --------------------------------------------
def legend_orders():
    handles = []
    for l in ORDERS:
        big = l in (MD, MG)
        name = olab(l) + ("  " + LAB[l] if l in LAB else "")
        handles.append(Line2D([0], [0], color=OC[l], lw=(1.4 if big else 0.9), marker="o", ms=(2.6 if big else 1.8),
                              mew=0, label=name))
    KS = 10.0
    fig = plt.figure(figsize=(180 * MM, 15 * MM))
    leg = fig.legend(handles=handles, loc="center", bbox_to_anchor=(0.5, 0.48), ncol=7, frameon=False,
                     title="Truncation order (color)", handlelength=1.5, handletextpad=0.5,
                     columnspacing=0.9, borderaxespad=0.0)
    for t in leg.get_texts():
        t.set_fontweight("bold"); t.set_fontsize(KS)
    leg.get_title().set_fontweight("bold"); leg.get_title().set_fontsize(KS + 0.5)
    save(fig, "fig4_legend_orders")


# ---- (a) both delivered patterns with more and more harmonics --------------------------------------------------------
def pattern_inset(ax, rect, b, title):
    ins = ax.inset_axes(rect)
    ins.imshow(1 - np.vstack([b, b]), cmap="gray", vmin=-0.4, vmax=1.0, origin="lower", aspect="auto",
               extent=[0, 3.0, 0, 1.0], interpolation="nearest")
    ins.set_xticks([]); ins.set_yticks([])
    for s in ins.spines.values():
        s.set_visible(True); s.set_color(INK2); s.set_linewidth(0.5)
    note(ins, 0.0, 1.04, title, transform=ins.transAxes, ha="left", va="bottom")
    return ins


def panel_a():
    W, H = 50.0, 48.0
    fig, ax = canvas(W, H, left=18, top=13)
    lc = D31["part2"]["final"]["ladder"]
    ncv = np.array([r["n_terms"] for r in lc], float); ecv = np.array([r["eta"] for r in lc])
    lvc = [tuple(r["level"]) for r in lc]
    lo = P2["delivered_ladder"]
    nou = np.array([r["n_terms"] for r in lo], float); eou = np.array([r["eta"] for r in lo])
    lvo = [tuple(r["level"]) for r in lo]
    ax.axhline(CONV_REP, color=OC[MD], lw=0.9, ls=(0, (4, 2)), zorder=0)
    # conventional pattern: grey ladder, its M_r reading as the diamond of Fig. 2(c)
    ax.plot(ncv, ecv, "-", color=GREY_L, lw=0.9, zorder=1)
    ax.scatter(ncv, ecv, s=9, color=GREY, zorder=2, linewidths=0)
    icr = lvc.index(MR)
    ax.scatter([ncv[icr]], [ecv[icr]], s=26, zorder=4, **DIA)
    # this work: ladder in the order colours, its M_r reading as the star
    ax.plot(nou, eou, "-", color=INK2, lw=0.9, zorder=2)
    for i, l in enumerate(lvo):
        if l == MR:
            continue
        if l in OC:
            big = l in (MD, MG)
            ax.scatter([nou[i]], [eou[i]], s=(40 if big else 18), color=OC[l], zorder=3, edgecolors="white", linewidths=0.7)
        else:
            ax.scatter([nou[i]], [eou[i]], s=9, color=INK2, zorder=3, linewidths=0)
    ior = lvo.index(MR)
    ax.scatter([nou[ior]], [eou[ior]], s=95, zorder=5, **STAR)
    note(ax, 300, 0.905, "This work", color=INK, ha="left", va="bottom")
    note(ax, 420, 0.715, "Conventional", ha="left", va="bottom")
    ax.set_xscale("log")
    ax.set_xlabel("Number of retained harmonics $N$")
    ax.set_ylabel("Efficiency of the delivered pattern")
    ax.set_ylim(0.30, 1.0)
    ax.set_xlim(ncv[0] * 0.75, ncv[-1] * 1.3)
    # the two delivered patterns, 3 um x 1 um (one period along x, two along y) at their true 3 : 1 aspect, side by side
    wi = 0.43
    hi = wi * W / 3.0 / H
    pattern_inset(ax, [0.06, 0.03, wi, hi], np.load(os.path.join(F31DATA, "f31_final_binary.npy")).astype(float), "Conventional")
    pattern_inset(ax, [0.54, 0.03, wi, hi], np.load(os.path.join(DATA, "f33_delivered_binary.npy")).astype(float), "This work")
    hd = [h_star("This work: delivered and reported, at " + LAB[MR]),
          h_dia("Conventional: delivered, at " + LAB[MR]),
          Line2D([0], [0], color=OC[MD], lw=0.9, ls=(0, (4, 2)), label="Conventional: reported")]
    reg_legend(ax, handles=hd, loc="lower left", bbox_to_anchor=(-0.02, 1.0), ncol=1, handlelength=1.6,
               handletextpad=0.5, borderaxespad=0.2, labelspacing=0.25)
    bold_ticks(ax)
    save(fig, "fig4_a_ladder")


# ---- (b) the run step by step ----------------------------------------------------------------------------------------
def panel_b():
    fig, ax = canvas(70, 48, left=15, top=11)
    traj = np.array([np.nan if v is None else v for v in P1["trajectory_descent"]] + [P1["reported_continuous"]])
    rd = P1["reads"]
    cs = np.array([r["step"] for r in rd])
    qd = np.array([r["Q_%d-%d" % MD] for r in rd]); qg = np.array([r["Q_%d-%d" % MG] for r in rd])
    qr = np.array([r["Q_%d-%d" % MR] for r in rd])
    jd = traj[cs]
    ax.fill_between(cs, qd, jd, where=jd >= qd, color=F2.FILL_BIN, lw=0, zorder=0, interpolate=True)
    ax.fill_between(cs, qr, qd, where=qd >= qr, color=F2.FILL_TRUNC, lw=0, zorder=0, interpolate=True)
    ax.plot(np.arange(len(traj)), traj, color=OC[MD], lw=1.2, zorder=3)
    ax.plot(cs, qd, "o", ms=2.7, mfc="white", mec=OC[MD], mew=0.8, zorder=4)
    ax.plot(cs, qg, "-s", color=OC[MG], lw=0.8, ms=2.3, mew=0, zorder=2)
    ax.plot(cs, qr, "-D", color=OC[MR], lw=1.0, ms=2.4, mew=0, zorder=2)
    # the conventional run of Fig. 2(b), its pattern at M_r, plotted at the same beta; the diamond = what it delivers
    c31 = D31["part1"]["checkpoints"]
    xs = np.array([c["step"] for c in c31]) * STEPS / 800.0
    yc = np.array([c["Q_top"] for c in c31])
    ax.plot(xs, yc, ls=(0, (2, 1.5)), color=GREY, lw=0.9, zorder=1)
    ax.scatter([xs[-1]], [yc[-1]], s=22, zorder=5, clip_on=False, **DIA)
    # delivered checkpoint of this work = the star
    best = P1["best_step"]
    ib = list(cs).index(best)
    ax.scatter([best], [qr[ib]], s=95, zorder=6, clip_on=False, **STAR)
    ax.annotate("Delivered and reported", xy=(best - 3, qr[ib] - 0.03), xytext=(176, 0.71), fontsize=F2.ANS,
                color=INK, ha="center", va="top", math_fontfamily="stix",
                arrowprops=dict(arrowstyle="-", lw=0.5, color=INK2, shrinkA=1, shrinkB=1))
    ax.axvline(T_MIX, color=GREY, lw=0.6, ls=(0, (3, 2)), zorder=0)
    note(ax, T_MIX + 2, 0.985, "First gradient at " + LAB[MG], ha="left", va="top")
    note(ax, 40, 0.56, "Binarization\ngap", ha="center", va="center", linespacing=1.0)
    ax.annotate("Truncation gap", xy=(118, 0.745), xytext=(118, 0.47), fontsize=F2.ANS, color=INK2, ha="center",
                va="top", arrowprops=dict(arrowstyle="-", lw=0.5, color=INK2, shrinkA=1, shrinkB=0))
    xr = STEPS + 5
    note(ax, xr, traj[-1] + 0.035, "Objective (line) and\npattern (o) at " + LAB[MD], color=INK, va="bottom", ha="left",
         linespacing=1.0)
    note(ax, xr, qg[-1] - 0.005, "Pattern at " + LAB[MG], color=INK, va="center", ha="left")
    note(ax, xr, qr[-1] - 0.06, "Pattern at " + LAB[MR], color=INK, va="center", ha="left")
    note(ax, xr + 3, yc[-1] - 0.005, "Conventional run,\npattern at " + LAB[MR] + "\n(same $\\beta$)", va="center",
         ha="left", linespacing=1.0)
    ax.set_xlim(0, STEPS)
    ax.set_ylim(0, 1.0)
    ax.set_xlabel("Optimization step")
    ax.set_ylabel("Efficiency")
    top = ax.secondary_xaxis("top", functions=(lambda s: s, lambda s: s))
    top.set_xticks([STEPS * math.log(b / 2) / math.log(1000) for b in F2.BETA_TICKS])
    top.set_xticklabels([str(b) for b in F2.BETA_TICKS])
    top.set_xlabel("Projection sharpness $\\beta$", labelpad=2)
    top.tick_params(length=2.5)
    bold_ticks(ax, top)
    save(fig, "fig4_b_run")


# ---- (c) the 24 initial designs of Fig. 2(c): delivered by the conventional workflow -> delivered by this work --------
def panel_c():
    fig, ax = canvas(160, 38, left=15, top=8)
    rows = sorted(AN["1"]["rows"], key=lambda r: r["T_Qr"])          # the order of Fig. 2(c)
    x = np.arange(len(rows))
    tq = np.array([r["T_Qr"] for r in rows]); bq = np.array([r["B_Qr"] for r in rows])
    k14 = [i for i, r in enumerate(rows) if r["i"] == P1["index"]][0]
    ax.axvspan(k14 - 0.45, k14 + 0.45, color=BAND, zorder=0)
    for i in range(len(rows)):
        if bq[i] - tq[i] > 0.06:
            up_arrow(ax, x[i], tq[i], bq[i])
    ax.scatter(x, tq, s=18, zorder=3, **DIA)
    ax.scatter(x, bq, s=60, zorder=4, **STAR)
    ieq = int(np.argmin(np.abs(bq - tq)))
    note(ax, x[ieq], tq[ieq] - 0.07, "Equal", ha="center", va="top")
    note(ax, k14, 0.03, "Initial design\nof (a, b)", ha="center", va="bottom", linespacing=1.0)
    gain = bq - tq
    note(ax, len(rows) - 0.6, 0.06,
         "Arrow: gain of this work (median %.2f)\nThis work higher for %d of %d initial designs"
         % (np.median(gain), int((gain > 0).sum()), len(rows)), ha="right", va="bottom", linespacing=1.15)
    ax.set_xticks([])
    ax.set_xlim(-0.8, len(rows) - 0.2)
    ax.set_ylim(0, 1.0)
    ax.set_xlabel("The 24 initial designs of Fig. 2(c), in the same order")
    ax.set_ylabel("Delivered efficiency at " + LAB[MR])
    hd = [h_dia("Conventional workflow: delivered, at " + LAB[MR]),
          h_star("This work: delivered and reported, at " + LAB[MR])]
    reg_legend(ax, handles=hd, loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=2, handletextpad=0.4,
               columnspacing=2.5, borderaxespad=0.2)
    bold_ticks(ax)
    save(fig, "fig4_c_runs24")


# ---- (d) the four transmitted channels ------------------------------------------------------------------------------
def _jitter(v, width=0.21, ncol=5):
    """Spread the points of one column over ncol sub-columns, neighbours in value on different sub-columns."""
    order = np.argsort(v)
    j = np.empty(len(v))
    j[order] = ((np.arange(len(v)) % ncol) - (ncol - 1) / 2.0) * width / (ncol - 1)
    return j


def panel_d():
    fig, ax = canvas(78, 45, left=17, bottom=20, top=8)
    for j, m in enumerate((1, 2, 3, 4)):
        rr = AN[str(m)]["rows"]
        tq = np.array([r["T_Qr"] for r in rr]); bq = np.array([r["B_Qr"] for r in rr])
        x0, x1 = j - 0.2, j + 0.2
        ax.scatter(x0 + _jitter(tq), tq, s=13, zorder=3, **DIA)
        ax.scatter(x1 + _jitter(bq), bq, s=34, zorder=3, **STAR)
        for xx, v in ((x0, np.median(tq)), (x1, np.median(bq))):
            median_bar(ax, xx - 0.15, xx + 0.15, v)
        nh = int((bq > tq).sum())
        tr = ax.get_xaxis_transform()
        note(ax, j, -0.13, "%d of %d" % (nh, len(rr)), transform=tr, ha="center", va="top", color=INK)
        note(ax, j, -0.235, "×%.2f" % AN[str(m)]["price_ratio_B_over_T"], transform=tr, ha="center", va="top", color=INK)
    tr = ax.get_xaxis_transform()
    note(ax, -0.62, -0.13, "This work higher", transform=tr, ha="right", va="top")
    note(ax, -0.62, -0.235, "Cost per run", transform=tr, ha="right", va="top")
    ax.set_xticks(range(4)); ax.set_xticklabels(["(1,0)", "(2,0)", "(3,0)", "(4,0)"])
    ax.set_xlim(-0.55, 3.55)
    ax.set_ylim(0, 1.0)
    ax.set_xlabel("Target channel", labelpad=30)
    ax.set_ylabel("Delivered efficiency at " + LAB[MR])
    hd = [h_dia("Conventional", ms=3.6), h_star("This work", ms=7.0),
          Line2D([0], [0], color=INK, lw=1.3, label="Median")]
    reg_legend(ax, handles=hd, loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=3, handlelength=1.4,
               handletextpad=0.4, columnspacing=1.6, borderaxespad=0.2)
    bold_ticks(ax)
    save(fig, "fig4_d_channels")


# ---- (e) optional refinement: which runs it lifts --------------------------------------------------------------------
def refinement_points():
    """Every refinement chain at the released setting (beta = 64) on P2 under the beta -> 2000 schedule (as
    f33_plot.refinement_points): S7 = parents are mixed-order runs without the screen (best and weakest run of each
    group of three at m = 1, weakest run of each group at m = 4); F33 = parents are runs of the Sec. 3.2 workflow
    (m = 1).  Efficiencies at the first rung of the reference ladder ((40,6) at m = 1, (52,7) at m = 4)."""
    pts = []
    S = json.load(open(os.path.join(S7DATA, "s7_chain_b2000.json"), encoding="utf-8"))["units"]
    for k, u in S.items():
        if k.split("|")[1] in ("chain_b64", "repair_b64"):
            pts.append({"src": "S7", "key": k, "step": u["parent_step"], "before": u["parent_eta_rung1"],
                        "after": u["final_eta_rung1"]})
    RF = json.load(open(os.path.join(DATA, "f33_refine.json"), encoding="utf-8"))["chains"]
    for k, c in RF.items():
        pts.append({"src": "F33", "key": k, "step": c["parent_step"], "before": c["parent_rung1"],
                    "after": c["final_rung1"]})
    return pts


def panel_e():
    fig, ax = canvas(64, 45, left=17, bottom=14, top=12)
    pts = refinement_points()
    EARLY = 110
    ax.axvspan(0, EARLY, color=BAND, zorder=0)
    note(ax, EARLY / 2, 0.985, "Run stopped improving\nbefore step %d" % EARLY, ha="center", va="top", linespacing=1.0)
    for p in pts:
        if p["after"] - p["before"] > 0.01:
            up_arrow(ax, p["step"], p["before"], p["after"], shrink_a=3.2, shrink_b=1.0, lw=0.9)
    s7 = [p for p in pts if p["src"] == "S7"]
    f33 = [p for p in pts if p["src"] == "F33"]
    ax.scatter([p["step"] for p in s7], [p["before"] for p in s7], s=20, marker="o", facecolors="white",
               edgecolors=INK2, linewidths=0.8, zorder=3)
    ax.scatter([p["step"] for p in f33], [p["before"] for p in f33], s=52, marker="*", color=INK, linewidths=0,
               zorder=4)
    # read-off labels on the largest change
    pe = max(pts, key=lambda p: p["after"] - p["before"])
    note(ax, pe["step"] - 6, pe["before"], "Before", ha="right", va="center")
    note(ax, pe["step"] - 6, pe["after"] - 0.01, "After\nrefinement", ha="right", va="center", linespacing=1.0)
    early = [p for p in pts if p["step"] < EARLY]
    late = [p for p in pts if p["step"] >= EARLY]
    imp = lambda ps: sum(1 for p in ps if p["after"] - p["before"] > 0.01)            # noqa: E731
    yb = 0.33
    note(ax, EARLY / 2, yb - 0.075, "Improved: %d of %d" % (imp(early), len(early)), color=INK, ha="center", va="center")
    note(ax, 170, 0.985, "Improved: %d of %d" % (imp(late), len(late)), color=INK, ha="center", va="top")
    # where the 72 runs of this work had their best checkpoint
    steps72 = [r["B_step"] for m in ("1", "2", "3", "4") for r in AN[m]["rows"]]
    lo, hi = min(steps72), max(steps72)
    ax.plot([lo, hi], [yb, yb], color=INK, lw=1.4, solid_capstyle="butt", zorder=3)
    for xx in (lo, hi):
        ax.plot([xx, xx], [yb - 0.018, yb + 0.018], color=INK, lw=1.0, zorder=3)
    note(ax, (lo + hi) / 2, yb - 0.03, "All %d runs of\nthis work peaked here" % len(steps72), color=INK,
         ha="center", va="top", linespacing=1.0)
    ax.set_xlim(0, STEPS + 6)
    ax.set_ylim(0.12, 1.0)
    ax.set_xlabel("Step at which the run peaked (best checkpoint)")
    ax.set_ylabel("Efficiency before and after refinement")
    hd = [Line2D([0], [0], marker="*", ls="none", color=INK, mew=0, ms=7.5, label="Run of this work, (1,0)"),
          Line2D([0], [0], marker="o", ls="none", mfc="white", mec=INK2, mew=0.8, ms=4.3,
                 label="Mixed-order run without the screen, (1,0) and (4,0)")]
    reg_legend(ax, handles=hd, loc="lower left", bbox_to_anchor=(-0.02, 1.0), ncol=1, handlelength=1.2,
               handletextpad=0.4, borderaxespad=0.2, labelspacing=0.25)
    bold_ticks(ax)
    save(fig, "fig4_e_refinement")


if __name__ == "__main__":
    which = sys.argv[1:] or ["key", "a", "b", "c", "d", "e"]
    for w in which:
        {"key": legend_orders, "a": panel_a, "b": panel_b, "c": panel_c, "d": panel_d, "e": panel_e}[w]()
    print("written to", OUT)
