"""F33 -- reference-order reads for Fig. 4 of manuscript Sec. 3.3.

Every delivered pattern of both workflows, P2, targets m = 1..4, is evaluated at
the reference order M_r = the upper rung of the order rule's ladder
((48,7) for m <= 2, (60,9) for m = 3, (64,9) for m = 4):
  T  conventional workflow (S7, README schedule, 800 steps, single order):
     the final binary (its delivery); the S7 JSON has the rung-1 read only.
  B  guarded mixed-order tickets (F33 / S10 arm B): the delivered checkpoint.
Reads already made elsewhere are reused and cross-checked by sha1:
  T m=1 : F31 part 3 (Q_top of the 24 final binaries);
  B m=3/4 group winners : S10 / F33 group records (eta_top).
Also: the descent-order read of T's final binary for m = 2..4 (S7 v1 did not
store it), so the conventional report can be split into relaxation + truncation.

Resumable (data/f33_reads_<who>_m<list>.json, one entry per pattern).  GPU complex64, eig on
the CPU, FMM_THREADS=3.
  python f33_reads.py --who T --m 2,3,4
  python f33_reads.py --who B --m 1,2,3,4
"""
import argparse
import json
import os
import sys
import time

os.environ.setdefault("TFMM_EIG_DEVICE", "cpu")
os.environ.setdefault("FMM_THREADS", "3")

import numpy as np                                                    # noqa: E402
import torch                                                          # noqa: E402

_HERE = os.path.dirname(os.path.abspath(__file__))
_EXP = os.path.abspath(os.path.join(_HERE, "..", ".."))
sys.path.insert(0, os.path.join(_EXP, "S6_lottery_pricing", "scripts"))
import s6_common as C                                                 # noqa: E402

DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
S7DATA = os.path.join(_EXP, "S7_headtohead", "data")
F31DATA = os.path.join(_EXP, "F31_section31_figures", "data")
# output: data/f33_reads_<who>_m<list>.json (one file per parallel lane)


def log(msg, fh):
    line = time.strftime("%Y-%m-%d %H:%M:%S ") + msg
    print(line, flush=True)
    fh.write(line + "\n")
    fh.flush()


def load_bin(path):
    z = np.load(path)
    shape = tuple(int(v) for v in z["shape"])
    b = np.unpackbits(z["packed"], axis=1)[:, :shape[1]]
    return torch.from_numpy(b.astype("float64"))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--who", default="T")
    ap.add_argument("--m", default="1,2,3,4")
    a = ap.parse_args()
    device = C.setup_runtime()
    fh = open(os.path.join(DATA, "logs", "f33_reads.log"), "a", encoding="utf-8")
    out = os.path.join(DATA, "f33_reads_%s_m%s.json" % (a.who, a.m.replace(",", "")))   # one file per lane (lanes run in parallel)
    R = json.load(open(out, encoding="utf-8")) if os.path.exists(out) else {"meta": {}, "reads": {}}
    R["meta"] = {"what": "reference-order reads of delivered patterns (Fig. 4)", "threads": os.environ.get("FMM_THREADS"),
                 "eig_device": os.environ.get("TFMM_EIG_DEVICE"), "device": device}
    cfg = C.make_cfg(5)
    T = json.load(open(os.path.join(S7DATA, "s7_T_b2000.json"), encoding="utf-8"))["units"]
    f31 = {r["index"]: r for r in json.load(open(os.path.join(F31DATA, "f31_fig2.json"), encoding="utf-8"))["part3"]["runs"]}
    for m in [int(x) for x in a.m.split(",")]:
        od = C.orders_for(m, cfg)
        ctx = C.make_ctx(cfg, (m, 0), od["descent"], od["gate"], device)
        if a.who == "T":
            items = sorted(((k, u) for k, u in T.items() if k.startswith("m%d|T|" % m)), key=lambda kv: kv[1]["index"])
            for k, u in items:
                key = "T|m%d|s%02d" % (m, u["index"])
                if key in R["reads"]:
                    continue
                b = load_bin(os.path.join(S7DATA, u["deliver_final"]["files"]["binary"]))
                sha = C.sha1_of(b)
                assert sha == u["deliver_final"]["sha1"], key
                t0 = time.perf_counter()
                if m == 1:
                    r = f31[u["index"]]
                    rec = {"Q_top": r["Q_top"], "Q_descent": r["Q_descent"], "source": "F31 part3"}
                else:
                    rec = {"Q_top": C.eta(b, od["top"], ctx), "Q_descent": C.eta(b, od["descent"], ctx), "source": "F33"}
                rec.update({"top": list(od["top"]), "descent": list(od["descent"]), "sha1": sha, "seed": u["seed"],
                            "reported": u["reported"], "Q_gate": u["deliver_final"]["eta_gate"], "Q_rung1": u["deliver_final"]["eta_rung1"],
                            "wall_s": time.perf_counter() - t0})
                R["reads"][key] = rec
                C.save_json(out, R)
                log("%s top %s %.4f descent %.4f (reported %.4f, rung1 %.4f) %.0f s" % (key, od["top"], rec["Q_top"], rec["Q_descent"],
                                                                                        rec["reported"], rec["Q_rung1"], rec["wall_s"]), fh)
        else:
            path = os.path.join(DATA, "s10_B_m%d.json" % m)
            B = json.load(open(path, encoding="utf-8"))
            winners = {}
            for g in B.get("groups", {}).values():
                winners[g["winner"]] = g["eta_top"]
            for k, u in sorted(B["tickets"].items()):
                key = "B|m%d|%s" % (m, k)
                if key in R["reads"]:
                    continue
                db = u["deliver_best"]
                b = load_bin(os.path.join(DATA, db["files"]["binary"]))
                sha = C.sha1_of(b)
                assert sha == db["sha1"], key
                t0 = time.perf_counter()
                if u["index"] in winners:
                    qt, src = winners[u["index"]], "group record"
                else:
                    qt, src = C.eta(b, od["top"], ctx), "F33"
                ck = [c for c in u["checkpoints"] if c["step"] == db["step"]][0]
                rec = {"Q_top": qt, "source": src, "top": list(od["top"]), "sha1": sha, "seed": u["seed"], "best_step": db["step"],
                       "Q_gate": db["eta_gate"], "Q_rung1": db["eta_rung1"], "Q_descent": ck["eta_binary_descent"],
                       "reported_continuous": u["reported_continuous"], "wall_s": time.perf_counter() - t0}
                R["reads"][key] = rec
                C.save_json(out, R)
                log("%s top %s %.4f (gate %.4f, rung1 %.4f, best@%d) %s %.0f s" % (key, od["top"], qt, db["eta_gate"], db["eta_rung1"],
                                                                                db["step"], src, rec["wall_s"]), fh)
    log("reads done: %s m=%s" % (a.who, a.m), fh)


if __name__ == "__main__":
    main()
