"""F33 -- one guarded mixed-order run read step by step (Fig. 4(a,b) of Sec. 3.3).

The run: P2, target (1,0), seed 151014 = the initial design of the conventional
run of Fig. 2(a,b) (S7 T m=1 index 14).  It is ticket s14 of f33_tickets.py
(m=1); this script replays it with the same code path (s10_e3.PolicyDescent,
arm B) and keeps a read-only copy of the latent density every EVERY steps and at
the 30 checkpoints of the protocol.  Copies do not touch the optimizer, so the
replay is the same run; the script checks this against the stored ticket
(trajectory, gate checkpoints, guard events, delivered pattern).

  part 1: at every stored step, the thresholded pattern at M_d (16,2),
          M_g (28,4), rung 1 (40,6) and M_r (48,7), and the smooth objective at
          M_d (the trajectory, with the probe value at gate-order steps).
  part 2: the delivered pattern on the order ladder (4,1) ... (64,9), as Fig. 2(a).

Descriptive.  GPU complex64, eig on the CPU, FMM_THREADS=3.
  python f33_traj.py [--part 1|2]
"""
import argparse
import json
import os
import sys
import time

os.environ.setdefault("TFMM_EIG_DEVICE", "cpu")
os.environ.setdefault("TFMM_GAP_ONLY_DIAGNOSTICS", "1")
os.environ.setdefault("FMM_THREADS", "3")

import numpy as np                                                    # noqa: E402

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import f33_tickets as F                                               # noqa: E402

S10 = F.S10
C = S10.C
DATA = F.DATA
OUT = os.path.join(DATA, "f33_traj.json")
M, INDEX, SEED = 1, 14, 151014
EVERY = 6
LADDER = [(4, 1), (8, 1), (12, 2), (16, 2), (20, 3), (24, 3), (28, 4), (32, 5), (36, 5),
          (40, 6), (44, 6), (48, 7), (52, 7), (56, 8), (60, 9), (64, 9)]


class Rec(S10.PolicyDescent):
    """PolicyDescent that stores latent copies at chosen steps (one step at a time)."""

    def run_to(self, step):
        if not hasattr(self, "store"):
            self.store = {0: self.latent.detach().cpu().clone()}
        end = min(int(step), self.steps)
        while self.t < end:
            super().run_to(self.t + 1)
            if self.t in self.keep:
                self.store[self.t] = self.latent.detach().cpu().clone()
        return self


def log(msg, fh):
    line = time.strftime("%Y-%m-%d %H:%M:%S ") + msg
    print(line, flush=True)
    fh.write(line + "\n")
    fh.flush()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--part", default="1,2")
    a = ap.parse_args()
    parts = [int(x) for x in a.part.split(",")]
    device = C.setup_runtime()
    S10.assert_eig_cpu()
    fh = open(os.path.join(DATA, "logs", "f33_traj.log"), "a", encoding="utf-8")
    R = json.load(open(OUT, encoding="utf-8")) if os.path.exists(OUT) else {"meta": {}}
    ref = json.load(open(os.path.join(DATA, "s10_B_m%d.json" % M), encoding="utf-8"))["tickets"]["s%02d" % INDEX]
    assert ref["seed"] == SEED
    arm = S10.ARMS["B"]
    cfg = C.make_cfg(5)
    od = C.orders_for(M, cfg)
    ctx = C.make_ctx(cfg, (M, 0), od["descent"], od["gate"], device)
    tau = S10.load_tau()
    beta_fn_t, u_fn = S10.make_ramp(arm["ramp"])
    ck = S10.S7.o_ckpts(S10.STEPS)
    reads = [od["descent"], od["gate"], od["rung1"], od["top"]]
    if 1 in parts:
        keep = sorted(set(range(0, S10.STEPS + 1, EVERY)) | set(ck) | {S10.STEPS})
        pol = S10.GradPolicy(ctx, od, arm, tau, None)
        d = Rec(ctx, SEED, S10.STEPS, lambda t, steps: beta_fn_t(t), u_fn, ck, [], pol, arm["lr_index"])
        d.keep = set(keep)
        t0 = time.perf_counter()
        r = d.finish()
        wall = time.perf_counter() - t0
        diff = max(abs((x or 0.0) - (y or 0.0)) for x, y in zip(r["trajectory"], ref["trajectory"]))
        dck = max(abs(c1["eta_gate"] - c2["eta_gate"]) for c1, c2 in zip(r["checkpoints"], ref["checkpoints"]))
        ev_same = [(e["t"], e["action"]) for e in pol.events] == [(e["t"], e["action"]) for e in ref["events"]]
        sha = C.sha1_of(r["best"]["binary"])
        log("replay s%02d: traj max|diff| %.3g, gate ckpt max|diff| %.3g, guard events same %s, delivered sha1 %s (%s), best@%d, %.1f min"
            % (INDEX, diff, dck, ev_same, sha[:10], "SAME" if sha == ref["deliver_best"]["sha1"] else "DIFFERENT",
               r["best"]["step"], wall / 60), fh)
        rows = []
        for s in keep:
            lat = d.store[s]
            b = S10.app_hard_binary(lat, cfg, ctx.mode)
            row = {"step": s, "beta": beta_fn_t(s), "sha1": C.sha1_of(b)}
            for lv in reads:
                row["Q_%d-%d" % tuple(lv)] = C.eta(b, lv, ctx)
            rows.append(row)
            log("  step %3d beta %7.2f | %s" % (s, row["beta"], " ".join("%s %.4f" % (k[2:], v) for k, v in row.items() if k.startswith("Q_"))), fh)
        R["part1"] = {"seed": SEED, "index": INDEX, "m": M, "orders": {k: list(v) for k, v in od.items()}, "every": EVERY,
                      "replay_traj_max_abs_diff": diff, "replay_gate_max_abs_diff": dck, "replay_guard_events_same": ev_same,
                      "delivered_sha1_same": sha == ref["deliver_best"]["sha1"], "best_step": r["best"]["step"],
                      "trajectory": r["trajectory"], "trajectory_descent": r["trajectory_descent"], "level_series": r["level_series"],
                      "checkpoints": r["checkpoints"], "reported_continuous": r["reported_continuous"], "reads": rows,
                      "events": pol.events, "wall_replay_s": wall}
        C.save_json(OUT, R)
        np.save(os.path.join(DATA, "f33_delivered_binary.npy"), r["best"]["binary"].numpy().astype(np.uint8))
        np.save(os.path.join(DATA, "f33_delivered_latent.npy"), r["best"]["latent"].numpy().astype(np.float64))
    if 2 in parts:
        import torch
        b = torch.from_numpy(np.load(os.path.join(DATA, "f33_delivered_binary.npy")).astype(np.float64))
        assert C.sha1_of(b) == ref["deliver_best"]["sha1"]
        lad = []
        for lv in LADDER:
            t0 = time.perf_counter()
            e = C.eta(b, lv, ctx)
            lad.append({"level": list(lv), "n_terms": (2 * lv[0] + 1) * (2 * lv[1] + 1), "eta": e, "wall_s": time.perf_counter() - t0})
            log("  ladder %s eta %.4f (%.0f s)" % (lv, e, lad[-1]["wall_s"]), fh)
        R["part2"] = {"delivered_ladder": lad, "sha1": ref["deliver_best"]["sha1"]}
        C.save_json(OUT, R)
    log("f33_traj done parts %s" % parts, fh)


if __name__ == "__main__":
    main()
