"""F33 -- numbers of manuscript Sec. 3.3 (zero solves).

Pairs, by initial design (seed 150000 + 1000 m + i), the conventional workflow
(S7 T: 800 steps, single order, final field, reported = smooth objective at M_d)
with the guarded mixed-order workflow (F33/S10 arm B), P2, m = 1..4, and reads
everything at the reference order M_r (f33_reads_*.json, merged).

Prices: conventional = measured wall time of its 800-step descent;
guarded = measured descent wall time (incl. probes and screen recomputations)
+ 30 gate evaluations at the calibrated price (the delivery is chosen among 30
checkpoints).  m = 3, 4: the price of the guarded workflow is the median over
the six runs made in S10 (uncontended); the later six ran next to other jobs.

Statistics are descriptive: medians, quartiles, counts; E[best of N] by exact
order statistics over all N-subsets with the workflow's own selection rule;
equal wall clock = the conventional workflow gets the money of 3 guarded runs
(fractional N interpolated between floor and ceil, N <= n/2); 95 % intervals by
resampling initial designs (paired), 4000 resamples, seed 0.

  python f33_analyze.py
"""
import itertools
import json
import math
import os

import numpy as np

_HERE = os.path.dirname(os.path.abspath(__file__))
_EXP = os.path.abspath(os.path.join(_HERE, "..", ".."))
DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
S7DATA = os.path.join(_EXP, "S7_headtohead", "data")
GATE_FWD = {1: 0.75, 2: 0.75, 3: 5.3, 4: 6.9}
N_CKPT = 30
RNG = np.random.default_rng(0)
NBOOT = 4000


def e_best(select, value, N):
    """E[value of the member with the largest `select`] over all N-subsets."""
    n = len(select)
    if N < 1 or N > n:
        return None
    order = np.argsort(-np.asarray(select), kind="stable")
    v = np.asarray(value)[order]
    # member ranked r (0-based, by select) is chosen iff it is in the subset and no higher-ranked one is
    tot = 0.0
    for r in range(n):
        rest = n - r - 1
        if rest >= N - 1:
            tot += v[r] * math.comb(rest, N - 1)
    return tot / math.comb(n, N)


def e_best_frac(select, value, N):
    lo, hi = math.floor(N), math.ceil(N)
    a, b = e_best(select, value, lo), e_best(select, value, hi)
    if a is None or b is None:
        return None
    return a if hi == lo else a + (b - a) * (N - lo)


def q(v):
    a = np.asarray(v, float)
    return {"n": int(a.size), "median": float(np.median(a)), "q1": float(np.percentile(a, 25)), "q3": float(np.percentile(a, 75)),
            "min": float(a.min()), "max": float(a.max())}


def boot(f, n):
    out = []
    for _ in range(NBOOT):
        idx = RNG.integers(0, n, n)
        v = f(idx)
        if v is not None:
            out.append(v)
    return [float(np.percentile(out, 2.5)), float(np.percentile(out, 97.5))]


def main():
    T = json.load(open(os.path.join(S7DATA, "s7_T_b2000.json"), encoding="utf-8"))["units"]
    RD = {}
    for fn in sorted(os.listdir(DATA)):                                    # one reads file per parallel lane
        if fn.startswith("f33_reads_") and fn.endswith(".json"):
            RD.update(json.load(open(os.path.join(DATA, fn), encoding="utf-8"))["reads"])
    out = {"meta": {"note": __doc__.strip().splitlines()[0]}, "m": {}}
    lines = []
    for m in (1, 2, 3, 4):
        B = json.load(open(os.path.join(DATA, "s10_B_m%d.json" % m), encoding="utf-8"))["tickets"]
        rows = []
        for i in range(len(B)):
            b = B["s%02d" % i]
            t = [u for k, u in T.items() if k.startswith("m%d|T|" % m) and u["index"] == i][0]
            assert t["seed"] == b["seed"], (m, i)
            rt, rb = RD.get("T|m%d|s%02d" % (m, i)), RD.get("B|m%d|s%02d" % (m, i))
            if rt is None or rb is None:
                continue
            gs = b["guard_stats"]
            rows.append({
                "i": i, "seed": b["seed"],
                "T_rep": t["reported"], "T_Qd": rt["Q_descent"], "T_Qg": t["deliver_final"]["eta_gate"], "T_Qr1": t["deliver_final"]["eta_rung1"],
                "T_Qr": rt["Q_top"], "T_ckpt_r1": t["deliver_best"]["eta_rung1"], "T_price": t["wall_descent_s"],
                "B_Qg": b["deliver_best"]["eta_gate"], "B_Qr1": b["deliver_best"]["eta_rung1"], "B_Qr": rb["Q_top"], "B_Qd": rb["Q_descent"],
                "B_step": b["deliver_best"]["step"], "B_final_r1": b["deliver_final"]["eta_rung1"], "B_cliff": b["cliff_gate_best_minus_final"],
                "B_price": b["wall_descent_s"] + N_CKPT * GATE_FWD[m], "B_price_s10": b["ticket_cost_s"],
                "B_n_eval": sum(gs["n_eval"].values()), "B_trig": gs["n_trigger"]["norm"], "B_repl": gs["n_true_positive"]["norm"],
                "B_c128": gs["n_c128"], "B_fail": gs["n_trigger"]["raise"] + gs["n_trigger"]["nonfinite"],
            })
        n = len(rows)
        if n == 0:
            continue
        g = lambda k: np.array([r[k] for r in rows])   # noqa: E731
        d = g("B_Qr") - g("T_Qr")
        pT = float(np.median(g("T_price")))
        pB_all = g("B_price")
        pB = float(np.median(pB_all[:6])) if m in (3, 4) else float(np.median(pB_all))
        Nw = 3.0 * pB / pT
        capped = Nw > n / 2
        Nw_used = min(Nw, n / 2)
        res = {
            "n": n,
            "T_reported": q(g("T_rep")), "T_delivered_Mr": q(g("T_Qr")), "T_delivered_Md": q(g("T_Qd")),
            "T_report_minus_delivery": q(g("T_rep") - g("T_Qr")),
            "B_delivered_Mr": q(g("B_Qr")), "B_gate": q(g("B_Qg")), "B_gate_minus_Mr": q(g("B_Qg") - g("B_Qr")),
            "B_Md_minus_Mr": q(g("B_Qd") - g("B_Qr")), "T_Md_minus_Mr": q(g("T_Qd") - g("T_Qr")),
            "paired_B_minus_T_Mr": q(d), "paired_pos": int((d > 0).sum()), "paired_neg": int((d < 0).sum()),
            "paired_median_ci": boot(lambda idx: float(np.median(d[idx])), n),
            "E3_T_own": e_best(g("T_rep"), g("T_Qr"), 3), "E3_T_gate": e_best(g("T_Qg"), g("T_Qr"), 3),
            "E3_B": e_best(g("B_Qg"), g("B_Qr"), 3),
            "E3_diff_ci_own": boot(lambda idx: e_best(g("B_Qg")[idx], g("B_Qr")[idx], 3) - e_best(g("T_rep")[idx], g("T_Qr")[idx], 3), n),
            "price_T_s": pT, "price_B_s": pB, "price_ratio_B_over_T": pB / pT,
            "equal_wall_N_T": Nw, "equal_wall_capped": bool(capped),
            "equal_wall_T_own": e_best_frac(g("T_rep"), g("T_Qr"), Nw_used), "equal_wall_T_gate": e_best_frac(g("T_Qg"), g("T_Qr"), Nw_used),
            "B_best_step": q(g("B_step")), "B_best_step_lt_110": int((g("B_step") < 110).sum()),
            "B_cliffs_gt_0p1": int((g("B_cliff") > 0.1).sum()), "B_collapse_final_r1_lt_0p1": int((g("B_final_r1") < 0.1).sum()),
            "T_collapse_final_Mr_lt_0p1": int((g("T_Qr") < 0.1).sum()),
            "B_screen_per_100_evals": {"triggers": float(100 * g("B_trig").sum() / g("B_n_eval").sum()),
                                       "replaced": float(100 * g("B_repl").sum() / g("B_n_eval").sum())},
            "B_c128_total": int(g("B_c128").sum()), "B_failures_total": int(g("B_fail").sum()),
            "rows": rows,
        }
        out["m"][str(m)] = res
        lines.append("m=%d n=%d | T report %.3f deliv(Mr) %.3f [%.3f,%.3f] | B deliv(Mr) %.3f [%.3f,%.3f] gate-Mr %+.3f | paired %+.3f [%+.3f,%+.3f] CI %s  +%d/-%d"
                     % (m, n, res["T_reported"]["median"], res["T_delivered_Mr"]["median"], res["T_delivered_Mr"]["q1"], res["T_delivered_Mr"]["q3"],
                        res["B_delivered_Mr"]["median"], res["B_delivered_Mr"]["q1"], res["B_delivered_Mr"]["q3"], res["B_gate_minus_Mr"]["median"],
                        res["paired_B_minus_T_Mr"]["median"], res["paired_B_minus_T_Mr"]["q1"], res["paired_B_minus_T_Mr"]["q3"],
                        ["%+.3f" % x for x in res["paired_median_ci"]], res["paired_pos"], res["paired_neg"]))
        lines.append("      E[best of 3] T own %.3f  T gate %.3f  B %.3f  diff CI %s | price T %.0f s  B %.0f s (x%.2f) | equal wall N_T %.2f%s: T own %.3f gate %.3f"
                     % (res["E3_T_own"], res["E3_T_gate"], res["E3_B"], ["%+.3f" % x for x in res["E3_diff_ci_own"]], pT, pB, pB / pT, Nw,
                        " (capped at n/2)" if capped else "", res["equal_wall_T_own"], res["equal_wall_T_gate"]))
        lines.append("      B best step med %.0f (<110: %d) cliffs %d collapses %d | T collapses %d | screen trig %.2f repl %.2f per 100 | c128 %d fail %d"
                     % (res["B_best_step"]["median"], res["B_best_step_lt_110"], res["B_cliffs_gt_0p1"], res["B_collapse_final_r1_lt_0p1"],
                        res["T_collapse_final_Mr_lt_0p1"], res["B_screen_per_100_evals"]["triggers"], res["B_screen_per_100_evals"]["replaced"],
                        res["B_c128_total"], res["B_failures_total"]))
    # ---- one change at a time (SI): the same initial designs, first rung, m = 1, 2 --------------------
    S6 = json.load(open(os.path.join(_EXP, "S6_lottery_pricing", "data", "s6_2d_mixed.json"), encoding="utf-8"))["units"]
    out["ladder_of_changes"] = {}
    for m in (1, 2):
        B = json.load(open(os.path.join(DATA, "s10_B_m%d.json" % m), encoding="utf-8"))["tickets"]
        steps = {"conventional (800 steps, last state)": [], "conventional, best gate checkpoint": [],
                 "219 steps, single order, best gate checkpoint": [], "+ mixed order (k=4 from step 54)": [],
                 "+ screen, mixing from beta>=16 (this work)": []}
        wall = {k: [] for k in steps}
        for i in range(len(B)):
            t = [u for k, u in T.items() if k.startswith("m%d|T|" % m) and u["index"] == i][0]
            s1, s4 = S6["m%d|SINGLE|s%02d" % (m, i)], S6["m%d|MIX4|s%02d" % (m, i)]
            b = B["s%02d" % i]
            assert t["seed"] == s1["seed"] == s4["seed"] == b["seed"]
            vals = [t["deliver_final"]["eta_rung1"], t["deliver_best"]["eta_rung1"], s1["deliver_best"]["eta_rung1"],
                    s4["deliver_best"]["eta_rung1"], b["deliver_best"]["eta_rung1"]]
            for k, v in zip(steps, vals):
                steps[k].append(v)
        base = np.array(steps["conventional (800 steps, last state)"])
        res = {}
        for k, v in steps.items():
            v = np.array(v)
            res[k] = {"rung1": q(v), "paired_vs_conventional": q(v - base), "pos": int((v - base > 0).sum()), "neg": int((v - base < 0).sum())}
            lines.append("  ladder m=%d %-48s rung1 med %.3f [%.3f, %.3f] | vs conventional %+.3f (+%d/-%d)"
                         % (m, k, res[k]["rung1"]["median"], res[k]["rung1"]["q1"], res[k]["rung1"]["q3"],
                            res[k]["paired_vs_conventional"]["median"], res[k]["pos"], res[k]["neg"]))
        out["ladder_of_changes"][str(m)] = res
    json.dump(out, open(os.path.join(DATA, "f33_analysis.json"), "w", encoding="utf-8"), indent=1)
    txt = "\n".join(lines)
    open(os.path.join(DATA, "logs", "f33_analysis.txt"), "w", encoding="utf-8").write(txt + "\n")
    print(txt)


if __name__ == "__main__":
    main()
