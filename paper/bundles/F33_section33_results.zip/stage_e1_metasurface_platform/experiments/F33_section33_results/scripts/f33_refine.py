"""F33 -- the optional refinement of Sec. 3.2 applied to delivered runs of the
guarded mixed-order workflow (Sec. 3.3, 'selective refinement').

Chain = s10_e3.run_chain (the released repair chain; guards on, 30 re-descent
steps with k = 4 from the first step, 15 hops, stop after 12 rejections in a
row, noise 330000 + 10000 m + 100 i + hop) at the released default beta = 64
(the parent's beta* is ignored).  Every acceptance is read at rung 1 (false-
acceptance record); the final incumbent is read at M_r.

Parents are named on the command line (ticket keys of data/s10_B_m<m>.json):
  python f33_refine.py --m 1 --parents s01,s05 --label weak
Descriptive; GPU complex64, eig on the CPU, FMM_THREADS=3.
"""
import argparse
import json
import os
import sys
import time

os.environ.setdefault("TFMM_EIG_DEVICE", "cpu")
os.environ.setdefault("TFMM_GAP_ONLY_DIAGNOSTICS", "1")
os.environ.setdefault("FMM_THREADS", "3")

import numpy as np                                                    # noqa: E402

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import f33_tickets as F                                               # noqa: E402

S10 = F.S10
C = S10.C
DATA = F.DATA
OUT = os.path.join(DATA, "f33_refine.json")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--m", type=int, required=True)
    ap.add_argument("--parents", required=True)
    ap.add_argument("--label", default="")
    a = ap.parse_args()
    real = F.REAL_RUN_CHAIN                                           # the released chain (f33_tickets stubs it for the tickets)
    device = C.setup_runtime()
    S10.assert_eig_cpu()
    fh = open(os.path.join(DATA, "logs", "f33_refine.log"), "a", encoding="utf-8")
    R = json.load(open(OUT, encoding="utf-8")) if os.path.exists(OUT) else {"meta": {}, "chains": {}}
    R["meta"] = {"beta_re": 64.0, "hops": S10.CHAIN_HOPS, "stop_after": S10.CHAIN_STOP, "re_steps": S10.RE_STEPS, "re_k": S10.RE_K,
                 "noise": "330000 + 10000 m + 100 i + hop", "threads": os.environ.get("FMM_THREADS")}
    B = json.load(open(os.path.join(DATA, "s10_B_m%d.json" % a.m), encoding="utf-8"))
    arm = S10.ARMS["B"]
    cfg = C.make_cfg(5)
    od = C.orders_for(a.m, cfg)
    ctx = C.make_ctx(cfg, (a.m, 0), od["descent"], od["gate"], device)
    tau = S10.load_tau()
    S10b = S10
    for key in a.parents.split(","):
        ck = "m%d|%s" % (a.m, key)
        if ck in R["chains"]:
            continue
        par = dict(B["tickets"][key])
        par["beta_star"] = 0.0                                        # -> beta_re = max(0, 64) = 64, the released default
        i = int(key[1:])
        S10b.log("refine m=%d %s (%s): parent gate %.4f r1 %.4f best@%d" % (a.m, key, a.label, par["deliver_best"]["eta_gate"],
                                                                         par["deliver_best"]["eta_rung1"], par["deliver_best"]["step"]), fh)
        t0 = time.perf_counter()
        ch = real(par, a.m, i, ctx, od, arm, tau, device, fh, "Bref")
        wall = time.perf_counter() - t0
        zb = np.load(os.path.join(DATA, ch["files"]["binary"]))
        import torch
        b = torch.from_numpy(np.unpackbits(zb["packed"], axis=1)[:, :int(zb["shape"][1])].astype(np.float64))
        e_top = C.eta(b, od["top"], ctx)
        rd = {}
        for fn in sorted(os.listdir(DATA)):                                # one reads file per parallel lane
            if fn.startswith("f33_reads_") and fn.endswith(".json"):
                rd.update(json.load(open(os.path.join(DATA, fn), encoding="utf-8"))["reads"])
        rd = rd.get("B|m%d|%s" % (a.m, key), {})
        rec = {"m": a.m, "parent": key, "label": a.label, "seed": par["seed"], "parent_step": par["deliver_best"]["step"],
               "parent_gate": par["deliver_best"]["eta_gate"], "parent_rung1": par["deliver_best"]["eta_rung1"],
               "parent_Mr": rd.get("Q_top"), "final_gate": ch["final_eta_gate"], "final_rung1": ch["final_eta_rung1"], "final_Mr": e_top,
               "n_accept": ch["n_accept"], "n_false_accept": ch["n_false_accept"], "hops_run": ch["hops_run"],
               "incumbent_curve": ch["incumbent_curve"], "jumps": ch["jumps"], "wall_s": wall, "files": ch["files"],
               "guard_stats": ch["guard_stats"]}
        R["chains"][ck] = rec
        C.save_json(OUT, R)
        S10b.log("refine m=%d %s done: %d accepts (%d false), gate %.4f -> %.4f, r1 %.4f -> %.4f, Mr %s -> %.4f, %.1f min"
                 % (a.m, key, ch["n_accept"], ch["n_false_accept"], par["deliver_best"]["eta_gate"], ch["final_eta_gate"],
                    par["deliver_best"]["eta_rung1"], ch["final_eta_rung1"], ("%.4f" % rd["Q_top"]) if rd else "?", e_top, wall / 60), fh)


if __name__ == "__main__":
    main()
