"""F33 -- the three small plots of Fig. 3 as separate files, for the user's own redraw of the flowchart
(2026-09-27).  Times New Roman, bold, transparent background; SVG (editable), PDF and PNG (600 dpi), plus CSV
of the plotted data.

  1. gradient order of every step of the run from the initial design of Fig. 2(a,b) (F33 m=1 s14):
     short marks M_d (colour of M_d), tall marks M_g (colour of M_g)
  2. checkpoint values at M_g of the same run, delivered checkpoint ringed
  3. three runs (F33 m=1 s15, s16, s17): values at M_g at the checkpoints, best checkpoint of each ringed,
     the selected run (highest value) drawn thicker.  Run colours: green / teal / crimson, chosen so that
     they are separable from each other and from the three order colours (#0d0887, #aa2395, #f89540) in
     normal vision and in protan / deutan / tritan simulation (dataviz validator: worst all-pairs dE 12.4
     deutan, normal-vision floor 21.1).

  python f33_fig3_parts.py
"""
import csv
import json
import os
import sys

import numpy as np

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _HERE)
import f33_plot as F                                                  # noqa: E402  (style, colours, data paths)
import matplotlib.pyplot as plt                                       # noqa: E402

OUT = os.path.join(F.FIG, "fig3_parts")
MM = F.MM
MDc, MGc = F.OC[F.MD], F.OC[F.MG]
INK, INK2, GREY_L = F.INK, F.INK2, F.GREY_L
RUN_COLOURS = ["#0e810e", "#26a2b5", "#f91561"]                       # green, teal, crimson
STEPS, T_MIX = F.STEPS, F.T_MIX
RC = {"font.weight": "bold", "axes.labelweight": "bold", "font.size": 9, "axes.labelsize": 9,
      "xtick.labelsize": 8.5, "ytick.labelsize": 8.5, "axes.linewidth": 0.9,
      "xtick.major.width": 0.9, "ytick.major.width": 0.9,
      "mathtext.rm": "Times New Roman:bold", "mathtext.it": "Times New Roman:italic:bold",
      "mathtext.bf": "Times New Roman:bold", "savefig.transparent": True}


def save(fig, name):
    os.makedirs(OUT, exist_ok=True)
    for ext, kw in (("svg", {}), ("pdf", {}), ("png", {"dpi": 600})):
        fig.savefig(os.path.join(OUT, "%s.%s" % (name, ext)), bbox_inches="tight", pad_inches=0.02, **kw)
    plt.close(fig)
    print("saved", name)


def write_csv(name, header, rows):
    os.makedirs(OUT, exist_ok=True)
    with open(os.path.join(OUT, name + ".csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)


def main():
    B = F.load_B(1)["tickets"]
    tk = B["s14"]
    lvs = tk["level_series"]
    ck = tk["checkpoints"]
    cs = np.array([c["step"] for c in ck]); qg = np.array([c["eta_gate"] for c in ck])
    best = tk["deliver_best"]["step"]
    with plt.rc_context(RC):
        # 1. gradient order ------------------------------------------------------------------------------------
        fig, ax = plt.subplots(figsize=(92 * MM, 24 * MM))
        xs_d = [t for t in range(STEPS) if lvs[t] == 0]
        xs_g = [t for t in range(STEPS) if lvs[t] == 1]
        ax.vlines(xs_d, 0, 0.5, color=MDc, lw=0.6)
        ax.vlines(xs_g, 0, 1.0, color=MGc, lw=1.2)
        ax.text(STEPS + 5, 0.25, "$M_d$", va="center", ha="left", fontsize=9, color=INK)
        ax.text(STEPS + 5, 0.82, "$M_g$", va="center", ha="left", fontsize=9, color=INK)
        ax.annotate("$\\beta$ = 16", xy=(T_MIX, 1.02), xytext=(T_MIX, 1.32), ha="center", va="bottom", fontsize=8.5,
                    color=INK, arrowprops=dict(arrowstyle="-", lw=0.7, color=INK2), annotation_clip=False)
        ax.set_xlim(-2, STEPS + 2); ax.set_ylim(0, 1.05)
        ax.set_yticks([])
        ax.set_xticks([0, 66, 219])
        ax.set_xlabel("Step", labelpad=1)
        for s_ in ("left", "right", "top"):
            ax.spines[s_].set_visible(False)
        save(fig, "gradient_order")
        write_csv("gradient_order", ["step", "order"], [(t, "M_g (28,4)" if lvs[t] == 1 else "M_d (16,2)") for t in range(STEPS)])

        # 2. checkpoints at M_g -----------------------------------------------------------------------------------
        fig, ax = plt.subplots(figsize=(92 * MM, 46 * MM))
        ax.plot(cs, qg, "-", color=GREY_L, lw=1.0, zorder=1)
        ax.scatter(cs, qg, s=16, color=MGc, linewidths=0, zorder=3)
        ib = list(cs).index(best)
        ax.scatter([best], [qg[ib]], s=90, facecolors="none", edgecolors=INK, linewidths=1.2, zorder=4)
        ax.annotate("Delivered", xy=(best - 4, qg[ib] - 0.04), xytext=(best - 40, qg[ib] - 0.3), ha="center", va="center",
                    fontsize=9, color=INK, arrowprops=dict(arrowstyle="-", lw=0.7, color=INK2))
        ax.set_xlim(-4, STEPS + 6); ax.set_ylim(0, 1.0)
        ax.set_xticks([0, 66, 219]); ax.set_yticks([0, 0.5, 1.0])
        ax.set_xlabel("Step", labelpad=1)
        ax.set_ylabel("Value at $M_g$", labelpad=2)
        for s_ in ("right", "top"):
            ax.spines[s_].set_visible(False)
        save(fig, "checkpoints_at_Mg")
        write_csv("checkpoints_at_Mg", ["step", "beta", "value_at_Mg_(28,4)", "delivered"],
                  [(int(c["step"]), round(c["beta"], 3), round(c["eta_gate"], 5), int(c["step"] == best)) for c in ck])

        # 3. three runs -----------------------------------------------------------------------------------------------
        keys = ["s15", "s16", "s17"]
        runs = [B[k] for k in keys]
        win = max(range(3), key=lambda i: runs[i]["deliver_best"]["eta_gate"])
        order = sorted(range(3), key=lambda i: -runs[i]["deliver_best"]["eta_gate"])
        label_y = {i: 1.0 - 0.13 * rank for rank, i in enumerate(order)}
        fig, ax = plt.subplots(figsize=(72 * MM, 48 * MM))
        rows = []
        for i, r in enumerate(runs):
            c2 = r["checkpoints"]
            x2 = [c["step"] for c in c2]; y2 = [c["eta_gate"] for c in c2]
            ax.plot(x2, y2, "-", color=RUN_COLOURS[i], lw=(2.0 if i == win else 1.1), zorder=2 + (i == win))
            bs, bq = r["deliver_best"]["step"], r["deliver_best"]["eta_gate"]
            ax.scatter([bs], [bq], s=(60 if i == win else 36), facecolors="white", edgecolors=RUN_COLOURS[i],
                       linewidths=(1.6 if i == win else 1.1), zorder=5)
            ax.annotate("%.2f" % bq + ("  selected" if i == win else ""), xy=(bs + 3, bq), xytext=(STEPS + 14, label_y[i]),
                        fontsize=8.5, va="center", ha="left", color=INK, annotation_clip=False,
                        arrowprops=dict(arrowstyle="-", lw=0.8, color=RUN_COLOURS[i], shrinkA=1, shrinkB=2))
            rows += [(k, int(c["step"]), round(c["eta_gate"], 5), int(c["step"] == bs)) for k, c in [(keys[i], c) for c in c2]]
        ax.set_xlim(0, STEPS + 4); ax.set_ylim(0, 1.05)
        ax.set_xticks([0, 66, 219]); ax.set_yticks([0, 0.5, 1.0])
        ax.set_xlabel("Step", labelpad=1)
        ax.set_ylabel("Value at $M_g$", labelpad=2)
        for s_ in ("right", "top"):
            ax.spines[s_].set_visible(False)
        save(fig, "three_runs")
        write_csv("three_runs", ["run", "step", "value_at_Mg_(28,4)", "delivered_checkpoint"], rows)
    json.dump({"run_colours": dict(zip(keys, RUN_COLOURS)), "order_colours": {"M_d": MDc, "M_g": MGc, "M_r": F.OC[F.MR]},
               "runs": {k: {"seed": B[k]["seed"], "best_step": B[k]["deliver_best"]["step"], "value_at_Mg": B[k]["deliver_best"]["eta_gate"]}
                        for k in keys + ["s14"]}},
              open(os.path.join(OUT, "README_parts.json"), "w", encoding="utf-8"), indent=1)


if __name__ == "__main__":
    main()
