"""F33 -- tickets of the final method (S10 arm B = the shipped guarded_mixed
protocol) on P2 for the manuscript's Sec. 3.3, paired by initial design with the
conventional-workflow tickets of S7 (seed = 150000 + 1000 m + i).

  m = 1, 2 : 24 tickets each (seeds 151000-151023 / 152000-152023), new.
  m = 3, 4 : S10 ran s00-s05 (seeds 153000-153005 / 154000-154005); the JSON and
             designs were copied into ./data and this script adds s06-s11.

Everything numerical is S10's code path (s10_e3.run_arm, arm B); this wrapper
only (i) points DATA/DESIGNS/LOGS at ./data, (ii) adds the repair-trigger bar
for m = 1, 2 (median rung-1 value of S7's O pool, 24 tickets: 0.814 / 0.764),
(iii) replaces the repair chain by a stub, so a group only RECORDS whether the
numeric trigger would have fired (refinement is run separately), and
(iv) --check: replays S10 B m=3 s00 to a given step and compares the
trajectory with the stored one (bitwise reproduction test of the code path).

Descriptive; GPU / complex64, eig on the CPU, FMM_THREADS=3 (as S7 / S10).
  python f33_tickets.py --check 120
  python f33_tickets.py --m 1 --n 24
  python f33_tickets.py --m 3 --n 12
"""
import argparse
import json
import os
import sys
import time

os.environ.setdefault("TFMM_EIG_DEVICE", "cpu")
os.environ.setdefault("TFMM_GAP_ONLY_DIAGNOSTICS", "1")
os.environ.setdefault("FMM_THREADS", "3")

_HERE = os.path.dirname(os.path.abspath(__file__))
_S10 = os.path.abspath(os.path.join(_HERE, "..", "..", "S10_e3_v2", "scripts"))
sys.path.insert(0, _S10)
import s10_e3 as S10                                                  # noqa: E402

C = S10.C
DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
S10_DATA = os.path.abspath(os.path.join(_HERE, "..", "..", "S10_e3_v2", "data"))
S10.DATA, S10.DESIGNS, S10.LOGS = DATA, os.path.join(DATA, "designs"), os.path.join(DATA, "logs")
S10.POOL_MEDIAN_RUNG1.update({1: 0.8137, 2: 0.7638})               # S7 O pool (24 MIX4 tickets) rung-1 medians
S10.SEEDS.update({1: [151000 + i for i in range(24)], 2: [152000 + i for i in range(24)]})


def _no_chain(*args, **kwargs):
    return None                                                       # refinement is run separately (f33_refine.py)


REAL_RUN_CHAIN = S10.run_chain                                        # kept for f33_refine.py
S10.run_chain = _no_chain


def check(upto):
    """Replay S10 B m=3 s00 (seed 153000) to step ``upto`` and compare."""
    device = C.setup_runtime()
    S10.assert_eig_cpu()
    ref = json.load(open(os.path.join(S10_DATA, "s10_B_m3.json"), encoding="utf-8"))["tickets"]["s00"]
    arm = S10.ARMS["B"]
    cfg = C.make_cfg(5)
    od = C.orders_for(3, cfg)
    ctx = C.make_ctx(cfg, (3, 0), od["descent"], od["gate"], device)
    tau = S10.load_tau()
    beta_fn_t, u_fn = S10.make_ramp(arm["ramp"])
    pol = S10.GradPolicy(ctx, od, arm, tau, None)
    d = S10.PolicyDescent(ctx, 153000, S10.STEPS, lambda t, steps: beta_fn_t(t), u_fn, S7ck(), [], pol, arm["lr_index"])
    t0 = time.perf_counter()
    d.run_to(upto)
    a, b = d.traj[:upto], ref["trajectory"][:upto]
    diff = max(abs((x or 0.0) - (y or 0.0)) for x, y in zip(a, b))
    cka = [(c["step"], c["eta_gate"]) for c in d.ckpts if c["step"] <= upto]
    ckb = [(c["step"], c["eta_gate"]) for c in ref["checkpoints"] if c["step"] <= upto]
    dck = max(abs(x[1] - y[1]) for x, y in zip(cka, ckb))
    ev_a = [(e["t"], e["action"]) for e in pol.events if e["t"] < upto]
    ev_b = [(e["t"], e["action"]) for e in ref["events"] if e["t"] < upto]
    print("check B m=3 s00 to step %d: traj max|diff| %.3g over %d steps; gate ckpt max|diff| %.3g over %d; guard events %s vs %s -> %s; %.1f min"
          % (upto, diff, len(a), dck, len(cka), ev_a, ev_b, "SAME" if ev_a == ev_b else "DIFFERENT", (time.perf_counter() - t0) / 60), flush=True)


def S7ck():
    return S10.S7.o_ckpts(S10.STEPS)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--m", type=int, default=1)
    ap.add_argument("--n", type=int, default=24)
    ap.add_argument("--check", type=int, default=0)
    a = ap.parse_args()
    if a.check:
        check(a.check)
        return
    os.makedirs(S10.LOGS, exist_ok=True)
    S10.V.GAP_ONLY_DIAGNOSTICS = True
    device = C.setup_runtime()
    S10.assert_eig_cpu()
    fh = open(os.path.join(S10.LOGS, "f33_tickets.log"), "a", encoding="utf-8")
    seeds = S10.SEEDS[a.m][:a.n]
    S10.log("F33 start | arm B | m=%d | n=%d | seeds %d-%d | threads %s | device %s"
            % (a.m, len(seeds), seeds[0], seeds[-1], os.environ.get("FMM_THREADS"), device), fh)
    t0 = time.perf_counter()
    S10.run_arm("B", a.m, seeds, device, fh, S10.load_tau())
    S10.log("F33 m=%d done in %s" % (a.m, C.fmt_s(time.perf_counter() - t0)), fh)


if __name__ == "__main__":
    main()
