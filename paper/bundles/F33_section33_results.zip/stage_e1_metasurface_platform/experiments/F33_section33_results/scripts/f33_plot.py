"""F33 -- figures of manuscript Secs. 3.2 and 3.3 (Times New Roman; the style,
order colours and ink rules of Fig. 2 -- imported from F31's f31_plot_v2).

Fig. 3 (method schematic, Sec. 3.2)
  (a) the three orders of the workflow and what each is used for
  (b) one run: beta ramp; order of every gradient; gate readings at the 30 checkpoints
  (c) selection across runs, reporting at M_r, optional refinement
  (d) minimal model of Eq. (12): gap along a run, single order vs one gate gradient in k
Fig. 4 (results, Sec. 3.3) -- see fig4().

  python f33_plot.py [fig3|fig4|all]
"""
import json
import math
import os
import sys

import numpy as np

_HERE = os.path.dirname(os.path.abspath(__file__))
_EXP = os.path.abspath(os.path.join(_HERE, "..", ".."))
sys.path.insert(0, os.path.join(_EXP, "F31_section31_figures", "scripts"))
import f31_plot_v2 as P                                               # noqa: E402  (sets rcParams)
import matplotlib.pyplot as plt                                       # noqa: E402
from matplotlib.gridspec import GridSpec, GridSpecFromSubplotSpec     # noqa: E402
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch        # noqa: E402
from matplotlib.lines import Line2D                                   # noqa: E402

DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))
FIG = os.path.abspath(os.path.join(_HERE, "..", "figures"))
OC, INK, INK2, GREY, GREY_L, BAND = P.OC, P.INK, P.INK2, P.GREY, P.GREY_L, P.BAND
MD, MG, MR = P.MD, P.MG, P.MR
R1 = (40, 6)
MM, FULL_W = P.MM, P.FULL_W
LAB = P.LAB
STEPS, T_MIX, K = 219, 66, 4


def save(fig, name):
    os.makedirs(FIG, exist_ok=True)
    for ext in ("png", "pdf"):
        fig.savefig(os.path.join(FIG, "%s.%s" % (name, ext)), bbox_inches="tight", pad_inches=0.02)
    plt.close(fig)
    print("saved", name)


def beta_of(t):
    return 2.0 * 1000.0 ** (t / STEPS)


def load_B(m):
    return json.load(open(os.path.join(DATA, "s10_B_m%d.json" % m), encoding="utf-8"))


def nterms(lv):
    return (2 * lv[0] + 1) * (2 * lv[1] + 1)


# ---------------------------------------------------------------------- Fig. 3
def box(ax, x, y, w, h, text, ls="-", fc="white", ec=None, fs=7.2, lw=0.7):
    ec = ec or INK2
    p = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.006,rounding_size=0.012", fc=fc, ec=ec, lw=lw, ls=ls,
                       transform=ax.transAxes, zorder=2)
    ax.add_patch(p)
    ax.text(x + w / 2, y + h / 2, text, transform=ax.transAxes, ha="center", va="center", fontsize=fs, color=INK, zorder=3,
            linespacing=1.25)
    return p


def arrow(ax, xy0, xy1, ls="-", color=None, rad=0.0, lw=0.8):
    a = FancyArrowPatch(xy0, xy1, transform=ax.transAxes, arrowstyle="-|>", mutation_scale=7, lw=lw, color=color or INK2,
                        ls=ls, connectionstyle="arc3,rad=%g" % rad, zorder=1, shrinkA=0, shrinkB=0)
    ax.add_patch(a)


def minimal_model(k, t_mix=T_MIX, steps=STEPS, alpha=0.02, kappa=6.0, b1=0.9):
    """a: size of a feature the descent order rewards (reward mu(beta), switching on over
    beta 16-128 as the truncation error does in Fig. 2(d)) and the gate order penalizes
    (penalty kappa*a).  Momentum-averaged steps; returns the gap D = mu a + kappa a^2 / 2."""
    a, m, D = 0.0, 0.0, []
    for t in range(steps + 1):
        b = beta_of(t)
        mu = 1.0 / (1.0 + math.exp(-(math.log(b) - math.log(45.0)) / 0.45))
        high = (k is not None) and t >= t_mix and (t - t_mix) % k == 0
        c = -kappa * a if high else mu
        m = b1 * m + (1 - b1) * c
        a = max(a + alpha * m / (1 - b1 ** (t + 1)) * 1.0, 0.0)
        D.append(mu * a + 0.5 * kappa * a * a)
    return np.array(D)


def fig3(m=1, key="s14", group=("s15", "s16", "s17")):
    B = load_B(m)
    tk = B["tickets"][key]
    fig = plt.figure(figsize=(FULL_W, 128 * MM))
    outer = GridSpec(2, 1, figure=fig, height_ratios=[1.0, 0.92], hspace=0.42)
    row1 = GridSpecFromSubplotSpec(1, 2, subplot_spec=outer[0], width_ratios=[0.78, 1.55], wspace=0.22)
    row2 = GridSpecFromSubplotSpec(1, 2, subplot_spec=outer[1], width_ratios=[1.55, 0.78], wspace=0.26)

    # (a) three orders, three roles -------------------------------------------------------
    ax = fig.add_subplot(row1[0, 0])
    ax.axis("off")
    ax.set_xlim(0, 1); ax.set_ylim(0, 1)
    roles = [
        (MD, r"$M_d$", "every gradient before $\\beta=16$, then 3 in 4", "0.08 s per gradient"),
        (MG, r"$M_g$", "1 gradient in 4 after $\\beta=16$; every selection", "0.99 s per gradient"),
        (MR, r"$M_r$", "report of the delivered pattern", "13.5 s per evaluation"),
    ]
    nmax = float(nterms(MR))
    for i, (lv, name, role, cost) in enumerate(roles):
        y = 0.90 - 0.315 * i
        n = nterms(lv)
        ax.text(0.0, y, name + " " + P.olab(lv), ha="left", va="center", fontsize=7.8, color=INK)
        ax.text(1.0, y, cost, ha="right", va="center", fontsize=6.7, color=INK2)
        ax.add_patch(plt.Rectangle((0.0, y - 0.115), 0.86 * n / nmax, 0.05, color=OC[lv], lw=0))
        ax.text(0.86 * n / nmax + 0.015, y - 0.09, "$N=%d$" % n, ha="left", va="center", fontsize=6.7, color=INK2)
        ax.text(0.0, y - 0.175, role, ha="left", va="center", fontsize=7.0, color=INK)
    ax.text(0.0, -0.02, "bar length: number of retained harmonics $N$", ha="left", va="bottom", fontsize=6.5, color=INK2)
    P.panel(ax, "a", x=-0.02, y=1.0)

    # (b) one run ----------------------------------------------------------------------------
    sub = GridSpecFromSubplotSpec(3, 1, subplot_spec=row1[0, 1], height_ratios=[0.8, 0.55, 1.1], hspace=0.12)
    steps = np.arange(STEPS + 1)
    axb = fig.add_subplot(sub[0])
    axb.semilogy(steps, [beta_of(t) for t in steps], color=INK2, lw=1.0)
    axb.axhline(16, color=GREY, lw=0.6, ls=(0, (3, 2)))
    axb.axvline(T_MIX, color=GREY, lw=0.6, ls=(0, (3, 2)))
    axb.text(T_MIX + 3, 2.6, r"first step with $\beta\geq16$", fontsize=6.8, color=INK2, va="bottom")
    axb.set_ylabel(r"$\beta$", labelpad=2)
    axb.set_yticks([2, 16, 128, 1000]); axb.set_yticklabels(["2", "16", "128", "1000"])
    axb.set_xlim(-2, STEPS + 2)
    axb.tick_params(labelbottom=False)
    P.panel(axb, "b", x=-0.1, y=0.98)

    axo = fig.add_subplot(sub[1], sharex=axb)
    lvs = tk["level_series"]
    xs_d = [t for t in range(STEPS) if lvs[t] == 0]
    xs_g = [t for t in range(STEPS) if lvs[t] == 1]
    axo.vlines(xs_d, 0, 0.45, color=OC[MD], lw=0.55)
    axo.vlines(xs_g, 0, 1.0, color=OC[MG], lw=1.1)
    rep = [e for e in tk["events"] if e.get("action") == "jitter"]
    for e in rep:
        axo.plot([e["t"]], [1.25 if e.get("high") else 0.7], marker="v", ms=3.6, color=INK, mew=0, clip_on=False)
    axo.set_ylim(0, 1.35)
    axo.set_yticks([])
    axo.spines["left"].set_visible(False)
    axo.tick_params(labelbottom=False)
    axo.text(STEPS + 4, 0.2, "gradient at " + LAB[MD], fontsize=6.8, color=INK, va="center")
    axo.text(STEPS + 4, 0.85, "gradient at " + LAB[MG], fontsize=6.8, color=INK, va="center")

    axc = fig.add_subplot(sub[2], sharex=axb)
    ck = tk["checkpoints"]
    cs = np.array([c["step"] for c in ck]); qg = np.array([c["eta_gate"] for c in ck])
    best = tk["deliver_best"]["step"]
    axc.plot(cs, qg, "-", color=GREY_L, lw=0.8, zorder=1)
    axc.scatter(cs, qg, s=11, color=OC[MG], zorder=3, linewidths=0)
    ib = list(cs).index(best)
    axc.scatter([best], [qg[ib]], s=70, facecolors="none", edgecolors=INK, linewidths=0.9, zorder=4)
    axc.annotate("delivered checkpoint", xy=(best - 3, qg[ib] + 0.04), xytext=(best - 40, 1.03), fontsize=6.9, color=INK,
                 va="center", ha="right", arrowprops=dict(arrowstyle="-", lw=0.5, color=INK2, shrinkA=1, shrinkB=0))
    axc.set_ylim(0, 1.08)
    axc.set_ylabel("pattern at " + LAB[MG], labelpad=2)
    axc.set_xlabel("optimization step")
    axc.text(4, 0.62, "30 checkpoints\n(binary pattern\nevaluated at " + LAB[MG] + ")", fontsize=6.8, color=INK2, va="center", ha="left")

    # (c) selection, reporting, refinement -------------------------------------------------------
    ax = fig.add_subplot(row2[0, 0])
    ax.axis("off")
    if group is None:
        idx = int(key[1:])
        group = ["s%02d" % i for i in range(3 * (idx // 3), 3 * (idx // 3) + 3)]
    runs = [B["tickets"][g] for g in group]
    win = max(range(3), key=lambda i: runs[i]["deliver_best"]["eta_gate"])
    ax.text(0.10, 0.93, "runs from 3 initial designs;\neach delivers its best checkpoint", transform=ax.transAxes,
            ha="left", va="bottom", fontsize=6.8, color=INK2, linespacing=1.15)
    for i, r in enumerate(runs):
        y0 = 0.64 - i * 0.30
        ins = ax.inset_axes([0.10, y0, 0.20, 0.23])
        c2 = r["checkpoints"]
        x2 = [c["step"] for c in c2]; y2 = [c["eta_gate"] for c in c2]
        ins.plot(x2, y2, "-", color=GREY_L, lw=0.7)
        ins.scatter(x2, y2, s=4, color=OC[MG], linewidths=0, zorder=3)
        bs = r["deliver_best"]["step"]; bq = r["deliver_best"]["eta_gate"]
        ins.scatter([bs], [bq], s=24, facecolors="none", edgecolors=INK, linewidths=0.7, zorder=4)
        ins.set_ylim(0, 1.08); ins.set_xlim(0, STEPS + 4)
        ins.set_xticks([]); ins.set_yticks([])
        for s_ in ins.spines.values():
            s_.set_color(GREY); s_.set_linewidth(0.5)
        ins.text(-0.05, 0.5, "run %d" % (i + 1), transform=ins.transAxes, ha="right", va="center", fontsize=6.8, color=INK2)
        ax.text(0.315, y0 + 0.23 * bq / 1.08, "%.3f" % bq, transform=ax.transAxes, ha="left", va="center", fontsize=6.7,
                color=INK if i == win else INK2, fontweight=("bold" if i == win else "normal"))
        arrow(ax, (0.39, y0 + 0.23 * bq / 1.08), (0.44, 0.70), color=(INK if i == win else GREY_L), lw=(0.9 if i == win else 0.6))
    box(ax, 0.44, 0.58, 0.22, 0.24, "keep the run with\nthe highest value\nat " + LAB[MG])
    arrow(ax, (0.66, 0.70), (0.74, 0.70))
    box(ax, 0.74, 0.58, 0.25, 0.24, "evaluate it at " + LAB[MR] + ":\nthe reported\nefficiency", fc="#f7f6f3")
    box(ax, 0.44, 0.02, 0.55, 0.34, "optional refinement (off by default):\nperturb $\\rightarrow$ 30 steps of Eq. (11) at $\\beta=64$\n$\\rightarrow$ threshold $\\rightarrow$ accept if higher at "
        + LAB[MG] + "\n(up to 15 hops)", ls=(0, (3, 2)), fs=6.7)
    arrow(ax, (0.55, 0.58), (0.55, 0.36), ls=(0, (3, 2)))
    arrow(ax, (0.865, 0.36), (0.865, 0.58), ls=(0, (3, 2)))
    P.panel(ax, "c", x=-0.0, y=0.98)

    # (d) minimal model ----------------------------------------------------------------------------
    ax = fig.add_subplot(row2[0, 1])
    s1 = minimal_model(None); s8 = minimal_model(8); s4 = minimal_model(4)
    ax.axvline(T_MIX, color=GREY, lw=0.6, ls=(0, (3, 2)))
    ax.plot(steps, s1, color=OC[MD], lw=1.3)
    ax.plot(steps, s8, color=OC[MG], lw=1.0, ls=(0, (4, 2)))
    ax.plot(steps, s4, color=OC[MG], lw=1.3)
    top = s1.max()
    ax.text(STEPS * 0.99, s1[-1], "single order", fontsize=6.9, color=INK, ha="right", va="bottom")
    ax.text(STEPS * 0.99, s8[-1] + 0.03 * top, "$k=8$", fontsize=6.9, color=INK, ha="right", va="bottom")
    ax.text(STEPS * 0.99, s4[-1] + 0.03 * top, "$k=4$", fontsize=6.9, color=INK, ha="right", va="bottom")
    ax.set_xlim(0, STEPS)
    ax.set_ylim(0, top * 1.12)
    ax.set_yticks([])
    ax.set_xlabel("Optimization step")
    ax.set_ylabel("Gap $D$ (arbitrary units)")
    ax.text(0.36, 0.60, "minimal model", transform=ax.transAxes, fontsize=6.9, color=INK2, va="top")
    P.panel(ax, "d", x=-0.12, y=1.02)
    save(fig, "fig3_method_panels")        # superseded 2026-09-27 by fig3_flow (user: one flowchart, no panels)


# ---------------------------------------------------------------------- Fig. 3 as one flowchart
def fbox(ax, x0, y0, x1, y1, text=None, ec=None, fc="white", ls="-", lw=0.8, fs=7.0, r=1.4, weight="normal", zorder=2):
    p = FancyBboxPatch((x0, y0), x1 - x0, y1 - y0, boxstyle="round,pad=0,rounding_size=%g" % r, fc=fc, ec=ec or INK2,
                       lw=lw, ls=ls, zorder=zorder)
    ax.add_patch(p)
    if text:
        ax.text((x0 + x1) / 2, (y0 + y1) / 2, text, ha="center", va="center", fontsize=fs, color=INK, linespacing=1.25,
                zorder=zorder + 1, fontweight=weight)
    return p


def fdiamond(ax, cx, cy, hw, hh, text, fs=6.8, ec=None, weight="normal"):
    from matplotlib.patches import Polygon
    ax.add_patch(Polygon([(cx - hw, cy), (cx, cy + hh), (cx + hw, cy), (cx, cy - hh)], closed=True, fc="white",
                         ec=ec or INK2, lw=0.8, zorder=2))
    ax.text(cx, cy, text, ha="center", va="center", fontsize=fs, color=INK, linespacing=1.2, zorder=3, fontweight=weight)


def farrow(ax, pts, ls="-", color=None, lw=0.8, head=True):
    """Polyline arrow through the points (data units); head at the last point."""
    color = color or INK2
    xs, ys = zip(*pts)
    if len(pts) > 2:
        ax.plot(xs[:-1], ys[:-1], color=color, lw=lw, ls=ls, zorder=1, solid_capstyle="butt")
    a = FancyArrowPatch(pts[-2], pts[-1], arrowstyle="-|>" if head else "-", mutation_scale=7, lw=lw, color=color, ls=ls,
                        shrinkA=0, shrinkB=0, zorder=1)
    ax.add_patch(a)


def fig3_flow(m=1, key="s14", group=("s15", "s16", "s17")):
    """Fig. 3: the guarded mixed-order workflow as one flowchart.
    User rulings 2026-09-27: one flowchart, no panels; box text starts with a capital letter; large bold text;
    only explanations a reader can follow from the figure (minimal model moved to SI Fig. S3.6).
    Round 3: 'Design task:' with a colon, polarization added, target channel (m, n); the order-rule entries
    centred; insets with complete axes (ticks and labels); t -> t + 1; the three runs in three colours
    (categorical blue / green / red, validated against the order colours); a wider, taller layout (narrow left
    column, wide middle column, room for the 'No' line).
    Round 4: short decision and update text ('beta_t reaches 16?', 'Adam update'); 'Example run' centred, without
    the pointer to Fig. 2 (the caption carries it); inset text (ticks, axis labels, annotations) in regular weight;
    the three-run inset widened, the run names dropped and only the selected (highest) value labelled.
    Weight handling: the flowchart text is bold explicitly (fbox/fdiamond weight, lab), not through font.weight,
    because a bold font.weight also turns the STIX math fonts bold; box math uses the bold custom mathtext fonts,
    inset math uses STIX in regular weight.
    Round 5: box text FS = 11 pt and the example insets moved left (user's values); the layout re-flowed for the
    larger text (height 186 -> 192 mm, taller design-task / threshold / select boxes, larger checkpoint diamond,
    one-line beta diamond flatter)."""
    B = load_B(m)
    tk = B["tickets"][key]
    W, H = 206.0, 192.0
    FS, FSS, FST, FT = 11.0, 8.4, 9.8, 7.6          # box text, labels, titles, inset ticks
    RUNC = ["#2a78d6", "#008300", "#e34948"]         # three runs: categorical blue / green / red
    rc = {"mathtext.rm": "Times New Roman:bold",
          "mathtext.it": "Times New Roman:italic:bold", "mathtext.bf": "Times New Roman:bold",
          "axes.linewidth": 0.8, "xtick.major.width": 0.8, "ytick.major.width": 0.8}
    REG = dict(fontweight="normal", math_fontfamily="stix")       # inset text: regular Times, math in regular STIX
    with plt.rc_context(rc):
        fig = plt.figure(figsize=(W * MM, H * MM))
        ax = fig.add_axes([0, 0, 1, 1])
        ax.set_xlim(0, W); ax.set_ylim(0, H); ax.axis("off")

        def inset(x0, y0, x1, y1):
            return fig.add_axes([x0 / W, y0 / H, (x1 - x0) / W, (y1 - y0) / H])

        def lab(x, y, s, **kw):
            kw.setdefault("fontsize", FSS)
            kw.setdefault("color", INK)
            return ax.text(x, y, s, fontweight="bold", **kw)

        def style_inset(a):
            a.tick_params(labelsize=FT, length=2.5, pad=1.5, width=0.8)
            for s_ in ("right", "top"):
                a.spines[s_].set_visible(False)
            for t in a.get_xticklabels() + a.get_yticklabels():
                t.set_fontweight("normal")
                t.set_math_fontfamily("stix")

        MDc, MGc, MRc = OC[MD], OC[MG], OC[MR]
        FILL = "#f7f6f3"

        # ---- left column: set-up (x 3-49) --------------------------------------------------------------------
        CXL = 26.0
        fbox(ax, 3, 152, 49, 178, "Design task:\nPeriod, wavelength,\npolarization, materials,\ntarget channel $(m,n)$", fs=FS, weight="bold")
        farrow(ax, [(CXL, 152), (CXL, 146)])
        fbox(ax, 3, 92, 49, 146, fc=FILL)
        lab(CXL, 140.5, "Order rule", ha="center", va="center", fontsize=FST)
        rows = [(MD, "$M_d$ = (16,2)", "Descent order"), (MG, "$M_g$ = (28,4)", "Gate order"), (MR, "$M_r$ = (48,7)", "Reference order")]
        chips, texts = [], []
        for i, (lv, name, role) in enumerate(rows):
            y = 129.3 - 14.0 * i
            chip = plt.Rectangle((0.0, y - 4.2), 4.0, 8.4, color=OC[lv], lw=0, zorder=3)
            ax.add_patch(chip)
            chips.append(chip)
            texts.append(lab(6.5, y + 2.1, name, ha="left", va="center", fontsize=FS))
            texts.append(lab(6.5, y - 2.4, role, ha="left", va="center", fontsize=FSS))
        fig.canvas.draw()                                            # centre the three entries in the box
        inv = ax.transData.inverted()
        right = max(inv.transform(t.get_window_extent(fig.canvas.get_renderer()))[1][0] for t in texts)
        dx = CXL - right / 2.0                                       # group spans x = 0 .. right
        for c in chips:
            c.set_x(c.get_x() + dx)
        for t in texts:
            x_, y_ = t.get_position()
            t.set_position((x_ + dx, y_))
        farrow(ax, [(CXL, 92), (CXL, 86)])
        fbox(ax, 3, 70, 49, 86, "$K$ random\ninitial designs", fs=FS, weight="bold")
        farrow(ax, [(49, 78), (55, 78)])

        # ---- middle column: one run (x 55-142) ------------------------------------------------------------------
        fbox(ax, 55, 3, 142, 189, fc="#fbfaf8", ec=GREY, lw=0.9, r=2.6, zorder=0)
        lab(98.5, 184.3, "Each run: 219 steps", ha="center", va="center", fontsize=FST)
        cx, xl, xr, xloop = 95.0, 60.0, 130.0, 135.5
        fbox(ax, xl, 166, xr, 176, "Step $t$:  $\\beta_t=2\\cdot1000^{\\,t/219}$", fs=FS, weight="bold")
        farrow(ax, [(cx, 166), (cx, 162)])
        hw, hh, yd = 35.0, 8.5, 153.5
        fdiamond(ax, cx, yd, hw, hh, "$\\beta_t$ reaches 16?", fs=FS, weight="bold")
        xg, xd = 76.0, 114.0
        fbox(ax, 60, 126, 92, 136, "Gradient at $M_g$", ec=MGc, lw=1.6, fs=FS, weight="bold")
        fbox(ax, 98, 126, 130, 136, "Gradient at $M_d$", ec=MDc, lw=1.6, fs=FS, weight="bold")
        ye = lambda x: yd - hh + abs(cx - x) / hw * hh                 # noqa: E731  lower edge of the diamond
        farrow(ax, [(xg, ye(xg)), (xg, 136)])
        farrow(ax, [(xd, ye(xd)), (xd, 136)])
        lab(xg - 1.5, 139.5, "Yes", ha="right", va="center")
        lab(xd + 1.5, 139.5, "No", ha="left", va="center")
        fbox(ax, xl, 101, xr, 120, "Screen: if $\\|g\\|$ > 3 × recent median,\nrecompute at $1.01\\beta$ and keep $g$\nonly if the two agree", fs=FS, weight="bold")
        farrow(ax, [(xg, 126), (xg, 120)])
        farrow(ax, [(xd, 126), (xd, 120)])
        farrow(ax, [(cx, 101), (cx, 97)])
        fbox(ax, xl, 88, xr, 97, "Adam update", fs=FS, weight="bold")
        farrow(ax, [(cx, 88), (cx, 84)])
        fdiamond(ax, cx, 75.5, 26.0, 8.5, "Checkpoint\nstep?", fs=FS, weight="bold")
        farrow(ax, [(cx, 67), (cx, 61)])
        lab(cx + 1.6, 64, "Yes", ha="left", va="center")
        fbox(ax, xl, 48, xr, 61, "Threshold; evaluate at $M_g$;\nkeep the best checkpoint", ec=MGc, lw=1.6, fs=FS, weight="bold")
        ax.plot([cx + 26.0, xloop], [75.5, 75.5], color=INK2, lw=1.0, zorder=1)
        lab(cx + 27.5, 76.6, "No", ha="left", va="bottom")
        ax.plot([xr, xloop], [54.5, 54.5], color=INK2, lw=1.0, zorder=1)
        farrow(ax, [(xloop, 54.5), (xloop, 171), (xr, 171)], lw=1.0)
        lab(xloop + 1.2, 113, "$t\\rightarrow t+1$", rotation=90, ha="left", va="center", fontsize=FS)

        # example run: gradient order strip + checkpoint values, complete axes, regular-weight text
        lab(cx, 43.5, "Example run", ha="center", va="center", fontsize=FSS)
        AX0, AX1 = 73.0, 127.0
        a1 = inset(AX0, 30.0, AX1, 39.5)
        lvs = tk["level_series"]
        xs_d = [t for t in range(STEPS) if lvs[t] == 0]
        xs_g = [t for t in range(STEPS) if lvs[t] == 1]
        a1.vlines(xs_d, -0.35, 0.35, color=MDc, lw=0.5)
        a1.vlines(xs_g, 0.65, 1.35, color=MGc, lw=1.0)
        a1.set_xlim(-3, STEPS + 3); a1.set_ylim(-0.65, 1.65)
        a1.set_yticks([0, 1]); a1.set_yticklabels(["$M_d$", "$M_g$"])
        a1.set_xticks([0, 50, 100, 150, 200]); a1.set_xticklabels([])
        a1.set_ylabel("Order", fontsize=FSS, labelpad=3, **REG)
        a1.set_facecolor("none")
        style_inset(a1)
        a2 = inset(AX0, 11.0, AX1, 26.0)
        ck = tk["checkpoints"]
        cs = np.array([c["step"] for c in ck]); qg = np.array([c["eta_gate"] for c in ck])
        a2.plot(cs, qg, "-", color=GREY_L, lw=0.8)
        a2.scatter(cs, qg, s=10, color=MGc, linewidths=0, zorder=3)
        best = tk["deliver_best"]["step"]
        qb = qg[list(cs).index(best)]
        a2.scatter([best], [qb], s=50, facecolors="none", edgecolors=INK, linewidths=1.0, zorder=4)
        a2.annotate("Delivered", xy=(best - 4, qb - 0.06), xytext=(best - 42, 0.45), fontsize=FT, color=INK,
                    ha="center", va="center", arrowprops=dict(arrowstyle="-", lw=0.6, color=INK2, shrinkA=1, shrinkB=1), **REG)
        a2.set_xlim(-3, STEPS + 3); a2.set_ylim(0, 1.05)
        a2.set_yticks([0, 0.5, 1]); a2.set_yticklabels(["0", "0.5", "1"])
        a2.set_xticks([0, 50, 100, 150, 200])
        a2.set_xlabel("Step", fontsize=FSS, labelpad=1.5, **REG)
        a2.set_ylabel("Value\nat $M_g$", fontsize=FSS, labelpad=3, linespacing=1.0, **REG)
        a2.set_facecolor("none")
        style_inset(a2)

        # ---- right column: selection, refinement, report (x 148-196) ---------------------------------------------
        CXR = 172.0
        farrow(ax, [(142, 171), (148, 171)])
        fbox(ax, 148, 162, 196, 180, "Each run delivers\nits best checkpoint", fs=FS, weight="bold")
        farrow(ax, [(CXR, 162), (CXR, 157.5)])
        lab(CXR, 155.2, "Three runs", ha="center", va="center", fontsize=FSS)
        runs = [B["tickets"][g] for g in group]
        win = max(range(len(runs)), key=lambda i: runs[i]["deliver_best"]["eta_gate"])
        ar = inset(157.5, 130.5, 193.0, 152.0)
        for i, r in enumerate(runs):
            c2 = r["checkpoints"]
            x2 = [c["step"] for c in c2]; y2 = [c["eta_gate"] for c in c2]
            ar.plot(x2, y2, "-", color=RUNC[i], lw=(1.6 if i == win else 1.1), zorder=2 + (i == win))
            bs, bq = r["deliver_best"]["step"], r["deliver_best"]["eta_gate"]
            ar.scatter([bs], [bq], s=28, facecolors="white", edgecolors=RUNC[i], linewidths=1.2, zorder=4)
        bs, bq = runs[win]["deliver_best"]["step"], runs[win]["deliver_best"]["eta_gate"]
        ar.annotate("%.2f" % bq, xy=(bs, bq), xytext=(bs - 4, 0.5), fontsize=FT, color=INK, ha="center", va="center",
                    bbox=dict(boxstyle="round,pad=0.3", fc="white", ec=MGc, lw=1.1),
                    arrowprops=dict(arrowstyle="-", lw=0.7, color=INK2, shrinkA=0, shrinkB=3.5), **REG)
        ar.set_xlim(0, STEPS + 6); ar.set_ylim(0, 1.08)
        ar.set_xticks([0, 50, 100, 150, 200]); ar.set_yticks([0, 0.5, 1]); ar.set_yticklabels(["0", "0.5", "1"])
        ar.set_xlabel("Step", fontsize=FSS, labelpad=1.5, **REG)
        ar.set_ylabel("Value at $M_g$", fontsize=FSS, labelpad=2, **REG)
        style_inset(ar)
        farrow(ax, [(CXR, 121.5), (CXR, 118)])
        fbox(ax, 148, 104, 196, 118, "Select the run with the\nhighest value at $M_g$", ec=MGc, lw=1.6, fs=FS, weight="bold")
        farrow(ax, [(CXR, 104), (CXR, 100)])
        fdiamond(ax, CXR, 92, 23, 8, "Stalled\nearly?", fs=FS, weight="bold")
        farrow(ax, [(CXR, 84), (CXR, 77)])
        lab(CXR + 1.6, 80.5, "Yes", ha="left", va="center")
        fbox(ax, 148, 42, 196, 77, "Optional refinement\n(off by default):\nperturb, 30 mixed steps\nat $\\beta$ = 64, accept if\nhigher at $M_g$", ls=(0, (3, 2)),
             fs=FS, weight="bold")
        farrow(ax, [(CXR, 42), (CXR, 26)])
        ax.plot([CXR + 23, 201.5], [92, 92], color=INK2, lw=1.1, zorder=1)
        lab(CXR + 24.2, 93.2, "No", ha="left", va="bottom")
        farrow(ax, [(201.5, 92), (201.5, 18), (196, 18)], lw=1.1)
        fbox(ax, 148, 10, 196, 26, "Evaluate at $M_r$:\nreported efficiency", ec=MRc, lw=1.9, fs=FS, weight="bold")
        save(fig, "fig3_method")


# ---------------------------------------------------------------------- Fig. 4
F31DATA = os.path.join(_EXP, "F31_section31_figures", "data")
CONV_EDGE = dict(facecolors="white", linewidths=0.9)
OURS_EDGE = dict(edgecolors="white", linewidths=0.5)


def pattern_inset(ax, rect, b, title):
    ins = ax.inset_axes(rect)
    ins.imshow(1 - np.vstack([b, b]), cmap="gray", vmin=-0.4, vmax=1.0, origin="lower", aspect="auto",
               extent=[0, 3.0, 0, 1.0], interpolation="nearest")
    ins.set_xticks([]); ins.set_yticks([])
    for s_ in ins.spines.values():
        s_.set_visible(True); s_.set_color(INK2); s_.set_linewidth(0.5)
    ins.text(0.0, 1.05, title, transform=ins.transAxes, fontsize=6.8, color=INK2, ha="left", va="bottom")
    return ins


def beta_top(ax, steps):
    """P.beta_axis with a capitalized label; returns the secondary axis so that Fig. 4 can style its ticks."""
    top = ax.secondary_xaxis("top", functions=(lambda s: s, lambda s: s))
    top.set_xticks([steps * math.log(b / 2) / math.log(1000) for b in P.BETA_TICKS])
    top.set_xticklabels([str(b) for b in P.BETA_TICKS])
    top.set_xlabel(r"Projection sharpness $\beta$", labelpad=2)
    top.tick_params(length=2.5)
    return top


def fig4():
    """Fig. 4 (Sec. 3.3).
    User rulings 2026-09-27 (Fig. 4 round 2, the Fig. 3 asks carried over): tick labels and axis labels larger and
    bold (8.5 / 9.5 pt; bold math through the mathtext rc, font.weight left normal so that the math of the
    regular-weight annotations and legends, set in STIX, stays regular); every text starts with a capital letter;
    panels (c), (d) and (e) as wide as the first row including the labels to the right of (b): the outer grid has a
    second column sized to that overhang, row 1 stops before it, rows 2 and 3 span it."""
    TR = json.load(open(os.path.join(DATA, "f33_traj.json"), encoding="utf-8"))
    A = json.load(open(os.path.join(DATA, "f33_analysis.json"), encoding="utf-8"))["m"]
    D31 = json.load(open(os.path.join(F31DATA, "f31_fig2.json"), encoding="utf-8"))
    RF = json.load(open(os.path.join(DATA, "f33_refine.json"), encoding="utf-8"))["chains"] if os.path.exists(os.path.join(DATA, "f33_refine.json")) else {}
    p1, p2 = TR["part1"], TR["part2"]
    conv_rep = D31["part1"]["reported"]

    ALS, TLS = 9.5, 8.5                                   # axis labels, tick labels (both bold)
    REG = dict(math_fontfamily="stix")                    # regular-weight text that contains math
    rc = {"mathtext.rm": "Times New Roman:bold", "mathtext.it": "Times New Roman:italic:bold",
          "mathtext.bf": "Times New Roman:bold", "axes.labelsize": ALS, "axes.labelweight": "bold",
          "xtick.labelsize": TLS, "ytick.labelsize": TLS}
    with plt.rc_context(rc):
        fig = plt.figure(figsize=(FULL_W, 186 * MM))
        L, R = 0.085, 0.99
        outer = GridSpec(3, 2, figure=fig, height_ratios=[1.0, 0.72, 0.95], width_ratios=[0.82, 0.18], hspace=0.45,
                         wspace=0.0, left=L, right=R, top=0.955, bottom=0.06)
        row1 = GridSpecFromSubplotSpec(1, 2, subplot_spec=outer[0, 0], width_ratios=[0.82, 1.3], wspace=0.3)
        row3 = GridSpecFromSubplotSpec(1, 2, subplot_spec=outer[2, :], width_ratios=[1.25, 1.0], wspace=0.3)
        panels, tick_axes = [], []

        # (a) delivered pattern on the ladder: this work vs the conventional run of Fig. 2 ----------
        ax = fig.add_subplot(row1[0, 0])
        lc = D31["part2"]["final"]["ladder"]
        ncv = np.array([r["n_terms"] for r in lc], float); ecv = np.array([r["eta"] for r in lc])
        lo = p2["delivered_ladder"]
        nou = np.array([r["n_terms"] for r in lo], float); eou = np.array([r["eta"] for r in lo]); lvo = [tuple(r["level"]) for r in lo]
        ax.axhline(conv_rep, color=OC[MD], lw=0.9, ls=(0, (4, 2)), zorder=0)
        ax.text(ncv[0], conv_rep + 0.012, "Value reported by the conventional run", color=INK2, fontsize=7.0, va="bottom", ha="left")
        ax.plot(ncv, ecv, "-", color=GREY_L, lw=0.9, zorder=1)
        ax.scatter(ncv, ecv, s=9, color=GREY, zorder=2, linewidths=0)
        ax.plot(nou, eou, "-", color=INK2, lw=0.9, zorder=2)
        for i, l in enumerate(lvo):
            if l in OC:
                big = l in (MD, MG, MR)
                ax.scatter([nou[i]], [eou[i]], s=(40 if big else 18), color=OC[l], zorder=3, edgecolors="white", linewidths=0.7)
            else:
                ax.scatter([nou[i]], [eou[i]], s=9, color=INK2, zorder=3, linewidths=0)
        ir = lvo.index(MR)
        ax.annotate("Value reported\nby this work (" + LAB[MR] + ")", xy=(nou[ir], eou[ir] - 0.012), xytext=(nou[ir] * 0.62, 0.745), fontsize=6.9,
                    color=INK, ha="center", va="center", arrowprops=dict(arrowstyle="-", lw=0.5, color=INK2, shrinkA=1, shrinkB=1), **REG)
        ax.text(260, 0.905, "This work", fontsize=7.0, color=INK, ha="left", va="bottom")
        ax.annotate("Conventional\n(Fig. 2(a))", xy=(118, 0.772), xytext=(44, 0.845), fontsize=6.9, color=INK2, ha="center", va="center",
                    arrowprops=dict(arrowstyle="-", lw=0.5, color=GREY, shrinkA=1, shrinkB=2))
        ax.set_xscale("log")
        ax.set_xlabel("Number of retained harmonics $N$")
        ax.set_ylabel("Efficiency of the delivered pattern")
        ax.set_ylim(0.36, 1.02)
        ax.set_xlim(ncv[0] * 0.75, ncv[-1] * 1.3)
        pattern_inset(ax, [0.36, 0.20, 0.62, 0.11], np.load(os.path.join(DATA, "f33_delivered_binary.npy")).astype(float), "This work")
        pattern_inset(ax, [0.36, 0.035, 0.62, 0.11], np.load(os.path.join(F31DATA, "f31_final_binary.npy")).astype(float), "Conventional")
        panels.append((ax, "a", 13.0)); tick_axes.append(ax)

        # (b) the run step by step ---------------------------------------------------------------------
        axb = ax = fig.add_subplot(row1[0, 1])
        traj = np.array([np.nan if v is None else v for v in p1["trajectory_descent"]] + [p1["reported_continuous"]])
        rd = p1["reads"]
        cs = np.array([r["step"] for r in rd])
        qd = np.array([r["Q_%d-%d" % MD] for r in rd]); qg = np.array([r["Q_%d-%d" % MG] for r in rd]); qr = np.array([r["Q_%d-%d" % MR] for r in rd])
        jd = traj[cs]
        ax.fill_between(cs, qd, jd, where=jd >= qd, color=P.FILL_BIN, lw=0, zorder=0, interpolate=True)
        ax.fill_between(cs, qr, qd, where=qd >= qr, color=P.FILL_TRUNC, lw=0, zorder=0, interpolate=True)
        ax.plot(np.arange(len(traj)), traj, color=OC[MD], lw=1.2, zorder=3)
        ax.plot(cs, qd, "o", ms=2.7, mfc="white", mec=OC[MD], mew=0.8, zorder=4)
        ax.plot(cs, qg, "-s", color=OC[MG], lw=0.8, ms=2.3, mew=0, zorder=2)
        ax.plot(cs, qr, "-D", color=OC[MR], lw=1.0, ms=2.4, mew=0, zorder=2)
        c31 = D31["part1"]["checkpoints"]
        xs = np.array([c["step"] for c in c31]) * STEPS / 800.0
        ax.plot(xs, [c["Q_top"] for c in c31], ls=(0, (2, 1.5)), color=GREY, lw=0.9, zorder=1)
        right_texts = [ax.text(xs[-1] + 3, c31[-1]["Q_top"], "Conventional run, pattern at " + LAB[MR] + "\n(Fig. 2(b), same $\\beta$)",
                               fontsize=6.8, color=INK2, va="center", ha="left", **REG)]
        best = p1["best_step"]
        ib = list(cs).index(best)
        ax.scatter([best], [qr[ib]], s=60, facecolors="none", edgecolors=INK, linewidths=0.9, zorder=5)
        ax.annotate("Delivered", xy=(best - 2, qr[ib] - 0.03), xytext=(best - 30, qr[ib] - 0.13), fontsize=6.9, color=INK, ha="center",
                    arrowprops=dict(arrowstyle="-", lw=0.5, color=INK2))
        ax.axvline(T_MIX, color=GREY, lw=0.6, ls=(0, (3, 2)), zorder=0)
        ax.text(T_MIX + 2, 0.985, "First gradient at " + LAB[MG], fontsize=6.8, color=INK2, ha="left", va="top", **REG)
        xr = STEPS + 3
        right_texts += [ax.text(xr, traj[-1] + 0.03, "Objective (line) and\npattern (o) at " + LAB[MD], color=INK, fontsize=7.0, va="bottom", ha="left", **REG),
                        ax.text(xr, qg[-1] + 0.0, "Pattern at " + LAB[MG], color=INK, fontsize=7.0, va="center", ha="left", **REG),
                        ax.text(xr, qr[-1] - 0.04, "Pattern at " + LAB[MR], color=INK, fontsize=7.0, va="center", ha="left", **REG)]
        ax.set_xlim(0, STEPS)
        ax.set_ylim(0, 1.0)
        ax.set_xlabel("Optimization step")
        ax.set_ylabel("Efficiency")
        panels.append((ax, "b", 12.0)); tick_axes += [ax, beta_top(ax, STEPS)]

        # (c) 24 initial designs, paired ------------------------------------------------------------------
        ax = fig.add_subplot(outer[1, :])
        rows = sorted(A["1"]["rows"], key=lambda r: r["T_Qr"])
        x = np.arange(len(rows))
        k14 = [i for i, r in enumerate(rows) if r["i"] == p1["index"]][0]
        ax.axvspan(k14 - 0.45, k14 + 0.45, color=BAND, zorder=0)
        for i, r in enumerate(rows):
            ax.plot([x[i], x[i]], [r["T_Qr"], r["B_Qr"]], color=GREY_L, lw=1.6, zorder=1, solid_capstyle="butt")
        ax.scatter(x, [r["T_rep"] for r in rows], s=26, facecolors="none", edgecolors=OC[MD], linewidths=0.9, zorder=3,
                   label="Conventional: reported value")
        ax.scatter(x, [r["T_Qr"] for r in rows], s=20, marker="D", edgecolors=OC[MR], zorder=3, label="Conventional: delivered, at " + LAB[MR], **CONV_EDGE)
        ax.scatter(x, [r["B_Qr"] for r in rows], s=26, marker="D", color=OC[MR], zorder=4, label="This work: delivered and reported, at " + LAB[MR], **OURS_EDGE)
        ax.text(k14, 0.035, "Initial design\nof (a, b), Fig. 2", ha="center", va="bottom", fontsize=6.6, color=INK2)
        ax.set_xticks([])
        ax.set_xlim(-0.8, len(rows) - 0.2)
        ax.set_ylim(0, 1.05)
        ax.set_xlabel("24 initial designs (those of Fig. 2(c)), sorted by the efficiency the conventional workflow delivers")
        ax.set_ylabel("Efficiency")
        leg = ax.legend(loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=3, handletextpad=0.3, columnspacing=1.6, borderaxespad=0.2)
        for t in leg.get_texts():
            t.set_math_fontfamily("stix")
        panels.append((ax, "c", 13.0)); tick_axes.append(ax)

        # (d) four targets ----------------------------------------------------------------------------------
        ax = fig.add_subplot(row3[0, 0])
        for j, m in enumerate((1, 2, 3, 4)):
            if str(m) not in A:
                continue
            rr = A[str(m)]["rows"]
            tq = np.array([r["T_Qr"] for r in rr]); bq = np.array([r["B_Qr"] for r in rr]); tr = np.array([r["T_rep"] for r in rr])
            jit = (np.arange(len(rr)) % 6 - 2.5) * 0.035
            x0, x1 = j - 0.18, j + 0.18
            ax.scatter(x0 + jit, tq, s=11, marker="D", edgecolors=OC[MR], zorder=3, **CONV_EDGE)
            ax.scatter(x1 + jit, bq, s=13, marker="D", color=OC[MR], zorder=3, **OURS_EDGE)
            for xx, v in ((x0, np.median(tq)), (x1, np.median(bq))):
                ax.plot([xx - 0.13, xx + 0.13], [v, v], color=INK, lw=1.2, zorder=4)
            ax.plot([x0 - 0.13, x0 + 0.13], [np.median(tr)] * 2, color=OC[MD], lw=1.2, ls=(0, (2, 1)), zorder=4)
            ax.text(j, -0.13, "Cost ×%.2f" % A[str(m)]["price_ratio_B_over_T"], transform=ax.get_xaxis_transform(), ha="center", va="top",
                    fontsize=6.6, color=INK2)
        ax.set_xticks(range(4)); ax.set_xticklabels(["(1,0)", "(2,0)", "(3,0)", "(4,0)"])
        ax.set_xlim(-0.55, 3.55)
        ax.set_ylim(0, 1.05)
        ax.set_xlabel("Target channel", labelpad=14)
        ax.set_ylabel("Delivered efficiency at " + LAB[MR])
        hd = [Line2D([0], [0], marker="D", ls="none", mfc="white", mec=OC[MR], ms=4, label="Conventional"),
              Line2D([0], [0], marker="D", ls="none", color=OC[MR], ms=4, label="This work"),
              Line2D([0], [0], color=INK, lw=1.2, label="Median"),
              Line2D([0], [0], color=OC[MD], lw=1.2, ls=(0, (2, 1)), label="Median reported (conventional)")]
        ax.legend(handles=hd, loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=2, fontsize=6.7, handlelength=1.5, columnspacing=1.2, borderaxespad=0.2)
        panels.append((ax, "d", 13.0)); tick_axes.append(ax)

        # (e) refinement ---------------------------------------------------------------------------------------
        ax = fig.add_subplot(row3[0, 1])
        pts = refinement_points(RF)
        ax.axvspan(0, 110, color=BAND, zorder=0)
        ax.axhline(0, color=INK2, lw=0.5)
        for src, mk, kw in (("S7", "o", dict(facecolors="white", edgecolors=INK2, linewidths=0.8)),
                            ("F33", "o", dict(color=INK, linewidths=0))):
            xs = [p["step"] for p in pts if p["src"] == src]; ys = [p["gain"] for p in pts if p["src"] == src]
            ax.scatter(xs, ys, s=22, marker=mk, zorder=3, **kw)
        ax.text(55, 0.10, "Best checkpoint\nbefore step 110", fontsize=6.8, color=INK2, ha="center", va="top")
        ax.set_xlim(0, STEPS + 6)
        ax.set_ylim(-0.04, 0.45)
        ax.set_xlabel("Step of the parent run's delivered checkpoint")
        ax.set_ylabel("Gain from refinement (first rung)")
        hd = [Line2D([0], [0], marker="o", ls="none", mfc=INK, mec=INK, ms=4.5, label="Runs of this work, (1,0)"),
              Line2D([0], [0], marker="o", ls="none", mfc="white", mec=INK2, ms=4.5, label="Runs without the screen, (1,0) and (4,0)")]
        ax.legend(handles=hd, loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=1, fontsize=6.7, handlelength=1.2, borderaxespad=0.2)
        panels.append((ax, "e", 12.0)); tick_axes.append(ax)

        for a in tick_axes:                                          # bold tick labels (no rcParam for their weight)
            for t in a.get_xticklabels(which="both") + a.get_yticklabels(which="both"):
                t.set_fontweight("bold")

        # rows (c) and (d, e) end where the labels right of (b) end: size the second outer column to that overhang
        for _ in range(2):
            fig.canvas.draw()
            rend = fig.canvas.get_renderer()
            over = max(t.get_window_extent(rend).x1 for t in right_texts) / fig.bbox.width - axb.get_position().x1
            f = (R - over - L) / (R - L)
            outer.set_width_ratios([f, 1.0 - f])
            for a in fig.axes:
                if a.get_subplotspec() is not None:
                    a.set_position(a.get_subplotspec().get_position(fig))
        for a, s, off in panels:                                     # panel labels a fixed distance left of each axes
            p = a.get_position()
            fig.text(p.x0 - off / 180.0, p.y1 + 0.012, "(%s)" % s, fontsize=10.5, fontweight="bold", va="bottom", ha="left")
        save(fig, "fig4_results")


S7DATA = os.path.join(_EXP, "S7_headtohead", "data")


def refinement_points(RF):
    """Every refinement chain at the released setting (beta = 64) on P2 under the beta -> 2000 schedule:
    S7 (parents = mixed-order runs without the screen: the group winners and the weakest run of each group
    at m = 1, the weakest run of each group at m = 4) and F33 (parents = runs of the Sec. 3.2 workflow, m = 1)."""
    pts = []
    S = json.load(open(os.path.join(S7DATA, "s7_chain_b2000.json"), encoding="utf-8"))["units"]
    for k, u in S.items():
        if k.split("|")[1] in ("chain_b64", "repair_b64"):
            pts.append({"src": "S7", "key": k, "step": u["parent_step"], "parent": u["parent_eta_rung1"],
                        "gain": u["final_eta_rung1"] - u["parent_eta_rung1"], "n_accept": u["n_accept"]})
    for k, c in RF.items():
        pts.append({"src": "F33", "key": k, "step": c["parent_step"], "parent": c["parent_rung1"],
                    "gain": c["final_rung1"] - c["parent_rung1"], "n_accept": c["n_accept"]})
    return pts


# ------------------------------------------------------------------ SI Fig. S3.5
def figS3_5():
    """Gap between the thresholded patterns at M_d and M_g along a run (median over runs):
    single order, k = 8, k = 4 (S6-2d: 48 runs each, mixing from step 54, no screen) and
    the workflow of Sec. 3.2 (F33: 24 runs, mixing from beta >= 16, screen on)."""
    S6 = json.load(open(os.path.join(_EXP, "S6_lottery_pricing", "data", "s6_2d_mixed.json"), encoding="utf-8"))["units"]
    fig = plt.figure(figsize=(FULL_W, 62 * MM))
    gs = GridSpec(1, 2, figure=fig, wspace=0.28)
    for j, m in enumerate((1, 2)):
        ax = fig.add_subplot(gs[0, j])
        B = load_B(m)["tickets"]
        curves = []
        for arm, col, ls, lw, lab in (("SINGLE", OC[MD], "-", 1.3, "single order ($M_d$ only)"),
                                      ("MIX8", OC[MG], (0, (4, 2)), 1.0, "$k=8$, from step 54"),
                                      ("MIX4", OC[MG], (0, (1.2, 1.2)), 1.2, "$k=4$, from step 54")):
            us = [u for k, u in S6.items() if k.startswith("m%d|%s|" % (m, arm))]
            st = [c["step"] for c in us[0]["checkpoints"]]
            g = np.median(np.array([[c["gap_descent_minus_gate"] for c in u["checkpoints"]] for u in us]), axis=0)
            ax.plot(st, g, color=col, ls=ls, lw=lw, label=lab + " (%d runs)" % len(us))
            curves.append(g)
        st = [c["step"] for c in B["s00"]["checkpoints"]]
        g = np.median(np.array([[c["gap_descent_minus_gate"] for c in u["checkpoints"]] for u in B.values()]), axis=0)
        ax.plot(st, g, color=OC[MG], lw=1.6, label="Sec. 3.2 workflow (%d runs)" % len(B))
        ax.axvline(54, color=GREY, lw=0.5, ls=(0, (3, 2)))
        ax.axvline(T_MIX, color=GREY, lw=0.5, ls=(0, (3, 2)))
        ax.axhline(0, color=INK2, lw=0.5)
        ax.set_xlim(0, STEPS)
        ax.set_ylim(-0.02, 0.2)
        ax.set_xlabel("optimization step")
        ax.set_ylabel("pattern at $M_d$ minus pattern at $M_g$\n(median over runs)")
        ax.text(0.02, 0.97, "channel (%d,0)" % m, transform=ax.transAxes, fontsize=7.4, color=INK, va="top")
        P.beta_axis(ax, steps=STEPS)
        P.panel(ax, "ab"[j], x=-0.17)
        if j == 0:
            ax.legend(loc="center right", bbox_to_anchor=(1.0, 0.62), fontsize=6.6, handlelength=2.2)
    save(fig, "figS3_5_gap_along_runs")


# ------------------------------------------------------------------ SI Fig. S3.6 (moved out of Fig. 3, 2026-09-27)
def figS3_6():
    """Minimal model of SI S3.7: gap between the descent- and gate-order objectives along a run,
    single order vs one gate-order gradient in every k = 8 or k = 4 steps from step 66 (arbitrary units)."""
    fig = plt.figure(figsize=(88 * MM, 60 * MM))
    ax = fig.add_subplot(111)
    steps = np.arange(STEPS + 1)
    s1, s8, s4 = minimal_model(None), minimal_model(8), minimal_model(4)
    ax.axvline(T_MIX, color=GREY, lw=0.6, ls=(0, (3, 2)))
    ax.plot(steps, s1, color=OC[MD], lw=1.3)
    ax.plot(steps, s8, color=OC[MG], lw=1.0, ls=(0, (4, 2)))
    ax.plot(steps, s4, color=OC[MG], lw=1.4)
    top = s1.max()
    ax.text(168, 0.72 * top, "single order", fontsize=7.4, color=INK, ha="right", va="center")
    ax.text(STEPS * 0.98, s8[-1] + 0.03 * top, "$k=8$", fontsize=7.4, color=INK, ha="right", va="bottom")
    ax.text(STEPS * 0.98, s4[-1] + 0.02 * top, "$k=4$", fontsize=7.4, color=INK, ha="right", va="bottom")
    ax.text(T_MIX + 3, 0.95 * top, "first gradient\nat $M_g$", fontsize=7.0, color=INK2, ha="left", va="top")
    ax.set_xlim(0, STEPS); ax.set_ylim(0, top * 1.08)
    ax.set_yticks([]); ax.set_xticks([0, 50, 100, 150, 200])
    ax.set_xlabel("optimization step")
    ax.set_ylabel("gap $J_{M_d}-J_{M_g}$ (arbitrary units)")
    save(fig, "figS3_6_minimal_model")


if __name__ == "__main__":
    what = sys.argv[1] if len(sys.argv) > 1 else "fig3"
    if what in ("fig3", "all"):
        fig3_flow(1)
    if what == "fig3panels":
        fig3(1)
    if what in ("fig4", "all"):
        fig4()
    if what in ("figS3_5", "all"):
        figS3_5()
    if what in ("figS3_6", "all"):
        figS3_6()
