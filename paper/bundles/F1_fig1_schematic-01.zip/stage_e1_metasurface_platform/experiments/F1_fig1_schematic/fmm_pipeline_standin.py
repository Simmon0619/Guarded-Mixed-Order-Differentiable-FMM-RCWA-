"""
STAND-IN for the Fig. 1(b) pipeline script ``fmm_pipeline.py`` (2026-09-26).

The user's own ``fmm_pipeline.py`` was not on this machine, so this file provides
only the names that ``panels/c/fig1c_spectrum_beta_order.py`` reads from the part
above the plotting marker (the fig1c script cuts at the FIRST occurrence of that
marker string, so it must not appear anywhere above the real marker line):

    rho_tilde, tanh_projection, ETA, EPS_LOW, EPS_HIGH

Replace this file with the real pipeline to regenerate Fig. 1(c) with the same
design state as the Fig. 1(b) panels.

Design state (illustrative, square unit cell on an N x N grid): smooth random
design variables resembling a partly optimized density, filtered with the
workbench kernel exp(-r^2 / R^2) (normalized, periodic, centred on a pixel).
"""
import numpy as np

N = 128                     # pixels per period (square cell)
SEED = 20260926
CORR_PX = N / 12            # correlation radius of the design variables (px)
AMP = 0.35                  # design variables: 0.5 + AMP * unit-std field, clipped to [0, 1]
R_PX = N / 40               # filter radius R (px), kernel exp(-r^2 / R^2)
ETA = 0.5                   # projection threshold tau
EPS_LOW, EPS_HIGH = 1.0, 3.2 ** 2   # background / feature permittivity


def periodic_gaussian(a, r_px):
    """Circular convolution with the normalized kernel exp(-r^2/r_px^2), r = minimum-image distance."""
    n = a.shape[0]
    d = np.minimum(np.arange(n), n - np.arange(n)).astype(float)
    kernel = np.exp(-(d[:, None] ** 2 + d[None, :] ** 2) / r_px ** 2)
    kernel /= kernel.sum()
    return np.real(np.fft.ifft2(np.fft.fft2(a) * np.fft.fft2(kernel)))


def tanh_projection(u, beta, eta):
    """Pi_beta(u), identical to trustworthy_fmm.fabrication.process.tanh_projection."""
    return (np.tanh(beta * eta) + np.tanh(beta * (u - eta))) / (
        np.tanh(beta * eta) + np.tanh(beta * (1.0 - eta)))


rng = np.random.default_rng(SEED)
xi = periodic_gaussian(rng.standard_normal((N, N)), CORR_PX)
xi /= xi.std()
rho = np.clip(0.5 + AMP * xi, 0.0, 1.0)          # design variables (panel 1)
rho_tilde = periodic_gaussian(rho, R_PX)          # filtered density (panel 2)

# ----------------------------- plotting
# (the real pipeline draws the Fig. 1(b) panels here; the stand-in draws nothing)
