"""
Differentiable FMM solver – design parametrization pipeline
rho (Nx x Ny)  ->  spatial filter B  ->  smooth projection P_beta  ->  permittivity eps(x, y)
Each stage is saved as a separate figure (no arrows, no text -- labels are added manually later).
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from scipy.ndimage import gaussian_filter, zoom

# ----------------------------- parameters -----------------------------
SEED      = 3
NX, NY    = 12, 12     # number of design variables
UPS       = 20         # upsampling factor for display / FMM grid
SIGMA     = 0.65 * UPS  # filter width (pixels on the fine grid)
BETA      = 8.0        # projection steepness
ETA       = 0.5        # projection threshold
EPS_LOW, EPS_HIGH = 1.0, 3.48**2   # e.g. air / silicon

CMAP = "gray_r"   # 0 -> white, 1 -> black  (same convention as eps_low/eps_high)

# ----------------------------- pipeline -------------------------------
rng = np.random.default_rng(SEED)
# A purely random rho gives a very grey filtered field; for a clearer illustration we
# mimic an intermediate design: low-frequency structure + pixel-level noise.
MIX = 0.55                                           # 0 -> purely random rho
base = gaussian_filter(rng.random((NY, NX)), sigma=1.0, mode="wrap")
base = (base - base.min()) / (base.max() - base.min())
rho = np.clip(MIX * base + (1 - MIX) * rng.random((NY, NX)), 0, 1)   # design variables in [0, 1]

# fine grid (piecewise-constant pixels)
rho_fine = np.kron(rho, np.ones((UPS, UPS)))

# spatial filter B: Gaussian convolution with periodic boundary (unit cell)
rho_tilde = gaussian_filter(rho_fine, sigma=SIGMA, mode="wrap")

# smooth (tanh) projection P_beta
def tanh_projection(x, beta, eta):
    return (np.tanh(beta * eta) + np.tanh(beta * (x - eta))) / \
           (np.tanh(beta * eta) + np.tanh(beta * (1.0 - eta)))

rho_bar = tanh_projection(rho_tilde, BETA, ETA)

# permittivity (shown at the binary limit beta -> inf for clarity)
rho_bin = (rho_bar >= 0.5).astype(float)
eps = EPS_LOW + rho_bin * (EPS_HIGH - EPS_LOW)
# (differentiable version used in optimisation: eps = EPS_LOW + rho_bar*(EPS_HIGH-EPS_LOW))

# ----------------------------- plotting -------------------------------
def make_panel(data, fname, vmin=0, vmax=1, legend="colorbar"):
    """One stage of the pipeline: image + legend strip, no text at all.
    Figure geometry is kept fixed so labels can be added by hand afterwards."""
    fig = plt.figure(figsize=(2.6, 3.9), dpi=300)
    # image
    ax = fig.add_axes([0.08, 0.235, 0.84, 0.84 * 2.6 / 3.9])
    ax.imshow(data, cmap=CMAP, vmin=vmin, vmax=vmax,
              interpolation="nearest" if legend == "colorbar_pix" else "bilinear",
              origin="lower")
    ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values():
        s.set_linewidth(1.5); s.set_color("black")

    if legend in ("colorbar", "colorbar_pix"):
        # grey-scale bar (0 -> white, 1 -> black), no tick labels
        cax = fig.add_axes([0.08, 0.145, 0.84, 0.045])
        grad = np.linspace(0, 1, 256)[None, :]
        cax.imshow(grad, cmap=CMAP, aspect="auto", extent=[0, 1, 0, 1])
        cax.set_xticks([]); cax.set_yticks([])
        for s in cax.spines.values():
            s.set_linewidth(0.8)
    else:  # binary legend for permittivity: white / black swatches only
        lax = fig.add_axes([0.08, 0.08, 0.84, 0.13]); lax.axis("off")
        lax.set_xlim(0, 1); lax.set_ylim(0, 1)
        lax.add_patch(Rectangle((0.02, 0.35), 0.13, 0.45, fc="white", ec="black", lw=1.2))
        lax.add_patch(Rectangle((0.52, 0.35), 0.13, 0.45, fc="black", ec="black", lw=1.2))

    for ext in ("png", "svg"):
        fig.savefig(f"{fname}.{ext}", dpi=300, transparent=False, facecolor="white")
    plt.close(fig)

make_panel(rho,       "1_design_variables", legend="colorbar_pix")
make_panel(rho_tilde, "2_spatial_filter")
make_panel(rho_bar,   "3_smooth_projection")
make_panel(rho_bin,   "4_permittivity", legend="binary")
print("filtered range:", rho_tilde.min().round(3), rho_tilde.max().round(3))


# =====================================================================
#  Stages 5-7: Fourier coefficients -> convolution matrix -> layer eigenmodes
# =====================================================================
from matplotlib.transforms import Affine2D
from matplotlib.patches import Polygon, FancyArrowPatch

P_ORD = Q_ORD = 3                 # retained orders |p| <= P, |q| <= Q
SHOW  = 8                         # spectrum displayed for |p|,|q| <= SHOW
LINK  = (1, 0)                    # coefficient (p, q) highlighted in stage 5 and traced in C
ACCENT = "#149c8b"                # single accent colour used only for correspondences
LOG_DECADES = 2.0                 # grey scale spans this many decades below eps~(0,0)
LAMBDA_OVER_PERIOD = 1.0          # lambda / Lambda (normal incidence)

# --- stage 5: Fourier coefficients of eps(x, y) (unit cell, periodic) ---
N_FINE = eps.shape[0]
eps_hat = np.fft.fftshift(np.fft.fft2(eps)) / eps.size    # eps~(p, q), centred
c0 = N_FINE // 2                                           # index of (0, 0)
def eps_tilde(p, q):
    return eps_hat[c0 + q, c0 + p]

spec = np.array([[abs(eps_tilde(p, q)) for p in range(-SHOW, SHOW + 1)]
                 for q in range(-SHOW, SHOW + 1)])
hi = np.log10(abs(eps_tilde(0, 0)))
def to_grey(a, decades=None):                              # log magnitude -> [0, 1]
    d = LOG_DECADES if decades is None else decades
    return np.clip((np.log10(np.maximum(a, 1e-12)) - (hi - d)) / d, 0, 1)

# --- stage 6: convolution (block-Toeplitz) matrix C ---
orders = [(p, q) for q in range(-Q_ORD, Q_ORD + 1) for p in range(-P_ORD, P_ORD + 1)]
NO = len(orders)                                           # (2P+1)(2Q+1)
C = np.array([[eps_tilde(p - pp, q - qq) for (pp, qq) in orders] for (p, q) in orders])

# --- stage 7: layer eigenmodes (Fourier modal method, mu = 1) ---
pv = np.array([o[0] for o in orders], float); qv = np.array([o[1] for o in orders], float)
Kx = np.diag(pv * LAMBDA_OVER_PERIOD); Ky = np.diag(qv * LAMBDA_OVER_PERIOD)
I = np.eye(NO); Ci = np.linalg.inv(C)
Pm = np.block([[Kx @ Ci @ Ky, I - Kx @ Ci @ Kx], [Ky @ Ci @ Ky - I, -Ky @ Ci @ Kx]])
Qm = np.block([[Kx @ Ky, C - Kx @ Kx], [Ky @ Ky - C, -Ky @ Kx]])
lam2, W = np.linalg.eig(Pm @ Qm)
lam = np.sqrt(lam2.astype(complex)); lam[lam.real < 0] *= -1     # E ~ exp(-lam k0 z)
order = np.argsort(lam2.real)                              # most propagating first
lam, lam2, W = lam[order], lam2[order], W[:, order]
n_prop = int(np.sum(lam2.real < 0))
MODES = [0, 4, n_prop + 8]                                 # fundamental, a higher propagating, an evanescent mode

NG = 120
xg = np.linspace(0, 1, NG, endpoint=False); X, Y = np.meshgrid(xg, xg)
def mode_profile(m):
    w = W[:, m]; sx, sy = w[:NO], w[NO:]
    Ex = sum(sx[i] * np.exp(2j * np.pi * (pv[i] * X + qv[i] * Y)) for i in range(NO))
    Ey = sum(sy[i] * np.exp(2j * np.pi * (pv[i] * X + qv[i] * Y)) for i in range(NO))
    E = np.sqrt(abs(Ex) ** 2 + abs(Ey) ** 2)
    return E / E.max()

def mode_profile_signed(m):
    """Dominant transverse component, phase-rotated to be (almost) real, in [-1, 1]."""
    w = W[:, m]; sx, sy = w[:NO], w[NO:]
    s_, comp = (sx, "x") if np.linalg.norm(sx) >= np.linalg.norm(sy) else (sy, "y")
    F = sum(s_[i] * np.exp(2j * np.pi * (pv[i] * X + qv[i] * Y)) for i in range(NO))
    F = F * np.exp(-1j * np.angle(F.flat[np.argmax(abs(F))]))     # make it maximally real
    F = np.real(F)
    return F / np.max(np.abs(F))

# ----------------------------- plotting -------------------------------
def grey_bar(fig, rect=(0.08, 0.145, 0.84, 0.045)):
    cax = fig.add_axes(rect)
    cax.imshow(np.linspace(0, 1, 256)[None, :], cmap=CMAP, aspect="auto", extent=[0, 1, 0, 1])
    cax.set_xticks([]); cax.set_yticks([])
    for s in cax.spines.values():
        s.set_linewidth(0.8)

def save(fig, fname):
    for ext in ("png", "svg"):
        fig.savefig(f"{fname}.{ext}", dpi=300, transparent=False, facecolor="white")
    plt.close(fig)

# stage 5 / 6 (grey version + colour version) ---------------------------
def grad_bar(fig, cmap, rect=(0.08, 0.145, 0.84, 0.045)):
    cax = fig.add_axes(rect)
    cax.imshow(np.linspace(0, 1, 256)[None, :], cmap=cmap, aspect="auto", extent=[0, 1, 0, 1])
    cax.set_xticks([]); cax.set_yticks([])
    for s in cax.spines.values():
        s.set_linewidth(0.8)

def frame(ax):
    ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values():
        s.set_linewidth(1.5); s.set_color("black")

# The Fourier-domain magnitude panels (5, 6, 8) and the mode-field panels (7) show
# different quantities, so their colour versions use different colour maps -- the two
# colour bars must not be mistaken for one another.
VERSIONS      = [("", CMAP, ACCENT),                 # |eps~| family: grey, teal accent
                 ("_color", "magma", "#00e5ff")]     #               magma, cyan accent
MODE_VERSIONS = [("", CMAP, ACCENT),                 # |E_m(x, y)|:  grey, teal accent
                 ("_color", "viridis", "#ff2d2d")]   #               viridis, red accent
# Alternative scheme kept side by side for comparison: the Fourier-domain panels go back
# to viridis ("_viridis") and the mode field moves to the diverging RdBu_r ("_rdbu").
VERSIONS_ALT = [("_viridis", "viridis", "#ff2d2d")]
MODE_ALT     = [("_rdbu", "RdBu_r", False),          # |E_m|      on RdBu_r, 0 .. 1
                ("_rdbu_signed", "RdBu_r", True)]    # Re[E_m]    on RdBu_r, -1 .. 1
LEVEL_COLORS_ALT = ["#ff2d2d", "#ff4fd8", "#ffffff"]  # red / magenta / white (on viridis)

for suffix, cmap, acc in VERSIONS:
    # stage 5: spectrum with retained box and one traced coefficient
    fig = plt.figure(figsize=(2.6, 3.9), dpi=300)
    ax = fig.add_axes([0.08, 0.235, 0.84, 0.84 * 2.6 / 3.9])
    ax.imshow(to_grey(spec), cmap=cmap, vmin=0, vmax=1, interpolation="nearest", origin="lower",
              extent=[-SHOW - 0.5, SHOW + 0.5, -SHOW - 0.5, SHOW + 0.5])
    ax.add_patch(Rectangle((-P_ORD - 0.5, -Q_ORD - 0.5), 2 * P_ORD + 1, 2 * Q_ORD + 1,
                           fc="none", ec=acc, lw=1.6))
    ax.add_patch(Rectangle((LINK[0] - 0.5, LINK[1] - 0.5), 1, 1, fc=acc, ec=acc, lw=0.8))
    frame(ax); grad_bar(fig, cmap)
    save(fig, "5_fourier_coefficients" + suffix)

    # stage 6: convolution matrix with block lines and the traced coefficient
    fig = plt.figure(figsize=(2.6, 3.9), dpi=300)
    ax = fig.add_axes([0.08, 0.235, 0.84, 0.84 * 2.6 / 3.9])
    ax.imshow(to_grey(abs(C)), cmap=cmap, vmin=0, vmax=1, interpolation="nearest",
              extent=[0, NO, NO, 0])
    nb = 2 * P_ORD + 1
    line_c = "black" if suffix == "" else "white"
    for k in range(1, 2 * Q_ORD + 1):
        ax.axhline(k * nb, color=line_c, lw=0.5); ax.axvline(k * nb, color=line_c, lw=0.5)
    for i, (p, q) in enumerate(orders):
        for j, (pp, qq) in enumerate(orders):
            if (p - pp, q - qq) == LINK:
                ax.add_patch(Rectangle((j, i), 1, 1, fc=acc, ec=acc, lw=0.4))
    ax.set_xlim(0, NO); ax.set_ylim(NO, 0)
    frame(ax); grad_bar(fig, cmap)
    save(fig, "6_convolution_matrix" + suffix)

# stage 7 ---------------------------------------------------------------
Wb, Hb, dx, dy = 1.0, 0.50, 0.32, 0.32                     # slab: width, thickness, oblique offsets
ROW = Hb + dy + 0.28                                       # vertical pitch between modes
KZ_MAX = 3.5                                               # k0 * layer thickness for the z-curve
# z runs upward: z = 0 on the bottom face, z = KZ_MAX on the top face

for suffix, cmap, acc in MODE_VERSIONS:
    fig = plt.figure(figsize=(2.6, 3.9), dpi=300)
    ax = fig.add_axes([0.03, 0.03, 0.94, 0.94]); ax.axis("off"); ax.set_aspect("equal")
    for r, m in enumerate(MODES):
        y0 = -r * ROW                                      # top-front-left corner of slab r
        top   = [(0, y0), (Wb, y0), (Wb + dx, y0 + dy), (dx, y0 + dy)]
        front = [(0, y0), (Wb, y0), (Wb, y0 - Hb), (0, y0 - Hb)]
        right = [(Wb, y0), (Wb + dx, y0 + dy), (Wb + dx, y0 + dy - Hb), (Wb, y0 - Hb)]
        ax.add_patch(Polygon(front, closed=True, fc="#f2f2f2", ec="black", lw=1.0))
        ax.add_patch(Polygon(right, closed=True, fc="#d9d9d9", ec="black", lw=1.0))
        # top face: |E_m(x, y)| drawn in oblique projection
        tr = Affine2D(np.array([[Wb, dx, 0], [0, dy, y0], [0, 0, 1]])) + ax.transData
        im = ax.imshow(mode_profile(m), cmap=cmap, vmin=0, vmax=1, origin="lower",
                       extent=[0, 1, 0, 1], interpolation="bilinear", transform=tr, zorder=3)
        im.set_clip_path(Polygon(top, closed=True, transform=ax.transData))
        ax.add_patch(Polygon(top, closed=True, fc="none", ec="black", lw=1.0, zorder=4))
        # front face: z-dependence Re[exp(-lam k0 z)], z upward from the bottom face
        z = np.linspace(0, KZ_MAX, 300)
        f = np.real(np.exp(-lam[m] * z))
        xc = 0.5 * Wb + 0.38 * Wb * f; yc = (y0 - Hb) + Hb * z / KZ_MAX
        ax.plot(xc, yc, color="black", lw=1.1, zorder=3)
        ax.plot([0.5 * Wb, 0.5 * Wb], [y0, y0 - Hb], color="black", lw=0.5, ls=(0, (2, 2)), zorder=2)
        # propagation arrow along z on the right face, pointing upward
        ax.add_patch(FancyArrowPatch((Wb + 0.5 * dx, y0 + 0.5 * dy - Hb + 0.02),
                                     (Wb + 0.5 * dx, y0 + 0.5 * dy - 0.05),
                                     arrowstyle="-|>", mutation_scale=9, lw=1.0,
                                     color=acc, zorder=5))
    ax.set_xlim(-0.05, Wb + dx + 0.08)
    ax.set_ylim(-(len(MODES) - 1) * ROW - Hb - 0.08, dy + 0.08)
    save(fig, "7_layer_eigenmodes" + suffix)


# stage 7 faces: top face (|E_m(x,y)|) and front face (z-dependence) as separate images
Z_ = np.linspace(0, KZ_MAX, 300)
for k, m in enumerate(MODES, 1):
    # top face: square image, no frame (the box is drawn manually); grey + colour version
    prof = mode_profile(m)
    for suffix, cmap, _ in MODE_VERSIONS:
        fig = plt.figure(figsize=(2.0, 2.0), dpi=300)
        ax = fig.add_axes([0, 0, 1, 1]); ax.axis("off")
        ax.imshow(prof, cmap=cmap, vmin=0, vmax=1, origin="lower", interpolation="bilinear")
        save(fig, f"7_mode{k}_top" + suffix)
    # front face: Re[exp(-lam k0 z)] vs z (z downward), transparent background
    fig = plt.figure(figsize=(2.0, 1.0), dpi=300)
    ax = fig.add_axes([0, 0, 1, 1]); ax.axis("off")
    f = np.real(np.exp(-lam[m] * Z_))
    ax.plot(0.5 + 0.42 * f, Z_ / KZ_MAX, color="black", lw=1.4)
    ax.plot([0.5, 0.5], [0, 1], color="black", lw=0.6, ls=(0, (2, 2)))
    ax.set_xlim(0, 1); ax.set_ylim(-0.02, 1.02)
    for ext in ("png", "svg"):
        fig.savefig(f"7_mode{k}_front.{ext}", dpi=300, transparent=True)
    plt.close(fig)

# =====================================================================
#  Stage 8: Fourier truncation hierarchy (same design, larger retained sets)
# =====================================================================
LEVELS = [3, 7, 15]                       # |p|,|q| <= N  ->  (2N+1)^2 orders
SHOW_L = 20                               # spectrum displayed for |p|,|q| <= SHOW_L
# one distinct colour per fidelity level, so the nested panel stays readable
LEVEL_COLORS = {"":       ["#009E73", "#D55E00", "#0072B2"],   # green / vermillion / blue (on grey)
                "_color": ["#00e5ff", "#00ff5e", "#ffffff"]}   # cyan / green / white (on magma)

spec_L = np.array([[abs(eps_tilde(p, q)) for p in range(-SHOW_L, SHOW_L + 1)]
                   for q in range(-SHOW_L, SHOW_L + 1)])

def spectrum_axes(fig, cmap):
    ax = fig.add_axes([0.08, 0.235, 0.84, 0.84 * 2.6 / 3.9])
    ax.imshow(to_grey(spec_L), cmap=cmap, vmin=0, vmax=1, interpolation="nearest", origin="lower",
              extent=[-SHOW_L - 0.5, SHOW_L + 0.5, -SHOW_L - 0.5, SHOW_L + 0.5])
    frame(ax)
    return ax

for suffix, cmap, acc in VERSIONS:
    cols = LEVEL_COLORS[suffix]
    # 8a: one panel per level, same spectrum, growing box (each level its own colour)
    for N, col in zip(LEVELS, cols):
        fig = plt.figure(figsize=(2.6, 3.9), dpi=300)
        ax = spectrum_axes(fig, cmap)
        ax.add_patch(Rectangle((-N - 0.5, -N - 0.5), 2 * N + 1, 2 * N + 1,
                               fc="none", ec=col, lw=1.6))
        grad_bar(fig, cmap)
        save(fig, f"8_truncation_N{N}" + suffix)
    # 8b: nested boxes in one panel, same colours
    fig = plt.figure(figsize=(2.6, 3.9), dpi=300)
    ax = spectrum_axes(fig, cmap)
    for N, col in zip(LEVELS, cols):
        ax.add_patch(Rectangle((-N - 0.5, -N - 0.5), 2 * N + 1, 2 * N + 1,
                               fc="none", ec=col, lw=1.6))
    grad_bar(fig, cmap)
    save(fig, "8_truncation_nested" + suffix)

# 8c: what the solver "sees" at each level -- band-limited eps reconstructed from the
#     retained harmonics only (real-space grid unchanged, design unchanged)
for N in LEVELS:
    mask = np.zeros_like(eps_hat)
    mask[c0 - N:c0 + N + 1, c0 - N:c0 + N + 1] = 1
    eps_N = np.real(np.fft.ifft2(np.fft.ifftshift(eps_hat * mask)) * eps.size)
    fig = plt.figure(figsize=(2.6, 3.9), dpi=300)
    ax = fig.add_axes([0.08, 0.235, 0.84, 0.84 * 2.6 / 3.9])
    ax.imshow(eps_N, cmap=CMAP, vmin=EPS_LOW, vmax=EPS_HIGH, interpolation="bilinear", origin="lower")
    frame(ax); grad_bar(fig, CMAP)
    save(fig, f"8_bandlimited_eps_N{N}")

# 8d: convolution matrices at true relative size (49x49, 225x225, 961x961)
def conv_matrix(N):
    ords = [(p, q) for q in range(-N, N + 1) for p in range(-N, N + 1)]
    return np.array([[abs(eps_tilde(p - pp, q - qq)) for (pp, qq) in ords] for (p, q) in ords])

mats = [conv_matrix(N) for N in LEVELS]
big = (2 * LEVELS[-1] + 1) ** 2                 # largest matrix dimension
# MATRIX_CMAPS: grey plus one entry per colour scheme, so 8_matrix_* matches the
# colour map used by the other Fourier-domain panels of that scheme.
MATRIX_CMAPS = [("", CMAP), ("_color", "magma"), ("_viridis", "viridis")]
# The large matrices reach further below eps~(0, 0) than the spectrum panels do, so they
# get their own (wider) log range -- otherwise the 961 x 961 panel washes out to empty.
MATRIX_DECADES = 3.5

for suffix, cmap in MATRIX_CMAPS:
    # single panels, each filling its own figure (structure of C at that level)
    for N, M in zip(LEVELS, mats):
        fig = plt.figure(figsize=(2.4, 2.4), dpi=300)
        ax = fig.add_axes([0.02, 0.02, 0.96, 0.96])
        ax.imshow(to_grey(M, MATRIX_DECADES), cmap=cmap, vmin=0, vmax=1, interpolation="nearest")
        frame(ax)
        save(fig, f"8_matrix_N{N}" + suffix)
    # combined, side by side, true relative size (49 : 225 : 961)
    FW, FH = 4.2, 2.6
    fig = plt.figure(figsize=(FW, FH), dpi=300)
    x = 0.03
    for N, M in zip(LEVELS, mats):
        h = 0.9 * M.shape[0] / big; w = h * FH / FW
        ax = fig.add_axes([x, 0.5 - h / 2, w, h])
        ax.imshow(to_grey(M, MATRIX_DECADES), cmap=cmap, vmin=0, vmax=1, interpolation="nearest")
        frame(ax); x += w + 0.04
    save(fig, "8_matrix_sizes" + suffix)
print("truncation levels:", [(N, (2 * N + 1) ** 2) for N in LEVELS])

print("orders:", NO, "| propagating modes:", n_prop, "| shown modes:", MODES)
print("lambda of shown modes:", np.round(lam[MODES], 3))


# =====================================================================
#  Alternative colour scheme (kept alongside the current one)
#    Fourier-domain panels: viridis      -> *_viridis
#    mode field:            RdBu_r       -> *_rdbu (magnitude) / *_rdbu_signed (signed)
# =====================================================================
for suffix, cmap, acc in VERSIONS_ALT:
    # stage 5
    fig = plt.figure(figsize=(2.6, 3.9), dpi=300)
    ax = fig.add_axes([0.08, 0.235, 0.84, 0.84 * 2.6 / 3.9])
    ax.imshow(to_grey(spec), cmap=cmap, vmin=0, vmax=1, interpolation="nearest", origin="lower",
              extent=[-SHOW - 0.5, SHOW + 0.5, -SHOW - 0.5, SHOW + 0.5])
    ax.add_patch(Rectangle((-P_ORD - 0.5, -Q_ORD - 0.5), 2 * P_ORD + 1, 2 * Q_ORD + 1,
                           fc="none", ec=acc, lw=1.6))
    ax.add_patch(Rectangle((LINK[0] - 0.5, LINK[1] - 0.5), 1, 1, fc=acc, ec=acc, lw=0.8))
    frame(ax); grad_bar(fig, cmap)
    save(fig, "5_fourier_coefficients" + suffix)
    # stage 6
    fig = plt.figure(figsize=(2.6, 3.9), dpi=300)
    ax = fig.add_axes([0.08, 0.235, 0.84, 0.84 * 2.6 / 3.9])
    ax.imshow(to_grey(abs(C)), cmap=cmap, vmin=0, vmax=1, interpolation="nearest",
              extent=[0, NO, NO, 0])
    nb = 2 * P_ORD + 1
    for k in range(1, 2 * Q_ORD + 1):
        ax.axhline(k * nb, color="white", lw=0.5); ax.axvline(k * nb, color="white", lw=0.5)
    for i, (p, q) in enumerate(orders):
        for j, (pp, qq) in enumerate(orders):
            if (p - pp, q - qq) == LINK:
                ax.add_patch(Rectangle((j, i), 1, 1, fc=acc, ec=acc, lw=0.4))
    ax.set_xlim(0, NO); ax.set_ylim(NO, 0)
    frame(ax); grad_bar(fig, cmap)
    save(fig, "6_convolution_matrix" + suffix)
    # stage 8
    for N, col in zip(LEVELS, LEVEL_COLORS_ALT):
        fig = plt.figure(figsize=(2.6, 3.9), dpi=300)
        ax = spectrum_axes(fig, cmap)
        ax.add_patch(Rectangle((-N - 0.5, -N - 0.5), 2 * N + 1, 2 * N + 1,
                               fc="none", ec=col, lw=1.6))
        grad_bar(fig, cmap); save(fig, f"8_truncation_N{N}" + suffix)
    fig = plt.figure(figsize=(2.6, 3.9), dpi=300)
    ax = spectrum_axes(fig, cmap)
    for N, col in zip(LEVELS, LEVEL_COLORS_ALT):
        ax.add_patch(Rectangle((-N - 0.5, -N - 0.5), 2 * N + 1, 2 * N + 1,
                               fc="none", ec=col, lw=1.6))
    grad_bar(fig, cmap); save(fig, "8_truncation_nested" + suffix)

for suffix, cmap, signed in MODE_ALT:
    lo = -1 if signed else 0
    prof = {m: (mode_profile_signed(m) if signed else mode_profile(m)) for m in MODES}
    # separate top faces
    for k, m in enumerate(MODES, 1):
        fig = plt.figure(figsize=(2.0, 2.0), dpi=300)
        ax = fig.add_axes([0, 0, 1, 1]); ax.axis("off")
        ax.imshow(prof[m], cmap=cmap, vmin=lo, vmax=1, origin="lower", interpolation="bilinear")
        save(fig, f"7_mode{k}_top" + suffix)
    # composite
    fig = plt.figure(figsize=(2.6, 3.9), dpi=300)
    ax = fig.add_axes([0.03, 0.03, 0.94, 0.94]); ax.axis("off"); ax.set_aspect("equal")
    for r, m in enumerate(MODES):
        y0 = -r * ROW
        top   = [(0, y0), (Wb, y0), (Wb + dx, y0 + dy), (dx, y0 + dy)]
        front = [(0, y0), (Wb, y0), (Wb, y0 - Hb), (0, y0 - Hb)]
        right = [(Wb, y0), (Wb + dx, y0 + dy), (Wb + dx, y0 + dy - Hb), (Wb, y0 - Hb)]
        ax.add_patch(Polygon(front, closed=True, fc="#f2f2f2", ec="black", lw=1.0))
        ax.add_patch(Polygon(right, closed=True, fc="#d9d9d9", ec="black", lw=1.0))
        tr = Affine2D(np.array([[Wb, dx, 0], [0, dy, y0], [0, 0, 1]])) + ax.transData
        im = ax.imshow(prof[m], cmap=cmap, vmin=lo, vmax=1, origin="lower",
                       extent=[0, 1, 0, 1], interpolation="bilinear", transform=tr, zorder=3)
        im.set_clip_path(Polygon(top, closed=True, transform=ax.transData))
        ax.add_patch(Polygon(top, closed=True, fc="none", ec="black", lw=1.0, zorder=4))
        z = np.linspace(0, KZ_MAX, 300); f = np.real(np.exp(-lam[m] * z))
        ax.plot(0.5 * Wb + 0.38 * Wb * f, (y0 - Hb) + Hb * z / KZ_MAX, color="black", lw=1.1, zorder=3)
        ax.plot([0.5 * Wb, 0.5 * Wb], [y0, y0 - Hb], color="black", lw=0.5, ls=(0, (2, 2)), zorder=2)
        ax.add_patch(FancyArrowPatch((Wb + 0.5 * dx, y0 + 0.5 * dy - Hb + 0.02),
                                     (Wb + 0.5 * dx, y0 + 0.5 * dy - 0.05),
                                     arrowstyle="-|>", mutation_scale=9, lw=1.0,
                                     color="#2b2b2b", zorder=5))
    ax.set_xlim(-0.05, Wb + dx + 0.08)
    ax.set_ylim(-(len(MODES) - 1) * ROW - Hb - 0.08, dy + 0.08)
    save(fig, "7_layer_eigenmodes" + suffix)
