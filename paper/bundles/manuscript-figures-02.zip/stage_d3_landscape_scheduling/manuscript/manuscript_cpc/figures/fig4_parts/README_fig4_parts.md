# Fig. 4 拆图（2026-10-06）

脚本：`stage_e1_metasurface_platform/experiments/F33_section33_results/scripts/f33_fig4_parts.py`（`python f33_fig4_parts.py [key a b c d e]`，Windows 先设 `PYTHONIOENCODING=utf-8`）。只读已有数据（F33、F31、S7），没有新计算。
旧的拼合版 `fig4_results.*` 已移到 `../_superseded/2026-10-06_fig4_assembled_before_parts/`。

## 文件（png 300 dpi + svg，无 pdf，无面板字母，100% 摆放即为标称字号）

| 文件 | 内容 | 宽 × 高 (mm) |
|---|---|---|
| `fig4_legend_orders` | 截断阶颜色条（与 Fig. 2 的相同，标题 "Truncation order (color)"），放在最前 | 151 × 14 |
| `fig4_a_ladder` | 两种流程交付图案的阶梯（原 a） | 68 × 75 |
| `fig4_b_run` | 本文这条运行的逐步曲线（原 b） | 106 × 67 |
| `fig4_c_runs24` | 24 个初值：常规交付 → 本文交付（原 c，**重画**） | 173 × 51 |
| `fig4_d_channels` | 四个通道（原 d） | 100 × 72 |
| `fig4_e_refinement` | 修复：修复前 → 修复后 对 运行达到最好检查点的步数（原 e，**重画**） | 78 × 67 |

建议排法与原来一样：颜色条；a + b 一行（174 mm）；c 一行（173 mm）；d + e 一行（178 mm）。按 100% 叠起来约 226 mm 高（含行距），比原图高，可以把行距压紧或把颜色条并到第一行上方。

## 图标规则（Fig. 2 与 Fig. 4 统一）

| 图标 | 含义 | 出现在 |
|---|---|---|
| 实心橙色菱形 ◆ | 常规流程交付的图案在 $M_r$ 的效率 | Fig. 2(b)(c)；Fig. 4(a)(b)(c)(d) |
| 橙色五角星 ★（深橙色边 #b9651c，0.5 pt） | 本文交付的图案在 $M_r$ 的效率 = 本文报告的值 | Fig. 4(a)(b)(c)(d) |
| 黑色短横（带白色描边） | 中位数 | Fig. 4(d) |
| 深蓝虚线 | 常规流程报告的值 | Fig. 2(a)；Fig. 4(a) |
| 箭头（灰） | 本文相对常规的增益（Fig. 4(c)）；修复带来的变化（Fig. 4(e)） | Fig. 4(c)(e) |
| 灰色竖条 | 报告值与交付值的差距 | 只在 Fig. 2(c) |

- **Fig. 2(c) 没改**：它的任务是"报告值与交付值的差距"，现有设计就是为这个服务的。改的是 Fig. 4(c)：原来实心菱形在 Fig. 2(c) 表示常规流程交付、在 Fig. 4(c) 却表示本文交付，灰条在两图里含义也不同。现在常规流程交付在两图里都是同一个实心菱形，本文用五角星；Fig. 4(c) 的横轴顺序与 Fig. 2(c) 完全相同，读者可以把两图的菱形一一对上。
- Fig. 4(c)(d) **去掉了常规流程的报告值**（空心圆 / 中位虚线）：报告值与交付值的差距是 Fig. 2(c) 的内容；Fig. 4(c)(d) 只比较两种流程交付的效率。正文第 3、4 段里"常规流程报告值高出交付值 0.23 / 0.31、0.14、0.16"这几个数仍然成立，只是不再从 Fig. 4 读出（m=1 的 0.23 就是 Fig. 2(c) 的那 24 个运行；其余见 SI 表）。如果你希望 (d) 保留"常规报告中位"的虚线，改一行即可恢复。
- 2026-10-07 调整：五角星原来是黑边，观感偏重，并且在 (d) 里和黑色中位线混在一起，看不清中位线。改为比填充色深一档的同色系深橙色边；(d) 的中位短横加 1 pt 白色描边，画在星的上层。星的填充仍是 $M_r$ 的橙色：换成淡红或淡蓝会破坏"颜色 = 截断阶"的规则，因此没有采用。比较过的几种方案（无边、白边、淡红、淡蓝）只在临时预览里，没有保留。
- Fig. 4(e) 是例外：纵轴是第一档参考阶（(1,0) 为 (40,6)，(4,0) 为 (52,7)）上的效率，不是 $M_r$，所以五角星用黑色（形状仍表示"本文的运行"，颜色不冒充 $M_r$ 的橙色）；S7 的旧修复链只有第一档的读数。
- 图中文字只引用 "Fig. 2(c)"（c 的横轴）与 "(a, b)"（c 中阴影列 = a、b 所用的初值）；若你重排后字母变了，这两处要跟着改。

## 各图的变化

- **a**：常规图案的阶梯保持灰色，其 $M_r$ 点改为菱形；本文图案的 $M_r$ 点改为五角星；图例放在轴上方（三项：星、菱形、蓝虚线）。两个图案插图按真实 3 : 1 比例并排（原来被压扁）。
- **b**：交付检查点由圆圈改为五角星，注 "Delivered and reported"；常规运行（灰虚线）末端加菱形 = 它交付的值；加了 "Binarization gap" 与 "Truncation gap" 两个标注（与 Fig. 2(b) 一致）；右侧说明去掉 "Fig. 2(b)" 字样，改为 "(same β)"。
- **c**：每个初值一对：菱形（常规交付）→ 箭头 → 五角星（本文交付）；增益小于 0.06 的不画箭头（星紧贴菱形），两者相同的一个标 "Equal"；右下角写 "Arrow: gain of this work (median 0.18) / This work higher for 23 of 24 initial designs"；纵轴改为 "Delivered efficiency at $M_r$"。
- **d**：菱形 / 五角星 / 中位线；轴下方加两行小表："This work higher" 23 of 24、23 of 24、11 of 12、11 of 12，"Cost per run" ×1.26、×1.26、×1.75、×1.03。
- **e**：原图纵轴是"增益"、横轴是"父运行交付检查点的步数"，读者要先理解这两个量才能看懂。现在：纵轴 = 修复前后的效率，每个运行一个点（修复前），有改善的画箭头到修复后；横轴 = 运行达到最好检查点的步数；左侧阴影 "Run stopped improving before step 110"，两侧分别写 "Improved: 3 of 3" 与 "Improved: 3 of 27"；下方横条标出本文全部 72 个运行最好检查点所在的范围（153–219 步，"All 72 runs of this work peaked here"）。一眼可读出：修复只抬高了早停的运行，而本文的运行都不早停。

## 图注草稿（替换 `sections/03_3_…_v1` 中的 Fig. 4 图注；正文未改）

**Fig. 4.** The guarded mixed-order workflow on the task of Fig. 2 and on the other transmitted channels of the grating. Colours denote truncation orders as in Fig. 2. Star: pattern delivered by the new workflow, evaluated at $M_r$, which is also the value it reports; diamond: pattern delivered by the conventional workflow from the same initial design, evaluated at $M_r$ (as in Fig. 2(c)); navy dashes: value reported by the conventional workflow. (a) The pattern delivered from the initial design of Fig. 2(a,b), evaluated with an increasing number of retained harmonics $N$ (dark line), next to the pattern the conventional workflow delivers from the same initial design (grey; Fig. 2(a)). Insets: the two patterns (dark: high-index material), one period along $x$ and two along $y$. (b) The run step by step, as in Fig. 2(b): the smooth objective at $M_d$ (line) and the binary pattern of the current design at $M_d$, $M_g$, and $M_r$ (symbols, every 6 steps and at the checkpoints); shading: binarization and truncation gaps; vertical dashed line: first gradient at $M_g$; grey dashes: the efficiency at $M_r$ of the conventional run of Fig. 2(b), plotted at the same $\beta$. (c) The 24 initial designs of Fig. 2(c), in the same order: efficiency at $M_r$ of the pattern each workflow delivers; arrows mark gains larger than 0.06. (d) Channels (1,0) to (4,0): delivered efficiency at $M_r$ of every run (24, 24, 12, and 12 initial designs, the same for both workflows), with medians; below: the number of initial designs from which the new workflow delivers the more efficient pattern, and its cost per run relative to the conventional workflow. $M_r$ is (48,7) for (1,0) and (2,0), (60,9) for (3,0), and (64,9) for (4,0). (e) Optional refinement ($\beta=64$, 15 hops): efficiency at the first rung of the reference ladder ((40,6) for (1,0), (52,7) for (4,0)) before refinement (symbols) and after it (arrow heads; changes larger than 0.01), against the step at which the refined run reached its best checkpoint; stars: runs of the new workflow at (1,0) (the six weakest and the four strongest); open circles: mixed-order runs made without the screen at (1,0) and (4,0) (SI S3.9); bar: range of the best checkpoints of all 72 runs of the new workflow.

## 数据来源（与原 Fig. 4 相同）

| 图 | 数据 |
|---|---|
| a | F33 `f33_traj.json` part2（本文阶梯）、`f33_delivered_binary.npy`；F31 `f31_fig2.json` part1 reported、part2（常规阶梯）、`f31_final_binary.npy` |
| b | F33 `f33_traj.json` part1；F31 `f31_fig2.json` part1 checkpoints（常规运行，Q_top） |
| c、d | F33 `f33_analysis.json`（rows：T_Qr、B_Qr；price_ratio_B_over_T） |
| e | S7 `s7_chain_b2000.json`（chain_b64、repair_b64 共 20 条）；F33 `f33_refine.json`（10 条）；`f33_analysis.json` rows 的 B_step（72 个运行） |
