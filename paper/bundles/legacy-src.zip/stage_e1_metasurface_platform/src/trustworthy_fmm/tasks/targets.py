"""General routing targets and pre-solver physical feasibility checks."""

from dataclasses import dataclass, field
from typing import Dict, Mapping, Optional, Sequence, Tuple, Union

import torch

from trustworthy_fmm.core.types import DeviceState, InputChannel, Order, OutputChannel
from trustworthy_fmm.physics.channels import (
    diffraction_angles_deg,
    longitudinal_wavevectors,
    normalized_in_plane_wavevectors,
    propagating_mask,
)


@dataclass(frozen=True)
class PowerTarget:
    powers: Mapping[Order, float]

    def __post_init__(self) -> None:
        if any(value < 0 for value in self.powers.values()):
            raise ValueError("target powers must be non-negative")


@dataclass(frozen=True)
class ComplexTarget:
    amplitudes: Mapping[Order, complex]
    global_phase_invariant: bool = True


@dataclass(frozen=True)
class SubspaceTarget:
    orders: Sequence[Order]
    minimum_power: float = 0.0


Target = Union[PowerTarget, ComplexTarget, SubspaceTarget]


@dataclass(frozen=True)
class TargetOperator:
    inputs: Sequence[InputChannel]
    states: Sequence[DeviceState]
    outputs: Mapping[str, Target]
    required_symmetry: Optional[str] = None

    def __post_init__(self) -> None:
        state_names = {state.name for state in self.states}
        if state_names != set(self.outputs):
            raise ValueError("outputs must provide exactly one target for every state")
        if not self.inputs:
            raise ValueError("at least one input channel is required")


@dataclass
class FeasibilityReport:
    feasible: bool
    errors: Sequence[str]
    warnings: Sequence[str]
    channel_table: Sequence[Mapping[str, object]] = field(default_factory=list)
    feasibility_gap_lower_bound: float = 0.0

    def require(self) -> None:
        if not self.feasible:
            raise ValueError("infeasible target: " + "; ".join(self.errors))


def _target_orders(target: Target) -> Sequence[Order]:
    if isinstance(target, PowerTarget):
        return list(target.powers)
    if isinstance(target, ComplexTarget):
        return list(target.amplitudes)
    return list(target.orders)


def check_target_feasibility(
    target: TargetOperator,
    lattice_nm: Tuple[float, float],
    incident_index: float,
    output_index: float,
    *,
    passive: bool = True,
) -> FeasibilityReport:
    errors = []
    warnings = []
    table = []
    gap = 0.0
    for input_channel in target.inputs:
        all_orders = sorted({order for state_target in target.outputs.values() for order in _target_orders(state_target)})
        kx, ky = normalized_in_plane_wavevectors(
            all_orders,
            input_channel.wavelength_nm,
            lattice_nm,
            incident_index,
            input_channel.theta_deg,
            input_channel.phi_deg,
        )
        kz = longitudinal_wavevectors(kx, ky, output_index)
        mask = propagating_mask(kz)
        theta, phi, angle_mask = diffraction_angles_deg(kx, ky, output_index)
        for index, order in enumerate(all_orders):
            is_propagating = bool(mask[index].item() and angle_mask[index].item())
            table.append(
                {
                    "wavelength_nm": input_channel.wavelength_nm,
                    "order": order,
                    "propagating": is_propagating,
                    "theta_deg": float(theta[index].item()),
                    "phi_deg": float(phi[index].item()),
                }
            )
            if not is_propagating:
                errors.append("target order {} is evanescent".format(order))
    for state, state_target in target.outputs.items():
        if isinstance(state_target, PowerTarget):
            total = sum(state_target.powers.values())
            if passive and total > 1.0 + 1e-12:
                errors.append("state {} requests total power {:.6g} > 1".format(state, total))
                gap = max(gap, total - 1.0)
        if isinstance(state_target, ComplexTarget):
            requested_power = sum(abs(value) ** 2 for value in state_target.amplitudes.values())
            if passive and requested_power > 1.0 + 1e-12:
                errors.append("state {} complex target has norm squared {:.6g} > 1".format(state, requested_power))
                gap = max(gap, requested_power - 1.0)
    if target.required_symmetry == "mirror_x":
        for state, state_target in target.outputs.items():
            if isinstance(state_target, PowerTarget):
                powers = state_target.powers
                for (m, n), value in powers.items():
                    mirror = (-m, n)
                    if mirror in powers and abs(value - powers[mirror]) > 1e-12:
                        errors.append("state {} violates forced mirror_x power symmetry".format(state))
                        break
    return FeasibilityReport(not errors, errors, warnings, table, gap)

