"""Empirical fidelity indicators and convergence classification.

Nothing in this module is a rigorous error certificate.  The routines expose
adjacent-fidelity changes, gradient agreement, conditional Richardson
extrapolation, and calibration diagnostics so that the evidence supporting a
numerical reference remains explicit and machine readable.
"""

from dataclasses import asdict, dataclass
import math
from typing import Dict, List, Optional, Sequence, Tuple

import torch


ASYMPTOTIC_MONOTONE = "asymptotic_monotone"
OSCILLATORY_BOUNDED = "oscillatory_bounded"
STAGNANT_OR_DIVERGENT = "stagnant_or_divergent"
ANOMALY_NEARBY = "anomaly_nearby"

SAFE = "safe"
REFINE = "refine"
REJECT = "reject"
INSUFFICIENT_EVIDENCE = "insufficient_evidence"

VALUE_AND_GRADIENT_CONVERGED = "value_and_gradient_converged"
VALUE_CONVERGED_GRADIENT_NOT = "value_converged_gradient_not"
GRADIENT_CONVERGED_VALUE_NOT = "gradient_converged_value_not"
VALUE_AND_GRADIENT_NOT_CONVERGED = "value_and_gradient_not_converged"


@dataclass(frozen=True)
class PairIndicator:
    coarse_level: float
    fine_level: float
    forward_relative_change: float
    gradient_cosine: Optional[float] = None
    gradient_disagreement: Optional[float] = None
    gradient_norm_ratio: Optional[float] = None

    def to_dict(self) -> Dict[str, object]:
        return asdict(self)


@dataclass(frozen=True)
class ConvergenceAssessment:
    classification: str
    can_extrapolate: bool
    observed_orders: Tuple[float, ...]
    extrapolated_limit: Optional[float]
    extrapolation_uncertainty: Optional[float]
    finest_envelope: Tuple[float, float]
    adjacent_absolute_changes: Tuple[float, ...]
    reason: str

    def to_dict(self) -> Dict[str, object]:
        return asdict(self)


@dataclass(frozen=True)
class FidelitySequenceAssessment:
    levels: Tuple[float, ...]
    reference_value: float
    convergence: ConvergenceAssessment
    pair_indicators: Tuple[PairIndicator, ...]
    final_forward_relative_change: float
    final_gradient_cosine: Optional[float]
    final_gradient_norm_ratio: Optional[float]
    reference_gradient_cosine: Optional[float]
    reference_gradient_relative_error: Optional[float]
    reference_directional_derivative: Optional[float]
    dtype_relative_change: Optional[float]
    reference_validation_relative_change: Optional[float]
    stable_window_pairs: int
    decision: str
    evidence_complete: bool
    reference_qualified: bool
    qualification_reasons: Tuple[str, ...]

    def to_dict(self) -> Dict[str, object]:
        payload = asdict(self)
        return payload


@dataclass(frozen=True)
class IndicatorCalibration:
    samples: int
    empirical_coverage: float
    predicted_safe_count: int
    false_safe_count: int
    false_safe_rate: float
    conditional_false_safe_rate: Optional[float]
    conditional_false_safe_upper_95: float
    safe_precision: Optional[float]
    mean_excess_conservatism: float
    mean_underestimation: float
    required_safety_factor: float
    safe_threshold: float
    actual_error_tolerance: float

    def to_dict(self) -> Dict[str, object]:
        return asdict(self)


@dataclass(frozen=True)
class ValueGradientConvergenceState:
    state: str
    value_relative_error: float
    gradient_cosine: float
    value_converged: bool
    gradient_converged: bool
    separated: bool

    def to_dict(self) -> Dict[str, object]:
        return asdict(self)


def classify_value_gradient_convergence(
    value_relative_error: float,
    gradient_cosine: float,
    *,
    value_tolerance: float,
    gradient_cosine_tolerance: float,
) -> ValueGradientConvergenceState:
    """Classify value and gradient convergence without conflating the two."""
    values = (
        float(value_relative_error),
        float(gradient_cosine),
        float(value_tolerance),
        float(gradient_cosine_tolerance),
    )
    if any(not math.isfinite(value) for value in values):
        raise ValueError("value/gradient convergence inputs must be finite")
    if value_relative_error < 0 or value_tolerance <= 0:
        raise ValueError("value error must be non-negative and tolerance positive")
    if not -1.0 <= gradient_cosine <= 1.0:
        raise ValueError("gradient_cosine must lie in [-1, 1]")
    if not -1.0 <= gradient_cosine_tolerance <= 1.0:
        raise ValueError("gradient cosine tolerance must lie in [-1, 1]")
    value_converged = value_relative_error <= value_tolerance
    gradient_converged = gradient_cosine >= gradient_cosine_tolerance
    if value_converged and gradient_converged:
        state = VALUE_AND_GRADIENT_CONVERGED
    elif value_converged:
        state = VALUE_CONVERGED_GRADIENT_NOT
    elif gradient_converged:
        state = GRADIENT_CONVERGED_VALUE_NOT
    else:
        state = VALUE_AND_GRADIENT_NOT_CONVERGED
    return ValueGradientConvergenceState(
        state=state,
        value_relative_error=float(value_relative_error),
        gradient_cosine=float(gradient_cosine),
        value_converged=value_converged,
        gradient_converged=gradient_converged,
        separated=state == VALUE_CONVERGED_GRADIENT_NOT,
    )


def relative_change(coarse: float, fine: float, epsilon: float = 1e-12) -> float:
    if epsilon <= 0:
        raise ValueError("epsilon must be positive")
    return abs(float(fine) - float(coarse)) / max(abs(float(fine)), epsilon)


def gradient_pair_metrics(
    coarse_gradient: torch.Tensor,
    fine_gradient: torch.Tensor,
    epsilon: float = 1e-15,
) -> Tuple[float, float, float]:
    """Return ``(cosine, 1-cosine, coarse/fine norm ratio)``."""
    if coarse_gradient.shape != fine_gradient.shape:
        raise ValueError("gradient tensors must have identical shapes")
    coarse = coarse_gradient.reshape(-1)
    fine = fine_gradient.reshape(-1)
    coarse_norm = torch.linalg.vector_norm(coarse)
    fine_norm = torch.linalg.vector_norm(fine)
    denominator = coarse_norm * fine_norm
    if float(denominator.detach().cpu()) <= epsilon:
        cosine = 1.0 if float(torch.max(torch.abs(coarse - fine)).detach().cpu()) <= epsilon else 0.0
    else:
        inner = torch.sum(torch.conj(coarse) * fine)
        cosine = float(torch.clamp(torch.real(inner) / denominator, -1.0, 1.0).detach().cpu())
    norm_ratio = float((coarse_norm / torch.clamp(fine_norm, min=epsilon)).detach().cpu())
    return cosine, 1.0 - cosine, norm_ratio


def fourier_tail_fraction(
    samples: torch.Tensor,
    retained_half_orders,
    epsilon: float = 1e-30,
) -> float:
    """Return spectral energy outside a retained centered Fourier rectangle.

    The result is a diagnostic of material-map resolution, not a field-error
    bound.  One-dimensional samples accept an integer half-order; 2D samples
    accept ``(mx, my)`` in the solver's order convention.
    """
    if samples.ndim not in (1, 2):
        raise ValueError("samples must be one- or two-dimensional")
    dims = (-1,) if samples.ndim == 1 else (-2, -1)
    coefficients = torch.fft.fftshift(torch.fft.fftn(samples, dim=dims, norm="forward"), dim=dims)
    energy = torch.abs(coefficients) ** 2
    retained = torch.zeros_like(energy, dtype=torch.bool)
    if samples.ndim == 1:
        half_order = int(retained_half_orders)
        if half_order < 0:
            raise ValueError("retained half-order must be non-negative")
        center = samples.shape[0] // 2
        lower, upper = max(0, center - half_order), min(samples.shape[0], center + half_order + 1)
        retained[lower:upper] = True
    else:
        mx, my = (int(value) for value in retained_half_orders)
        if mx < 0 or my < 0:
            raise ValueError("retained half-orders must be non-negative")
        ny, nx = samples.shape
        cy, cx = ny // 2, nx // 2
        retained[
            max(0, cy - my) : min(ny, cy + my + 1),
            max(0, cx - mx) : min(nx, cx + mx + 1),
        ] = True
    total = torch.sum(energy)
    tail = torch.sum(torch.where(retained, torch.zeros_like(energy), energy))
    return float((tail / torch.clamp(total, min=epsilon)).real.detach().cpu())


def rayleigh_anomaly_distance(
    *,
    wavelength_nm: float,
    lattice_nm: Tuple[float, float],
    incident_index: complex,
    output_index: complex,
    orders: Sequence[Tuple[int, int]],
    theta_deg: float = 0.0,
    phi_deg: float = 0.0,
    epsilon: float = 1e-15,
) -> float:
    """Return the smallest normalized squared-kz distance to a channel cutoff."""
    if wavelength_nm <= 0 or any(period <= 0 for period in lattice_nm):
        raise ValueError("wavelength and lattice periods must be positive")
    theta, phi = math.radians(theta_deg), math.radians(phi_deg)
    base = float(complex(incident_index).real) * math.sin(theta)
    minimum = float("inf")
    for m, n in orders:
        kx = base * math.cos(phi) + m * wavelength_nm / lattice_nm[0]
        ky = base * math.sin(phi) + n * wavelength_nm / lattice_nm[1]
        for medium_index in (incident_index, output_index):
            medium_epsilon = complex(medium_index) ** 2
            residual = abs(medium_epsilon - kx ** 2 - ky ** 2)
            minimum = min(minimum, residual / max(abs(medium_epsilon), epsilon))
    return minimum


def _observed_orders(
    levels: Sequence[float],
    absolute_changes: Sequence[float],
    *,
    ratio_log_tolerance: float,
    epsilon: float,
) -> List[float]:
    estimates: List[float] = []
    for index in range(len(absolute_changes) - 1):
        first, second = absolute_changes[index], absolute_changes[index + 1]
        ratio_1 = levels[index + 1] / levels[index]
        ratio_2 = levels[index + 2] / levels[index + 1]
        if first <= epsilon or second <= epsilon:
            continue
        if abs(math.log(ratio_1) - math.log(ratio_2)) > ratio_log_tolerance:
            continue
        ratio = math.sqrt(ratio_1 * ratio_2)
        estimates.append(math.log(first / second) / math.log(ratio))
    return estimates


def classify_convergence(
    levels: Sequence[float],
    values: Sequence[float],
    *,
    anomaly_distance: Optional[float] = None,
    anomaly_tolerance: float = 1e-3,
    ratio_log_tolerance: float = 0.1,
    order_stability_tolerance: float = 0.25,
    epsilon: float = 1e-14,
) -> ConvergenceAssessment:
    """Classify a refinement sequence and condition Richardson extrapolation.

    Richardson extrapolation is enabled only for at least four levels with
    decreasing monotone changes and two positive, mutually consistent observed
    orders.  All other cases return an envelope without pretending to provide a
    power-law error bar.
    """
    if len(levels) != len(values) or len(levels) < 3:
        raise ValueError("provide at least three paired levels and values")
    levels = tuple(float(level) for level in levels)
    values = tuple(float(value) for value in values)
    if any(not math.isfinite(value) for value in levels + values):
        raise ValueError("levels and values must be finite")
    if any(level <= 0 for level in levels) or any(
        right <= left for left, right in zip(levels[:-1], levels[1:])
    ):
        raise ValueError("levels must be positive and strictly increasing")
    envelope_values = values[-min(3, len(values)) :]
    envelope = (min(envelope_values), max(envelope_values))
    differences = tuple(right - left for left, right in zip(values[:-1], values[1:]))
    absolute_changes = tuple(abs(value) for value in differences)

    if anomaly_distance is not None and anomaly_distance <= anomaly_tolerance:
        return ConvergenceAssessment(
            ANOMALY_NEARBY,
            False,
            (),
            None,
            None,
            envelope,
            absolute_changes,
            "a propagating channel is within the frozen Rayleigh-anomaly tolerance",
        )

    scale = max(max(abs(value) for value in values), 1.0)
    sign_tolerance = epsilon * scale
    nonzero = [value for value in differences if abs(value) > sign_tolerance]
    if not nonzero:
        return ConvergenceAssessment(
            ASYMPTOTIC_MONOTONE,
            False,
            (),
            values[-1],
            0.0,
            envelope,
            absolute_changes,
            "the sequence is numerically stationary; extrapolation is unnecessary",
        )
    monotone = all(value > 0 for value in nonzero) or all(value < 0 for value in nonzero)
    decreasing = all(
        later <= earlier * (1.0 + 1e-6)
        for earlier, later in zip(absolute_changes[:-1], absolute_changes[1:])
    )
    observed = _observed_orders(
        levels,
        absolute_changes,
        ratio_log_tolerance=ratio_log_tolerance,
        epsilon=sign_tolerance,
    )

    if monotone and decreasing:
        positive_orders = [order for order in observed if order > 0 and math.isfinite(order)]
        stable = (
            len(positive_orders) >= 2
            and max(positive_orders) - min(positive_orders) <= order_stability_tolerance
        )
        if stable:
            order = sum(positive_orders[-2:]) / 2.0
            refinement_ratio = levels[-1] / levels[-2]
            denominator = refinement_ratio ** order - 1.0
            extrapolated = values[-1] + differences[-1] / denominator
            uncertainty = abs(extrapolated - values[-1])
            reason = "monotone refinement with stable positive observed order"
        else:
            extrapolated = None
            uncertainty = None
            reason = "monotone bounded refinement, but observed order is not yet stable"
        return ConvergenceAssessment(
            ASYMPTOTIC_MONOTONE,
            stable,
            tuple(observed),
            extrapolated,
            uncertainty,
            envelope,
            absolute_changes,
            reason,
        )

    signs_change = any(left * right < 0 for left, right in zip(nonzero[:-1], nonzero[1:]))
    envelope_contracts = absolute_changes[-1] < absolute_changes[0]
    if signs_change and envelope_contracts:
        return ConvergenceAssessment(
            OSCILLATORY_BOUNDED,
            False,
            tuple(observed),
            None,
            None,
            envelope,
            absolute_changes,
            "successive refinements oscillate while the finest envelope contracts",
        )
    return ConvergenceAssessment(
        STAGNANT_OR_DIVERGENT,
        False,
        tuple(observed),
        None,
        None,
        envelope,
        absolute_changes,
        "refinement is non-asymptotic, stagnant, or divergent",
    )


def assess_fidelity_sequence(
    levels: Sequence[float],
    values: Sequence[float],
    gradients: Optional[Sequence[torch.Tensor]] = None,
    *,
    forward_tolerance: float = 5e-3,
    gradient_cosine_tolerance: float = 0.99,
    gradient_norm_ratio_tolerance: float = 0.05,
    dtype_reference_value: Optional[float] = None,
    dtype_tolerance: float = 5e-3,
    anomaly_distance: Optional[float] = None,
    anomaly_tolerance: float = 1e-3,
    same_class_external_pass: Optional[bool] = None,
    heterogeneous_external_pass: Optional[bool] = None,
    reference_gradient: Optional[torch.Tensor] = None,
    reference_validation_value: Optional[float] = None,
    reference_validation_tolerance: Optional[float] = None,
    stable_window_pairs: int = 2,
    strict: bool = False,
    require_gradients: bool = False,
    require_reference_gradient: bool = False,
    require_dtype: bool = False,
    require_same_class_external: bool = False,
    require_heterogeneous_external: bool = False,
    require_reference_validation: bool = False,
) -> FidelitySequenceAssessment:
    """Assess whether the finest result is a qualified numerical reference.

    ``strict=True`` requires gradients, dtype promotion, both external checks,
    and a still-higher reference-validation value.  Missing evidence is then an
    explicit ``insufficient_evidence`` decision, never an implicit pass.
    Independently of strict mode, oscillatory sequences cannot qualify and all
    pairs in the final ``stable_window_pairs`` window must meet the tolerances.
    """
    if stable_window_pairs < 1:
        raise ValueError("stable_window_pairs must be positive")
    if strict:
        require_gradients = True
        require_reference_gradient = True
        require_dtype = True
        require_same_class_external = True
        require_heterogeneous_external = True
        require_reference_validation = True
    convergence = classify_convergence(
        levels,
        values,
        anomaly_distance=anomaly_distance,
        anomaly_tolerance=anomaly_tolerance,
    )
    if gradients is not None and len(gradients) != len(values):
        raise ValueError("provide one gradient for every fidelity value")
    pairs: List[PairIndicator] = []
    for index in range(len(values) - 1):
        cosine = disagreement = norm_ratio = None
        if gradients is not None:
            cosine, disagreement, norm_ratio = gradient_pair_metrics(
                gradients[index], gradients[index + 1]
            )
        pairs.append(
            PairIndicator(
                float(levels[index]),
                float(levels[index + 1]),
                relative_change(values[index], values[index + 1]),
                cosine,
                disagreement,
                norm_ratio,
            )
        )
    final_pair = pairs[-1]
    dtype_change = (
        None
        if dtype_reference_value is None
        else relative_change(values[-1], dtype_reference_value)
    )
    reference_gradient_cosine = None
    reference_gradient_relative_error = None
    reference_directional_derivative = None
    reference_gradient_norm_ratio = None
    if reference_gradient is not None:
        if gradients is None:
            raise ValueError("reference_gradient requires a gradient sequence")
        (
            reference_gradient_cosine,
            _,
            reference_gradient_norm_ratio,
        ) = gradient_pair_metrics(gradients[-1], reference_gradient)
        reference_norm = torch.linalg.vector_norm(reference_gradient.reshape(-1))
        difference_norm = torch.linalg.vector_norm(
            (gradients[-1] - reference_gradient).reshape(-1)
        )
        reference_gradient_relative_error = float(
            (
                difference_norm
                / torch.clamp(reference_norm, min=1e-15)
            ).detach().cpu()
        )
        candidate_flat = gradients[-1].reshape(-1)
        reference_flat = reference_gradient.reshape(-1)
        candidate_norm = torch.linalg.vector_norm(candidate_flat)
        directional = torch.real(torch.sum(torch.conj(reference_flat) * candidate_flat))
        reference_directional_derivative = float(
            (directional / torch.clamp(candidate_norm, min=1e-15)).detach().cpu()
        )
    validation_tolerance = (
        forward_tolerance
        if reference_validation_tolerance is None
        else float(reference_validation_tolerance)
    )
    if validation_tolerance < 0:
        raise ValueError("reference_validation_tolerance must be non-negative")
    reference_validation_change = (
        None
        if reference_validation_value is None
        else relative_change(values[-1], reference_validation_value)
    )
    reasons: List[str] = []
    missing: List[str] = []
    if convergence.classification != ASYMPTOTIC_MONOTONE:
        reasons.append("convergence classification is {}".format(convergence.classification))
    if len(pairs) < stable_window_pairs:
        reasons.append("fewer adjacent pairs than the required stable window")
        window = pairs
    else:
        window = pairs[-stable_window_pairs:]
    if any(pair.forward_relative_change > forward_tolerance for pair in window):
        reasons.append("stable-window observable change exceeds tolerance")
    if gradients is None:
        if require_gradients:
            missing.append("gradient sequence")
    else:
        if any(
            pair.gradient_cosine is None
            or pair.gradient_cosine < gradient_cosine_tolerance
            for pair in window
        ):
            reasons.append("stable-window gradient cosine is below tolerance")
        if any(
            pair.gradient_norm_ratio is None
            or abs(pair.gradient_norm_ratio - 1.0) > gradient_norm_ratio_tolerance
            for pair in window
        ):
            reasons.append("stable-window gradient norm ratio is outside tolerance")
    if reference_gradient is None:
        if require_reference_gradient:
            missing.append("higher-level reference gradient")
    else:
        assert reference_gradient_cosine is not None
        assert reference_gradient_norm_ratio is not None
        if reference_gradient_cosine < gradient_cosine_tolerance:
            reasons.append("candidate gradient direction disagrees with the validation level")
        if abs(reference_gradient_norm_ratio - 1.0) > gradient_norm_ratio_tolerance:
            reasons.append("candidate gradient norm disagrees with the validation level")
    if dtype_change is None:
        if require_dtype:
            missing.append("dtype promotion check")
    if dtype_change is not None and dtype_change > dtype_tolerance:
        reasons.append("dtype promotion changes the reference beyond tolerance")
    if same_class_external_pass is None:
        if require_same_class_external:
            missing.append("same-class external alignment")
    elif same_class_external_pass is False:
        reasons.append("same-class external alignment failed")
    if heterogeneous_external_pass is None:
        if require_heterogeneous_external:
            missing.append("heterogeneous external alignment")
    elif heterogeneous_external_pass is False:
        reasons.append("heterogeneous external alignment failed")
    if reference_validation_change is None:
        if require_reference_validation:
            missing.append("higher reference validation")
    elif reference_validation_change > validation_tolerance:
        reasons.append("candidate reference changes at the validation level")
    reasons.extend("missing required {}".format(item) for item in missing)
    hard_reject = convergence.classification == ANOMALY_NEARBY or any(
        pair.gradient_cosine is not None and pair.gradient_cosine < 0 for pair in window
    )
    hard_reject = hard_reject or (
        reference_directional_derivative is not None
        and reference_directional_derivative < 0
    )
    if hard_reject:
        decision = REJECT
    elif reasons and len(reasons) > len(missing):
        decision = REFINE
    elif missing:
        decision = INSUFFICIENT_EVIDENCE
    else:
        decision = SAFE
    return FidelitySequenceAssessment(
        tuple(float(level) for level in levels),
        float(values[-1]),
        convergence,
        tuple(pairs),
        final_pair.forward_relative_change,
        final_pair.gradient_cosine,
        final_pair.gradient_norm_ratio,
        reference_gradient_cosine,
        reference_gradient_relative_error,
        reference_directional_derivative,
        dtype_change,
        reference_validation_change,
        stable_window_pairs,
        decision,
        not missing,
        decision == SAFE,
        tuple(reasons),
    )


def evaluate_indicator_calibration(
    predicted_errors: Sequence[float],
    actual_errors: Sequence[float],
    *,
    safe_threshold: float,
    actual_error_tolerance: float,
    predicted_safe_flags: Optional[Sequence[bool]] = None,
) -> IndicatorCalibration:
    """Evaluate empirical coverage and false-safe behavior on held-out cases.

    When ``predicted_safe_flags`` is omitted, safety is defined by the scalar
    error threshold for backward compatibility.  Supplying flags evaluates the
    complete decision rule (convergence, stable window, gradient and evidence),
    which is the relevant quantity for an adaptive-fidelity controller.
    """
    if len(predicted_errors) != len(actual_errors) or not predicted_errors:
        raise ValueError("provide equally sized non-empty predicted and actual errors")
    if safe_threshold < 0 or actual_error_tolerance < 0:
        raise ValueError("error thresholds must be non-negative")
    if predicted_safe_flags is not None and len(predicted_safe_flags) != len(predicted_errors):
        raise ValueError("provide one predicted-safe flag for every error pair")
    predicted = [float(value) for value in predicted_errors]
    actual = [float(value) for value in actual_errors]
    if any(value < 0 or not math.isfinite(value) for value in predicted + actual):
        raise ValueError("errors must be finite and non-negative")
    count = len(predicted)
    coverage = sum(p >= a for p, a in zip(predicted, actual)) / count
    safe_flags = (
        [p <= safe_threshold for p in predicted]
        if predicted_safe_flags is None
        else [bool(value) for value in predicted_safe_flags]
    )
    false_safe_count = sum(
        safe and a > actual_error_tolerance
        for safe, a in zip(safe_flags, actual)
    )
    predicted_safe_count = sum(safe_flags)
    false_safe = false_safe_count / count
    conditional_false_safe = (
        None
        if predicted_safe_count == 0
        else false_safe_count / predicted_safe_count
    )
    safe_precision = (
        None
        if predicted_safe_count == 0
        else 1.0 - float(conditional_false_safe)
    )
    # One-sided 95% Wilson upper bound.  With no predicted-safe samples the
    # bound is deliberately 1: absence of evidence is not evidence of safety.
    if predicted_safe_count == 0:
        conditional_upper = 1.0
    else:
        z = 1.6448536269514722
        phat = false_safe_count / predicted_safe_count
        denominator = 1.0 + z * z / predicted_safe_count
        centre = phat + z * z / (2.0 * predicted_safe_count)
        spread = z * math.sqrt(
            phat * (1.0 - phat) / predicted_safe_count
            + z * z / (4.0 * predicted_safe_count ** 2)
        )
        conditional_upper = min(1.0, (centre + spread) / denominator)
    conservatism = sum(max(p - a, 0.0) for p, a in zip(predicted, actual)) / count
    underestimation = sum(max(a - p, 0.0) for p, a in zip(predicted, actual)) / count
    epsilon = 1e-15
    required_safety_factor = max(
        a / max(p, epsilon) for p, a in zip(predicted, actual)
    )
    return IndicatorCalibration(
        count,
        coverage,
        predicted_safe_count,
        false_safe_count,
        false_safe,
        conditional_false_safe,
        conditional_upper,
        safe_precision,
        conservatism,
        underestimation,
        required_safety_factor,
        safe_threshold,
        actual_error_tolerance,
    )
