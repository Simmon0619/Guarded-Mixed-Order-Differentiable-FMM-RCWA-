"""Rule-based observable/gradient fidelity controller."""

from dataclasses import dataclass
from typing import Optional

from trustworthy_fmm.core.types import FidelityDecision


@dataclass(frozen=True)
class FidelityThresholds:
    forward_tolerance: float = 0.005
    gradient_cosine_search: float = 0.95
    gradient_cosine_final: float = 0.99
    local_ratio_reject: float = 0.25
    local_ratio_expand: float = 0.75
    order_increment: int = 2
    max_fourier_order: int = 31
    trust_radius_min: float = 1e-4
    trust_radius_max: float = 0.5
    trust_shrink: float = 0.5
    trust_expand: float = 1.5


def decide_fidelity(
    *,
    fourier_order: int,
    trust_radius: float,
    forward_error: float,
    gradient_cosine: Optional[float],
    local_ratio: Optional[float],
    final_stage: bool = False,
    thresholds: FidelityThresholds = FidelityThresholds(),
) -> FidelityDecision:
    required_cosine = (
        thresholds.gradient_cosine_final if final_stage else thresholds.gradient_cosine_search
    )
    diagnostics = {
        "forward_error": forward_error,
        "gradient_cosine": float("nan") if gradient_cosine is None else gradient_cosine,
        "local_ratio": float("nan") if local_ratio is None else local_ratio,
    }
    if forward_error > thresholds.forward_tolerance:
        next_order = min(fourier_order + thresholds.order_increment, thresholds.max_fourier_order)
        if next_order == fourier_order:
            return FidelityDecision("blocked", False, fourier_order, trust_radius, "forward error remains high at maximum order", diagnostics)
        return FidelityDecision("increase_order", False, next_order, trust_radius, "forward error exceeds tolerance", diagnostics)
    if gradient_cosine is not None and gradient_cosine < required_cosine:
        next_order = min(fourier_order + thresholds.order_increment, thresholds.max_fourier_order)
        if next_order == fourier_order:
            return FidelityDecision("increase_precision", False, fourier_order, trust_radius, "gradient is not converged at maximum order", diagnostics)
        return FidelityDecision("increase_order", False, next_order, trust_radius, "gradient cosine is below the required threshold", diagnostics)
    if local_ratio is not None and local_ratio <= thresholds.local_ratio_reject:
        radius = max(trust_radius * thresholds.trust_shrink, thresholds.trust_radius_min)
        return FidelityDecision("reject_shrink", False, fourier_order, radius, "local model ratio rejects the candidate", diagnostics)
    if local_ratio is not None and local_ratio > thresholds.local_ratio_expand:
        radius = min(trust_radius * thresholds.trust_expand, thresholds.trust_radius_max)
        return FidelityDecision("accept_expand", True, fourier_order, radius, "local model agrees with the candidate improvement", diagnostics)
    return FidelityDecision("accept_hold", True, fourier_order, trust_radius, "all available fidelity checks pass", diagnostics)

