"""Atomic, signature-checked checkpoints for long numerical campaigns."""

import json
import os
from pathlib import Path
import uuid
from typing import Any, Mapping, Optional

import torch

from trustworthy_fmm.reproducibility.artifacts import config_digest


CHECKPOINT_VERSION = 1


def _temporary_sibling(path: Path) -> Path:
    return path.with_name(".{}.{}.tmp".format(path.name, uuid.uuid4().hex))


def atomic_torch_save(payload: Any, path: Path) -> None:
    """Write a torch payload atomically in the destination directory."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = _temporary_sibling(path)
    try:
        torch.save(payload, temporary)
        os.replace(str(temporary), str(path))
    finally:
        if temporary.exists():
            temporary.unlink()


def atomic_json_write(payload: Any, path: Path) -> None:
    """Write JSON atomically so a killed process cannot leave partial syntax."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = _temporary_sibling(path)
    try:
        temporary.write_text(
            json.dumps(payload, indent=2, ensure_ascii=False, default=str),
            encoding="utf-8",
        )
        os.replace(str(temporary), str(path))
    finally:
        if temporary.exists():
            temporary.unlink()


class CheckpointStore:
    """Namespace checkpoints by a frozen configuration digest."""

    def __init__(self, root: Path, config: Mapping[str, Any], stage: str) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.signature = config_digest(config)
        self.stage = str(stage)
        atomic_json_write(
            {
                "checkpoint_version": CHECKPOINT_VERSION,
                "stage": self.stage,
                "config_signature": self.signature,
            },
            self.root / "manifest.json",
        )

    def path(self, *parts: str, suffix: str = ".pt") -> Path:
        if not parts:
            raise ValueError("checkpoint path requires at least one component")
        safe = [
            str(part).replace("/", "_").replace("\\", "_").replace(":", "_")
            for part in parts
        ]
        return self.root.joinpath(*safe[:-1], safe[-1] + suffix)

    def save(self, path: Path, payload: Mapping[str, Any]) -> None:
        atomic_torch_save(
            {
                "checkpoint_version": CHECKPOINT_VERSION,
                "stage": self.stage,
                "config_signature": self.signature,
                "payload": dict(payload),
            },
            path,
        )

    def load(self, path: Path) -> Optional[Mapping[str, Any]]:
        if not Path(path).exists():
            return None
        envelope = torch.load(str(path), map_location="cpu", weights_only=False)
        if not isinstance(envelope, Mapping):
            raise RuntimeError("checkpoint is not a mapping: {}".format(path))
        if int(envelope.get("checkpoint_version", -1)) != CHECKPOINT_VERSION:
            raise RuntimeError("unsupported checkpoint version: {}".format(path))
        if str(envelope.get("stage")) != self.stage:
            raise RuntimeError("checkpoint stage mismatch: {}".format(path))
        if str(envelope.get("config_signature")) != self.signature:
            raise RuntimeError(
                "checkpoint configuration changed; use a new output directory: {}".format(path)
            )
        payload = envelope.get("payload")
        if not isinstance(payload, Mapping):
            raise RuntimeError("checkpoint payload is not a mapping: {}".format(path))
        return payload
