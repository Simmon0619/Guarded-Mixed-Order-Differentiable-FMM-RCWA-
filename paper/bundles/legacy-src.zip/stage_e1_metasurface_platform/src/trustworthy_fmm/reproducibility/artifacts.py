"""Artifact writer implementing the frozen stage-output contract."""

import csv
import hashlib
import json
import os
import platform
import random
import sys
from pathlib import Path
from typing import Any, Dict, Iterable, Mapping, Sequence

import numpy as np
import scipy
import torch
import yaml


def environment_metadata() -> Dict[str, Any]:
    metadata = {
        "python": sys.version,
        "platform": platform.platform(),
        "torch": torch.__version__,
        "numpy": np.__version__,
        "scipy": scipy.__version__,
        "cuda_available": torch.cuda.is_available(),
        "cuda_version": torch.version.cuda,
        "device": torch.cuda.get_device_name(0) if torch.cuda.is_available() else "cpu",
    }
    return metadata


def set_reproducible_seed(seed: int, deterministic: bool = True) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    if deterministic:
        # Required by deterministic CuBLAS matmul on CUDA >= 10.2.  Setting it
        # before the first solver call is sufficient and keeps GPU Gate C/D
        # reproducible instead of silently falling back to CPU.
        os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
        torch.use_deterministic_algorithms(True)


def config_digest(config: Mapping[str, Any]) -> str:
    canonical = json.dumps(config, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


class StageArtifactWriter:
    def __init__(self, output_directory: Path) -> None:
        self.output_directory = Path(output_directory)
        self.output_directory.mkdir(parents=True, exist_ok=True)

    def write_config(self, config: Mapping[str, Any]) -> None:
        payload = dict(config)
        payload["sha256"] = config_digest(config)
        with (self.output_directory / "config.yaml").open("w", encoding="utf-8") as stream:
            yaml.safe_dump(payload, stream, sort_keys=False, allow_unicode=True)

    def write_environment(self) -> None:
        with (self.output_directory / "environment.json").open("w", encoding="utf-8") as stream:
            json.dump(environment_metadata(), stream, indent=2, ensure_ascii=False)

    def write_metrics(self, rows: Sequence[Mapping[str, Any]]) -> None:
        fieldnames = sorted({key for row in rows for key in row})
        with (self.output_directory / "raw_metrics.csv").open("w", newline="", encoding="utf-8") as stream:
            writer = csv.DictWriter(stream, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)

    def write_summary(self, summary: Mapping[str, Any]) -> None:
        with (self.output_directory / "summary.json").open("w", encoding="utf-8") as stream:
            json.dump(summary, stream, indent=2, ensure_ascii=False, default=str)

    def write_arrays(self, arrays: Mapping[str, Any], filename: str = "raw_arrays.npz") -> None:
        """Write exact numeric arrays without lossy CSV/JSON string conversion."""
        if not arrays:
            raise ValueError("arrays must not be empty")
        np.savez_compressed(
            str(self.output_directory / filename),
            **{name: np.asarray(value) for name, value in arrays.items()},
        )

    def write_report(
        self,
        title: str,
        gate_status: str,
        summary: Mapping[str, Any],
        allowed_actions: Sequence[str],
    ) -> None:
        if gate_status not in ("PASS", "FAIL", "CONDITIONAL"):
            raise ValueError("gate_status must be PASS, FAIL, or CONDITIONAL")
        lines = ["# {}".format(title), "", "## Summary", ""]
        for key, value in summary.items():
            lines.append("- **{}:** `{}`".format(key, value))
        lines.extend(["", "## Allowed next actions", ""])
        lines.extend("- {}".format(action) for action in allowed_actions)
        lines.extend(["", "## Gate", "", "**{}**".format(gate_status), ""])
        (self.output_directory / "STAGE_REPORT.md").write_text("\n".join(lines), encoding="utf-8")
