"""Solver-independent power and complex-amplitude routing objectives."""

from typing import Mapping, Sequence

import torch

from trustworthy_fmm.core.types import Order, ScatteringResult


def power_routing_loss(
    result: ScatteringResult,
    target_powers: Mapping[Order, float],
    *,
    reflection_weight: float = 0.0,
    leakage_weight: float = 0.0,
) -> torch.Tensor:
    loss = torch.zeros((), dtype=result.power_t.dtype, device=result.power_t.device)
    target_indices = set()
    for order, target in target_powers.items():
        index = result.order_index(order)
        target_indices.add(index)
        loss = loss + (result.power_t[..., index] - target) ** 2
    if leakage_weight:
        leakage = torch.stack(
            [result.power_t[..., index] for index in range(len(result.orders)) if index not in target_indices]
        ).sum(dim=0)
        loss = loss + leakage_weight * leakage
    return loss + reflection_weight * result.total_R


def one_hot_routing_score(
    result: ScatteringResult,
    target_order: Order,
    *,
    leakage_orders: Sequence[Order] = (),
    leakage_weight: float = 0.0,
    reflection_weight: float = 0.0,
) -> torch.Tensor:
    score = result.transmitted_power(target_order)
    for order in leakage_orders:
        score = score - leakage_weight * result.transmitted_power(order)
    return score - reflection_weight * result.total_R


def complex_routing_loss(
    result: ScatteringResult,
    target_amplitudes: Mapping[Order, complex],
    *,
    global_phase_invariant: bool = True,
) -> torch.Tensor:
    predicted = torch.stack([result.transmitted_amplitude(order) for order in target_amplitudes])
    target = torch.as_tensor(
        list(target_amplitudes.values()), dtype=predicted.dtype, device=predicted.device
    )
    if global_phase_invariant:
        overlap = torch.sum(torch.conj(target) * predicted)
        phase = overlap / torch.clamp(torch.abs(overlap), min=1e-15)
        target = phase * target
    return torch.sum(torch.abs(predicted - target) ** 2)


def state_confusion_matrix(
    results: Mapping[str, ScatteringResult], orders: Sequence[Order]
) -> torch.Tensor:
    rows = []
    for result in results.values():
        rows.append(torch.stack([result.transmitted_power(order) for order in orders]))
    return torch.stack(rows)

