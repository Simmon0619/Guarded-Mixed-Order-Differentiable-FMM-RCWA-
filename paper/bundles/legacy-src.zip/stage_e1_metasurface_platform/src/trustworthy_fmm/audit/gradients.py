"""Directional, cross-fidelity, and local-model gradient audits."""

import math
from typing import Any, Callable, Dict, Mapping, Sequence, Tuple

import torch

from trustworthy_fmm.core.types import AuditResult


TensorObjective = Callable[[torch.Tensor], torch.Tensor]


def normalized_direction(direction: torch.Tensor) -> torch.Tensor:
    norm = torch.linalg.vector_norm(direction)
    if float(norm.detach().cpu()) == 0.0:
        raise ValueError("direction must be non-zero")
    return direction / norm


def directional_derivative_audit(
    objective: TensorObjective,
    point: torch.Tensor,
    direction: torch.Tensor,
    steps: Sequence[float],
) -> AuditResult:
    if not steps or any(step <= 0 for step in steps):
        raise ValueError("steps must contain positive finite-difference scales")
    work = point.detach().clone().requires_grad_(True)
    unit = normalized_direction(direction.to(dtype=work.dtype, device=work.device))
    value = objective(work)
    if value.ndim != 0 or value.is_complex():
        raise ValueError("objective must return one real scalar")
    gradient = torch.autograd.grad(value, work, create_graph=False)[0]
    ad = torch.sum(gradient * unit)
    finite: Dict[float, float] = {}
    errors: Dict[float, float] = {}
    absolute_errors: Dict[float, float] = {}
    with torch.no_grad():
        for step in steps:
            plus = objective(point + step * unit)
            minus = objective(point - step * unit)
            fd = (plus - minus) / (2 * step)
            finite[float(step)] = float(fd.detach().cpu())
            ad_value = float(ad.detach().cpu())
            fd_value = float(fd.detach().cpu())
            absolute_errors[float(step)] = abs(ad_value - fd_value)
            denom = max(abs(fd_value), abs(ad_value), 1e-12)
            errors[float(step)] = absolute_errors[float(step)] / denom
    best_step = min(errors, key=errors.get)
    return AuditResult(
        ad_directional=float(ad.detach().cpu()),
        finite_differences=finite,
        best_step=best_step,
        best_fd=finite[best_step],
        relative_error=errors[best_step],
        gradient_norm=float(torch.linalg.vector_norm(gradient).detach().cpu()),
        diagnostics={
            "errors_by_step": errors,
            "absolute_errors_by_step": absolute_errors,
            "best_absolute_error": absolute_errors[best_step],
            "objective": float(value.detach().cpu()),
        },
    )


def gradient_cosine(first: torch.Tensor, second: torch.Tensor, epsilon: float = 1e-15) -> float:
    a = first.reshape(-1)
    b = second.reshape(-1)
    denominator = torch.linalg.vector_norm(a) * torch.linalg.vector_norm(b)
    cosine = torch.real(torch.sum(torch.conj(a) * b)) / torch.clamp(denominator, min=epsilon)
    # Roundoff can produce 1+O(eps) for nearly identical high-dimensional
    # gradients.  Cosine is mathematically bounded and downstream strict gates
    # should not fail on that representation artifact.
    return float(torch.clamp(cosine, min=-1.0, max=1.0).detach().cpu())


def objective_and_gradient(objective: TensorObjective, point: torch.Tensor) -> Tuple[float, torch.Tensor]:
    work = point.detach().clone().requires_grad_(True)
    value = objective(work)
    gradient = torch.autograd.grad(value, work)[0]
    return float(value.detach().cpu()), gradient.detach()


def cross_fidelity_audit(
    low_objective: TensorObjective,
    high_objective: TensorObjective,
    point: torch.Tensor,
) -> Dict[str, float]:
    low_value, low_gradient = objective_and_gradient(low_objective, point)
    high_value, high_gradient = objective_and_gradient(high_objective, point)
    forward_error = abs(high_value - low_value) / max(abs(high_value), 1e-12)
    cosine = gradient_cosine(low_gradient, high_gradient)
    normalized_difference = float(
        (torch.linalg.vector_norm(high_gradient - low_gradient) /
         torch.clamp(torch.linalg.vector_norm(high_gradient), min=1e-15)).cpu()
    )
    low_norm = float(torch.linalg.vector_norm(low_gradient).cpu())
    high_norm = float(torch.linalg.vector_norm(high_gradient).cpu())
    scale = max(
        float(torch.amax(torch.abs(low_gradient)).cpu()),
        float(torch.amax(torch.abs(high_gradient)).cpu()),
        1e-15,
    )
    active = (torch.abs(low_gradient) > 1e-10 * scale) | (
        torch.abs(high_gradient) > 1e-10 * scale
    )
    sign_flips = (low_gradient * high_gradient < 0) & active
    sign_flip_fraction = (
        float(torch.mean(sign_flips[active].to(torch.float64)).cpu())
        if bool(torch.any(active))
        else 0.0
    )
    return {
        "low_value": low_value,
        "high_value": high_value,
        "forward_error": forward_error,
        "gradient_cosine": cosine,
        "gradient_angle_error": 1.0 - cosine,
        "gradient_normalized_difference": normalized_difference,
        "gradient_norm_ratio": low_norm / max(high_norm, 1e-15),
        "gradient_sign_flip_fraction": sign_flip_fraction,
    }


def multi_directional_derivative_audit(
    objective: TensorObjective,
    point: torch.Tensor,
    directions: Sequence[torch.Tensor],
    steps: Sequence[float],
    *,
    relative_error_tolerance: float = 1e-4,
) -> Dict[str, Any]:
    """Run a central-FD step scan in several independent directions."""
    if not directions:
        raise ValueError("directions must be non-empty")
    if relative_error_tolerance <= 0:
        raise ValueError("relative_error_tolerance must be positive")
    audits = [directional_derivative_audit(objective, point, d, steps) for d in directions]
    errors = [audit.relative_error for audit in audits]
    finite = [
        math.isfinite(audit.ad_directional)
        and math.isfinite(audit.best_fd)
        and math.isfinite(audit.gradient_norm)
        and all(math.isfinite(value) for value in audit.finite_differences.values())
        for audit in audits
    ]
    sorted_errors = sorted(errors)
    middle = len(sorted_errors) // 2
    median_error = (
        sorted_errors[middle]
        if len(sorted_errors) % 2
        else 0.5 * (sorted_errors[middle - 1] + sorted_errors[middle])
    )
    return {
        "direction_count": len(audits),
        "finite_count": sum(finite),
        "pass_count": sum(
            is_finite and error <= relative_error_tolerance
            for is_finite, error in zip(finite, errors)
        ),
        "all_finite": all(finite),
        "all_pass": all(
            is_finite and error <= relative_error_tolerance
            for is_finite, error in zip(finite, errors)
        ),
        "maximum_relative_error": max(errors),
        "median_relative_error": median_error,
        "audits": [
            {
                "ad_directional": audit.ad_directional,
                "finite_differences": dict(audit.finite_differences),
                "best_step": audit.best_step,
                "best_fd": audit.best_fd,
                "relative_error": audit.relative_error,
                "gradient_norm": audit.gradient_norm,
                "diagnostics": audit.diagnostics,
            }
            for audit in audits
        ],
    }


def cross_fidelity_step_audit(
    low_objective: TensorObjective,
    high_objective: TensorObjective,
    point: torch.Tensor,
    *,
    step_radius: float,
    maximize: bool = True,
    bounds: Tuple[float, float] = (0.0, 1.0),
) -> Dict[str, float]:
    """Audit whether a low-fidelity ascent/descent step helps the high model."""
    if step_radius <= 0:
        raise ValueError("step_radius must be positive")
    if bounds[0] >= bounds[1]:
        raise ValueError("bounds must be strictly increasing")
    low_value, low_gradient = objective_and_gradient(low_objective, point)
    high_value, high_gradient = objective_and_gradient(high_objective, point)
    direction = normalized_direction(low_gradient) * (1.0 if maximize else -1.0)
    candidate = torch.clamp(point + step_radius * direction, bounds[0], bounds[1])
    actual_step = candidate - point
    with torch.no_grad():
        candidate_low = float(low_objective(candidate).detach().cpu())
        candidate_high = float(high_objective(candidate).detach().cpu())
    low_prediction = float(torch.sum(low_gradient * actual_step).cpu())
    high_prediction = float(torch.sum(high_gradient * actual_step).cpu())
    low_change = candidate_low - low_value
    high_change = candidate_high - high_value
    sign = 1.0 if maximize else -1.0
    return {
        **cross_fidelity_audit(low_objective, high_objective, point),
        "step_norm": float(torch.linalg.vector_norm(actual_step).cpu()),
        "low_predicted_change": low_prediction,
        "high_predicted_change": high_prediction,
        "low_actual_change": low_change,
        "high_actual_change": high_change,
        "high_local_ratio": (
            high_change / high_prediction if abs(high_prediction) > 1e-15 else float("nan")
        ),
        "low_improves_high_degrades": float(
            sign * low_change > 0 and sign * high_change < 0
        ),
    }


def _rank_correlation(first: Sequence[float], second: Sequence[float]) -> float:
    if len(first) != len(second) or len(first) < 2:
        return float("nan")
    a = torch.as_tensor(first, dtype=torch.float64)
    b = torch.as_tensor(second, dtype=torch.float64)
    if not bool(torch.all(torch.isfinite(a))) or not bool(torch.all(torch.isfinite(b))):
        return float("nan")
    rank_a = torch.argsort(torch.argsort(a)).to(torch.float64)
    rank_b = torch.argsort(torch.argsort(b)).to(torch.float64)
    rank_a = rank_a - torch.mean(rank_a)
    rank_b = rank_b - torch.mean(rank_b)
    denominator = torch.linalg.vector_norm(rank_a) * torch.linalg.vector_norm(rank_b)
    if float(denominator) == 0.0:
        return float("nan")
    return float(torch.sum(rank_a * rank_b) / denominator)


def eigen_gradient_risk_summary(
    records: Sequence[Mapping[str, float]],
    *,
    relative_error_tolerance: float = 1e-4,
    correlation_trigger: float = 0.5,
) -> Dict[str, Any]:
    """Decide from evidence whether a stabilized eig backward is warranted."""
    if not records:
        raise ValueError("records must be non-empty")
    failures = [
        (not bool(record.get("finite", 1.0)))
        or float(record["ad_fd_relative_error"]) > relative_error_tolerance
        for record in records
    ]
    gaps = [max(float(record["min_eigen_gap"]), 1e-300) for record in records]
    conditions = [max(float(record["modal_condition"]), 1.0) for record in records]
    errors = [max(float(record["ad_fd_relative_error"]), 1e-300) for record in records]
    gap_risk_correlation = _rank_correlation(
        [-math.log10(value) for value in gaps],
        [math.log10(value) for value in errors],
    )
    condition_risk_correlation = _rank_correlation(
        [math.log10(value) for value in conditions],
        [math.log10(value) for value in errors],
    )
    failure_count = sum(failures)
    systematic = failure_count >= 2 and failure_count / len(records) >= 0.2
    correlated = any(
        math.isfinite(value) and value >= correlation_trigger
        for value in (gap_risk_correlation, condition_risk_correlation)
    )
    return {
        "records": len(records),
        "failure_count": failure_count,
        "failure_rate": failure_count / len(records),
        "gap_risk_spearman": gap_risk_correlation,
        "condition_risk_spearman": condition_risk_correlation,
        "systematic_failure": systematic,
        "risk_correlated": correlated,
        "custom_backward_triggered": systematic and correlated,
        "decision": (
            "compare_stabilized_backward" if systematic and correlated else "keep_default_backward"
        ),
    }


def local_model_ratio(
    current_value: float,
    candidate_value: float,
    gradient: torch.Tensor,
    step: torch.Tensor,
    *,
    maximize: bool = True,
    epsilon: float = 1e-15,
) -> float:
    prediction = float(torch.real(torch.sum(torch.conj(gradient) * step)).detach().cpu())
    actual = candidate_value - current_value
    if not maximize:
        prediction = -prediction
        actual = -actual
    if abs(prediction) <= epsilon:
        return float("nan")
    return actual / prediction
