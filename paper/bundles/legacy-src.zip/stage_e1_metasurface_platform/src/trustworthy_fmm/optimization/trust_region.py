"""Trust-region helpers, including a first-order multifidelity correction."""

from dataclasses import dataclass

import torch


def bounded_gradient_step(
    gradient: torch.Tensor,
    radius: float,
    *,
    maximize: bool = True,
) -> torch.Tensor:
    if radius <= 0:
        raise ValueError("radius must be positive")
    norm = torch.linalg.vector_norm(gradient)
    if float(norm.detach().cpu()) == 0.0:
        return torch.zeros_like(gradient)
    direction = gradient / norm
    return direction * radius * (1.0 if maximize else -1.0)


def _real_inner(first: torch.Tensor, second: torch.Tensor) -> float:
    return float(torch.real(torch.sum(torch.conj(first) * second)).detach().cpu())


@dataclass(frozen=True)
class FirstOrderConsistentModel:
    """Additive correction making a low model tangent to the high model."""

    low_center_value: float
    high_center_value: float
    low_center_gradient: torch.Tensor
    high_center_gradient: torch.Tensor

    def __post_init__(self) -> None:
        if self.low_center_gradient.shape != self.high_center_gradient.shape:
            raise ValueError("low and high gradients must have identical shapes")

    @property
    def gradient_correction(self) -> torch.Tensor:
        return self.high_center_gradient - self.low_center_gradient

    def value(self, low_candidate_value: float, step: torch.Tensor) -> float:
        if step.shape != self.low_center_gradient.shape:
            raise ValueError("step shape must match the model gradients")
        return (
            float(low_candidate_value)
            + self.high_center_value
            - self.low_center_value
            + _real_inner(self.gradient_correction, step)
        )

    def predicted_change(self, low_candidate_value: float, step: torch.Tensor) -> float:
        return self.value(low_candidate_value, step) - self.high_center_value

    def consistency_residuals(self) -> tuple:
        center_value = self.value(self.low_center_value, torch.zeros_like(self.low_center_gradient))
        model_center_gradient = self.low_center_gradient + self.gradient_correction
        return (
            abs(center_value - self.high_center_value),
            float(torch.linalg.vector_norm(
                model_center_gradient - self.high_center_gradient
            ).detach().cpu()),
        )


@dataclass(frozen=True)
class ModelManagedDecision:
    action: str
    accepted: bool
    rho: float
    predicted_change: float
    actual_change: float
    next_radius: float
    high_candidate_evaluated: bool = True


def assess_model_managed_candidate(
    model: FirstOrderConsistentModel,
    *,
    low_candidate_value: float,
    high_candidate_value: float,
    step: torch.Tensor,
    radius: float,
    maximize: bool = True,
    acceptance_ratio: float = 0.1,
    expansion_ratio: float = 0.75,
    shrink: float = 0.5,
    expand: float = 1.5,
    radius_min: float = 1e-4,
    radius_max: float = 0.5,
) -> ModelManagedDecision:
    """Accept/reject a candidate after the mandatory high-fidelity evaluation."""
    if radius <= 0 or radius_min <= 0 or radius_max < radius_min:
        raise ValueError("invalid trust-region radii")
    if not 0 <= acceptance_ratio < expansion_ratio:
        raise ValueError("acceptance_ratio must be below expansion_ratio")
    predicted = model.predicted_change(low_candidate_value, step)
    actual = float(high_candidate_value) - model.high_center_value
    orientation = 1.0 if maximize else -1.0
    oriented_prediction = orientation * predicted
    oriented_actual = orientation * actual
    if oriented_prediction <= 1e-15:
        return ModelManagedDecision(
            "reject_nonpositive_model",
            False,
            float("nan"),
            predicted,
            actual,
            max(radius * shrink, radius_min),
        )
    rho = oriented_actual / oriented_prediction
    if not torch.isfinite(torch.as_tensor(rho)) or rho < acceptance_ratio:
        return ModelManagedDecision(
            "reject_shrink",
            False,
            rho,
            predicted,
            actual,
            max(radius * shrink, radius_min),
        )
    boundary_step = float(torch.linalg.vector_norm(step).detach().cpu()) >= 0.9 * radius
    if rho >= expansion_ratio and boundary_step:
        return ModelManagedDecision(
            "accept_expand",
            True,
            rho,
            predicted,
            actual,
            min(radius * expand, radius_max),
        )
    return ModelManagedDecision(
        "accept_hold", True, rho, predicted, actual, radius
    )
