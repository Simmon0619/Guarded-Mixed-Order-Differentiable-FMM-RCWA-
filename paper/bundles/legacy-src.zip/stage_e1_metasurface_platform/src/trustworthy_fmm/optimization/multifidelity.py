"""Utilities for trustworthy optimization across Fourier truncation levels.

The helpers in this module are deliberately independent of the RCWA solver.  A
Fourier level is always represented by ``(Mx, My)``; collapsing it to a scalar
would hide the strong aspect ratio of the project unit cell.  The MGDA helper
constructs a common ascent direction from several *discretizations of the same
physical objective*.  It is a proposal mechanism only -- an independently
evaluated high-fidelity objective must still accept or reject the candidate.
"""

from dataclasses import dataclass
import itertools
import math
from typing import Iterable, Sequence, Tuple

import torch


HalfOrders = Tuple[int, int]


def parse_half_orders(value: Sequence[int]) -> HalfOrders:
    """Return a validated ``(Mx, My)`` Fourier half-order pair."""
    if isinstance(value, (str, bytes)) or len(value) != 2:
        raise ValueError("Fourier half_orders must contain exactly [Mx, My]")
    mx, my = (int(component) for component in value)
    if mx < 0 or my < 0:
        raise ValueError("Fourier half-orders must be non-negative")
    return mx, my


def harmonic_count(half_orders: Sequence[int]) -> int:
    """Number of retained reciprocal-lattice orders."""
    mx, my = parse_half_orders(half_orders)
    return (2 * mx + 1) * (2 * my + 1)


def fidelity_key(half_orders: Sequence[int]) -> str:
    mx, my = parse_half_orders(half_orders)
    return "Mx{}_My{}".format(mx, my)


def rms_norm(tensor: torch.Tensor) -> float:
    if tensor.numel() == 0:
        return 0.0
    return float(
        (torch.linalg.vector_norm(tensor) / math.sqrt(tensor.numel()))
        .detach()
        .cpu()
    )


def project_feasible_gradient(
    point: torch.Tensor,
    gradient: torch.Tensor,
    *,
    lower: float = 0.0,
    upper: float = 1.0,
    mirror_y: bool = False,
    tolerance: float = 1e-12,
) -> torch.Tensor:
    """Project a maximizing gradient onto the box-constrained tangent cone."""
    if point.shape != gradient.shape:
        raise ValueError("point and gradient must have identical shapes")
    projected = gradient.detach().clone()
    projected = torch.where(
        (point <= lower + tolerance) & (projected < 0),
        torch.zeros_like(projected),
        projected,
    )
    projected = torch.where(
        (point >= upper - tolerance) & (projected > 0),
        torch.zeros_like(projected),
        projected,
    )
    if mirror_y:
        if projected.ndim != 2:
            raise ValueError("mirror_y requires a two-dimensional design tensor")
        projected = 0.5 * (projected + torch.flip(projected, dims=(0,)))
    return projected


def _minimum_norm_simplex_weights(vectors: torch.Tensor) -> torch.Tensor:
    """Solve ``min ||sum_i alpha_i v_i||`` over the probability simplex.

    The Gate-D consensus uses only two or three fidelities.  Enumerating every
    non-empty active face is therefore deterministic, exact up to the linear
    solve tolerance, and avoids introducing an optimizer dependency.
    """
    if vectors.ndim != 2 or vectors.shape[0] == 0:
        raise ValueError("vectors must have shape (levels, variables)")
    level_count = int(vectors.shape[0])
    gram = torch.real(vectors @ torch.conj(vectors).T).to(torch.float64)
    best_weights = None
    best_objective = float("inf")
    for active_count in range(1, level_count + 1):
        for active_tuple in itertools.combinations(range(level_count), active_count):
            active = list(active_tuple)
            sub_gram = gram[active][:, active]
            ones = torch.ones(active_count, dtype=torch.float64, device=gram.device)
            solution = torch.linalg.pinv(sub_gram) @ ones
            denominator = torch.dot(ones, solution)
            if not torch.isfinite(denominator) or float(abs(denominator)) <= 1e-15:
                continue
            active_weights = solution / denominator
            if bool(torch.any(active_weights < -1e-10)):
                continue
            active_weights = torch.clamp(active_weights, min=0.0)
            active_weights = active_weights / torch.sum(active_weights)
            weights = torch.zeros(level_count, dtype=torch.float64, device=gram.device)
            weights[active] = active_weights
            objective = float(torch.real(weights @ gram @ weights).detach().cpu())
            if objective < best_objective:
                best_objective = objective
                best_weights = weights
    if best_weights is None:
        raise RuntimeError("failed to solve the MGDA simplex problem")
    return best_weights


@dataclass(frozen=True)
class ConsensusDirection:
    direction: torch.Tensor
    weights: Tuple[float, ...]
    pairwise_cosines: Tuple[float, ...]
    common_ascent_cosines: Tuple[float, ...]
    minimum_common_ascent_cosine: float
    direction_rms: float
    conflict: bool


def common_ascent_direction(
    point: torch.Tensor,
    gradients: Iterable[torch.Tensor],
    *,
    mirror_y: bool = False,
    zero_tolerance: float = 1e-12,
) -> ConsensusDirection:
    """Return an RMS-normalized MGDA direction and a conservative conflict flag."""
    feasible = [
        project_feasible_gradient(point, gradient, mirror_y=mirror_y)
        for gradient in gradients
    ]
    if len(feasible) < 2:
        raise ValueError("gradient consensus requires at least two fidelities")
    unit = []
    for gradient in feasible:
        norm = torch.linalg.vector_norm(gradient)
        if float(norm.detach().cpu()) <= zero_tolerance:
            unit.append(torch.zeros_like(gradient))
        else:
            unit.append(gradient / norm)
    flattened = torch.stack([gradient.reshape(-1) for gradient in unit])
    weights_tensor = _minimum_norm_simplex_weights(flattened)
    combined = torch.sum(
        torch.stack(unit) * weights_tensor.to(unit[0]).reshape(
            (-1,) + (1,) * point.ndim
        ),
        dim=0,
    )
    combined_norm = torch.linalg.vector_norm(combined)
    if float(combined_norm.detach().cpu()) > zero_tolerance:
        direction = combined / combined_norm
    else:
        direction = torch.zeros_like(combined)

    pairwise = []
    for first, second in itertools.combinations(unit, 2):
        denominator = torch.linalg.vector_norm(first) * torch.linalg.vector_norm(second)
        pairwise.append(
            float("nan")
            if float(denominator.detach().cpu()) <= zero_tolerance
            else float(
                (torch.real(torch.sum(torch.conj(first) * second)) / denominator)
                .detach()
                .cpu()
            )
        )
    common_cosines = []
    for gradient in unit:
        denominator = torch.linalg.vector_norm(gradient) * torch.linalg.vector_norm(direction)
        common_cosines.append(
            float("nan")
            if float(denominator.detach().cpu()) <= zero_tolerance
            else float(
                (torch.real(torch.sum(torch.conj(gradient) * direction)) / denominator)
                .detach()
                .cpu()
            )
        )
    finite_common = [value for value in common_cosines if math.isfinite(value)]
    minimum_common = min(finite_common) if finite_common else float("nan")
    conflict = (
        rms_norm(combined) <= zero_tolerance
        or len(finite_common) != len(common_cosines)
        or minimum_common <= 0.0
    )
    return ConsensusDirection(
        direction=direction,
        weights=tuple(float(value) for value in weights_tensor.detach().cpu()),
        pairwise_cosines=tuple(pairwise),
        common_ascent_cosines=tuple(common_cosines),
        minimum_common_ascent_cosine=minimum_common,
        direction_rms=rms_norm(combined),
        conflict=conflict,
    )


@dataclass(frozen=True)
class ReferenceAuditDecision:
    accepted: bool
    rollback: bool
    actual_change: float


def assess_reference_audit(
    certified_value: float,
    candidate_value: float,
    *,
    allowed_drop: float = 1e-8,
) -> ReferenceAuditDecision:
    """Certify a provisional point or require rollback to the last certified one."""
    if allowed_drop < 0:
        raise ValueError("allowed_drop must be non-negative")
    actual_change = float(candidate_value) - float(certified_value)
    accepted = math.isfinite(actual_change) and actual_change >= -allowed_drop
    return ReferenceAuditDecision(accepted, not accepted, actual_change)
