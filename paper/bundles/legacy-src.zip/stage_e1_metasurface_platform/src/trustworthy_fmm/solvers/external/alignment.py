"""Convention-explicit external-solver order alignment and comparison."""

from dataclasses import dataclass
from typing import Dict, Mapping, Sequence, Tuple

import numpy as np

from trustworthy_fmm.core.types import Order


@dataclass(frozen=True)
class ExternalOrderRecord:
    order: Order
    complex_t: complex = complex(float("nan"), float("nan"))
    complex_r: complex = complex(float("nan"), float("nan"))
    power_t: float = float("nan")
    power_r: float = float("nan")


def records_by_order(records: Sequence[ExternalOrderRecord]) -> Dict[Order, ExternalOrderRecord]:
    indexed: Dict[Order, ExternalOrderRecord] = {}
    for record in records:
        if record.order in indexed:
            raise ValueError("duplicate external order {}".format(record.order))
        indexed[record.order] = record
    return indexed


def global_phase_aligned_relative_error(
    predicted: Sequence[complex], reference: Sequence[complex], epsilon: float = 1e-15
) -> float:
    first = np.asarray(predicted, dtype=np.complex128)
    second = np.asarray(reference, dtype=np.complex128)
    if first.shape != second.shape or first.size == 0:
        raise ValueError("amplitude arrays must have the same non-empty shape")
    overlap = np.vdot(second, first)
    phase = overlap / max(abs(overlap), epsilon)
    return float(np.linalg.norm(first - phase * second) / max(np.linalg.norm(second), epsilon))


def compare_order_powers(
    predicted: Mapping[Order, float], reference: Mapping[Order, float]
) -> Dict[str, float]:
    common = sorted(set(predicted) & set(reference))
    if not common:
        raise ValueError("no common diffraction orders")
    errors = np.asarray([abs(predicted[order] - reference[order]) for order in common])
    return {
        "orders_compared": float(len(common)),
        "maximum_absolute_power_error": float(errors.max()),
        "mean_absolute_power_error": float(errors.mean()),
    }

