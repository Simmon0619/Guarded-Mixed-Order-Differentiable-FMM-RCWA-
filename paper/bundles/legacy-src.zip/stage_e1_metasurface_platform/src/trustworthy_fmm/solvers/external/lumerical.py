"""Import the versioned JSON summaries produced by the existing Lumerical path."""

import json
from pathlib import Path
from typing import List

from trustworthy_fmm.solvers.external.alignment import ExternalOrderRecord


def load_lumerical_summary(path: Path, polarization: str = "p") -> List[ExternalOrderRecord]:
    with Path(path).open("r", encoding="utf-8") as stream:
        payload = json.load(stream)
    if polarization not in ("p", "s"):
        raise ValueError("polarization must be p or s")
    transmission_key = "T{}_power".format(polarization)
    reflection_key = "R{}_power".format(polarization)
    records = []
    seen = set()
    for row in payload["orders_m0"]:
        order = (int(row["order_n"]), int(row["order_m"]))
        matched = (int(row["matched_order_n"]), int(row["matched_order_m"]))
        if order != matched or order in seen:
            continue
        seen.add(order)
        records.append(
            ExternalOrderRecord(
                order=order,
                power_t=float(row[transmission_key]),
                power_r=float(row[reflection_key]),
            )
        )
    return records

