"""Optional, explicitly selected eigendecomposition backward stabilizers.

The forward solve is always ``torch.linalg.eig``.  The custom backward follows
TORCWA's Lorentzian replacement of inverse eigenvalue gaps.  ``lorentzian_scaled``
uses FMMAX's scale-aware broadening magnitude, avoiding a units-dependent fixed
epsilon.  Neither approximation is enabled silently: Gate C must demonstrate a
systematic, eig-risk-correlated failure before a stabilized method is selected.
"""

from typing import Tuple

import torch


DEFAULT_EIG_BACKWARD = "default"
LORENTZIAN_FIXED = "lorentzian_fixed"
LORENTZIAN_SCALED = "lorentzian_scaled"


class _LorentzianEig(torch.autograd.Function):
    @staticmethod
    def forward(
        ctx: torch.autograd.function.FunctionCtx,
        matrix: torch.Tensor,
        eps_relative: float,
        eps_absolute: float,
        scaled: bool,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        eigenvalues, eigenvectors = torch.linalg.eig(matrix)
        ctx.save_for_backward(eigenvalues, eigenvectors)
        ctx.input_was_complex = torch.is_complex(matrix)
        ctx.eps_relative = float(eps_relative)
        ctx.eps_absolute = float(eps_absolute)
        ctx.scaled = bool(scaled)
        return eigenvalues, eigenvectors

    @staticmethod
    def backward(ctx, grad_eigenvalues, grad_eigenvectors):
        eigenvalues, eigenvectors = ctx.saved_tensors
        if grad_eigenvalues is None:
            grad_eigenvalues = torch.zeros_like(eigenvalues)
        if grad_eigenvectors is None:
            grad_eigenvectors = torch.zeros_like(eigenvectors)
        delta = eigenvalues.unsqueeze(-2) - eigenvalues.unsqueeze(-1)
        if ctx.scaled:
            range_squared = torch.amax(torch.abs(delta) ** 2, dim=(-2, -1), keepdim=True)
            epsilon = torch.clamp(
                ctx.eps_relative * range_squared, min=ctx.eps_absolute
            )
        else:
            epsilon = torch.as_tensor(
                ctx.eps_absolute,
                dtype=eigenvalues.real.dtype,
                device=eigenvalues.device,
            )
        inverse_gap = torch.conj(delta) / (torch.abs(delta) ** 2 + epsilon)
        indices = torch.arange(eigenvalues.shape[-1], device=eigenvalues.device)
        inverse_gap[..., indices, indices] = 0.0
        eigenvectors_h = torch.conj(eigenvectors.transpose(-2, -1))
        vector_term = torch.conj(inverse_gap) * (
            eigenvectors_h @ grad_eigenvectors
        )
        right_hand_side = torch.diag_embed(grad_eigenvalues) + vector_term
        gradient = torch.linalg.solve(eigenvectors_h, right_hand_side) @ eigenvectors_h
        if not ctx.input_was_complex:
            gradient = gradient.real
        return gradient, None, None, None


def eigendecomposition(
    matrix: torch.Tensor,
    method: str = DEFAULT_EIG_BACKWARD,
    *,
    eps_relative: float = 1e-12,
    eps_absolute: float = 1e-24,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """Return eigenpairs with an auditable choice of backward convention."""
    method = str(method).lower()
    if method == DEFAULT_EIG_BACKWARD:
        return torch.linalg.eig(matrix)
    if eps_relative <= 0 or eps_absolute <= 0:
        raise ValueError("eigendecomposition broadening values must be positive")
    if method == LORENTZIAN_FIXED:
        return _LorentzianEig.apply(matrix, eps_relative, eps_absolute, False)
    if method == LORENTZIAN_SCALED:
        return _LorentzianEig.apply(matrix, eps_relative, eps_absolute, True)
    raise ValueError("unknown eig backward method {!r}".format(method))

