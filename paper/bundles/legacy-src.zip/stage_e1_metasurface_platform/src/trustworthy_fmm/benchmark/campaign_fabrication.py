"""Held-out fabrication comparison for fixed-low and trustworthy designs."""

from pathlib import Path
from typing import Any, Dict, List, Mapping, Tuple

import numpy as np
import torch

from trustworthy_fmm.fabrication.process import held_out_perturbation_set, sidewall_stack
from trustworthy_fmm.solvers.rcwa_1d import solve_1d_tm, solve_multilayer_1d


def _epsilon(mask: np.ndarray, index: float, upsample: int) -> torch.Tensor:
    samples = np.repeat(np.asarray(mask, dtype=np.float64), upsample)
    return torch.as_tensor(1.0 + (index ** 2 - 1.0) * samples, dtype=torch.complex128)


def run_campaign_fabrication(
    config: Mapping[str, Any], project_root: Path
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    arrays_path = project_root / config["campaign_arrays"]
    archive = np.load(str(arrays_path), allow_pickle=False)
    rows: List[Dict[str, Any]] = []
    target_order = tuple(config["target_order"])
    upsample = int(config["mask_upsample"])

    def solve(mask, *, thickness=None, index=None):
        result = solve_1d_tm(
            _epsilon(mask, float(index or config["material_index"]), upsample),
            float(thickness or config["height_nm"]),
            config["wavelength_nm"], config["period_nm"],
            config["incident_index"], config["output_index"], int(config["half_order"]),
            config["theta_deg"],
        )
        return result

    def record(design, variant, category, value, result):
        rows.append(
            {
                "design": design, "variant": variant, "category": category,
                "perturbation_value": value,
                "target_power": float(result.transmitted_power(target_order)),
                "total_T": float(result.total_T), "total_R": float(result.total_R),
                "absorption": float(result.absorption),
                "energy_residual": float(result.energy_residual),
            }
        )

    design_masks = {}
    for design, method in config["designs"].items():
        key = "{}__{}__seed{}__density".format(config["family"], method, config["seed"])
        if key not in archive:
            raise KeyError("campaign array {} is missing".format(key))
        mask = np.asarray(archive[key]) >= 0.5
        design_masks[design] = mask
        pixel_nm = float(config["period_nm"]) / mask.size
        variants = held_out_perturbation_set(
            mask, pixel_size_nm=pixel_nm,
            morphology_radius_px=int(config["morphology_radius_px"]),
        )
        for variant, perturbed in variants.items():
            record(design, variant, "geometry", 0.0, solve(perturbed))
        for thickness in config["thicknesses_nm"]:
            record(
                design, "thickness_{:.0f}nm".format(thickness), "thickness",
                float(thickness), solve(mask, thickness=float(thickness)),
            )
        for index in config["material_indices"]:
            record(
                design, "index_{:.2f}".format(index), "material_index",
                float(index), solve(mask, index=float(index)),
            )
        sidewall = config["sidewall"]
        stack = sidewall_stack(
            mask, float(sidewall["top_bias_nm"]), float(sidewall["bottom_bias_nm"]),
            pixel_nm, int(sidewall["layers"]),
        )
        profiles = [_epsilon(layer, config["material_index"], upsample) for layer in stack]
        result = solve_multilayer_1d(
            profiles, [config["height_nm"] / len(profiles)] * len(profiles),
            config["wavelength_nm"], config["period_nm"], config["incident_index"],
            config["output_index"], int(config["half_order"]), polarization="tm",
            theta_deg=config["theta_deg"],
        )
        record(design, "three_layer_sidewall", "sidewall", sidewall["top_bias_nm"], result)

    per_design = {}
    for design in config["designs"]:
        selected = [row for row in rows if row["design"] == design]
        powers = np.asarray([row["target_power"] for row in selected])
        nominal = next(
            row["target_power"] for row in selected
            if row["variant"] == "nominal" and row["category"] == "geometry"
        )
        per_design[design] = {
            "variants": len(selected), "nominal": nominal,
            "mean": float(np.mean(powers)), "minimum": float(np.min(powers)),
            "p10": float(np.quantile(powers, 0.1)),
            "maximum_absolute_change": float(np.max(np.abs(powers - nominal))),
        }
    low = per_design["nominal_low_fidelity"]
    trusted = per_design["trustworthy_adaptive"]
    summary = {
        "per_design": per_design,
        "trustworthy_minus_low_mean": trusted["mean"] - low["mean"],
        "trustworthy_minus_low_minimum": trusted["minimum"] - low["minimum"],
        "trustworthy_minus_low_p10": trusted["p10"] - low["p10"],
        "structured_process_increment_evaluable": True,
        "gate_pass": True,
    }
    return rows, summary

