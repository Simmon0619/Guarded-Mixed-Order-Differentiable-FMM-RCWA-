"""Converged circular-basis regression for TORCWA Example 6."""

import hashlib
import json
from pathlib import Path
import time
from typing import Any, Dict, List, Mapping, Tuple

import numpy as np
import torch

from trustworthy_fmm.physics.channels import circular_order_set
from trustworthy_fmm.solvers.vector_2d import solve_vector_2d


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def run_torcwa_example6(
    config: Mapping[str, Any], workspace_root: Path
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    asset = Path(config["asset"]["path"])
    if not asset.exists():
        raise FileNotFoundError(
            "TORCWA Example 6 asset is not available at the frozen provenance path: {}".format(asset)
        )
    actual_hash = _sha256(asset)
    expected_hash = str(config["asset"]["sha256"]).lower()
    if actual_hash.lower() != expected_hash:
        raise ValueError("TORCWA Example 6 asset hash does not match the frozen configuration")
    density_np = np.load(str(asset), allow_pickle=False).astype(np.float64)
    if config.get("sample_orientation") == "transpose_xy_to_yx":
        density_np = density_np.T
    density = torch.as_tensor(density_np, dtype=torch.float64)
    epsilon = (1.0 + (config["material_index"] ** 2 - 1.0) * density).to(torch.complex128)
    lumerical_path = workspace_root / config["lumerical_summary"]
    lumerical = json.loads(lumerical_path.read_text(encoding="utf-8"))
    reference = float(lumerical["target"]["Tp_power"])
    target_order = tuple(config["target_order"])
    rows: List[Dict[str, Any]] = []
    previous = None
    for approximate_terms in config["approximate_terms"]:
        orders = circular_order_set(tuple(config["lattice_nm"]), int(approximate_terms))
        started = time.perf_counter()
        result = solve_vector_2d(
            epsilon,
            config["height_nm"],
            config["wavelength_nm"],
            tuple(config["lattice_nm"]),
            config["incident_index"],
            config["output_index"],
            (0, 0),
            basis_orders=orders,
        )
        elapsed = time.perf_counter() - started
        target = float(result.transmitted_power(target_order))
        adjacent = float("nan") if previous is None else abs(target - previous) / max(abs(target), 1e-12)
        rows.append(
            {
                "approximate_terms": int(approximate_terms),
                "actual_terms": len(orders),
                "target_power": target,
                "lumerical_target_power": reference,
                "lumerical_absolute_error": abs(target - reference),
                "adjacent_relative_change": adjacent,
                "total_T": float(result.total_T),
                "total_R": float(result.total_R),
                "energy_residual": float(result.energy_residual),
                "runtime_seconds": elapsed,
            }
        )
        previous = target
    final = rows[-1]
    thresholds = config["thresholds"]
    summary = {
        "asset_sha256": actual_hash,
        "runs": len(rows),
        "final_actual_terms": final["actual_terms"],
        "final_target_power": final["target_power"],
        "lumerical_target_power": reference,
        "final_lumerical_absolute_error": final["lumerical_absolute_error"],
        "final_adjacent_relative_change": final["adjacent_relative_change"],
        "max_energy_residual": max(row["energy_residual"] for row in rows),
        "forward_convergence_pass": final["adjacent_relative_change"] <= thresholds["adjacent_relative_convergence"],
        "lumerical_target_pass": final["lumerical_absolute_error"] <= thresholds["lumerical_target_absolute_error"],
        "energy_pass": max(row["energy_residual"] for row in rows) <= thresholds["lossless_energy_residual"],
    }
    summary["gate_pass"] = bool(
        summary["forward_convergence_pass"]
        and summary["lumerical_target_pass"]
        and summary["energy_pass"]
    )
    return rows, summary

