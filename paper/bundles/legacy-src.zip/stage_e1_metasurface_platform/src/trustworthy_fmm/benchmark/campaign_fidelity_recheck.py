"""Final high-order PyTorch/Lumerical recheck for campaign candidates."""

import json
from pathlib import Path
from typing import Any, Dict, List, Mapping, Tuple

import numpy as np
import torch

from trustworthy_fmm.experiments.false_optimum import _families, _objective


def run_campaign_fidelity_recheck(
    config: Mapping[str, Any], project_root: Path
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    archive = np.load(str(project_root / config["campaign_arrays"]), allow_pickle=False)
    family = next(item for item in _families({}) if item.name == config["family"])
    rows: List[Dict[str, Any]] = []
    per_design = {}
    for design, method in config["designs"].items():
        lumerical = json.loads(
            (project_root / config["lumerical_summaries"][design]).read_text(encoding="utf-8")
        )
        key = "{}__{}__seed{}__raw".format(config["family"], method, config["seed"])
        raw = torch.as_tensor(archive[key], dtype=torch.float64)
        previous = None
        selected = []
        for half_order in config["half_orders"]:
            target = float(_objective(raw, family, int(half_order)).detach())
            row = {
                "design": design, "method": method, "half_order": int(half_order),
                "target_power": target,
                "adjacent_relative_change": float("nan") if previous is None else abs(target - previous) / max(abs(target), 1e-12),
            }
            rows.append(row); selected.append(row); previous = target
        external = float(lumerical["by_design"][design]["final_target_power"])
        per_design[design] = {
            "pytorch_final_target_power": selected[-1]["target_power"],
            "pytorch_final_adjacent_relative_change": selected[-1]["adjacent_relative_change"],
            "lumerical_k801_target_power": external,
            "pytorch_lumerical_absolute_error": abs(selected[-1]["target_power"] - external),
            "lumerical_k601_k801_relative_change": float(
                lumerical["by_design"][design]["adjacent_relative_change"]
            ),
        }
    trusted = per_design["trustworthy_adaptive"]
    low = per_design["nominal_low_fidelity"]
    fixed_high = per_design["fixed_high_baseline"]
    summary = {
        "per_design": per_design,
        "trustworthy_lumerical_convergence_pass": trusted["lumerical_k601_k801_relative_change"] <= 0.005,
        "trustworthy_external_alignment_pass": trusted["pytorch_lumerical_absolute_error"] <= 0.01,
        "fixed_high_lumerical_convergence_pass": fixed_high["lumerical_k601_k801_relative_change"] <= 0.005,
        "fixed_high_external_alignment_pass": fixed_high["pytorch_lumerical_absolute_error"] <= 0.01,
        "external_trustworthy_minus_fixed_high": trusted["lumerical_k801_target_power"] - fixed_high["lumerical_k801_target_power"],
        "external_trustworthy_minus_low": trusted["lumerical_k801_target_power"] - low["lumerical_k801_target_power"],
        "fixed_low_external_false_optimum_drop": float(config["fixed_low_training_value"]) - low["lumerical_k801_target_power"],
    }
    summary["gate_pass"] = bool(
        summary["trustworthy_lumerical_convergence_pass"]
        and summary["trustworthy_external_alignment_pass"]
        and summary["fixed_high_lumerical_convergence_pass"]
        and summary["fixed_high_external_alignment_pass"]
    )
    return rows, summary
