"""FFT-baseline Gate C/D campaign with anisotropic Fourier fidelities.

This module is the project-facing implementation of Main Claim 1.  Automatic
differentiation is first checked against finite differences *at the same
discretization*.  A separate cross-discretization audit then qualifies the
reference, because exact AD of ``J_(Mx,My)`` does not establish that its
gradient approximates the unresolved physical objective.
"""

from copy import deepcopy
import math
from pathlib import Path
import statistics
import time
from typing import Any, Callable, Dict, Iterable, List, Mapping, MutableMapping, Optional, Sequence, Tuple

import torch

from trustworthy_fmm.audit.gradients import gradient_cosine, multi_directional_derivative_audit
from trustworthy_fmm.benchmark.gate_cd import (
    _apply_design_symmetry,
    _density,
    _directions,
    _load_density_exact,
    _project_candidate,
    _rms_to_l2_radius,
    _save_density,
    _target_is_propagating,
    _target_slug,
    _validate_square_pixel_grid,
)
from trustworthy_fmm.fidelity.indicators import classify_value_gradient_convergence
from trustworthy_fmm.optimization.multifidelity import (
    HalfOrders,
    assess_reference_audit,
    common_ascent_direction,
    fidelity_key,
    harmonic_count,
    parse_half_orders,
    project_feasible_gradient,
    rms_norm,
)
from trustworthy_fmm.optimization.trust_region import (
    FirstOrderConsistentModel,
    assess_model_managed_candidate,
    bounded_gradient_step,
)
from trustworthy_fmm.reproducibility.checkpoints import CheckpointStore
from trustworthy_fmm.solvers.vector_2d import solve_vector_2d


METHODS = (
    "fixed_M",
    "fixed_H",
    "order_continuation",
    "FOC-TR",
    "MGDA-TR",
    "FOC-TR-recycled",
    "FOC-TR-recycled7",
)


def _float(value: torch.Tensor) -> float:
    return float(value.detach().cpu())


def _factorization(config: Mapping[str, Any]) -> str:
    value = str(config.get("factorization", ""))
    if value != "fft_baseline":
        raise ValueError(
            "Gate C/D main experiments require factorization='fft_baseline'; "
            "advanced factorizations belong only in supplementary regressions"
        )
    return value


def _device(config: Mapping[str, Any]) -> torch.device:
    requested = str(config.get("device", "cpu"))
    if requested == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("Gate C/D requested CUDA but torch.cuda.is_available() is false")
    if requested not in ("cpu", "cuda"):
        raise ValueError("Gate C/D device must be 'cpu' or 'cuda'")
    return torch.device(requested)


def _solver_result(
    config: Mapping[str, Any], density: torch.Tensor, half_orders: Sequence[int]
):
    orders = parse_half_orders(half_orders)
    solver_density = density.to(device=_device(config))
    epsilon = (
        float(config["background_index"]) ** 2
        + (
            float(config["feature_index"]) ** 2
            - float(config["background_index"]) ** 2
        )
        * solver_density
    ).to(torch.complex128)
    return solve_vector_2d(
        epsilon,
        float(config["thickness_nm"]),
        float(config["wavelength_nm"]),
        tuple(float(value) for value in config["lattice_nm"]),
        complex(config["incident_index"]),
        complex(config["output_index"]),
        orders,
        float(config["theta_deg"]),
        float(config["phi_deg"]),
        factorization=_factorization(config),
    )


def _objective_2d_fft(
    config: Mapping[str, Any],
    half_orders: Sequence[int],
    target_order: Sequence[int],
) -> Callable[[torch.Tensor], torch.Tensor]:
    orders = parse_half_orders(half_orders)
    target = tuple(int(value) for value in target_order)

    def objective(density: torch.Tensor) -> torch.Tensor:
        return _solver_result(config, density, orders).transmitted_power(target)

    return objective


def _multi_target_value_gradients(
    config: Mapping[str, Any],
    point: torch.Tensor,
    half_orders: Sequence[int],
    target_orders: Sequence[Sequence[int]],
) -> Dict[Tuple[int, int], Dict[str, Any]]:
    work = point.detach().clone().requires_grad_(True)
    result = _solver_result(config, work, half_orders)
    targets = [tuple(int(value) for value in target) for target in target_orders]
    objectives = [result.transmitted_power(target) for target in targets]
    records: Dict[Tuple[int, int], Dict[str, Any]] = {}
    for index, (target, objective) in enumerate(zip(targets, objectives)):
        gradient = torch.autograd.grad(
            objective, work, retain_graph=index + 1 < len(objectives)
        )[0].detach()
        records[target] = {
            "objective": _float(objective),
            "gradient": gradient,
            "gradient_norm": float(torch.linalg.vector_norm(gradient).cpu()),
            "diagnostics": {
                "min_eigen_gap": _float(result.diagnostics["min_eigen_gap"]),
                "modal_condition": _float(result.diagnostics["modal_condition"]),
                "energy_residual": _float(result.energy_residual),
            },
        }
    return records


def _cached_multi_target_value_gradients(
    store: Optional[CheckpointStore],
    config: Mapping[str, Any],
    case: str,
    point: torch.Tensor,
    half_orders: HalfOrders,
    target_orders: Sequence[Sequence[int]],
) -> Dict[Tuple[int, int], Dict[str, Any]]:
    """Load or atomically persist one expensive case/fidelity solve."""
    path = (
        store.path("levels", case, fidelity_key(half_orders))
        if store is not None
        else None
    )
    cached = store.load(path) if store is not None and path is not None else None
    if cached is not None:
        records = cached.get("records")
        if not isinstance(records, Mapping):
            raise RuntimeError("Gate C level checkpoint has no records")
        return {
            tuple(int(value) for value in target): dict(record)
            for target, record in records.items()
        }
    records = _multi_target_value_gradients(
        config, point, half_orders, target_orders
    )
    if store is not None and path is not None:
        store.save(
            path,
            {
                "case": case,
                "half_orders": list(half_orders),
                "records": {
                    tuple(target): {
                        **record,
                        "gradient": record["gradient"].detach().cpu(),
                    }
                    for target, record in records.items()
                },
                "complete": True,
            },
        )
    return records


def _scattering_metrics_fft(
    config: Mapping[str, Any],
    density: torch.Tensor,
    half_orders: Sequence[int],
    target_order: Sequence[int],
) -> Dict[str, Any]:
    with torch.no_grad():
        result = _solver_result(config, density, half_orders)
    target_power = _float(result.transmitted_power(tuple(target_order)))
    total_transmitted = _float(result.total_T)
    return {
        "half_orders": list(parse_half_orders(half_orders)),
        "mode_count": harmonic_count(half_orders),
        "target_power": target_power,
        "total_transmitted_power": total_transmitted,
        "total_reflected_power": _float(result.total_R),
        "target_fraction_of_transmission": target_power / max(total_transmitted, 1e-15),
        "energy_residual": _float(result.energy_residual),
    }


def _relative_change(first: float, second: float) -> float:
    return abs(float(first) - float(second)) / max(abs(float(second)), 1e-12)


def _order_index(levels: Sequence[HalfOrders], value: HalfOrders) -> int:
    try:
        return list(levels).index(value)
    except ValueError as error:
        raise ValueError("Fourier level {} is not in the configured ladder".format(value)) from error


def _reference_pair_records(
    evaluations: Mapping[Tuple[str, HalfOrders, Tuple[int, int]], Mapping[str, Any]],
    config: Mapping[str, Any],
    high: HalfOrders,
    reference: HalfOrders,
) -> Tuple[List[Dict[str, Any]], bool]:
    value_tolerance = float(config["reference_value_relative_tolerance"])
    cosine_tolerance = float(config["reference_gradient_cosine_tolerance"])
    norm_min, norm_max = (float(value) for value in config["reference_gradient_norm_ratio"])
    objective_floor = float(config["reference_objective_floor"])
    gradient_floor = float(config["reference_gradient_norm_floor"])
    minimum_valid = int(config["minimum_valid_cases_per_target"])
    target_orders = [tuple(int(value) for value in target) for target in config["target_orders"]]
    records: List[Dict[str, Any]] = []
    valid_by_target = {target: 0 for target in target_orders}
    for target in target_orders:
        for case_value in config["cases"]:
            case = str(case_value)
            high_record = evaluations[(case, high, target)]
            ref_record = evaluations[(case, reference, target)]
            ref_norm = float(ref_record["gradient_norm"])
            signal_valid = (
                abs(float(ref_record["objective"])) >= objective_floor
                and ref_norm >= gradient_floor
            )
            value_change = _relative_change(high_record["objective"], ref_record["objective"])
            cosine = gradient_cosine(high_record["gradient"], ref_record["gradient"])
            ratio = float(high_record["gradient_norm"]) / max(ref_norm, 1e-15)
            passed = (
                signal_valid
                and value_change <= value_tolerance
                and cosine >= cosine_tolerance
                and norm_min <= ratio <= norm_max
            )
            if signal_valid:
                valid_by_target[target] += 1
            records.append(
                {
                    "case": case,
                    "target_order": list(target),
                    "high_half_orders": list(high),
                    "reference_half_orders": list(reference),
                    "objective_relative_change": value_change,
                    "gradient_cosine": cosine,
                    "gradient_norm_ratio": ratio,
                    "reference_signal_valid": signal_valid,
                    "pass": passed,
                }
            )
    enough_signal = all(count >= minimum_valid for count in valid_by_target.values())
    all_valid_pass = all(record["pass"] for record in records if record["reference_signal_valid"])
    return records, enough_signal and all_valid_pass


def _select_middle_level(
    evaluations: Mapping[Tuple[str, HalfOrders, Tuple[int, int]], Mapping[str, Any]],
    config: Mapping[str, Any],
    ladder: Sequence[HalfOrders],
    high: HalfOrders,
) -> Tuple[HalfOrders, bool, List[Dict[str, Any]]]:
    high_index = _order_index(ladder, high)
    target_orders = [tuple(int(value) for value in target) for target in config["target_orders"]]
    objective_floor = float(config["reference_objective_floor"])
    gradient_floor = float(config["reference_gradient_norm_floor"])
    value_tolerance = float(config["working_value_relative_tolerance"])
    cosine_tolerance = float(config["working_gradient_cosine_tolerance"])
    summaries = []
    selected: Optional[HalfOrders] = None
    for candidate in ladder[1:high_index]:
        checks = []
        for target in target_orders:
            for case_value in config["cases"]:
                case = str(case_value)
                candidate_record = evaluations[(case, candidate, target)]
                high_record = evaluations[(case, high, target)]
                if (
                    abs(float(high_record["objective"])) < objective_floor
                    or float(high_record["gradient_norm"]) < gradient_floor
                ):
                    continue
                checks.append(
                    {
                        "value_relative_error": _relative_change(
                            candidate_record["objective"], high_record["objective"]
                        ),
                        "gradient_cosine": gradient_cosine(
                            candidate_record["gradient"], high_record["gradient"]
                        ),
                    }
                )
        qualified = bool(checks) and all(
            check["value_relative_error"] <= value_tolerance
            and check["gradient_cosine"] >= cosine_tolerance
            for check in checks
        )
        summaries.append(
            {
                "half_orders": list(candidate),
                "mode_count": harmonic_count(candidate),
                "qualified": qualified,
                "maximum_value_relative_error": max(
                    (check["value_relative_error"] for check in checks), default=float("nan")
                ),
                "minimum_gradient_cosine": min(
                    (check["gradient_cosine"] for check in checks), default=float("nan")
                ),
            }
        )
        if qualified and selected is None:
            selected = candidate
    if selected is not None:
        return selected, True, summaries
    if high_index == 0:
        raise ValueError("qualified high level has no lower model")
    return ladder[high_index - 1], False, summaries


def _apply_rms_step(point: torch.Tensor, gradient: torch.Tensor, step_rms: float) -> torch.Tensor:
    feasible = project_feasible_gradient(point, gradient)
    radius = _rms_to_l2_radius(point, step_rms)
    return torch.clamp(point + bounded_gradient_step(feasible, radius), 0.0, 1.0)


def _deep_merge(base: MutableMapping[str, Any], override: Mapping[str, Any]) -> MutableMapping[str, Any]:
    for key, value in override.items():
        if isinstance(value, Mapping) and isinstance(base.get(key), MutableMapping):
            _deep_merge(base[key], value)
        else:
            base[key] = deepcopy(value)
    return base


def _run_gate_c_fft(
    config: Mapping[str, Any],
    rows: List[Dict[str, Any]],
    *,
    scientific_mode: bool,
    checkpoint_dir: Optional[Path] = None,
) -> Dict[str, Any]:
    _factorization(config)
    checkpoint_store = (
        CheckpointStore(checkpoint_dir, config, "gate_c")
        if checkpoint_dir is not None
        else None
    )
    ladder = [parse_half_orders(value) for value in config["anisotropic_half_orders"]]
    emergency = parse_half_orders(config["emergency_validation_half_orders"])
    square_controls = [parse_half_orders(value) for value in config["square_control_half_orders"]]
    if len(ladder) != 5 or len(set(ladder)) != len(ladder):
        raise ValueError("Gate C anisotropic ladder must contain five unique levels")
    target_orders = [tuple(int(value) for value in target) for target in config["target_orders"]]
    for target in target_orders:
        if abs(target[0]) > ladder[0][0] or abs(target[1]) > ladder[0][1]:
            raise ValueError("the lowest anisotropic level does not contain target {}".format(target))

    evaluation_levels = list(dict.fromkeys(ladder + square_controls))
    evaluations: Dict[Tuple[str, HalfOrders, Tuple[int, int]], Dict[str, Any]] = {}
    resource_errors: List[Dict[str, Any]] = []
    for case_value in config["cases"]:
        case = str(case_value)
        point = _density(config, case)
        for level in evaluation_levels:
            try:
                level_records = _cached_multi_target_value_gradients(
                    checkpoint_store,
                    config,
                    case,
                    point,
                    level,
                    target_orders,
                )
            except RuntimeError as error:
                resource_errors.append(
                    {"case": case, "half_orders": list(level), "error": str(error)}
                )
                continue
            for target, record in level_records.items():
                evaluations[(case, level, target)] = record

    primary_high, primary_reference = ladder[-2], ladder[-1]
    complete_primary = all(
        (str(case), level, target) in evaluations
        for case in config["cases"]
        for level in (primary_high, primary_reference)
        for target in target_orders
    )
    if complete_primary:
        primary_records, primary_pass = _reference_pair_records(
            evaluations, config, primary_high, primary_reference
        )
    else:
        primary_records, primary_pass = [], False
    for record in primary_records:
        rows.append({"gate": "C_reference_qualification", **record})

    emergency_used = False
    selected_high, selected_reference = primary_high, primary_reference
    qualification_records = primary_records
    reference_qualified = primary_pass
    if not primary_pass:
        emergency_used = True
        for case_value in config["cases"]:
            case = str(case_value)
            point = _density(config, case)
            try:
                emergency_records = _cached_multi_target_value_gradients(
                    checkpoint_store,
                    config,
                    case,
                    point,
                    emergency,
                    target_orders,
                )
            except RuntimeError as error:
                resource_errors.append(
                    {"case": case, "half_orders": list(emergency), "error": str(error)}
                )
                continue
            for target, record in emergency_records.items():
                evaluations[(case, emergency, target)] = record
        complete_emergency = all(
            (str(case), level, target) in evaluations
            for case in config["cases"]
            for level in (primary_reference, emergency)
            for target in target_orders
        )
        if complete_emergency:
            qualification_records, reference_qualified = _reference_pair_records(
                evaluations, config, primary_reference, emergency
            )
            for record in qualification_records:
                rows.append({"gate": "C_reference_qualification_emergency", **record})
        else:
            qualification_records, reference_qualified = [], False
        selected_high, selected_reference = primary_reference, emergency

    # Smoke results exercise the path but are never promoted to scientific evidence.
    scientific_reference_qualified = bool(reference_qualified and scientific_mode)
    middle, middle_qualified, middle_records = _select_middle_level(
        evaluations, config, ladder, selected_high
    )
    low = ladder[0]

    per_target_case: Dict[str, Any] = {}
    separation_records: List[Dict[str, Any]] = []
    square_cost_records: List[Dict[str, Any]] = []
    reference_available = all(
        (str(case), selected_reference, target) in evaluations
        for case in config["cases"]
        for target in target_orders
    )
    for target in target_orders:
        for case_value in config["cases"]:
            case = str(case_value)
            reference_record = evaluations.get((case, selected_reference, target))
            case_rows = []
            for level in evaluation_levels:
                record = evaluations.get((case, level, target))
                if record is None or reference_record is None:
                    continue
                signal_valid = (
                    abs(float(reference_record["objective"]))
                    >= float(config["reference_objective_floor"])
                    and float(reference_record["gradient_norm"])
                    >= float(config["reference_gradient_norm_floor"])
                )
                value_error = (
                    _relative_change(record["objective"], reference_record["objective"])
                    if signal_valid
                    else float("nan")
                )
                cosine = (
                    gradient_cosine(record["gradient"], reference_record["gradient"])
                    if signal_valid
                    else float("nan")
                )
                norm_ratio = (
                    float(record["gradient_norm"])
                    / max(float(reference_record["gradient_norm"]), 1e-15)
                    if signal_valid
                    else float("nan")
                )
                state = classify_value_gradient_convergence(
                    value_error,
                    cosine,
                    value_tolerance=float(config["working_value_relative_tolerance"]),
                    gradient_cosine_tolerance=float(config["working_gradient_cosine_tolerance"]),
                ) if signal_valid else None
                row = {
                    "gate": "C_ladder",
                    "family": "anisotropic" if level in ladder else "square_control",
                    "case": case,
                    "target_order": list(target),
                    "target_m": target[0],
                    "target_n": target[1],
                    "half_orders": list(level),
                    "order_label": fidelity_key(level),
                    "mode_count": harmonic_count(level),
                    "reference_half_orders": list(selected_reference),
                    "reference_mode_count": harmonic_count(selected_reference),
                    "objective": float(record["objective"]),
                    "reference_objective": float(reference_record["objective"]),
                    "objective_relative_error_to_reference": value_error,
                    "gradient_cosine_to_reference": cosine,
                    "gradient_norm_ratio_to_reference": norm_ratio,
                    "reference_signal_valid": signal_valid,
                    "value_converged": bool(state.value_converged) if state else False,
                    "gradient_converged": bool(state.gradient_converged) if state else False,
                    "value_gradient_separation": bool(state.separated) if state else False,
                    "value_gradient_state": state.state if state else "insufficient_reference_signal",
                    **record["diagnostics"],
                }
                rows.append(row)
                case_rows.append({key: value for key, value in row.items() if key != "gate"})
                if row["value_gradient_separation"]:
                    separation_records.append(
                        {
                            "case": case,
                            "target_order": list(target),
                            "half_orders": list(level),
                            "objective_relative_error": value_error,
                            "gradient_cosine": cosine,
                        }
                    )
            key = "m{:+d}_n{:+d}__{}".format(target[0], target[1], case)
            per_target_case[key] = {
                "case": case,
                "target_order": list(target),
                "reference_signal_valid": bool(
                    case_rows and case_rows[0]["reference_signal_valid"]
                ),
                "rows": case_rows,
            }

    if reference_available:
        for square, anisotropic in zip(square_controls, ladder[: len(square_controls)]):
            for target in target_orders:
                for case_value in config["cases"]:
                    case = str(case_value)
                    ref_record = evaluations[(case, selected_reference, target)]
                    if (
                        abs(float(ref_record["objective"]))
                        < float(config["reference_objective_floor"])
                        or float(ref_record["gradient_norm"])
                        < float(config["reference_gradient_norm_floor"])
                    ):
                        continue
                    square_record = evaluations[(case, square, target)]
                    anisotropic_record = evaluations[(case, anisotropic, target)]
                    square_value_error = _relative_change(
                        square_record["objective"], ref_record["objective"]
                    )
                    anisotropic_value_error = _relative_change(
                        anisotropic_record["objective"], ref_record["objective"]
                    )
                    square_cosine = gradient_cosine(
                        square_record["gradient"], ref_record["gradient"]
                    )
                    anisotropic_cosine = gradient_cosine(
                        anisotropic_record["gradient"], ref_record["gradient"]
                    )
                    control = {
                        "case": case,
                        "target_order": list(target),
                        "square_half_orders": list(square),
                        "square_mode_count": harmonic_count(square),
                        "anisotropic_half_orders": list(anisotropic),
                        "anisotropic_mode_count": harmonic_count(anisotropic),
                        "square_value_error": square_value_error,
                        "anisotropic_value_error": anisotropic_value_error,
                        "square_gradient_cosine": square_cosine,
                        "anisotropic_gradient_cosine": anisotropic_cosine,
                        "anisotropic_value_error_better": anisotropic_value_error
                        < square_value_error,
                        "anisotropic_gradient_cosine_better": anisotropic_cosine
                        > square_cosine,
                    }
                    square_cost_records.append(control)
                    rows.append({"gate": "C_square_cost_control", **control})

    # Same-discretization AD/FD only checks the derivative implementation.
    directional_records = []
    directions = _directions(config)
    for case_value in config["cases"]:
        case = str(case_value)
        point = _density(config, case)
        for level_value in config["directional_audit_half_orders"]:
            level = parse_half_orders(level_value)
            audit_path = (
                checkpoint_store.path("directional", case, fidelity_key(level))
                if checkpoint_store is not None
                else None
            )
            audit_checkpoint = (
                checkpoint_store.load(audit_path)
                if checkpoint_store is not None and audit_path is not None
                else None
            )
            if audit_checkpoint is None:
                audit = multi_directional_derivative_audit(
                    _objective_2d_fft(config, level, config["audit_target_order"]),
                    point,
                    directions,
                    [float(value) for value in config["fd_steps"]],
                    relative_error_tolerance=float(config["relative_error_tolerance"]),
                )
                if checkpoint_store is not None and audit_path is not None:
                    checkpoint_store.save(
                        audit_path,
                        {"case": case, "half_orders": list(level), "audit": audit},
                    )
            else:
                audit = audit_checkpoint["audit"]
            for direction_index, direction_audit in enumerate(audit["audits"]):
                absolute_error = float(direction_audit["diagnostics"]["best_absolute_error"])
                relative_error = float(direction_audit["relative_error"])
                hybrid_error = min(
                    relative_error,
                    absolute_error
                    / float(config["absolute_error_tolerance"])
                    * float(config["relative_error_tolerance"]),
                )
                record = {
                    "case": case,
                    "half_orders": list(level),
                    "mode_count": harmonic_count(level),
                    "direction": direction_index,
                    "ad_fd_relative_error": relative_error,
                    "ad_fd_absolute_error": absolute_error,
                    "hybrid_error": hybrid_error,
                    "pass": bool(audit["all_finite"] and hybrid_error <= float(config["relative_error_tolerance"])),
                }
                directional_records.append(record)
                rows.append({"gate": "C_directional_AD_FD", **record})
    directional_pass = bool(directional_records) and all(record["pass"] for record in directional_records)

    oracle_records = []
    oracle_skipped_low_signal = []
    if reference_available:
        for target in target_orders:
            for case_value in config["cases"]:
                case = str(case_value)
                point = _density(config, case)
                reference_evaluation = evaluations[(case, selected_reference, target)]
                ref_value = float(reference_evaluation["objective"])
                if (
                    abs(ref_value) < float(config["reference_objective_floor"])
                    or float(reference_evaluation["gradient_norm"])
                    < float(config["reference_gradient_norm_floor"])
                ):
                    skipped = {
                        "case": case,
                        "target_order": list(target),
                        "reason": "insufficient_reference_signal",
                        "reference_objective": ref_value,
                        "reference_gradient_norm": float(
                            reference_evaluation["gradient_norm"]
                        ),
                    }
                    oracle_skipped_low_signal.append(skipped)
                    rows.append({"gate": "C_gradient_oracle_skipped", **skipped})
                    continue
                for level in ladder:
                    if level == selected_reference or (case, level, target) not in evaluations:
                        continue
                    gradient = evaluations[(case, level, target)]["gradient"]
                    feasible = project_feasible_gradient(point, gradient)
                    for step_rms in config["oracle_step_rms"]:
                        candidate = _apply_rms_step(point, feasible, float(step_rms))
                        oracle_path = (
                            checkpoint_store.path(
                                "oracle",
                                case,
                                _target_slug(target),
                                fidelity_key(level),
                                "rms_{:.6f}".format(float(step_rms)),
                            )
                            if checkpoint_store is not None
                            else None
                        )
                        oracle_checkpoint = (
                            checkpoint_store.load(oracle_path)
                            if checkpoint_store is not None and oracle_path is not None
                            else None
                        )
                        if oracle_checkpoint is None:
                            candidate_value = _scattering_metrics_fft(
                                config, candidate, selected_reference, target
                            )["target_power"]
                        else:
                            candidate_value = float(oracle_checkpoint["candidate_value"])
                        predicted = float(torch.sum(feasible * (candidate - point)).cpu())
                        actual = float(candidate_value) - ref_value
                        record = {
                            "case": case,
                            "target_order": list(target),
                            "proposal_half_orders": list(level),
                            "reference_half_orders": list(selected_reference),
                            "step_rms": float(step_rms),
                            "predicted_change": predicted,
                            "reference_actual_change": actual,
                            "false_ascent": bool(predicted > 0 and actual <= 0),
                        }
                        if (
                            oracle_checkpoint is None
                            and checkpoint_store is not None
                            and oracle_path is not None
                        ):
                            checkpoint_store.save(
                                oracle_path,
                                {
                                    "candidate_value": float(candidate_value),
                                    "record": record,
                                    "complete": True,
                                },
                            )
                        oracle_records.append(record)
                        rows.append({"gate": "C_gradient_oracle", **record})

    status = "PASS" if directional_pass and scientific_reference_qualified else "CONDITIONAL"
    reference_check = {
        "primary_high_half_orders": list(primary_high),
        "primary_reference_half_orders": list(primary_reference),
        "emergency_used": emergency_used,
        "selected_high_half_orders": list(selected_high),
        "selected_reference_half_orders": list(selected_reference),
        "all_pass": scientific_reference_qualified,
        "numerical_pair_pass": bool(reference_qualified),
        "scientific_mode": scientific_mode,
        "records": qualification_records,
        "resource_errors": resource_errors,
    }
    ladder_summary = {
        "orders": [list(level) for level in ladder],
        "square_control_orders": [list(level) for level in square_controls],
        "target_orders": [list(target) for target in target_orders],
        "reference_order": list(selected_reference),
        "reference_mode_count": harmonic_count(selected_reference),
        "value_relative_tolerance": float(config["working_value_relative_tolerance"]),
        "gradient_cosine_tolerance": float(config["working_gradient_cosine_tolerance"]),
        "separation_count": len(separation_records),
        "separation_demonstrated": bool(separation_records),
        "separation_records": separation_records,
        "per_target_case": per_target_case,
        "square_cost_control_count": len(square_cost_records),
        "anisotropic_value_win_count": sum(
            record["anisotropic_value_error_better"] for record in square_cost_records
        ),
        "anisotropic_gradient_win_count": sum(
            record["anisotropic_gradient_cosine_better"] for record in square_cost_records
        ),
    }
    return {
        "status": status,
        "factorization": _factorization(config),
        "directional_ad_fd_pass": directional_pass,
        "maximum_ad_fd_relative_error": max(
            (record["ad_fd_relative_error"] for record in directional_records),
            default=float("nan"),
        ),
        "gradient_convergence_ladder": ladder_summary,
        "gradient_reference_spot_check": reference_check,
        "reference_qualified": scientific_reference_qualified,
        "numerical_reference_pair_pass": bool(reference_qualified),
        "working_fidelities": {
            "low_half_orders": list(low),
            "middle_half_orders": list(middle),
            "middle_qualified": middle_qualified,
            "high_half_orders": list(selected_high),
            "reference_half_orders": list(selected_reference),
            "middle_selection_records": middle_records,
        },
        "false_ascent_count": sum(record["false_ascent"] for record in oracle_records),
        "gradient_oracle_record_count": len(oracle_records),
        "gradient_oracle_skipped_low_signal": oracle_skipped_low_signal,
        "main_claim_separation_demonstrated": bool(
            separation_records and scientific_reference_qualified
        ),
        "main_claim_reference_validated": scientific_reference_qualified,
        "scope": "lossless_dielectric_2d_fft_baseline_anisotropic",
        "gradient_contract": (
            "Same-level AD/FD validates the derivative of J_(Mx,My) only; "
            "reference qualification and actual-gain audits establish cross-level trust."
        ),
    }


class _CountedObjective:
    def __init__(
        self,
        config: Mapping[str, Any],
        half_orders: Sequence[int],
        target_order: Sequence[int],
    ):
        self.half_orders = parse_half_orders(half_orders)
        self.device = _device(config)
        self.objective = _objective_2d_fft(config, self.half_orders, target_order)
        self.forward_calls = 0
        self.backward_calls = 0
        self.wall_time_s = 0.0

    def value(self, point: torch.Tensor) -> float:
        start = time.perf_counter()
        self.forward_calls += 1
        with torch.no_grad():
            value = self.objective(point)
        self.wall_time_s += time.perf_counter() - start
        return _float(value)

    def value_and_gradient(self, point: torch.Tensor) -> Tuple[float, torch.Tensor]:
        start = time.perf_counter()
        self.forward_calls += 1
        self.backward_calls += 1
        work = point.detach().clone().requires_grad_(True)
        value = self.objective(work)
        gradient = torch.autograd.grad(value, work)[0].detach()
        self.wall_time_s += time.perf_counter() - start
        return _float(value), gradient

    def state_dict(self) -> Dict[str, Any]:
        return {
            "half_orders": list(self.half_orders),
            "forward_calls": int(self.forward_calls),
            "backward_calls": int(self.backward_calls),
            "wall_time_s": float(self.wall_time_s),
        }

    def load_state_dict(self, state: Mapping[str, Any]) -> None:
        if parse_half_orders(state["half_orders"]) != self.half_orders:
            raise ValueError("objective checkpoint fidelity mismatch")
        self.forward_calls = int(state["forward_calls"])
        self.backward_calls = int(state["backward_calls"])
        self.wall_time_s = float(state["wall_time_s"])


def _objective_states(
    objectives: Mapping[HalfOrders, _CountedObjective]
) -> Dict[str, Any]:
    return {
        fidelity_key(orders): objective.state_dict()
        for orders, objective in objectives.items()
    }


def _restore_objective_states(
    objectives: Mapping[HalfOrders, _CountedObjective],
    states: Mapping[str, Any],
) -> None:
    for orders, objective in objectives.items():
        state = states.get(fidelity_key(orders))
        if state is not None:
            objective.load_state_dict(state)


def _reset_peak_memory(objectives: Mapping[HalfOrders, _CountedObjective]) -> None:
    if objectives and next(iter(objectives.values())).device.type == "cuda":
        torch.cuda.synchronize()
        torch.cuda.reset_peak_memory_stats()


def _peak_memory_bytes(objectives: Mapping[HalfOrders, _CountedObjective]) -> int:
    if objectives and next(iter(objectives.values())).device.type == "cuda":
        torch.cuda.synchronize()
        return int(torch.cuda.max_memory_allocated())
    return 0


def _periodic_smooth_noise(shape: Sequence[int], seed: int, passes: int) -> torch.Tensor:
    generator = torch.Generator(device="cpu")
    generator.manual_seed(int(seed))
    noise = torch.randn(tuple(int(value) for value in shape), generator=generator, dtype=torch.float64)
    for _ in range(max(int(passes), 0)):
        noise = (
            4.0 * noise
            + torch.roll(noise, 1, 0)
            + torch.roll(noise, -1, 0)
            + torch.roll(noise, 1, 1)
            + torch.roll(noise, -1, 1)
        ) / 8.0
    noise = noise - torch.mean(noise)
    norm = rms_norm(noise)
    return noise if norm == 0 else noise / norm


def _initial_density(config: Mapping[str, Any], seed: int) -> torch.Tensor:
    base = _density(config, str(config["initial_case"]))
    noise = _periodic_smooth_noise(
        base.shape, seed, int(config["initial_noise_smoothing_pixels"])
    )
    point = torch.clamp(
        base + float(config["initial_noise_rms"]) * noise, 0.02, 0.98
    )
    return _apply_design_symmetry(config, point)


def _counter_snapshot(
    objectives: Mapping[HalfOrders, _CountedObjective], high: HalfOrders
) -> Dict[str, Any]:
    high_modes = harmonic_count(high)
    forward = sum(objective.forward_calls for objective in objectives.values())
    backward = sum(objective.backward_calls for objective in objectives.values())
    high_equivalent = 0.0
    for orders, objective in objectives.items():
        ratio = harmonic_count(orders) / high_modes
        high_equivalent += objective.backward_calls * ratio**3
        high_equivalent += 0.5 * objective.forward_calls * ratio**3
    return {
        "forward_calls": forward,
        "backward_calls": backward,
        "high_forward_calls": objectives[high].forward_calls,
        "high_backward_calls": objectives[high].backward_calls,
        "high_equivalent_cost": high_equivalent,
        "per_fidelity": {
            fidelity_key(orders): {
                "half_orders": list(orders),
                "mode_count": harmonic_count(orders),
                "forward_calls": objective.forward_calls,
                "backward_calls": objective.backward_calls,
                "wall_time_s": objective.wall_time_s,
            }
            for orders, objective in objectives.items()
        },
    }


def _monitor_reference(
    reference: _CountedObjective,
    point: torch.Tensor,
    iteration: int,
    start: float,
    objectives: Mapping[HalfOrders, _CountedObjective],
    high: HalfOrders,
) -> Dict[str, Any]:
    value = reference.value(point)
    snapshot = _counter_snapshot(objectives, high)
    return {
        "iteration": iteration,
        "reference_objective": value,
        "elapsed_s": time.perf_counter() - start,
        "high_backward_calls": snapshot["high_backward_calls"],
        "high_equivalent_cost": snapshot["high_equivalent_cost"],
    }


def _finalize_method_result(
    method: str,
    point: torch.Tensor,
    target_order: Sequence[int],
    start: float,
    objectives: Mapping[HalfOrders, _CountedObjective],
    high: HalfOrders,
    reference: HalfOrders,
    reference_history: List[Dict[str, Any]],
    **extra: Any,
) -> Dict[str, Any]:
    if not reference_history or reference_history[-1].get("is_final") is not True:
        final_record = _monitor_reference(
            objectives[reference], point, -1, start, objectives, high
        )
        final_record["is_final"] = True
        reference_history.append(final_record)
    else:
        reference_history[-1]["is_final"] = True
    snapshot = _counter_snapshot(objectives, high)
    return {
        "method": method,
        "target_order": list(target_order),
        "final_reference_objective": reference_history[-1]["reference_objective"],
        "final_authoritative_objective": reference_history[-1]["reference_objective"],
        "authoritative_half_orders": list(reference),
        "wall_time_s": time.perf_counter() - start,
        "peak_memory_bytes": _peak_memory_bytes(objectives),
        "reference_history": reference_history,
        **snapshot,
        **extra,
    }


def _fixed_method(
    config: Mapping[str, Any],
    initial: torch.Tensor,
    target_order: Sequence[int],
    level: HalfOrders,
    high: HalfOrders,
    reference: HalfOrders,
    method: str,
    *,
    resume_state: Optional[Mapping[str, Any]] = None,
    checkpoint_callback: Optional[Callable[[Mapping[str, Any]], None]] = None,
) -> Tuple[Dict[str, Any], List[Dict[str, Any]], torch.Tensor]:
    unique = list(dict.fromkeys((level, high, reference)))
    objectives = {orders: _CountedObjective(config, orders, target_order) for orders in unique}
    _reset_peak_memory(objectives)
    point = initial.clone()
    radius = _rms_to_l2_radius(point, float(config["step_radius_rms"]))
    trajectory: List[Dict[str, Any]] = []
    reference_history: List[Dict[str, Any]] = []
    start_iteration = 0
    elapsed_offset = 0.0
    if resume_state is not None:
        point = resume_state["point"].detach().cpu()
        trajectory = list(resume_state["trajectory"])
        reference_history = list(resume_state["reference_history"])
        start_iteration = int(resume_state["next_iteration"])
        elapsed_offset = float(resume_state.get("elapsed_s", 0.0))
        _restore_objective_states(objectives, resume_state.get("objectives", {}))
    start = time.perf_counter() - elapsed_offset
    if not reference_history:
        reference_history.append(
            _monitor_reference(objectives[reference], point, -1, start, objectives, high)
        )
    for iteration in range(start_iteration, int(config["fixed_iterations"])):
        value, gradient = objectives[level].value_and_gradient(point)
        feasible = project_feasible_gradient(
            point,
            gradient,
            mirror_y=bool(config.get("enforce_y_mirror_symmetry", False)),
        )
        point = _apply_design_symmetry(
            config, torch.clamp(point + bounded_gradient_step(feasible, radius), 0.0, 1.0)
        )
        entry = {
            "iteration": iteration,
            "selected_half_orders": list(level),
            "model_value": value,
            "gradient_rms": rms_norm(feasible),
        }
        if (iteration + 1) % int(config["reference_audit_interval_accepted"]) == 0:
            audit = _monitor_reference(
                objectives[reference], point, iteration, start, objectives, high
            )
            reference_history.append(audit)
            entry["reference_monitor"] = audit
        trajectory.append(entry)
        if checkpoint_callback is not None:
            checkpoint_callback(
                {
                    "kind": "fixed",
                    "method": method,
                    "next_iteration": iteration + 1,
                    "point": point.detach().cpu(),
                    "trajectory": trajectory,
                    "reference_history": reference_history,
                    "objectives": _objective_states(objectives),
                    "elapsed_s": time.perf_counter() - start,
                    "complete": False,
                }
            )
    result = _finalize_method_result(
        method,
        point,
        target_order,
        start,
        objectives,
        high,
        reference,
        reference_history,
        reference_rollbacks=0,
        false_ascent_count=sum(
            current["reference_objective"] < previous["reference_objective"]
            for previous, current in zip(reference_history, reference_history[1:])
        ),
    )
    return result, trajectory, point.detach()


def _continuation_method(
    config: Mapping[str, Any],
    initial: torch.Tensor,
    target_order: Sequence[int],
    levels: Sequence[HalfOrders],
    high: HalfOrders,
    reference: HalfOrders,
    *,
    resume_state: Optional[Mapping[str, Any]] = None,
    checkpoint_callback: Optional[Callable[[Mapping[str, Any]], None]] = None,
) -> Tuple[Dict[str, Any], List[Dict[str, Any]], torch.Tensor]:
    unique = list(dict.fromkeys(tuple(levels) + (reference,)))
    objectives = {orders: _CountedObjective(config, orders, target_order) for orders in unique}
    _reset_peak_memory(objectives)
    point = initial.clone()
    radius = _rms_to_l2_radius(point, float(config["step_radius_rms"]))
    selected_index = 0
    trajectory: List[Dict[str, Any]] = []
    reference_history: List[Dict[str, Any]] = []
    start_iteration = 0
    elapsed_offset = 0.0
    if resume_state is not None:
        point = resume_state["point"].detach().cpu()
        selected_index = int(resume_state["selected_index"])
        trajectory = list(resume_state["trajectory"])
        reference_history = list(resume_state["reference_history"])
        start_iteration = int(resume_state["next_iteration"])
        elapsed_offset = float(resume_state.get("elapsed_s", 0.0))
        _restore_objective_states(objectives, resume_state.get("objectives", {}))
    start = time.perf_counter() - elapsed_offset
    if not reference_history:
        reference_history.append(
            _monitor_reference(objectives[reference], point, -1, start, objectives, high)
        )
    for iteration in range(start_iteration, int(config["fixed_iterations"])):
        decision = "hold"
        cached: Dict[HalfOrders, Tuple[float, torch.Tensor]] = {}
        if (
            iteration % int(config["continuation_audit_interval"]) == 0
            and selected_index + 1 < len(levels)
        ):
            current, next_level = levels[selected_index], levels[selected_index + 1]
            cached[current] = objectives[current].value_and_gradient(point)
            cached[next_level] = objectives[next_level].value_and_gradient(point)
            value_error = _relative_change(cached[current][0], cached[next_level][0])
            cosine = gradient_cosine(cached[current][1], cached[next_level][1])
            if (
                value_error > float(config.get("working_value_relative_tolerance", 0.02))
                or cosine < float(config.get("working_gradient_cosine_tolerance", 0.90))
            ):
                selected_index += 1
                decision = "escalate"
        selected = levels[selected_index]
        value, gradient = cached.get(selected, (None, None))
        if value is None:
            value, gradient = objectives[selected].value_and_gradient(point)
        feasible = project_feasible_gradient(
            point,
            gradient,
            mirror_y=bool(config.get("enforce_y_mirror_symmetry", False)),
        )
        point = _apply_design_symmetry(
            config, torch.clamp(point + bounded_gradient_step(feasible, radius), 0.0, 1.0)
        )
        entry = {
            "iteration": iteration,
            "selected_half_orders": list(selected),
            "decision": decision,
            "model_value": value,
        }
        if (iteration + 1) % int(config["reference_audit_interval_accepted"]) == 0:
            audit = _monitor_reference(
                objectives[reference], point, iteration, start, objectives, high
            )
            reference_history.append(audit)
            entry["reference_monitor"] = audit
        trajectory.append(entry)
        if checkpoint_callback is not None:
            checkpoint_callback(
                {
                    "kind": "continuation",
                    "method": "order_continuation",
                    "next_iteration": iteration + 1,
                    "selected_index": selected_index,
                    "point": point.detach().cpu(),
                    "trajectory": trajectory,
                    "reference_history": reference_history,
                    "objectives": _objective_states(objectives),
                    "elapsed_s": time.perf_counter() - start,
                    "complete": False,
                }
            )
    result = _finalize_method_result(
        "order_continuation",
        point,
        target_order,
        start,
        objectives,
        high,
        reference,
        reference_history,
        final_selected_half_orders=list(levels[selected_index]),
        reference_rollbacks=0,
        false_ascent_count=sum(
            current["reference_objective"] < previous["reference_objective"]
            for previous, current in zip(reference_history, reference_history[1:])
        ),
    )
    return result, trajectory, point.detach()


def _trust_region_method(
    config: Mapping[str, Any],
    initial: torch.Tensor,
    target_order: Sequence[int],
    low: HalfOrders,
    middle: HalfOrders,
    high: HalfOrders,
    reference: HalfOrders,
    *,
    consensus: bool,
    method_name: Optional[str] = None,
    high_gradient_refresh_interval: int = 1,
    resume_state: Optional[Mapping[str, Any]] = None,
    checkpoint_callback: Optional[Callable[[Mapping[str, Any]], None]] = None,
) -> Tuple[Dict[str, Any], List[Dict[str, Any]], torch.Tensor]:
    all_levels = list(dict.fromkeys((low, middle, high, reference)))
    objectives = {orders: _CountedObjective(config, orders, target_order) for orders in all_levels}
    _reset_peak_memory(objectives)
    point = initial.clone()
    certified_point = point.clone()
    radius_scale = math.sqrt(point.numel())
    radius = float(config["trust_radius_initial_rms"]) * radius_scale
    radius_min = float(config["trust_radius_min_rms"]) * radius_scale
    radius_max = float(config["trust_radius_max_rms"]) * radius_scale
    start_iteration = 0
    elapsed_offset = 0.0
    start = time.perf_counter()
    certified_value = float("nan")
    reference_history: List[Dict[str, Any]] = []
    active_low, active_high = middle, high
    accepted_since_audit = 0
    trajectory: List[Dict[str, Any]] = []
    rollbacks = 0
    conflicts = 0
    all_high_evaluated = True
    max_value_residual = 0.0
    max_gradient_residual = 0.0
    cached_gradient_correction: Optional[torch.Tensor] = None
    high_gradient_refresh_count = 0

    if high_gradient_refresh_interval < 1:
        raise ValueError("high_gradient_refresh_interval must be at least one")
    if method_name is None:
        method_name = "MGDA-TR" if consensus else "FOC-TR"

    if resume_state is not None:
        point = resume_state["point"].detach().cpu()
        certified_point = resume_state["certified_point"].detach().cpu()
        certified_value = float(resume_state["certified_value"])
        radius = float(resume_state["radius"])
        active_low = parse_half_orders(resume_state["active_low"])
        active_high = parse_half_orders(resume_state["active_high"])
        accepted_since_audit = int(resume_state["accepted_since_audit"])
        trajectory = list(resume_state["trajectory"])
        reference_history = list(resume_state["reference_history"])
        rollbacks = int(resume_state["rollbacks"])
        conflicts = int(resume_state["conflicts"])
        all_high_evaluated = bool(resume_state["all_high_evaluated"])
        max_value_residual = float(resume_state["max_value_residual"])
        max_gradient_residual = float(resume_state["max_gradient_residual"])
        cached_gradient_correction = resume_state.get("cached_gradient_correction")
        if cached_gradient_correction is not None:
            cached_gradient_correction = cached_gradient_correction.detach().cpu()
        high_gradient_refresh_count = int(
            resume_state.get("high_gradient_refresh_count", 0)
        )
        start_iteration = int(resume_state["next_iteration"])
        elapsed_offset = float(resume_state.get("elapsed_s", 0.0))
        _restore_objective_states(objectives, resume_state.get("objectives", {}))
        start = time.perf_counter() - elapsed_offset
    else:
        certified_value = objectives[reference].value(point)
        reference_history = [
            {
                "iteration": -1,
                "reference_objective": certified_value,
                "elapsed_s": time.perf_counter() - start,
                "high_backward_calls": 0,
                "high_equivalent_cost": _counter_snapshot(objectives, high)["high_equivalent_cost"],
                "certified": True,
            }
        ]

    for iteration in range(start_iteration, int(config["trust_outer_candidates"])):
        low_center, low_gradient = objectives[active_low].value_and_gradient(point)
        if active_high == active_low:
            high_center, high_gradient = low_center, low_gradient
            high_gradient_refreshed = False
        else:
            high_gradient_refreshed = bool(
                consensus
                or cached_gradient_correction is None
                or iteration % high_gradient_refresh_interval == 0
            )
            if high_gradient_refreshed:
                high_center, high_gradient = objectives[active_high].value_and_gradient(point)
                cached_gradient_correction = (high_gradient - low_gradient).detach()
                high_gradient_refresh_count += 1
            else:
                high_center = objectives[active_high].value(point)
                high_gradient = low_gradient + cached_gradient_correction
        model = FirstOrderConsistentModel(
            low_center, high_center, low_gradient, high_gradient
        )
        value_residual, gradient_residual = model.consistency_residuals()
        max_value_residual = max(max_value_residual, value_residual)
        max_gradient_residual = max(max_gradient_residual, gradient_residual)
        conflict = False
        consensus_record: Dict[str, Any] = {}

        if consensus and active_low != active_high:
            consensus_levels = list(dict.fromkeys((low, active_low, active_high)))
            gradients = []
            for level in consensus_levels:
                if level == active_low:
                    gradients.append(low_gradient)
                elif level == active_high:
                    gradients.append(high_gradient)
                else:
                    _, gradient = objectives[level].value_and_gradient(point)
                    gradients.append(gradient)
            consensus_result = common_ascent_direction(
                point,
                gradients,
                mirror_y=bool(config.get("enforce_y_mirror_symmetry", False)),
            )
            conflict = consensus_result.conflict
            consensus_record = {
                "consensus_levels": [list(level) for level in consensus_levels],
                "consensus_weights": list(consensus_result.weights),
                "pairwise_gradient_cosines": list(consensus_result.pairwise_cosines),
                "common_ascent_cosines": list(consensus_result.common_ascent_cosines),
                "minimum_common_ascent_cosine": consensus_result.minimum_common_ascent_cosine,
                "gradient_conflict": conflict,
            }
            if conflict:
                conflicts += 1
                radius = max(radius * 0.5, radius_min)
                proposal_gradient = project_feasible_gradient(
                    point,
                    high_gradient,
                    mirror_y=bool(config.get("enforce_y_mirror_symmetry", False)),
                )
            else:
                proposal_gradient = consensus_result.direction
            candidate = _apply_design_symmetry(
                config,
                _project_candidate(
                    point,
                    point + bounded_gradient_step(proposal_gradient, radius),
                    radius,
                ),
            )
        else:
            candidate = point.clone()
            for _ in range(int(config["inner_low_steps"])):
                inner_start = time.perf_counter()
                work = candidate.detach().clone().requires_grad_(True)
                low_value_tensor = objectives[active_low].objective(work)
                objectives[active_low].forward_calls += 1
                objectives[active_low].backward_calls += 1
                correction = torch.sum(model.gradient_correction * (work - point))
                corrected = low_value_tensor + correction
                inner_gradient = torch.autograd.grad(corrected, work)[0].detach()
                objectives[active_low].wall_time_s += time.perf_counter() - inner_start
                feasible = project_feasible_gradient(
                    work.detach(),
                    inner_gradient,
                    mirror_y=bool(config.get("enforce_y_mirror_symmetry", False)),
                )
                candidate = _apply_design_symmetry(
                    config,
                    _project_candidate(
                        point,
                        work.detach()
                        + bounded_gradient_step(
                            feasible, radius / int(config["inner_low_steps"])
                        ),
                        radius,
                    ),
                )

        low_candidate = objectives[active_low].value(candidate)
        high_candidate = objectives[active_high].value(candidate)
        decision = assess_model_managed_candidate(
            model,
            low_candidate_value=low_candidate,
            high_candidate_value=high_candidate,
            step=candidate - point,
            radius=radius,
            acceptance_ratio=float(config["trust_acceptance_ratio"]),
            expansion_ratio=float(config["trust_expansion_ratio"]),
            radius_min=radius_min,
            radius_max=radius_max,
        )
        all_high_evaluated = all_high_evaluated and decision.high_candidate_evaluated
        if decision.accepted:
            point = candidate
            accepted_since_audit += 1
        radius = decision.next_radius
        entry = {
            "iteration": iteration,
            "accepted_by_high": decision.accepted,
            "action": decision.action,
            "rho": decision.rho,
            "predicted_change": decision.predicted_change,
            "high_actual_change": decision.actual_change,
            "active_low_half_orders": list(active_low),
            "active_high_half_orders": list(active_high),
            "radius_rms": radius / radius_scale,
            "high_gradient_refreshed": high_gradient_refreshed,
            "high_gradient_refresh_count": high_gradient_refresh_count,
            **consensus_record,
        }

        audit_due = accepted_since_audit >= int(config["reference_audit_interval_accepted"])
        final_provisional = iteration + 1 == int(config["trust_outer_candidates"]) and accepted_since_audit > 0
        if audit_due or final_provisional:
            reference_value = objectives[reference].value(point)
            audit = assess_reference_audit(
                certified_value,
                reference_value,
                allowed_drop=float(config["allowed_reference_drop"]),
            )
            snapshot = _counter_snapshot(objectives, high)
            history = {
                "iteration": iteration,
                "reference_objective": reference_value,
                "elapsed_s": time.perf_counter() - start,
                "high_backward_calls": snapshot["high_backward_calls"],
                "high_equivalent_cost": snapshot["high_equivalent_cost"],
                "certified": audit.accepted,
                "rollback": audit.rollback,
                "actual_change_from_certified": audit.actual_change,
            }
            reference_history.append(history)
            entry["reference_audit"] = history
            if audit.rollback:
                rollbacks += 1
                point = certified_point.clone()
                radius = max(radius * 0.5, radius_min)
                if active_high != reference:
                    active_low, active_high = active_high, reference
                    cached_gradient_correction = None
                    entry["fidelity_promotion"] = "high_to_reference"
                else:
                    active_low = active_high = reference
                    cached_gradient_correction = None
                    entry["fidelity_promotion"] = "fixed_reference"
            else:
                certified_point = point.clone()
                certified_value = reference_value
            accepted_since_audit = 0
        trajectory.append(entry)
        if checkpoint_callback is not None:
            checkpoint_callback(
                {
                    "kind": "trust_region",
                    "method": method_name,
                    "next_iteration": iteration + 1,
                    "point": point.detach().cpu(),
                    "certified_point": certified_point.detach().cpu(),
                    "certified_value": certified_value,
                    "radius": radius,
                    "active_low": list(active_low),
                    "active_high": list(active_high),
                    "accepted_since_audit": accepted_since_audit,
                    "trajectory": trajectory,
                    "reference_history": reference_history,
                    "rollbacks": rollbacks,
                    "conflicts": conflicts,
                    "all_high_evaluated": all_high_evaluated,
                    "max_value_residual": max_value_residual,
                    "max_gradient_residual": max_gradient_residual,
                    "cached_gradient_correction": (
                        cached_gradient_correction.detach().cpu()
                        if cached_gradient_correction is not None
                        else None
                    ),
                    "high_gradient_refresh_count": high_gradient_refresh_count,
                    "objectives": _objective_states(objectives),
                    "elapsed_s": time.perf_counter() - start,
                    "complete": False,
                }
            )

    point = certified_point
    # The last certified audit already evaluated this exact point.
    reference_history[-1]["reference_objective"] = certified_value
    reference_history[-1]["is_final"] = True
    result = _finalize_method_result(
        method_name,
        point,
        target_order,
        start,
        objectives,
        high,
        reference,
        reference_history,
        all_candidates_high_evaluated=all_high_evaluated,
        max_center_value_consistency_residual=max_value_residual,
        max_center_gradient_consistency_residual=max_gradient_residual,
        reference_rollbacks=rollbacks,
        gradient_conflict_count=conflicts,
        false_ascent_count=rollbacks,
        final_active_low_half_orders=list(active_low),
        final_active_high_half_orders=list(active_high),
        high_gradient_refresh_interval=high_gradient_refresh_interval,
        high_gradient_refresh_count=high_gradient_refresh_count,
    )
    return result, trajectory, point.detach()


def _cost_to_threshold(result: Mapping[str, Any], threshold: float, field: str) -> float:
    for record in result["reference_history"]:
        if float(record["reference_objective"]) >= threshold:
            return float(record[field])
    return float("inf")


def _median(values: Iterable[float]) -> float:
    # A method that never reaches the target has a right-censored cost of +inf.
    # Keep that value in the order statistic: dropping it makes unsuccessful
    # runs look artificially cheap.  Only NaNs are invalid observations.
    observed = [float(value) for value in values if not math.isnan(float(value))]
    return statistics.median(observed) if observed else float("inf")


def _run_gate_d_fft(
    config: Mapping[str, Any],
    rows: List[Dict[str, Any]],
    structure_output_dir: Path,
    gate_c: Mapping[str, Any],
    *,
    scientific_mode: bool,
    checkpoint_dir: Optional[Path] = None,
) -> Dict[str, Any]:
    _factorization(config)
    checkpoint_store = (
        CheckpointStore(checkpoint_dir, config, "gate_d")
        if checkpoint_dir is not None
        else None
    )
    levels = gate_c["working_fidelities"]
    low = parse_half_orders(levels["low_half_orders"])
    middle = parse_half_orders(levels["middle_half_orders"])
    high = parse_half_orders(levels["high_half_orders"])
    reference = parse_half_orders(levels["reference_half_orders"])
    if scientific_mode and not bool(gate_c["reference_qualified"]):
        return {
            "status": "BLOCKED_REFERENCE",
            "infrastructure_pass": True,
            "scientific_pass": False,
            "factorization": _factorization(config),
            "target_orders": [list(target) for target in config["target_orders"]],
            "per_target": {},
            "optimization_fidelity": {
                "low_half_orders": list(low),
                "middle_half_orders": list(middle),
                "high_half_orders": list(high),
                "reference_half_orders": list(reference),
            },
            "blocked_reason": (
                "Gate C did not qualify a value-and-gradient reference; Gate D was not run."
            ),
        }

    target_orders = [tuple(int(value) for value in target) for target in config["target_orders"]]
    for target in target_orders:
        if abs(target[0]) > low[0] or abs(target[1]) > low[1]:
            raise ValueError("low Fourier level does not contain target {}".format(target))
        if not _target_is_propagating(config, target):
            raise ValueError("target order {} is evanescent in the output medium".format(target))
    seeds = [int(value) for value in config["seeds"]]
    per_target: Dict[str, Any] = {}
    target_passes = []

    for target in target_orders:
        seed_entries: Dict[str, Any] = {}
        for seed in seeds:
            initial = _initial_density(config, seed)
            seed_dir = structure_output_dir / "seed_{}".format(seed)
            method_results: Dict[str, Any] = {}
            for method in METHODS:
                completed_path = (
                    checkpoint_store.path(
                        "completed",
                        _target_slug(target),
                        "seed_{}".format(seed),
                        method,
                    )
                    if checkpoint_store is not None
                    else None
                )
                completed = (
                    checkpoint_store.load(completed_path)
                    if checkpoint_store is not None and completed_path is not None
                    else None
                )
                if completed is None:
                    progress_path = (
                        checkpoint_store.path(
                            "in_progress",
                            _target_slug(target),
                            "seed_{}".format(seed),
                            method,
                        )
                        if checkpoint_store is not None
                        else None
                    )
                    resume_state = (
                        checkpoint_store.load(progress_path)
                        if checkpoint_store is not None and progress_path is not None
                        else None
                    )

                    def save_progress(state: Mapping[str, Any]) -> None:
                        if checkpoint_store is not None and progress_path is not None:
                            checkpoint_store.save(progress_path, state)

                    if method == "fixed_M":
                        result, trajectory, final_point = _fixed_method(
                            config,
                            initial,
                            target,
                            middle,
                            high,
                            reference,
                            method,
                            resume_state=resume_state,
                            checkpoint_callback=save_progress,
                        )
                    elif method == "fixed_H":
                        result, trajectory, final_point = _fixed_method(
                            config,
                            initial,
                            target,
                            high,
                            high,
                            reference,
                            method,
                            resume_state=resume_state,
                            checkpoint_callback=save_progress,
                        )
                    elif method == "order_continuation":
                        result, trajectory, final_point = _continuation_method(
                            config,
                            initial,
                            target,
                            (low, middle, high),
                            high,
                            reference,
                            resume_state=resume_state,
                            checkpoint_callback=save_progress,
                        )
                    elif method == "FOC-TR":
                        result, trajectory, final_point = _trust_region_method(
                            config,
                            initial,
                            target,
                            low,
                            middle,
                            high,
                            reference,
                            consensus=False,
                            resume_state=resume_state,
                            checkpoint_callback=save_progress,
                        )
                    elif method == "MGDA-TR":
                        result, trajectory, final_point = _trust_region_method(
                            config,
                            initial,
                            target,
                            low,
                            middle,
                            high,
                            reference,
                            consensus=True,
                            resume_state=resume_state,
                            checkpoint_callback=save_progress,
                        )
                    elif method == "FOC-TR-recycled":
                        result, trajectory, final_point = _trust_region_method(
                            config,
                            initial,
                            target,
                            low,
                            middle,
                            high,
                            reference,
                            consensus=False,
                            method_name="FOC-TR-recycled",
                            high_gradient_refresh_interval=int(
                                config.get("high_gradient_refresh_interval", 2)
                            ),
                            resume_state=resume_state,
                            checkpoint_callback=save_progress,
                        )
                    else:
                        # Post-hoc diagnostic extension: continue the already
                        # checkpointed five-candidate recycled trajectory for
                        # two smaller-radius candidates.  This avoids rerunning
                        # the exploratory prefix and stays below the protocol's
                        # maximum of ten outer candidates.
                        extended_resume = resume_state
                        if extended_resume is None and checkpoint_store is not None:
                            prefix_path = checkpoint_store.path(
                                "in_progress",
                                _target_slug(target),
                                "seed_{}".format(seed),
                                "FOC-TR-recycled",
                            )
                            extended_resume = checkpoint_store.load(prefix_path)
                        extended_config = dict(config)
                        extended_config["trust_outer_candidates"] = 7
                        result, trajectory, final_point = _trust_region_method(
                            extended_config,
                            initial,
                            target,
                            low,
                            middle,
                            high,
                            reference,
                            consensus=False,
                            method_name="FOC-TR-recycled7",
                            high_gradient_refresh_interval=2,
                            resume_state=extended_resume,
                            checkpoint_callback=save_progress,
                        )
                    if checkpoint_store is not None and completed_path is not None:
                        checkpoint_store.save(
                            completed_path,
                            {
                                "method": method,
                                "seed": seed,
                                "target_order": list(target),
                                "result": result,
                                "trajectory": trajectory,
                                "final_point": final_point.detach().cpu(),
                                "complete": True,
                            },
                        )
                else:
                    result = dict(completed["result"])
                    trajectory = list(completed["trajectory"])
                    final_point = completed["final_point"].detach().cpu()
                if result["method"] != method:
                    raise RuntimeError("method registration order changed")
                manifest = _save_density(seed_dir, target, method, final_point)
                reloaded = _load_density_exact(manifest)
                if not torch.equal(reloaded, final_point.cpu()):
                    raise RuntimeError("reference evaluator did not receive the exact saved tensor")
                result["saved_density"] = manifest
                result["saved_density_reloaded_exactly"] = True
                method_results[method] = result
                for entry in trajectory:
                    rows.append(
                        {
                            "gate": "D_trajectory",
                            "seed": seed,
                            "target_order": list(target),
                            "method": method,
                            **entry,
                        }
                    )
                for entry in result["reference_history"]:
                    rows.append(
                        {
                            "gate": "D_anytime",
                            "seed": seed,
                            "target_order": list(target),
                            "method": method,
                            **entry,
                        }
                    )

            initial_reference = method_results["fixed_H"]["reference_history"][0][
                "reference_objective"
            ]
            fixed_final = method_results["fixed_H"]["final_reference_objective"]
            threshold = initial_reference + 0.98 * (fixed_final - initial_reference)
            for result in method_results.values():
                result["fixed_high_98_percent_threshold"] = threshold
                result["high_backward_calls_to_threshold"] = _cost_to_threshold(
                    result, threshold, "high_backward_calls"
                )
                result["high_equivalent_cost_to_threshold"] = _cost_to_threshold(
                    result, threshold, "high_equivalent_cost"
                )
                result["wall_time_to_threshold_s"] = _cost_to_threshold(
                    result, threshold, "elapsed_s"
                )
            common_budget = min(
                float(result["high_equivalent_cost"])
                for result in method_results.values()
            )
            for result in method_results.values():
                eligible = [
                    record
                    for record in result["reference_history"]
                    if float(record["high_equivalent_cost"]) <= common_budget
                ]
                result["common_budget"] = common_budget
                result["common_budget_reference_objective"] = (
                    eligible[-1]["reference_objective"] if eligible else initial_reference
                )
            seed_entries[str(seed)] = {
                "seed": seed,
                "initial_reference_objective": initial_reference,
                "methods": method_results,
            }
            if checkpoint_store is not None:
                checkpoint_store.save(
                    checkpoint_store.path(
                        "seed_summaries",
                        _target_slug(target),
                        "seed_{}".format(seed),
                    ),
                    {
                        "seed": seed,
                        "target_order": list(target),
                        "summary": seed_entries[str(seed)],
                        "complete": True,
                    },
                )

        aggregates = {}
        for method in METHODS:
            results = [entry["methods"][method] for entry in seed_entries.values()]
            aggregates[method] = {
                "median_final_reference_objective": statistics.median(
                    float(result["final_reference_objective"]) for result in results
                ),
                "median_common_budget_reference_objective": statistics.median(
                    float(result["common_budget_reference_objective"]) for result in results
                ),
                "median_high_backward_calls": statistics.median(
                    int(result["high_backward_calls"]) for result in results
                ),
                "median_wall_time_s": statistics.median(
                    float(result["wall_time_s"]) for result in results
                ),
                "median_high_backward_calls_to_fixed_high_98_percent": _median(
                    result["high_backward_calls_to_threshold"] for result in results
                ),
                "median_cost_to_fixed_high_98_percent": _median(
                    result["high_equivalent_cost_to_threshold"] for result in results
                ),
                "median_wall_to_fixed_high_98_percent_s": _median(
                    result["wall_time_to_threshold_s"] for result in results
                ),
                "false_ascent_count": sum(int(result["false_ascent_count"]) for result in results),
            }
        fixed = aggregates["fixed_H"]
        primary = aggregates["FOC-TR"]
        noninferior = primary["median_final_reference_objective"] >= (
            fixed["median_final_reference_objective"]
            * (1.0 - float(config["fixed_high_noninferiority_relative"]))
        )
        cost_reduction = float(config["required_cost_reduction_relative"])
        cost_better = (
            primary["median_high_backward_calls_to_fixed_high_98_percent"]
            <= (1.0 - cost_reduction)
            * fixed["median_high_backward_calls_to_fixed_high_98_percent"]
            or primary["median_wall_to_fixed_high_98_percent_s"]
            <= (1.0 - cost_reduction) * fixed["median_wall_to_fixed_high_98_percent_s"]
        )
        target_scientific_pass = bool(scientific_mode and noninferior and cost_better)
        target_passes.append(target_scientific_pass)

        foc_values = [
            entry["methods"]["FOC-TR"]["final_reference_objective"]
            for entry in seed_entries.values()
        ]
        foc_median = statistics.median(float(value) for value in foc_values)
        representative_seed = min(
            seeds,
            key=lambda seed: abs(
                float(seed_entries[str(seed)]["methods"]["FOC-TR"]["final_reference_objective"])
                - foc_median
            ),
        )
        representative_methods = seed_entries[str(representative_seed)]["methods"]
        target_key = _target_slug(target)
        per_target[target_key] = {
            "target_order": list(target),
            "seeds": seed_entries,
            "aggregates": aggregates,
            "representative_seed": representative_seed,
            "methods": representative_methods,
            "best_authoritative_method": "FOC-TR",
            "best_authoritative_objective": representative_methods["FOC-TR"][
                "final_reference_objective"
            ],
            "authoritative_half_orders": list(reference),
            "foc_noninferior_to_fixed_high": noninferior,
            "foc_cost_reduction_pass": cost_better,
            "mgda_secondary": {
                "median_objective_delta_vs_foc": (
                    aggregates["MGDA-TR"]["median_final_reference_objective"]
                    - aggregates["FOC-TR"]["median_final_reference_objective"]
                ),
                "false_ascent_delta_vs_foc": (
                    aggregates["MGDA-TR"]["false_ascent_count"]
                    - aggregates["FOC-TR"]["false_ascent_count"]
                ),
            },
            "recycled_foc_exploratory": {
                "post_hoc": True,
                "median_objective_delta_vs_fixed_high": (
                    aggregates["FOC-TR-recycled"]["median_final_reference_objective"]
                    - aggregates["fixed_H"]["median_final_reference_objective"]
                ),
                "median_high_backward_calls_to_fixed_high_98_percent": aggregates[
                    "FOC-TR-recycled"
                ]["median_high_backward_calls_to_fixed_high_98_percent"],
                "false_ascent_count": aggregates["FOC-TR-recycled"][
                    "false_ascent_count"
                ],
            },
            "recycled7_foc_exploratory": {
                "post_hoc": True,
                "outer_candidates": 7,
                "median_objective_delta_vs_fixed_high": (
                    aggregates["FOC-TR-recycled7"]["median_final_reference_objective"]
                    - aggregates["fixed_H"]["median_final_reference_objective"]
                ),
                "median_high_backward_calls_to_fixed_high_98_percent": aggregates[
                    "FOC-TR-recycled7"
                ]["median_high_backward_calls_to_fixed_high_98_percent"],
                "false_ascent_count": aggregates["FOC-TR-recycled7"][
                    "false_ascent_count"
                ],
            },
            "scientific_pass": target_scientific_pass,
        }

    scientific_pass = bool(target_passes and all(target_passes))
    status = "PASS" if scientific_pass else ("SMOKE" if not scientific_mode else "CONDITIONAL")
    return {
        "status": status,
        "infrastructure_pass": True,
        "scientific_pass": scientific_pass,
        "factorization": _factorization(config),
        "optimization_fidelity": {
            "low_half_orders": list(low),
            "middle_half_orders": list(middle),
            "middle_qualified": bool(levels["middle_qualified"]),
            "high_half_orders": list(high),
            "reference_half_orders": list(reference),
        },
        "final_scoring_protocol": {
            "reference_half_orders": list(reference),
            "all_methods_scored_at_reference": True,
            "all_saved_densities_reloaded_exactly": True,
            "reference_audit_interval_accepted": int(
                config["reference_audit_interval_accepted"]
            ),
        },
        "methods": list(METHODS),
        "seeds": seeds,
        "protocol": {
            "fixed_iterations": int(config["fixed_iterations"]),
            "trust_outer_candidates": int(config["trust_outer_candidates"]),
            "inner_low_steps": int(config["inner_low_steps"]),
            "reference_audit_interval_accepted": int(
                config["reference_audit_interval_accepted"]
            ),
            "allowed_reference_drop": float(config["allowed_reference_drop"]),
        },
        "target_orders": [list(target) for target in target_orders],
        "per_target": per_target,
        "scope": "multi_seed_multi_target_fft_baseline_anisotropic",
        "fabrication_robustness_in_training": False,
    }


def run_gate_cd_fft(
    config: Mapping[str, Any],
    structure_output_dir: Path,
    *,
    mode: Optional[str] = None,
    checkpoint_dir: Optional[Path] = None,
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """Run the configured full campaign or a non-scientific smoke campaign."""
    effective = deepcopy(dict(config))
    selected_mode = str(mode or effective.get("run_mode", "full"))
    if selected_mode not in ("full", "smoke"):
        raise ValueError("Gate C/D mode must be 'full' or 'smoke'")
    if selected_mode == "smoke":
        _deep_merge(effective, effective.get("smoke", {}))
    scientific_mode = selected_mode == "full"
    gate_c_config = effective["gate_c"]
    gate_d_config = effective["gate_d"]
    _validate_square_pixel_grid(gate_c_config)
    _validate_square_pixel_grid(gate_d_config)
    for key in (
        "wavelength_nm",
        "lattice_nm",
        "thickness_nm",
        "incident_index",
        "output_index",
        "background_index",
        "feature_index",
        "pixel_size_nm",
        "grid_yx",
        "factorization",
        "device",
    ):
        if gate_c_config[key] != gate_d_config[key]:
            raise ValueError("Gate C and Gate D must share {}".format(key))
    rows: List[Dict[str, Any]] = []
    gate_c = _run_gate_c_fft(
        gate_c_config,
        rows,
        scientific_mode=scientific_mode,
        checkpoint_dir=(checkpoint_dir / "gate_c" if checkpoint_dir is not None else None),
    )
    gate_d = _run_gate_d_fft(
        gate_d_config,
        rows,
        structure_output_dir,
        gate_c,
        scientific_mode=scientific_mode,
        checkpoint_dir=(checkpoint_dir / "gate_d" if checkpoint_dir is not None else None),
    )
    status = (
        "PASS"
        if gate_c["status"] == "PASS" and gate_d["status"] == "PASS"
        else "SMOKE"
        if selected_mode == "smoke" and gate_d["status"] == "SMOKE"
        else "CONDITIONAL"
    )
    return rows, {
        "schema_version": int(effective.get("schema_version", 2)),
        "status": status,
        "run_mode": selected_mode,
        "scientific_evidence": scientific_mode,
        "gate_c": gate_c,
        "gate_d": gate_d,
        "excluded_legacy_examples_used": False,
        "manufacturing_robustness_deferred": True,
        "manufacturing_reentry_condition": (
            "Run Gate E only after Gate C qualifies the reference and Gate D passes "
            "the preregistered FOC-TR noninferiority/cost criteria."
        ),
    }
