"""Fresh TORCWA comparison for the current Gate-D structures.

This module deliberately does not read any historical TORCWA/sample assets.  It
loads only the current Gate-D summary, reruns TORCWA, and stores new artifacts.
"""

import hashlib
import importlib.metadata
import json
import math
from pathlib import Path
import platform
import time
from typing import Any, Dict, List, Mapping, Sequence, Tuple

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch

from trustworthy_fmm.benchmark.gate_cd import _density, _load_density_exact
from trustworthy_fmm.fabrication.process import periodic_gaussian_filter
from trustworthy_fmm.solvers.vector_2d import solve_vector_2d


def _target_slug(target: Sequence[int]) -> str:
    def component(value: int) -> str:
        return "p{}".format(value) if value > 0 else "m{}".format(abs(value)) if value < 0 else "0"

    return "target_{}_{}".format(component(int(target[0])), component(int(target[1])))


def _sha256(tensor: torch.Tensor) -> str:
    value = tensor.detach().cpu().contiguous()
    return hashlib.sha256(value.numpy().tobytes()).hexdigest()


def _save_tensor(path: Path, tensor: torch.Tensor) -> Dict[str, Any]:
    path.parent.mkdir(parents=True, exist_ok=True)
    value = tensor.detach().cpu().contiguous()
    torch.save(value, path)
    return {
        "path": str(path.resolve()),
        "sha256": _sha256(value),
        "shape": list(value.shape),
        "dtype": str(value.dtype),
        "minimum": float(value.min()),
        "maximum": float(value.max()),
        "mean": float(value.mean()),
    }


def example6_projection(density: torch.Tensor, beta: float) -> torch.Tensor:
    """Projection used by TORCWA Example 6, with threshold eta=0.5."""
    beta_tensor = torch.as_tensor(beta, dtype=density.dtype, device=density.device)
    return 0.5 + torch.tanh(2 * beta_tensor * density - beta_tensor) / (
        2 * torch.tanh(beta_tensor)
    )


def manufacturing_mask(
    density_yx: torch.Tensor,
    lattice_nm: Sequence[float],
    blur_radius_nm: float,
    threshold: float,
    *,
    enforce_y_mirror_symmetry: bool = False,
) -> torch.Tensor:
    """Apply the common fabrication map used for both optimizers."""
    if enforce_y_mirror_symmetry:
        density_yx = 0.5 * (density_yx + torch.flip(density_yx, dims=(0,)))
    filtered = periodic_gaussian_filter(density_yx, lattice_nm, blur_radius_nm)
    if enforce_y_mirror_symmetry:
        filtered = 0.5 * (filtered + torch.flip(filtered, dims=(0,)))
    return (filtered >= float(threshold)).to(dtype=torch.float64)


def binary_similarity(left: torch.Tensor, right: torch.Tensor) -> Dict[str, float]:
    left_bool = left.to(dtype=torch.bool)
    right_bool = right.to(dtype=torch.bool)
    intersection = torch.logical_and(left_bool, right_bool).sum().item()
    union = torch.logical_or(left_bool, right_bool).sum().item()
    disagreement = torch.logical_xor(left_bool, right_bool).to(torch.float64).mean()
    return {
        "our_fill_fraction": float(left_bool.to(torch.float64).mean()),
        "torcwa_fill_fraction": float(right_bool.to(torch.float64).mean()),
        "intersection_over_union": float(intersection / union) if union else 1.0,
        "pixel_disagreement_fraction": float(disagreement),
    }


def _torch_dtype(name: str) -> torch.dtype:
    mapping = {"complex64": torch.complex64, "complex128": torch.complex128}
    if name not in mapping:
        raise ValueError("unsupported complex dtype {!r}".format(name))
    return mapping[name]


def _torcwa_target_power(
    density_yx: torch.Tensor,
    physics: Mapping[str, Any],
    half_order: int,
    target_order: Sequence[int],
    *,
    dtype: torch.dtype,
    device: torch.device,
) -> torch.Tensor:
    """Return power for x-polarized incidence, summed over x/y output."""
    try:
        import torcwa
    except ImportError as exc:
        raise RuntimeError(
            "TORCWA is not installed; run `python -m pip install -r requirements-torcwa.txt`."
        ) from exc
    real_dtype = torch.float32 if dtype == torch.complex64 else torch.float64
    density_xy = density_yx.transpose(0, 1).to(device=device, dtype=real_dtype)
    epsilon_xy = (
        float(physics["background_index"]) ** 2
        + (
            float(physics["feature_index"]) ** 2
            - float(physics["background_index"]) ** 2
        )
        * density_xy
    )
    simulation = torcwa.rcwa(
        freq=1.0 / float(physics["wavelength_nm"]),
        order=[int(half_order), int(half_order)],
        L=[float(value) for value in physics["lattice_nm"]],
        dtype=dtype,
        device=device,
        stable_eig_grad=True,
    )
    simulation.add_input_layer(eps=float(physics["incident_index"]) ** 2)
    simulation.add_output_layer(eps=float(physics["output_index"]) ** 2)
    simulation.set_incident_angle(
        inc_ang=math.radians(float(physics["theta_deg"])),
        azi_ang=math.radians(float(physics["phi_deg"])),
    )
    simulation.add_layer(float(physics["thickness_nm"]), epsilon_xy)
    simulation.solve_global_smatrix()
    t_xx = simulation.S_parameters(
        orders=list(target_order),
        direction="forward",
        port="transmission",
        polarization="xx",
        ref_order=[0, 0],
    )
    t_yx = simulation.S_parameters(
        orders=list(target_order),
        direction="forward",
        port="transmission",
        polarization="yx",
        ref_order=[0, 0],
    )
    return torch.sum(torch.abs(t_xx) ** 2 + torch.abs(t_yx) ** 2)


def _our_target_power(
    density_yx: torch.Tensor,
    physics: Mapping[str, Any],
    half_order: int,
    target_order: Sequence[int],
    factorization: str,
) -> float:
    epsilon = (
        float(physics["background_index"]) ** 2
        + (
            float(physics["feature_index"]) ** 2
            - float(physics["background_index"]) ** 2
        )
        * density_yx.to(torch.float64)
    ).to(torch.complex128)
    with torch.no_grad():
        result = solve_vector_2d(
            epsilon,
            float(physics["thickness_nm"]),
            float(physics["wavelength_nm"]),
            tuple(float(value) for value in physics["lattice_nm"]),
            complex(physics["incident_index"]),
            complex(physics["output_index"]),
            (int(half_order), int(half_order)),
            float(physics["theta_deg"]),
            float(physics["phi_deg"]),
            factorization=factorization,
        )
    return float(result.transmitted_power(tuple(int(v) for v in target_order)))


def _optimize_torcwa_example6_style(
    initial_yx: torch.Tensor,
    physics: Mapping[str, Any],
    optimization: Mapping[str, Any],
    target_order: Sequence[int],
) -> Tuple[
    torch.Tensor,
    torch.Tensor,
    List[Dict[str, float]],
    float,
    int,
    float,
]:
    device = torch.device(str(optimization["device"]))
    complex_dtype = _torch_dtype(str(optimization["dtype"]))
    real_dtype = torch.float32 if complex_dtype == torch.complex64 else torch.float64
    iterations = int(optimization["iterations"])
    beta_start = float(optimization["projection_beta_initial"])
    beta_final = float(optimization["projection_beta_final"])
    raw = initial_yx.to(device=device, dtype=real_dtype).clone()
    enforce_y_symmetry = bool(optimization["enforce_mirror_symmetry"])
    if enforce_y_symmetry:
        raw = 0.5 * (raw + torch.flip(raw, dims=(0,)))
    momentum = torch.zeros_like(raw)
    velocity = torch.zeros_like(raw)
    history: List[Dict[str, float]] = []
    best_binary = torch.zeros_like(raw, dtype=torch.float64)
    best_projected = raw.detach().clone()
    best_binary_objective = -float("inf")
    best_binary_iteration = -1
    binary_audit_interval = int(optimization.get("binary_audit_interval", 1))
    if binary_audit_interval <= 0:
        raise ValueError("binary_audit_interval must be positive")
    start = time.perf_counter()
    for iteration in range(iterations):
        fraction = iteration / max(iterations - 1, 1)
        beta = beta_start * (beta_final / beta_start) ** fraction
        learning_rate = float(optimization["learning_rate_initial"]) * 0.5 * (
            1.0 + math.cos(math.pi * iteration / iterations)
        )
        work = raw.detach().clone().requires_grad_(True)
        filtered = periodic_gaussian_filter(
            work,
            physics["lattice_nm"],
            float(optimization["blur_radius_nm"]),
        )
        if enforce_y_symmetry:
            filtered = 0.5 * (filtered + torch.flip(filtered, dims=(0,)))
        projected = example6_projection(filtered, beta)
        objective = _torcwa_target_power(
            projected,
            physics,
            int(optimization["half_order"]),
            target_order,
            dtype=complex_dtype,
            device=device,
        )
        gradient = torch.autograd.grad(objective, work)[0]
        if not bool(torch.isfinite(gradient).all()):
            raise RuntimeError(
                "TORCWA returned a non-finite gradient at iteration {}".format(iteration)
            )
        binary_objective = float("nan")
        if iteration % binary_audit_interval == 0 or iteration == iterations - 1:
            with torch.no_grad():
                binary_candidate = (
                    filtered.detach() >= float(optimization["threshold"])
                ).to(torch.float64)
                binary_value = _torcwa_target_power(
                    binary_candidate,
                    physics,
                    int(optimization["half_order"]),
                    target_order,
                    dtype=complex_dtype,
                    device=device,
                )
                binary_objective = float(binary_value.detach().cpu())
                if binary_objective > best_binary_objective:
                    best_binary_objective = binary_objective
                    best_binary_iteration = iteration
                    best_binary = binary_candidate.detach().clone()
                    best_projected = projected.detach().clone()
        with torch.no_grad():
            beta1 = float(optimization["adam_beta1"])
            beta2 = float(optimization["adam_beta2"])
            momentum = beta1 * momentum + (1 - beta1) * gradient
            velocity = beta2 * velocity + (1 - beta2) * gradient.square()
            corrected_momentum = momentum / (1 - beta1 ** (iteration + 1))
            corrected_velocity = velocity / (1 - beta2 ** (iteration + 1))
            raw = torch.clamp(
                work
                + learning_rate
                * corrected_momentum
                / torch.sqrt(corrected_velocity + float(optimization["adam_epsilon"])),
                0.0,
                1.0,
            ).detach()
            if enforce_y_symmetry:
                raw = 0.5 * (raw + torch.flip(raw, dims=(0,)))
            history.append(
                {
                    "iteration": iteration,
                    "objective": float(objective.detach().cpu()),
                    "beta": beta,
                    "learning_rate": learning_rate,
                    "gradient_norm": float(torch.linalg.vector_norm(gradient).cpu()),
                    "projected_gray_fraction": float(
                        torch.logical_and(projected > 0.05, projected < 0.95)
                        .to(torch.float64)
                        .mean()
                        .cpu()
                    ),
                    "binary_objective": binary_objective,
                }
            )
    elapsed = time.perf_counter() - start
    if best_binary_iteration < 0:
        raise RuntimeError("no binary TORCWA candidate was audited")
    return (
        best_projected.detach().cpu().to(torch.float64),
        best_binary.detach().cpu(),
        history,
        elapsed,
        best_binary_iteration,
        best_binary_objective,
    )


def _save_figure(figure: Any, stem: Path) -> Dict[str, str]:
    outputs: Dict[str, str] = {}
    for suffix in ("png", "pdf", "svg"):
        path = stem.with_suffix("." + suffix)
        figure.savefig(path, dpi=300 if suffix == "png" else None, bbox_inches="tight")
        outputs[suffix] = str(path.resolve())
    plt.close(figure)
    return outputs


def _plot_structures(records: Sequence[Mapping[str, Any]], physics: Mapping[str, Any], stem: Path) -> Dict[str, str]:
    figure, axes = plt.subplots(len(records), 3, figsize=(10.2, 5.8), squeeze=False)
    extent = (
        0.0,
        float(physics["lattice_nm"][0]) / 1000,
        0.0,
        float(physics["lattice_nm"][1]) / 1000,
    )
    for row, record in enumerate(records):
        our_mask = torch.load(record["our_binary"]["path"], map_location="cpu", weights_only=True)
        torcwa_mask = torch.load(record["torcwa_binary"]["path"], map_location="cpu", weights_only=True)
        difference = torch.logical_xor(our_mask.bool(), torcwa_mask.bool()).to(torch.float64)
        for column, (value, title, cmap) in enumerate(
            (
                (our_mask, "Our current best → binary", "gray"),
                (torcwa_mask, "Fresh TORCWA optimization → binary", "gray"),
                (difference, "XOR structural difference", "magma"),
            )
        ):
            axis = axes[row, column]
            axis.imshow(value.numpy(), origin="lower", extent=extent, vmin=0, vmax=1, cmap=cmap, interpolation="nearest", aspect="equal")
            if row == 0:
                if column == 2:
                    similarity = record["binary_similarity"]
                    axis.set_title(
                        "XOR structural difference\ndifferent={:.1%}; IoU={:.3f}".format(
                            similarity["pixel_disagreement_fraction"],
                            similarity["intersection_over_union"],
                        ),
                        fontsize=8.5,
                    )
                else:
                    axis.set_title(title, fontsize=9)
            elif column == 2:
                similarity = record["binary_similarity"]
                axis.set_title(
                    "different={:.1%}; IoU={:.3f}".format(
                        similarity["pixel_disagreement_fraction"],
                        similarity["intersection_over_union"],
                    ),
                    fontsize=8,
                )
            if row == len(records) - 1:
                axis.set_xlabel("x [µm]")
            if column == 0:
                target = record["target_order"]
                axis.set_ylabel("target ({:+d},{:+d})\ny [µm]".format(*target))
            else:
                axis.tick_params(labelleft=False)
    figure.suptitle("Common fabrication map: periodic Gaussian filter + hard threshold", fontsize=12)
    figure.subplots_adjust(hspace=0.55, wspace=0.12, top=0.88)
    return _save_figure(figure, stem)


def _plot_scores(records: Sequence[Mapping[str, Any]], half_orders: Sequence[int], stem: Path) -> Dict[str, str]:
    labels = []
    our_jdf = []
    our_fft = []
    torcwa = []
    for record in records:
        target = record["target_order"]
        for design_key, design_label in (("our_binary", "ours"), ("torcwa_binary", "TORCWA")):
            for order in half_orders:
                score = record["scores"][design_key]["N{}".format(order)]
                labels.append("{:+d}\n{}·N{}".format(target[0], design_label, order))
                our_jdf.append(score["our_jones_direct_fourier"])
                our_fft.append(score["our_fft_baseline"])
                torcwa.append(score["torcwa"])
    x = np.arange(len(labels))
    width = 0.25
    figure, axis = plt.subplots(figsize=(12.0, 4.2))
    axis.bar(x - width, our_jdf, width, label="Our solver · JDF", color="#2457C5")
    axis.bar(x, our_fft, width, label="Our solver · FFT baseline", color="#7DA6F8")
    axis.bar(x + width, torcwa, width, label="TORCWA 0.1.4.2", color="#E57A2E")
    axis.set_ylabel("Target-order transmitted power")
    axis.set_xticks(x, labels, fontsize=7, rotation=30, ha="right")
    axis.set_ylim(bottom=0)
    axis.grid(axis="y", alpha=0.25)
    axis.legend(ncol=3, loc="upper center", fontsize=8)
    axis.set_title("Binary structures rescored by both solvers at N=6 and N=7")
    return _save_figure(figure, stem)


def _plot_histories(records: Sequence[Mapping[str, Any]], stem: Path) -> Dict[str, str]:
    figure, axis = plt.subplots(figsize=(7.4, 4.2))
    for record in records:
        target = record["target_order"]
        history = record["torcwa_optimization"]["history"]
        line = axis.plot(
            [entry["iteration"] for entry in history],
            [entry["objective"] for entry in history],
            label="({:+d},{:+d})".format(*target),
        )[0]
        axis.plot(
            [entry["iteration"] for entry in history],
            [entry["binary_objective"] for entry in history],
            linestyle="--",
            color=line.get_color(),
            alpha=0.65,
        )
    axis.set_xlabel("TORCWA backward iteration")
    axis.set_ylabel("Optimization objective (N=4)")
    axis.grid(alpha=0.25)
    axis.legend(title="target")
    axis.set_title("Projected objective (solid) and binary audit (dashed)")
    return _save_figure(figure, stem)


def _build_report(summary: Mapping[str, Any]) -> str:
    physics = summary["physics"]
    lines = [
        "# 当前 Gate D 与 TORCWA 的全新交叉比较",
        "",
        "> 本实验没有读取旧项目、旧 TORCWA sample 或历史外部评分；TORCWA 结构由本次脚本从当前初始条件重新优化得到。",
        "",
        "## 公平比较协议",
        "",
        "- 固定相同的波长、周期、层厚、上下半空间、材料折射率、入射角和目标阶。",
        "- 固定 x Jones 入射，目标为该衍射阶 x/y 输出偏振的总透射功率。",
        "- TORCWA 采用 Example 6 的周期 Gaussian filter、tanh beta continuation 和 Adam ascent。",
        "- 目标阶为 (m,0)，法向入射下对设计施加 y 镜像对称；在 native (Ny,Nx) 数组中翻转第 0 轴。",
        "- 两种优化结果统一经过相同的周期 Gaussian filter 和 rho=0.5 硬阈值，比较二值制造掩膜。",
        "- TORCWA 每次反向迭代后审计硬阈值结构，并以 N=4 二值目标选择交付迭代，避免 continuation 末端塌缩被误当成最优解。",
        "- 每个二值掩膜由我们的 JDF、我们的 FFT baseline 和 TORCWA 在 N=6/7 重新评分。",
        "- 当前 TORCWA 分支运行 80 次反向传播，而原 Gate D 方法只有 7 或 10 次迭代；结果是交付结构比较，不是等成本 optimizer 排名。",
        "",
        "## 物理条件",
        "",
        "| 参数 | 数值 |",
        "|---|---:|",
        "| wavelength | {:.1f} nm |".format(float(physics["wavelength_nm"])),
        "| period x / y | {:.1f} / {:.1f} nm |".format(*[float(v) for v in physics["lattice_nm"]]),
        "| patterned thickness | {:.1f} nm |".format(float(physics["thickness_nm"])),
        "| n incident / output | {:.3f} / {:.3f} |".format(float(physics["incident_index"]), float(physics["output_index"])),
        "| n background / feature | {:.3f} / {:.3f} |".format(float(physics["background_index"]), float(physics["feature_index"])),
        "| theta / phi | {:.1f} / {:.1f} deg |".format(float(physics["theta_deg"]), float(physics["phi_deg"])),
        "",
        "## TORCWA 优化记录",
        "",
        "| target | Nopt | iterations | wall time | projected first → last | best binary (iteration) | final gray fraction |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for record in summary["records"]:
        history = record["torcwa_optimization"]["history"]
        lines.append(
            "| ({:+d},{:+d}) | {} | {} | {:.2f} s | {:.6f} → {:.6f} | {:.6f} ({}) | {:.1%} |".format(
                *record["target_order"],
                record["torcwa_optimization"]["half_order"],
                record["torcwa_optimization"]["iterations"],
                record["torcwa_optimization"]["wall_time_s"],
                history[0]["objective"],
                history[-1]["objective"],
                record["torcwa_optimization"]["best_binary_objective"],
                record["torcwa_optimization"]["selected_binary_iteration"],
                history[-1]["projected_gray_fraction"],
            )
        )
    lines.extend(
        [
        "",
        "## 结果",
        "",
        "| target | design | N | our JDF | our FFT | TORCWA | abs(FFT-TORCWA) |",
        "|---|---|---:|---:|---:|---:|---:|",
        ]
    )
    for record in summary["records"]:
        target = "({:+d},{:+d})".format(*record["target_order"])
        for design_key, label in (("our_binary", "our binary"), ("torcwa_binary", "TORCWA binary")):
            for key, score in record["scores"][design_key].items():
                lines.append(
                    "| {} | {} | {} | {:.6f} | {:.6f} | {:.6f} | {:.3e} |".format(
                        target,
                        label,
                        key[1:],
                        score["our_jones_direct_fourier"],
                        score["our_fft_baseline"],
                        score["torcwa"],
                        score["fft_torcwa_absolute_difference"],
                    )
                )
    lines.extend(
        [
            "",
            "## 二值结构与阶数稳定性",
            "",
        ]
    )
    for record in summary["records"]:
        target = "({:+d},{:+d})".format(*record["target_order"])
        similarity = record["binary_similarity"]
        lines.append(
            "- {}: masks differ {:.1%}, IoU {:.3f}, fill fraction ours/TORCWA {:.1%}/{:.1%}; our continuous-to-binary JDF drop at N{} is {:.1%}.".format(
                target,
                similarity["pixel_disagreement_fraction"],
                similarity["intersection_over_union"],
                similarity["our_fill_fraction"],
                similarity["torcwa_fill_fraction"],
                record["our_continuous_authoritative_half_order"],
                record["our_continuous_to_binary_jdf_drop_fraction"],
            )
        )
        for design_key, label in (("our_binary", "our mask"), ("torcwa_binary", "TORCWA mask")):
            stability = record["order_stability"][design_key]
            lines.append(
                "  - {} N=6→7 relative change: JDF {:.1%}, FFT {:.1%}, TORCWA {:.1%}.".format(
                    label,
                    stability["our_jones_direct_fourier"],
                    stability["our_fft_baseline"],
                    stability["torcwa"],
                )
            )
    lines.extend(
        [
            "",
            "## 解释边界",
            "",
            "- our FFT 与 TORCWA 接近时，说明坐标、偏振、功率归一化和层方向已经对齐；JDF 与两者的差距主要反映 Fourier factorization，而不是同一离散公式的实现误差。",
            "- 当前我们的结构来自原 Gate D 连续 density 优化，再经过制造映射；TORCWA 分支在优化中已经包含滤波/投影。因此这可以回答交付结构的实际差异，但还不是纯粹的 optimizer-only 公平消融。",
            "- 二值高对比结构的 N=6/7 差异必须单独报告；若未收敛，不应把任一 N 的单点值称为 ground truth。",
            "",
        ]
    )
    return "\n".join(lines)


def run_torcwa_comparison(
    config: Mapping[str, Any],
    gate_cd_config: Mapping[str, Any],
    gate_cd_summary: Mapping[str, Any],
    output_dir: Path,
) -> Dict[str, Any]:
    if bool(config["scope"].get("excluded_legacy_examples_used", True)):
        raise ValueError("comparison must explicitly exclude legacy examples")
    if bool(gate_cd_summary.get("excluded_legacy_examples_used", True)):
        raise ValueError("current Gate-D summary is not marked legacy-free")
    physics = dict(gate_cd_config["gate_d"])
    targets = [tuple(int(v) for v in target) for target in config["scope"]["target_orders"]]
    optimization = config["optimization"]
    scoring = config["scoring"]
    if bool(optimization["enforce_mirror_symmetry"]):
        if abs(float(physics["theta_deg"])) > 1e-12 or any(
            target[1] != 0 for target in targets
        ):
            raise ValueError(
                "y mirror symmetry requires normal incidence and target order n=0"
            )
    torch.manual_seed(int(config["seed"]))
    torch.backends.cuda.matmul.allow_tf32 = False
    output_dir.mkdir(parents=True, exist_ok=True)
    structures_dir = output_dir / "binary_structures"
    records: List[Dict[str, Any]] = []
    for target in targets:
        key = _target_slug(target)
        target_summary = gate_cd_summary["gate_d"]["per_target"][key]
        our_method = str(target_summary["best_authoritative_method"])
        our_density = _load_density_exact(target_summary["methods"][our_method]["saved_density"])
        our_binary = manufacturing_mask(
            our_density,
            physics["lattice_nm"],
            float(optimization["blur_radius_nm"]),
            float(optimization["threshold"]),
            enforce_y_mirror_symmetry=bool(
                optimization["enforce_mirror_symmetry"]
            ),
        )
        (
            projected,
            torcwa_binary,
            history,
            elapsed,
            selected_binary_iteration,
            best_binary_objective,
        ) = _optimize_torcwa_example6_style(
            _density(physics, str(physics["initial_case"])),
            physics,
            optimization,
            target,
        )
        our_manifest = _save_tensor(structures_dir / (key + "__our_binary.pt"), our_binary)
        torcwa_projected_manifest = _save_tensor(
            structures_dir / (key + "__torcwa_projected.pt"), projected
        )
        torcwa_manifest = _save_tensor(
            structures_dir / (key + "__torcwa_binary.pt"), torcwa_binary
        )
        score_map: Dict[str, Any] = {"our_binary": {}, "torcwa_binary": {}}
        for design_key, mask in (("our_binary", our_binary), ("torcwa_binary", torcwa_binary)):
            for order in [int(value) for value in scoring["half_orders"]]:
                ours = {
                    factorization: _our_target_power(mask, physics, order, target, factorization)
                    for factorization in scoring["our_factorizations"]
                }
                torcwa_value = float(
                    _torcwa_target_power(
                        mask,
                        physics,
                        order,
                        target,
                        dtype=_torch_dtype(str(scoring["dtype"])),
                        device=torch.device(str(scoring["device"])),
                    )
                    .detach()
                    .cpu()
                )
                score_map[design_key]["N{}".format(order)] = {
                    "our_jones_direct_fourier": ours["jones_direct_fourier"],
                    "our_fft_baseline": ours["fft_baseline"],
                    "torcwa": torcwa_value,
                    "fft_torcwa_absolute_difference": abs(ours["fft_baseline"] - torcwa_value),
                }
        order_stability: Dict[str, Any] = {}
        low_key = "N{}".format(int(scoring["half_orders"][-2]))
        high_key = "N{}".format(int(scoring["half_orders"][-1]))
        for design_key, values in score_map.items():
            order_stability[design_key] = {}
            for solver_key in (
                "our_jones_direct_fourier",
                "our_fft_baseline",
                "torcwa",
            ):
                low_value = float(values[low_key][solver_key])
                high_value = float(values[high_key][solver_key])
                order_stability[design_key][solver_key] = abs(
                    low_value - high_value
                ) / max(abs(high_value), 1e-15)
        authoritative_order = int(target_summary["authoritative_half_order"])
        authoritative_key = "N{}".format(authoritative_order)
        binary_authoritative_jdf = float(
            score_map["our_binary"][authoritative_key][
                "our_jones_direct_fourier"
            ]
        )
        continuous_authoritative = float(
            target_summary["best_authoritative_objective"]
        )
        records.append(
            {
                "target_order": list(target),
                "our_source_method": our_method,
                "our_continuous_authoritative_half_order": authoritative_order,
                "our_continuous_authoritative_objective": continuous_authoritative,
                "our_continuous_to_binary_jdf_drop_fraction": (
                    continuous_authoritative - binary_authoritative_jdf
                )
                / max(abs(continuous_authoritative), 1e-15),
                "our_binary": our_manifest,
                "torcwa_projected": torcwa_projected_manifest,
                "torcwa_binary": torcwa_manifest,
                "binary_similarity": binary_similarity(our_binary, torcwa_binary),
                "torcwa_optimization": {
                    "iterations": int(optimization["iterations"]),
                    "half_order": int(optimization["half_order"]),
                    "wall_time_s": elapsed,
                    "selected_binary_iteration": selected_binary_iteration,
                    "best_binary_objective": best_binary_objective,
                    "history": history,
                },
                "scores": score_map,
                "order_stability": order_stability,
            }
        )
    all_fft_agree = all(
        score["fft_torcwa_absolute_difference"]
        <= float(scoring["cross_solver_absolute_tolerance"])
        for record in records
        for design in record["scores"].values()
        for score in design.values()
    )
    all_order_stable = all(
        relative_change <= float(scoring["order_relative_tolerance"])
        for record in records
        for design in record["order_stability"].values()
        for relative_change in design.values()
    )
    max_fft_torcwa_difference = max(
        score["fft_torcwa_absolute_difference"]
        for record in records
        for design in record["scores"].values()
        for score in design.values()
    )
    max_jdf_torcwa_difference = max(
        abs(score["our_jones_direct_fourier"] - score["torcwa"])
        for record in records
        for design in record["scores"].values()
        for score in design.values()
    )
    summary: Dict[str, Any] = {
        "schema_version": 1,
        "status": "PASS" if all_fft_agree and all_order_stable else "CONDITIONAL",
        "implementation_alignment_status": "PASS" if all_fft_agree else "FAIL",
        "scientific_convergence_status": "PASS" if all_order_stable else "CONDITIONAL",
        "physics": physics,
        "optimization": dict(optimization),
        "scoring": dict(scoring),
        "environment": {
            "python": platform.python_version(),
            "torch": torch.__version__,
            "torcwa": importlib.metadata.version("torcwa"),
            "cuda_available": torch.cuda.is_available(),
            "cuda_version": torch.version.cuda,
            "gpu": torch.cuda.get_device_name(0) if torch.cuda.is_available() else None,
        },
        "objective_contract": "x-polarized (0,0) incidence; |t_xx|^2+|t_yx|^2 at the selected transmitted order",
        "all_our_fft_vs_torcwa_within_tolerance": all_fft_agree,
        "maximum_our_fft_vs_torcwa_absolute_difference": max_fft_torcwa_difference,
        "maximum_our_jdf_vs_torcwa_absolute_difference": max_jdf_torcwa_difference,
        "all_binary_scores_stable_from_N6_to_N7": all_order_stable,
        "legacy_assets_used": False,
        "records": records,
    }
    figures = {
        "binary_structures": _plot_structures(records, physics, output_dir / "binary_structure_comparison"),
        "cross_solver_scores": _plot_scores(records, scoring["half_orders"], output_dir / "cross_solver_binary_scores"),
        "optimization_history": _plot_histories(records, output_dir / "torcwa_optimization_history"),
    }
    summary["figures"] = figures
    (output_dir / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    (output_dir / "COMPARISON_REPORT.md").write_text(
        _build_report(summary), encoding="utf-8"
    )
    return summary
