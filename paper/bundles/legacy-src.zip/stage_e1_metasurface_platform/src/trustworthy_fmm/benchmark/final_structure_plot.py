"""Publication figures and frozen-condition summaries for FFT Gate C/D."""

from pathlib import Path
from typing import Any, Dict, Mapping

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from trustworthy_fmm.benchmark.gate_cd import _load_density_exact


METHODS = ("fixed_M", "fixed_H", "order_continuation", "FOC-TR", "MGDA-TR")
METHOD_LABELS = {
    "fixed_M": "Fixed M",
    "fixed_H": "Fixed H",
    "order_continuation": "Continuation",
    "FOC-TR": "FOC-TR",
    "MGDA-TR": "MGDA-TR",
}


def _save_formats(figure: Any, output_stem: Path) -> Dict[str, str]:
    outputs: Dict[str, str] = {}
    output_stem.parent.mkdir(parents=True, exist_ok=True)
    for suffix in ("png", "pdf", "svg"):
        destination = output_stem.with_suffix("." + suffix)
        figure.savefig(
            destination,
            dpi=320 if suffix == "png" else None,
            bbox_inches="tight",
            pad_inches=0.05,
        )
        outputs[suffix] = str(destination.resolve())
    return outputs


def plot_final_density_structures(
    config: Mapping[str, Any],
    summary: Mapping[str, Any],
    output_stem: Path,
) -> Dict[str, str]:
    """Plot exact tensors from the representative, preregistered seed."""
    gate_d_config = config["gate_d"]
    target_entries = list(summary["gate_d"]["per_target"].values())
    if not target_entries:
        return {}
    lattice_x_um = float(gate_d_config["lattice_nm"][0]) / 1000.0
    lattice_y_um = float(gate_d_config["lattice_nm"][1]) / 1000.0
    figure, axes = plt.subplots(
        len(target_entries), len(METHODS), figsize=(14.0, 2.35 * len(target_entries)), squeeze=False
    )
    image = None
    for row_index, target_entry in enumerate(target_entries):
        target_order = tuple(int(value) for value in target_entry["target_order"])
        for column_index, method in enumerate(METHODS):
            axis = axes[row_index][column_index]
            result = target_entry["methods"][method]
            density = _load_density_exact(result["saved_density"])
            image = axis.imshow(
                density.numpy(),
                origin="lower",
                extent=(0.0, lattice_x_um, 0.0, lattice_y_um),
                cmap="viridis",
                vmin=0.0,
                vmax=1.0,
                interpolation="nearest",
                aspect="equal",
            )
            if row_index == 0:
                axis.set_title(METHOD_LABELS[method])
            reference = result["authoritative_half_orders"]
            score = float(result["final_reference_objective"])
            axis.text(
                0.5,
                1.02,
                "R=({},{})  J={:.3f}".format(reference[0], reference[1], score),
                transform=axis.transAxes,
                ha="center",
                va="bottom",
                fontsize=7.2,
                fontweight="bold" if method == "FOC-TR" else "normal",
            )
            axis.set_xlim(0.0, lattice_x_um)
            axis.set_ylim(0.0, lattice_y_um)
            if row_index == len(target_entries) - 1:
                axis.set_xlabel("x [µm]")
            else:
                axis.tick_params(labelbottom=False)
            if column_index == 0:
                axis.set_ylabel("({:+d},{:+d})\ny [µm]".format(*target_order))
            else:
                axis.tick_params(labelleft=False)
    if image is not None:
        figure.colorbar(image, ax=axes.ravel().tolist(), fraction=0.012, pad=0.012, label="density")
    figure.suptitle(
        "Representative seed structures; FOC-TR is preregistered, MGDA-TR is secondary",
        y=1.01,
    )
    outputs = _save_formats(figure, output_stem)
    plt.close(figure)
    return outputs


def build_test_conditions_markdown(
    config: Mapping[str, Any], summary: Mapping[str, Any]
) -> str:
    gate_c = config["gate_c"]
    gate_d = config["gate_d"]
    selected = summary["gate_c"]["working_fidelities"]
    protocol = summary["gate_d"].get("protocol", {})
    target_text = ", ".join(
        "({:+d},{:+d})".format(*target) for target in gate_d["target_orders"]
    )
    lines = [
        "# Gate C/D 测试条件",
        "",
        "> 由 schema-v2 FFT baseline 配置与本次 summary 自动生成。Smoke 结果不构成科学证据。",
        "",
        "## 物理条件",
        "",
        "| 条件 | 数值 |",
        "|---|---|",
        "| 传播方向 | 半无限基底 n=1.46 → 800 nm 图案层 → 半无限空气 n=1.0 |",
        "| 图案层 | 空气背景 n=1.0；介质特征 n=3.2 |",
        "| 波长 | {:.1f} nm |".format(float(gate_d["wavelength_nm"])),
        "| 周期 `(Lx,Ly)` | `{}` nm |".format(gate_d["lattice_nm"]),
        "| 网格 `(Ny,Nx)` | `{}`；20×20 nm/像素 |".format(gate_d["grid_yx"]),
        "| Fourier factorization | `{}` |".format(gate_d["factorization"]),
        "| 数值精度 | density/gradient float64；电磁量 complex128 |",
        "",
        "## Gate C：参考资格",
        "",
        "| 条件 | 数值 |",
        "|---|---|",
        "| 各向异性阶梯 `(Mx,My)` | `{}` |".format(gate_c["anisotropic_half_orders"]),
        "| 方形等成本对照 | `{}` |".format(gate_c["square_control_half_orders"]),
        "| 紧急 validation | `{}` |".format(gate_c["emergency_validation_half_orders"]),
        "| 已选 L/M/H/R | `{}` / `{}` / `{}` / `{}` |".format(
            selected["low_half_orders"],
            selected["middle_half_orders"],
            selected["high_half_orders"],
            selected["reference_half_orders"],
        ),
        "| H→R 阈值 | 值 0.5%；cosine 0.99；范数比 [0.90,1.10] |",
        "| oracle RMS 步长 | `{}` |".format(gate_c["oracle_step_rms"]),
        "",
        "## Gate D：预注册优化",
        "",
        "| 条件 | 数值 |",
        "|---|---|",
        "| 目标衍射阶 | `{}` |".format(target_text),
        "| 方法 | fixed_M, fixed_H, order_continuation, FOC-TR, MGDA-TR |",
        "| 主方法 / 次方法 | FOC-TR / MGDA-TR |",
        "| 随机种子 | `{}` |".format(summary["gate_d"].get("seeds", gate_d["seeds"])),
        "| fixed 最大步数 | `{}` |".format(protocol.get("fixed_iterations", gate_d["fixed_iterations"])),
        "| TR 外层候选 / 内层低阶步 | `{}` / `{}` |".format(
            protocol.get("trust_outer_candidates", gate_d["trust_outer_candidates"]),
            protocol.get("inner_low_steps", gate_d["inner_low_steps"]),
        ),
        "| 参考审计 | 每接受 `{}` 步；下降超过 `{}` 回滚 |".format(
            protocol.get("reference_audit_interval_accepted", gate_d["reference_audit_interval_accepted"]),
            protocol.get("allowed_reference_drop", gate_d["allowed_reference_drop"]),
        ),
        "| FOC-TR 判据 | 参考目标非劣 2%，达到 fixed-H 98% 改善所需成本降低 20% |",
        "",
        "## 加工鲁棒性隔离",
        "",
        "Gate C/D 不包含 opening、closing 或 CD/侧壁扰动。Gate E 的 50 nm opening/closing 保留为 held-out 硬审计，只有 Gate C 参考合格且 Gate D 主判据通过后才可重新运行。",
        "",
    ]
    return "\n".join(lines)
