"""Vector 2D same-order TORCWA and existing Lumerical regression."""

from pathlib import Path
from typing import Any, Dict, List, Mapping, Tuple

import numpy as np
import torch

from trustworthy_fmm.audit.gradients import gradient_cosine
from trustworthy_fmm.solvers.vector_2d import solve_vector_2d


def run_vector_2d_regression(
    config: Mapping[str, Any], workspace_root: Path
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    with np.load(str(workspace_root / config["asset"]), allow_pickle=False) as data:
        mask = data["masks"][int(config["sample_id"])].astype(np.float64)
    base_density = torch.as_tensor(mask, dtype=torch.float64)
    target_order = tuple(config["target_order"])
    lumerical = float(config["lumerical_reference"]["target_power"])
    torcwa_values = config["torcwa_same_order_reference"]["target_powers"]
    rows: List[Dict[str, Any]] = []
    previous = None
    previous_gradient = None
    for half_orders, torcwa_reference in zip(config["half_orders"], torcwa_values):
        density = base_density.detach().clone().requires_grad_(True)
        epsilon = (1.0 + (config["material_index"] ** 2 - 1.0) * density).to(torch.complex128)
        result = solve_vector_2d(
            epsilon,
            config["height_nm"],
            config["wavelength_nm"],
            tuple(config["lattice_nm"]),
            config["incident_index"],
            config["output_index"],
            tuple(half_orders),
        )
        target_tensor = result.transmitted_power(target_order)
        gradient = torch.autograd.grad(target_tensor, density)[0].detach()
        target = float(target_tensor.detach())
        adjacent = float("nan") if previous is None else abs(target - previous) / max(abs(target), 1e-12)
        adjacent_cosine = float("nan") if previous_gradient is None else gradient_cosine(previous_gradient, gradient)
        rows.append(
            {
                "sample_id": int(config["sample_id"]),
                "half_orders": str(tuple(half_orders)),
                "target_power": target,
                "torcwa_target_power": float(torcwa_reference),
                "torcwa_absolute_error": abs(target - float(torcwa_reference)),
                "lumerical_target_power": lumerical,
                "lumerical_absolute_error": abs(target - lumerical),
                "adjacent_relative_change": adjacent,
                "adjacent_gradient_cosine": adjacent_cosine,
                "gradient_norm": float(torch.linalg.vector_norm(gradient)),
                "total_T": float(result.total_T),
                "total_R": float(result.total_R),
                "energy_residual": float(result.energy_residual),
                "min_eigen_gap": float(result.diagnostics["min_eigen_gap"]),
                "modal_condition": float(result.diagnostics["modal_condition"]),
            }
        )
        previous = target
        previous_gradient = gradient
    thresholds = config["thresholds"]
    summary = {
        "sample_id": int(config["sample_id"]),
        "max_torcwa_same_order_error": max(row["torcwa_absolute_error"] for row in rows),
        "min_lumerical_target_error": min(row["lumerical_absolute_error"] for row in rows),
        "max_energy_residual": max(row["energy_residual"] for row in rows),
        "final_adjacent_relative_change": rows[-1]["adjacent_relative_change"],
        "final_adjacent_gradient_cosine": rows[-1]["adjacent_gradient_cosine"],
        "torcwa_same_order_pass": max(row["torcwa_absolute_error"] for row in rows) <= thresholds["torcwa_same_order_absolute_error"],
        "lumerical_target_pass": min(row["lumerical_absolute_error"] for row in rows) <= thresholds["lumerical_target_absolute_error"],
        "energy_pass": max(row["energy_residual"] for row in rows) <= thresholds["lossless_energy_residual"],
        "forward_convergence_pass": rows[-1]["adjacent_relative_change"] <= thresholds["adjacent_relative_convergence"],
        "gradient_convergence_pass": rows[-1]["adjacent_gradient_cosine"] >= 0.99,
    }
    return rows, summary
