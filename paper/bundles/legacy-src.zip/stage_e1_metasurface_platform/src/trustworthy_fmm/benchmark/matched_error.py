"""Matched-error selection for fair solver timing and memory comparisons."""

from typing import Any, Dict, Mapping, Sequence


def select_lowest_cost_at_error(
    rows: Sequence[Mapping[str, Any]],
    *,
    error_key: str,
    error_threshold: float,
    cost_key: str = "runtime_seconds",
) -> Mapping[str, Any]:
    eligible = [row for row in rows if float(row[error_key]) <= error_threshold]
    if not eligible:
        raise ValueError("no solver setting reaches error threshold {}".format(error_threshold))
    return min(eligible, key=lambda row: float(row[cost_key]))


def matched_error_table(
    rows_by_solver: Mapping[str, Sequence[Mapping[str, Any]]],
    *,
    error_key: str,
    error_threshold: float,
    cost_key: str = "runtime_seconds",
) -> Dict[str, Mapping[str, Any]]:
    selected = {}
    for solver, rows in rows_by_solver.items():
        selected[solver] = select_lowest_cost_at_error(
            rows,
            error_key=error_key,
            error_threshold=error_threshold,
            cost_key=cost_key,
        )
    return selected

