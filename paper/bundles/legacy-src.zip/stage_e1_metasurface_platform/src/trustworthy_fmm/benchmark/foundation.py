"""Fast foundation benchmarks for G0-G3 implementation validation."""

import math
from typing import Any, Dict, List, Mapping, Tuple

import torch

from trustworthy_fmm.audit.gradients import directional_derivative_audit
from trustworthy_fmm.solvers.fresnel import fresnel_interface, homogeneous_stack
from trustworthy_fmm.solvers.rcwa_1d import solve_1d_te


def run_foundation(config: Mapping[str, Any]) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    analytic = config["analytic"]
    max_fresnel_error = 0.0
    max_fresnel_energy = 0.0
    for angle in analytic["angles_deg"]:
        for polarization in analytic["polarizations"]:
            result = fresnel_interface(
                analytic["incident_index"],
                analytic["transmitted_index"],
                angle,
                polarization,
            )
            if angle == 0:
                reference_r = (
                    analytic["incident_index"] - analytic["transmitted_index"]
                ) / (analytic["incident_index"] + analytic["transmitted_index"])
                error = abs(float(result.r.real) - reference_r) / max(abs(reference_r), 1e-12)
                max_fresnel_error = max(max_fresnel_error, error)
            else:
                error = float("nan")
            max_fresnel_energy = max(max_fresnel_energy, float(result.energy_residual))
            rows.append(
                {
                    "family": "fresnel",
                    "angle_deg": angle,
                    "polarization": polarization,
                    "R": float(result.R),
                    "T": float(result.T),
                    "energy_residual": float(result.energy_residual),
                    "normal_incidence_relative_error": error,
                }
            )

    rcwa = config["rcwa_1d"]
    grid = torch.arange(rcwa["samples"], dtype=torch.float64)
    profile = torch.where(
        grid < rcwa["fill_fraction"] * rcwa["samples"],
        torch.tensor(rcwa["ridge_index"] ** 2, dtype=torch.float64),
        torch.tensor(rcwa["groove_index"] ** 2, dtype=torch.float64),
    ).to(torch.complex128)
    max_rcwa_energy = 0.0
    for half_order in rcwa["fourier_orders"]:
        result = solve_1d_te(
            profile,
            rcwa["thickness_nm"],
            rcwa["wavelength_nm"],
            rcwa["period_nm"],
            rcwa["superstrate_index"],
            rcwa["substrate_index"],
            half_order,
        )
        max_rcwa_energy = max(max_rcwa_energy, float(result.energy_residual))
        rows.append(
            {
                "family": "rcwa_1d",
                "half_order": half_order,
                "total_R": float(result.total_R),
                "total_T": float(result.total_T),
                "energy_residual": float(result.energy_residual),
                "min_eigen_gap": float(result.diagnostics["min_eigen_gap"]),
                "modal_condition": float(result.diagnostics["modal_condition"]),
            }
        )

    point = torch.tensor([220.0], dtype=torch.float64)

    def film_objective(value: torch.Tensor) -> torch.Tensor:
        return homogeneous_stack(
            1.0,
            [2.02],
            [value[0]],
            1.46,
            660.0,
            15.0,
            "s",
        ).T

    audit = directional_derivative_audit(
        film_objective,
        point,
        torch.ones_like(point),
        [1e-1, 1e-2, 1e-3, 1e-4],
    )
    rows.append(
        {
            "family": "gradient",
            "ad_directional": audit.ad_directional,
            "best_fd": audit.best_fd,
            "best_step": audit.best_step,
            "relative_error": audit.relative_error,
        }
    )
    thresholds = config["thresholds"]
    summary = {
        "max_fresnel_relative_error": max_fresnel_error,
        "max_fresnel_energy_residual": max_fresnel_energy,
        "max_rcwa_energy_residual": max_rcwa_energy,
        "simple_directional_error": audit.relative_error,
        "analytic_forward_pass": max_fresnel_error <= thresholds["fresnel_relative_error"]
        and max_fresnel_energy <= thresholds["energy_residual"],
        "rcwa_energy_pass": max_rcwa_energy <= thresholds["energy_residual"],
        "simple_gradient_pass": audit.relative_error <= thresholds["simple_directional_error"],
        "external_patterned_validation_complete": False,
    }
    return rows, summary

