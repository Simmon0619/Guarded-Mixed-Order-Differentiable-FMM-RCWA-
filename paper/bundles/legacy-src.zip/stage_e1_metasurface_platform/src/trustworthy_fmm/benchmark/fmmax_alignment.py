"""Independent FMMAX power and complex-amplitude alignment."""

import csv
from pathlib import Path
from typing import Any, Dict, List, Mapping, Tuple

import numpy as np
import torch

from trustworthy_fmm.physics.channels import circular_order_set
from trustworthy_fmm.solvers.vector_2d import solve_vector_2d


def run_fmmax_alignment(
    config: Mapping[str, Any], workspace_root: Path
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    with np.load(str(workspace_root / config["asset"]), allow_pickle=False) as data:
        density = torch.as_tensor(
            data["masks"][int(config["sample_id"])].astype(np.float64), dtype=torch.float64
        )
    with (workspace_root / config["fmmax_metrics"]).open("r", encoding="utf-8") as stream:
        reference_rows = list(csv.DictReader(stream))
    if len(reference_rows) != 1 or reference_rows[0]["formulation"] != "fft":
        raise ValueError("the frozen FMMAX amplitude artifact must contain one FFT row")
    reference = reference_rows[0]
    reference_power = float(reference["target_power"])
    reference_amplitude = complex(
        float(reference["target_ex_real"]), float(reference["target_ex_imag"])
    )
    epsilon = (1.0 + (config["material_index"] ** 2 - 1.0) * density).to(torch.complex128)
    orders = circular_order_set(tuple(config["lattice_nm"]), int(config["approximate_terms"]))
    result = solve_vector_2d(
        epsilon,
        config["height_nm"],
        config["wavelength_nm"],
        tuple(config["lattice_nm"]),
        config["incident_index"],
        config["output_index"],
        (0, 0),
        basis_orders=orders,
    )
    target_order = tuple(config["target_order"])
    power = float(result.transmitted_power(target_order))
    amplitude_tensor = result.transmitted_amplitude(target_order)
    amplitude = complex(float(amplitude_tensor.real), float(amplitude_tensor.imag))
    phase = 1.0 + 0.0j
    if abs(amplitude) > 0 and abs(reference_amplitude) > 0:
        phase = reference_amplitude / amplitude
        phase /= abs(phase)
    aligned = amplitude * phase
    relative_amplitude_error = abs(aligned - reference_amplitude) / max(
        abs(reference_amplitude), 1e-15
    )
    row = {
        "actual_terms": len(orders),
        "pytorch_power": power,
        "fmmax_power": reference_power,
        "power_absolute_error": abs(power - reference_power),
        "pytorch_ex_real": amplitude.real,
        "pytorch_ex_imag": amplitude.imag,
        "fmmax_ex_real": reference_amplitude.real,
        "fmmax_ex_imag": reference_amplitude.imag,
        "global_phase_aligned_amplitude_relative_error": relative_amplitude_error,
    }
    thresholds = config["thresholds"]
    summary = {
        **row,
        "power_pass": row["power_absolute_error"] <= thresholds["target_power_absolute_error"],
        "amplitude_pass": relative_amplitude_error
        <= thresholds["global_phase_aligned_amplitude_relative_error"],
        "reference_provenance": "FMMAX 1.7.1, JAX 0.11.0, x64, separate Python 3.12 runtime",
    }
    summary["gate_pass"] = bool(summary["power_pass"] and summary["amplitude_pass"])
    return [row], summary

