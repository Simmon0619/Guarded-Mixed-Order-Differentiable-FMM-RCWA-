"""Gate A/B factorization and empirical-fidelity benchmark suite."""

from typing import Any, Dict, List, Mapping, Tuple

import torch

from trustworthy_fmm.fidelity.indicators import (
    ANOMALY_NEARBY,
    SAFE,
    assess_fidelity_sequence,
    evaluate_indicator_calibration,
    fourier_tail_fraction,
    rayleigh_anomaly_distance,
    relative_change,
)
from trustworthy_fmm.solvers.fresnel import homogeneous_stack
from trustworthy_fmm.solvers.rcwa_1d import solve_1d_tm
from trustworthy_fmm.solvers.vector_2d import solve_multilayer_vector_2d, solve_vector_2d


def _float(value: torch.Tensor) -> float:
    return float(value.detach().cpu())


def _validate_current_project_sections(config: Mapping[str, Any]) -> None:
    """Keep project-facing Gate A/B cases aligned with the frozen device setup."""
    project = config["project_conditions"]
    lattice = tuple(float(value) for value in project["lattice_nm"])
    shape = tuple(int(value) for value in project["grid_yx"])
    if len(lattice) != 2 or len(shape) != 2:
        raise ValueError("project lattice_nm and grid_yx must contain two values")
    lx, ly = lattice
    ny, nx = shape
    pixel_size = float(project["pixel_size_nm"])
    pixel_yx = (ly / ny, lx / nx)
    if any(abs(value - pixel_size) > 1e-12 for value in pixel_yx):
        raise ValueError(
            "project grid_yx={} does not provide {} nm square pixels".format(
                list(shape), pixel_size
            )
        )

    def require_equal(section: str, key: str, project_key: str = None) -> None:
        project_key = key if project_key is None else project_key
        if config[section][key] != project[project_key]:
            raise ValueError(
                "{}.{} must match project_conditions.{}".format(
                    section, key, project_key
                )
            )

    for key in ("wavelength_nm", "lattice_nm", "incident_index", "output_index"):
        require_equal("b0_uniform_stack", key)
    if int(config["b0_uniform_stack"]["samples_x"]) != nx:
        raise ValueError("b0_uniform_stack.samples_x must match project Nx")

    b1_mapping = {
        "wavelength_nm": "wavelength_nm",
        "period_nm": "lattice_nm",
        "thickness_nm": "thickness_nm",
        "incident_index": "incident_index",
        "output_index": "output_index",
        "ridge_index": "feature_index",
        "groove_index": "background_index",
        "pixel_size_nm": "pixel_size_nm",
    }
    for key, project_key in b1_mapping.items():
        expected = project[project_key]
        if key == "period_nm":
            expected = project["lattice_nm"][0]
        if config["b1_high_contrast_1d"][key] != expected:
            raise ValueError(
                "b1_high_contrast_1d.{} must match current project conditions".format(
                    key
                )
            )
    if int(config["b1_high_contrast_1d"]["samples"]) != nx:
        raise ValueError("b1_high_contrast_1d.samples must match project Nx")

    for key in (
        "wavelength_nm",
        "lattice_nm",
        "thickness_nm",
        "incident_index",
        "output_index",
        "background_index",
        "feature_index",
        "pixel_size_nm",
        "grid_yx",
    ):
        require_equal("b2_b3_vector_2d", key)
    if list(config["b2_b3_vector_2d"]["target_order"]) not in [
        list(value) for value in project["target_orders"]
    ]:
        raise ValueError("B2/B3 target_order must be a current project target")


def _geometry(config: Mapping[str, Any], kind: str) -> torch.Tensor:
    ny, nx = (int(value) for value in config["grid_yx"])
    supersampling = int(config.get("geometry_supersampling", 1))
    if supersampling < 1:
        raise ValueError("geometry_supersampling must be positive")
    offsets = (torch.arange(supersampling, dtype=torch.float64) + 0.5) / supersampling
    y = (
        torch.arange(ny, dtype=torch.float64)[:, None, None, None]
        + offsets[None, None, :, None]
    )
    x = (
        torch.arange(nx, dtype=torch.float64)[None, :, None, None]
        + offsets[None, None, None, :]
    )
    if kind == "rectangle":
        mask = (
            (torch.abs(x - nx / 2) < float(config["rectangle_half_width_px"]))
            & (torch.abs(y - ny / 2) < float(config["rectangle_half_height_px"]))
        )
    elif kind == "circle":
        mask = (
            ((x - nx / 2) / float(config["circle_radius_x_px"])) ** 2
            + ((y - ny / 2) / float(config["circle_radius_y_px"])) ** 2
            < 1.0
        )
    else:
        raise ValueError("unknown Gate A/B geometry {!r}".format(kind))
    return mask.to(torch.float64).mean(dim=(-2, -1))


def _solve_2d_sequence(
    config: Mapping[str, Any],
    density: torch.Tensor,
    factorization: str,
    rows: List[Dict[str, Any]],
    family: str,
) -> Tuple[Dict[str, Any], float, float]:
    values: List[float] = []
    gradients: List[torch.Tensor] = []
    energy_residuals: List[float] = []
    for half_order in config["half_orders"]:
        point = density.detach().clone().requires_grad_(True)
        epsilon = (
            float(config["background_index"]) ** 2
            + (float(config["feature_index"]) ** 2 - float(config["background_index"]) ** 2)
            * point
        ).to(torch.complex128)
        result = solve_vector_2d(
            epsilon,
            float(config["thickness_nm"]),
            float(config["wavelength_nm"]),
            tuple(float(value) for value in config["lattice_nm"]),
            complex(config["incident_index"]),
            complex(config["output_index"]),
            (int(half_order), int(half_order)),
            float(config["theta_deg"]),
            float(config["phi_deg"]),
            factorization=factorization,
            normal_smoothing_sigma_px=float(config["normal_smoothing_sigma_px"]),
            detach_tangent_field=bool(config.get("detach_tangent_field", False)),
        )
        objective = result.transmitted_power(tuple(config["target_order"]))
        gradient = torch.autograd.grad(objective, point)[0].detach()
        value = _float(objective)
        energy = _float(result.energy_residual)
        values.append(value)
        gradients.append(gradient)
        energy_residuals.append(energy)
        rows.append(
            {
                "family": family,
                "factorization": factorization,
                "half_order": int(half_order),
                "objective": value,
                "gradient_norm": _float(torch.linalg.vector_norm(gradient)),
                "energy_residual": energy,
                "fourier_tail_fraction": fourier_tail_fraction(
                    epsilon.detach(), (int(half_order), int(half_order))
                ),
                "min_eigen_gap": _float(result.diagnostics["min_eigen_gap"]),
                "modal_condition": _float(result.diagnostics["modal_condition"]),
            }
        )
    validation_order = int(
        config.get("reference_validation_half_order", config["reference_half_order"])
    )
    validation_point = density.detach().clone().requires_grad_(True)
    epsilon = (
        float(config["background_index"]) ** 2
        + (float(config["feature_index"]) ** 2 - float(config["background_index"]) ** 2)
        * validation_point
    ).to(torch.complex128)
    validation = solve_vector_2d(
        epsilon,
        float(config["thickness_nm"]),
        float(config["wavelength_nm"]),
        tuple(float(value) for value in config["lattice_nm"]),
        complex(config["incident_index"]),
        complex(config["output_index"]),
        (validation_order, validation_order),
        float(config["theta_deg"]),
        float(config["phi_deg"]),
        factorization=factorization,
        normal_smoothing_sigma_px=float(config["normal_smoothing_sigma_px"]),
        detach_tangent_field=bool(config.get("detach_tangent_field", False)),
    )
    validation_objective = validation.transmitted_power(tuple(config["target_order"]))
    validation_value = _float(validation_objective)
    validation_gradient = torch.autograd.grad(
        validation_objective, validation_point
    )[0].detach()
    final_order = int(config["half_orders"][-1])
    epsilon_low_precision = (
        float(config["background_index"]) ** 2
        + (float(config["feature_index"]) ** 2 - float(config["background_index"]) ** 2)
        * density.to(torch.float32)
    ).to(torch.complex64)
    dtype_reference = solve_vector_2d(
        epsilon_low_precision,
        float(config["thickness_nm"]),
        float(config["wavelength_nm"]),
        tuple(float(value) for value in config["lattice_nm"]),
        complex(config["incident_index"]),
        complex(config["output_index"]),
        (final_order, final_order),
        float(config["theta_deg"]),
        float(config["phi_deg"]),
        factorization=factorization,
        normal_smoothing_sigma_px=float(config["normal_smoothing_sigma_px"]),
        detach_tangent_field=bool(config.get("detach_tangent_field", False)),
    )
    dtype_reference_value = _float(
        dtype_reference.transmitted_power(tuple(config["target_order"]))
    )
    assessment = assess_fidelity_sequence(
        config["half_orders"],
        values,
        gradients,
        forward_tolerance=float(config["forward_tolerance"]),
        gradient_cosine_tolerance=float(config["gradient_cosine_tolerance"]),
        gradient_norm_ratio_tolerance=float(config["gradient_norm_ratio_tolerance"]),
        dtype_reference_value=dtype_reference_value,
        reference_gradient=validation_gradient,
        dtype_tolerance=float(config.get("dtype_tolerance", 5e-3)),
        reference_validation_value=validation_value,
        reference_validation_tolerance=float(
            config.get("reference_validation_tolerance", config["forward_tolerance"])
        ),
        stable_window_pairs=int(config.get("stable_window_pairs", 2)),
        strict=bool(config.get("strict_reference", True)),
        same_class_external_pass=config.get("same_class_external_pass"),
        heterogeneous_external_pass=config.get("heterogeneous_external_pass"),
    )
    predicted_error = assessment.final_forward_relative_change
    actual_error = relative_change(values[-1], validation_value)
    result = assessment.to_dict()
    result.update(
        {
            "candidate_reference_half_order": final_order,
            "candidate_reference_value": values[-1],
            "reference_validation_half_order": validation_order,
            "reference_validation_value": validation_value,
            "predicted_adjacent_error": predicted_error,
            "actual_next_level_error": actual_error,
            "max_energy_residual": max(
                energy_residuals + [_float(validation.energy_residual)]
            ),
        }
    )
    return result, predicted_error, actual_error


def run_gate_ab(config: Mapping[str, Any]) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    _validate_current_project_sections(config)
    rows: List[Dict[str, Any]] = []
    thresholds = config["thresholds"]

    # B0: uniform multilayer analytic invariant, evaluated through both 2D paths.
    b0 = config["b0_uniform_stack"]
    uniform_layers = [
        torch.full(
            (1, int(b0["samples_x"])),
            float(index) ** 2,
            dtype=torch.complex128,
        )
        for index in b0["layer_indices"]
    ]
    analytic = homogeneous_stack(
        float(b0["incident_index"]),
        b0["layer_indices"],
        b0["thicknesses_nm"],
        float(b0["output_index"]),
        float(b0["wavelength_nm"]),
        0.0,
        "s",
    )
    b0_errors: Dict[str, float] = {}
    b0_energy: Dict[str, float] = {}
    for factorization in ("fft_baseline", "normal"):
        result = solve_multilayer_vector_2d(
            uniform_layers,
            b0["thicknesses_nm"],
            float(b0["wavelength_nm"]),
            tuple(float(value) for value in b0["lattice_nm"]),
            complex(b0["incident_index"]),
            complex(b0["output_index"]),
            tuple(int(value) for value in b0["half_orders"]),
            factorization=factorization,
        )
        error = abs(_float(result.total_T) - _float(analytic.T))
        b0_errors[factorization] = error
        b0_energy[factorization] = _float(result.energy_residual)
        rows.append(
            {
                "family": "B0_uniform_stack",
                "factorization": factorization,
                "objective": _float(result.total_T),
                "analytic_absolute_error": error,
                "energy_residual": b0_energy[factorization],
            }
        )

    # B1: 1D high-contrast TM baseline versus Li inverse rule.
    b1 = config["b1_high_contrast_1d"]
    grid = torch.arange(int(b1["samples"]), dtype=torch.float64)
    density_1d = (grid < float(b1["fill_fraction"]) * int(b1["samples"])).to(torch.float64)
    epsilon_1d = (
        float(b1["groove_index"]) ** 2
        + (float(b1["ridge_index"]) ** 2 - float(b1["groove_index"]) ** 2) * density_1d
    ).to(torch.complex128)
    b1_results: Dict[str, Dict[str, Any]] = {}
    calibration_predicted: List[float] = []
    calibration_actual: List[float] = []
    calibration_safe_flags: List[bool] = []
    for factorization in ("fft_baseline", "li_inverse"):
        values: List[float] = []
        gradients: List[torch.Tensor] = []
        energies: List[float] = []
        for half_order in b1["half_orders"]:
            point = density_1d.detach().clone().requires_grad_(True)
            epsilon = (
                float(b1["groove_index"]) ** 2
                + (float(b1["ridge_index"]) ** 2 - float(b1["groove_index"]) ** 2) * point
            ).to(torch.complex128)
            solve = solve_1d_tm(
                epsilon,
                float(b1["thickness_nm"]),
                float(b1["wavelength_nm"]),
                float(b1["period_nm"]),
                complex(b1["incident_index"]),
                complex(b1["output_index"]),
                int(half_order),
                float(b1["theta_deg"]),
                factorization=factorization,
            )
            objective = solve.transmitted_power(tuple(b1["target_order"]))
            gradient = torch.autograd.grad(objective, point)[0].detach()
            values.append(_float(objective))
            gradients.append(gradient)
            energies.append(_float(solve.energy_residual))
            rows.append(
                {
                    "family": "B1_high_contrast_1d",
                    "factorization": factorization,
                    "half_order": int(half_order),
                    "objective": values[-1],
                    "gradient_norm": _float(torch.linalg.vector_norm(gradient)),
                    "energy_residual": energies[-1],
                    "fourier_tail_fraction": fourier_tail_fraction(epsilon.detach(), int(half_order)),
                }
            )
        validation_order = int(
            b1.get("reference_validation_half_order", b1["reference_half_order"])
        )
        validation_point = density_1d.detach().clone().requires_grad_(True)
        validation_epsilon = (
            float(b1["groove_index"]) ** 2
            + (float(b1["ridge_index"]) ** 2 - float(b1["groove_index"]) ** 2)
            * validation_point
        ).to(torch.complex128)
        validation = solve_1d_tm(
            validation_epsilon,
            float(b1["thickness_nm"]),
            float(b1["wavelength_nm"]),
            float(b1["period_nm"]),
            complex(b1["incident_index"]),
            complex(b1["output_index"]),
            validation_order,
            float(b1["theta_deg"]),
            factorization=factorization,
        )
        validation_objective = validation.transmitted_power(tuple(b1["target_order"]))
        validation_value = _float(validation_objective)
        validation_gradient = torch.autograd.grad(
            validation_objective, validation_point
        )[0].detach()
        final_order = int(b1["half_orders"][-1])
        dtype_reference = solve_1d_tm(
            epsilon_1d.to(torch.complex64),
            float(b1["thickness_nm"]),
            float(b1["wavelength_nm"]),
            float(b1["period_nm"]),
            complex(b1["incident_index"]),
            complex(b1["output_index"]),
            final_order,
            float(b1["theta_deg"]),
            factorization=factorization,
        )
        dtype_reference_value = _float(
            dtype_reference.transmitted_power(tuple(b1["target_order"]))
        )
        assessment = assess_fidelity_sequence(
            b1["half_orders"],
            values,
            gradients,
            forward_tolerance=float(b1["forward_tolerance"]),
            gradient_cosine_tolerance=float(b1["gradient_cosine_tolerance"]),
            gradient_norm_ratio_tolerance=float(b1["gradient_norm_ratio_tolerance"]),
            dtype_reference_value=dtype_reference_value,
            reference_gradient=validation_gradient,
            dtype_tolerance=float(b1.get("dtype_tolerance", 5e-3)),
            reference_validation_value=validation_value,
            reference_validation_tolerance=float(
                b1.get("reference_validation_tolerance", b1["forward_tolerance"])
            ),
            stable_window_pairs=int(b1.get("stable_window_pairs", 2)),
            strict=bool(b1.get("strict_reference", True)),
            same_class_external_pass=b1.get("same_class_external_pass"),
            heterogeneous_external_pass=b1.get("heterogeneous_external_pass"),
        )
        predicted = assessment.final_forward_relative_change
        actual = relative_change(values[-1], validation_value)
        calibration_predicted.append(predicted)
        calibration_actual.append(actual)
        calibration_safe_flags.append(assessment.decision == SAFE)
        b1_results[factorization] = assessment.to_dict()
        b1_results[factorization].update(
            {
                "candidate_reference_half_order": final_order,
                "candidate_reference_value": values[-1],
                "reference_validation_half_order": validation_order,
                "reference_validation_value": validation_value,
                "predicted_adjacent_error": predicted,
                "actual_next_level_error": actual,
                "max_energy_residual": max(
                    energies + [_float(validation.energy_residual)]
                ),
            }
        )

    # B2/B3: compare the baseline, real normal field, Jones normalization, and
    # the Jones-direct field optimized in the active Fourier expansion.
    b23 = config["b2_b3_vector_2d"]
    vector_results: Dict[str, Dict[str, Any]] = {}
    vector_comparisons: Dict[str, Dict[str, Any]] = {}
    advanced_not_worse_count = 0
    advanced_internally_stable_count = 0
    for family, kind in (("B2_rectangle_2d", "rectangle"), ("B3_circle_2d", "circle")):
        density = _geometry(b23, kind)
        per_factorization: Dict[str, Any] = {}
        for factorization in (
            "fft_baseline",
            "normal",
            "jones",
            "jones_direct_fourier",
        ):
            assessment, predicted, actual = _solve_2d_sequence(
                b23, density, factorization, rows, family
            )
            per_factorization[factorization] = assessment
            calibration_predicted.append(predicted)
            calibration_actual.append(actual)
            calibration_safe_flags.append(assessment["decision"] == SAFE)
        baseline_error = per_factorization["fft_baseline"]["actual_next_level_error"]
        advanced_errors = {
            name: per_factorization[name]["actual_next_level_error"]
            for name in ("normal", "jones", "jones_direct_fourier")
        }
        best_advanced = min(advanced_errors, key=advanced_errors.get)
        not_worse = advanced_errors[best_advanced] <= baseline_error
        numeric_reasons = [
            reason
            for reason in per_factorization[best_advanced]["qualification_reasons"]
            if not reason.startswith("missing required ")
        ]
        internally_stable = not numeric_reasons
        if not_worse:
            advanced_not_worse_count += 1
        if internally_stable:
            advanced_internally_stable_count += 1
        vector_comparisons[family] = {
            "baseline_next_level_error": baseline_error,
            "best_advanced_factorization": best_advanced,
            "best_advanced_next_level_error": advanced_errors[best_advanced],
            "advanced_not_worse": not_worse,
            "advanced_internally_stable": internally_stable,
        }
        vector_results[family] = per_factorization

    # B4: exact channel cutoff must route to anomaly_nearby and block extrapolation.
    b4 = config["b4_anomaly_stress"]
    anomaly_distance = rayleigh_anomaly_distance(
        wavelength_nm=float(b4["wavelength_nm"]),
        lattice_nm=tuple(float(value) for value in b4["lattice_nm"]),
        incident_index=complex(b4["incident_index"]),
        output_index=complex(b4["output_index"]),
        orders=[tuple(int(value) for value in b4["order"])],
    )
    anomaly_assessment = assess_fidelity_sequence(
        b4["levels"],
        b4["probe_values"],
        anomaly_distance=anomaly_distance,
        anomaly_tolerance=float(b4["anomaly_tolerance"]),
    )

    raw_indicator_calibration = evaluate_indicator_calibration(
        calibration_predicted,
        calibration_actual,
        safe_threshold=float(thresholds["indicator_safe_threshold"]),
        actual_error_tolerance=float(thresholds["actual_error_tolerance"]),
    )
    decision_calibration = evaluate_indicator_calibration(
        calibration_predicted,
        calibration_actual,
        safe_threshold=float(thresholds["indicator_safe_threshold"]),
        actual_error_tolerance=float(thresholds["actual_error_tolerance"]),
        predicted_safe_flags=calibration_safe_flags,
    )
    max_energy = max(
        list(b0_energy.values())
        + [entry["max_energy_residual"] for entry in b1_results.values()]
        + [
            entry["max_energy_residual"]
            for family in vector_results.values()
            for entry in family.values()
        ]
    )
    invariant_pass = (
        max(b0_errors.values()) <= float(thresholds["analytic_absolute_error"])
        and max_energy <= float(thresholds["lossless_energy_residual"])
    )
    convergence_pass = advanced_not_worse_count >= int(
        thresholds["advanced_not_worse_required"]
    )
    reference_stability_pass = advanced_internally_stable_count >= int(
        thresholds["advanced_internally_stable_required"]
    )
    gate_a_status = (
        "PASS"
        if invariant_pass and convergence_pass and reference_stability_pass
        else "CONDITIONAL"
    )
    gate_b_infrastructure_pass = (
        anomaly_assessment.convergence.classification == ANOMALY_NEARBY
        and not anomaly_assessment.convergence.can_extrapolate
        and anomaly_assessment.decision == "reject"
        and raw_indicator_calibration.samples == len(calibration_predicted)
        and decision_calibration.samples == len(calibration_safe_flags)
    )
    reference_qualified_count = sum(calibration_safe_flags)
    conditional_rate = decision_calibration.conditional_false_safe_rate
    gate_b_scientific_pass = (
        reference_qualified_count >= int(thresholds["minimum_predicted_safe_cases"])
        and conditional_rate is not None
        and conditional_rate <= float(thresholds["maximum_conditional_false_safe_rate"])
        and decision_calibration.conditional_false_safe_upper_95
        <= float(thresholds["maximum_conditional_false_safe_upper_95"])
    )
    gate_b_status = (
        "PASS"
        if gate_b_infrastructure_pass and gate_b_scientific_pass
        else "CONDITIONAL"
    )
    summary = {
        "gate_a_status": gate_a_status,
        "gate_a_invariant_pass": invariant_pass,
        "gate_a_convergence_pass": convergence_pass,
        "gate_a_reference_stability_pass": reference_stability_pass,
        "advanced_not_worse_2d_cases": advanced_not_worse_count,
        "advanced_not_worse_required": int(thresholds["advanced_not_worse_required"]),
        "advanced_internally_stable_2d_cases": advanced_internally_stable_count,
        "advanced_internally_stable_required": int(
            thresholds["advanced_internally_stable_required"]
        ),
        "max_uniform_analytic_error": max(b0_errors.values()),
        "max_lossless_energy_residual": max_energy,
        "b0_uniform_stack": {"errors": b0_errors, "energy_residuals": b0_energy},
        "b1_high_contrast_1d": b1_results,
        "b2_b3_vector_2d": vector_results,
        "b2_b3_comparisons": vector_comparisons,
        "b4_anomaly_stress": {
            "distance": anomaly_distance,
            "assessment": anomaly_assessment.to_dict(),
        },
        "gate_b_infrastructure_pass": gate_b_infrastructure_pass,
        "gate_b_scientific_status": gate_b_status,
        "gate_b_scientific_pass": gate_b_scientific_pass,
        "reference_qualified_cases": reference_qualified_count,
        "raw_adjacent_indicator_calibration": raw_indicator_calibration.to_dict(),
        "strict_decision_calibration": decision_calibration.to_dict(),
        "gate_b_reference_claim": "one_sided_risk_gate_not_yet_calibrated_safe_acceptor",
    }
    return rows, summary
