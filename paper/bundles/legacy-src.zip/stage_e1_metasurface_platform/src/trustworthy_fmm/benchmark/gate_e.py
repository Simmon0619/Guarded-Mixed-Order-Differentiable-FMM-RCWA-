"""Gate E: manufacturing distributions, lower-tail risk, and relaxation audit.

This benchmark starts from the current Gate-D structures.  It does not import
historical candidate or sample assets.  Training and held-out process catalogs
are constructed separately and the held-out catalog is not evaluated until all
optimization methods have returned frozen tensors.
"""

import hashlib
import json
import math
from pathlib import Path
import time
from typing import Any, Dict, List, Mapping, Sequence, Tuple

import numpy as np
import torch

from trustworthy_fmm.benchmark.gate_cd import (
    _load_density_exact,
    _validate_square_pixel_grid,
)
from trustworthy_fmm.fabrication.process import (
    correlated_periodic_field,
    hard_process_layers,
    periodic_gaussian_filter,
    spatial_tanh_projection,
)
from trustworthy_fmm.fabrication.risk import (
    ProcessScenario,
    build_scenario_catalog,
    lower_tail_cvar,
    mean_lower_tail_reward,
    reward_statistics,
    scenario_weights,
    validate_blind_split,
    weighted_mean_reward,
)
from trustworthy_fmm.optimization.multifidelity import parse_half_orders
from trustworthy_fmm.solvers.vector_2d import solve_multilayer_vector_2d


METHODS = ("nominal", "mean", "mean_lcvar")


def _target_slug(target: Sequence[int]) -> str:
    def component(value: int) -> str:
        if value > 0:
            return "p{}".format(value)
        if value < 0:
            return "m{}".format(abs(value))
        return "0"

    return "target_{}_{}".format(component(int(target[0])), component(int(target[1])))


def _tensor_sha256(tensor: torch.Tensor) -> str:
    value = tensor.detach().cpu().contiguous()
    return hashlib.sha256(value.numpy().tobytes()).hexdigest()


def _validate_source_density_shape(
    density: torch.Tensor, physics: Mapping[str, Any], source_name: str
) -> None:
    expected_shape = tuple(int(value) for value in physics["grid_yx"])
    if tuple(density.shape) != expected_shape:
        raise ValueError(
            "Gate-D source density for {} has stale shape {}; expected {}. "
            "Rerun Gate D with the current grid before Gate E.".format(
                source_name, tuple(density.shape), expected_shape
            )
        )


def _save_tensor(path: Path, tensor: torch.Tensor) -> Dict[str, Any]:
    path.parent.mkdir(parents=True, exist_ok=True)
    value = tensor.detach().cpu().contiguous()
    torch.save(value, path)
    return {
        "path": str(path.resolve()),
        "sha256": _tensor_sha256(value),
        "shape": list(value.shape),
        "dtype": str(value.dtype),
        "minimum": float(value.min()),
        "maximum": float(value.max()),
        "mean": float(value.mean()),
        "gray_fraction_005_095": float(
            torch.logical_and(value > 0.05, value < 0.95)
            .to(torch.float64)
            .mean()
        ),
    }


def _resolve_device(name: str) -> torch.device:
    device = torch.device(name)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("Gate E requested CUDA but CUDA is unavailable")
    return device


def _real_dtype(name: str) -> torch.dtype:
    if name == "float32":
        return torch.float32
    if name == "float64":
        return torch.float64
    raise ValueError("dtype must be float32 or float64")


def _apply_design_symmetry(density: torch.Tensor, enabled: bool) -> torch.Tensor:
    if enabled:
        density = 0.5 * (density + torch.flip(density, dims=(0,)))
    return density


def _scenario_biases(scenario: ProcessScenario) -> List[float]:
    return [
        float(value)
        for value in np.linspace(
            scenario.sidewall_top_bias_nm,
            scenario.sidewall_bottom_bias_nm,
            scenario.sidewall_layers,
        )
    ]


def _soft_process_layers(
    filtered_density: torch.Tensor,
    scenario: ProcessScenario,
    physics: Mapping[str, Any],
    process: Mapping[str, Any],
    beta: float,
    *,
    allow_unmodeled_hard_morphology: bool = False,
) -> Tuple[List[torch.Tensor], List[float], float]:
    """Build differentiable top-to-bottom process layers for one scenario."""
    if scenario.morphology != "none" and not allow_unmodeled_hard_morphology:
        raise ValueError("hard morphology cannot be used in differentiable training")
    transition_nm = float(process["soft_cd_transition_nm"])
    if transition_nm <= 0:
        raise ValueError("soft_cd_transition_nm must be positive")
    if scenario.ler_rms_nm > 0:
        ler = correlated_periodic_field(
            filtered_density.shape,
            physics["lattice_nm"],
            scenario.ler_correlation_nm,
            scenario.ler_seed,
            dtype=filtered_density.dtype,
            device=str(filtered_density.device),
        )
    else:
        ler = torch.zeros_like(filtered_density)
    threshold = float(process["threshold"])
    layers: List[torch.Tensor] = []
    for sidewall_bias in _scenario_biases(scenario):
        physical_offset = (
            scenario.cd_bias_nm
            + sidewall_bias
            + scenario.ler_rms_nm * ler
        )
        eta = torch.clamp(
            threshold - physical_offset / transition_nm,
            min=float(process["minimum_soft_threshold"]),
            max=float(process["maximum_soft_threshold"]),
        )
        layers.append(spatial_tanh_projection(filtered_density, beta, eta))
    total_thickness = float(physics["thickness_nm"]) + scenario.thickness_delta_nm
    if total_thickness <= 0:
        raise ValueError("process scenario produced non-positive thickness")
    thicknesses = [total_thickness / len(layers)] * len(layers)
    feature_index = float(physics["feature_index"]) + scenario.feature_index_delta
    if feature_index <= 0:
        raise ValueError("process scenario produced non-positive feature index")
    return layers, thicknesses, feature_index


def _target_power_from_layers(
    density_layers: Sequence[torch.Tensor],
    thicknesses_nm: Sequence[float],
    feature_index: float,
    physics: Mapping[str, Any],
    half_orders: Sequence[int],
    target_order: Sequence[int],
    factorization: str,
) -> torch.Tensor:
    background_epsilon = float(physics["background_index"]) ** 2
    contrast = feature_index**2 - background_epsilon
    epsilon_layers = [
        (background_epsilon + contrast * density).to(
            torch.complex128
            if density.dtype == torch.float64
            else torch.complex64
        )
        for density in density_layers
    ]
    result = solve_multilayer_vector_2d(
        epsilon_layers,
        thicknesses_nm,
        float(physics["wavelength_nm"]),
        tuple(float(value) for value in physics["lattice_nm"]),
        complex(physics["incident_index"]),
        complex(physics["output_index"]),
        parse_half_orders(half_orders),
        float(physics["theta_deg"]),
        float(physics["phi_deg"]),
        factorization=factorization,
    )
    return result.transmitted_power(tuple(int(value) for value in target_order))


def _soft_catalog_values(
    raw_density: torch.Tensor,
    scenarios: Sequence[ProcessScenario],
    physics: Mapping[str, Any],
    process: Mapping[str, Any],
    beta: float,
    half_orders: Sequence[int],
    target_order: Sequence[int],
    factorization: str,
    enforce_y_symmetry: bool,
    *,
    allow_unmodeled_hard_morphology: bool = False,
) -> torch.Tensor:
    filtered = periodic_gaussian_filter(
        _apply_design_symmetry(raw_density, enforce_y_symmetry),
        physics["lattice_nm"],
        float(process["filter_radius_nm"]),
    )
    filtered = _apply_design_symmetry(filtered, enforce_y_symmetry)
    values = []
    for scenario in scenarios:
        layers, thicknesses, feature_index = _soft_process_layers(
            filtered,
            scenario,
            physics,
            process,
            beta,
            allow_unmodeled_hard_morphology=allow_unmodeled_hard_morphology,
        )
        values.append(
            _target_power_from_layers(
                layers,
                thicknesses,
                feature_index,
                physics,
                half_orders,
                target_order,
                factorization,
            )
        )
    return torch.stack(values)


def _nominal_hard_mask(
    raw_density: torch.Tensor,
    physics: Mapping[str, Any],
    process: Mapping[str, Any],
    enforce_y_symmetry: bool,
) -> torch.Tensor:
    filtered = periodic_gaussian_filter(
        _apply_design_symmetry(raw_density, enforce_y_symmetry),
        physics["lattice_nm"],
        float(process["filter_radius_nm"]),
    )
    filtered = _apply_design_symmetry(filtered, enforce_y_symmetry)
    return (filtered >= float(process["threshold"])).to(torch.float64)


def _hard_scenario_value(
    nominal_mask: torch.Tensor,
    scenario: ProcessScenario,
    physics: Mapping[str, Any],
    half_orders: Sequence[int],
    target_order: Sequence[int],
    factorization: str,
    device: torch.device,
    dtype: torch.dtype,
) -> float:
    masks = hard_process_layers(
        nominal_mask.detach().cpu().numpy() >= 0.5,
        scenario.to_dict(),
        physics["lattice_nm"],
    )
    layers = [
        torch.as_tensor(mask, dtype=dtype, device=device) for mask in masks
    ]
    total_thickness = float(physics["thickness_nm"]) + scenario.thickness_delta_nm
    if total_thickness <= 0:
        raise ValueError("hard scenario produced non-positive thickness")
    thicknesses = [total_thickness / len(layers)] * len(layers)
    feature_index = float(physics["feature_index"]) + scenario.feature_index_delta
    with torch.no_grad():
        value = _target_power_from_layers(
            layers,
            thicknesses,
            feature_index,
            physics,
            half_orders,
            target_order,
            factorization,
        )
    return float(value.detach().cpu())


def _hard_catalog_values(
    raw_density: torch.Tensor,
    scenarios: Sequence[ProcessScenario],
    physics: Mapping[str, Any],
    process: Mapping[str, Any],
    half_orders: Sequence[int],
    target_order: Sequence[int],
    factorization: str,
    enforce_y_symmetry: bool,
    device: torch.device,
    dtype: torch.dtype,
) -> Tuple[torch.Tensor, List[float]]:
    mask = _nominal_hard_mask(raw_density, physics, process, enforce_y_symmetry)
    values = [
        _hard_scenario_value(
            mask,
            scenario,
            physics,
            half_orders,
            target_order,
            factorization,
            device,
            dtype,
        )
        for scenario in scenarios
    ]
    return mask, values


def _risk_reward(
    method: str,
    values: torch.Tensor,
    weights: torch.Tensor,
    nominal_index: int,
    alpha: float,
    beta: float,
) -> torch.Tensor:
    if method == "nominal":
        return values[nominal_index]
    if method == "mean":
        return weighted_mean_reward(values, weights)
    if method == "mean_lcvar":
        return mean_lower_tail_reward(values, alpha, beta, weights)
    raise ValueError("unknown Gate E method {}".format(method))


def _risk_reward_float(
    method: str,
    values: Sequence[float],
    scenarios: Sequence[ProcessScenario],
    nominal_index: int,
    alpha: float,
    beta: float,
) -> float:
    tensor = torch.as_tensor(values, dtype=torch.float64)
    weights = torch.as_tensor(
        [scenario.weight for scenario in scenarios], dtype=torch.float64
    )
    return float(
        _risk_reward(method, tensor, weights, nominal_index, alpha, beta)
    )


def _find_nominal_index(scenarios: Sequence[ProcessScenario]) -> int:
    indices = [
        index for index, scenario in enumerate(scenarios) if scenario.category == "nominal"
    ]
    if len(indices) != 1:
        raise ValueError("each scenario catalog must contain exactly one nominal category")
    return indices[0]


def _optimize_method(
    method: str,
    initial: torch.Tensor,
    training: Sequence[ProcessScenario],
    physics: Mapping[str, Any],
    config: Mapping[str, Any],
    target_order: Sequence[int],
    device: torch.device,
    dtype: torch.dtype,
) -> Tuple[torch.Tensor, torch.Tensor, Dict[str, Any], List[Dict[str, Any]]]:
    optimization = config["optimization"]
    process = config["process_model"]
    factorization = str(optimization["factorization"])
    enforce_y = bool(optimization["enforce_y_mirror_symmetry"])
    nominal_index = _find_nominal_index(training)
    alpha = float(optimization["lcvar_alpha"])
    tail_beta = float(optimization["lcvar_beta"])
    order = parse_half_orders(optimization["half_orders"])
    iterations = int(optimization["iterations"])
    beta_start = float(optimization["projection_beta_initial"])
    beta_final = float(optimization["projection_beta_final"])
    weights = scenario_weights(training, dtype=dtype, device=device)
    raw = _apply_design_symmetry(
        initial.to(device=device, dtype=dtype).clone(), enforce_y
    )
    with torch.no_grad():
        initial_soft = _soft_catalog_values(
            raw,
            training,
            physics,
            process,
            beta_final,
            order,
            target_order,
            factorization,
            enforce_y,
        )
    nominal_soft_reference = float(initial_soft[nominal_index].detach().cpu())
    initial_mask, initial_hard_values = _hard_catalog_values(
        raw,
        training,
        physics,
        process,
        order,
        target_order,
        factorization,
        enforce_y,
        device,
        dtype,
    )
    nominal_hard_reference = float(initial_hard_values[nominal_index])
    allowed_loss = float(optimization["nominal_loss_budget_fraction"])
    soft_floor = nominal_soft_reference * (1.0 - allowed_loss)
    hard_floor = nominal_hard_reference * (1.0 - allowed_loss)
    penalty_weight = float(optimization["nominal_constraint_penalty"])
    binarization_weight = float(optimization["binarization_penalty"])
    learning_rate = float(optimization["learning_rate"])
    beta1 = float(optimization["adam_beta1"])
    beta2 = float(optimization["adam_beta2"])
    epsilon = float(optimization["adam_epsilon"])
    audit_interval = int(optimization["hard_audit_interval"])
    if audit_interval <= 0:
        raise ValueError("hard_audit_interval must be positive")
    momentum = torch.zeros_like(raw)
    velocity = torch.zeros_like(raw)
    best_raw = raw.detach().clone()
    best_mask = initial_mask.detach().clone()
    best_audit = _risk_reward_float(
        method,
        initial_hard_values,
        training,
        nominal_index,
        alpha,
        tail_beta,
    ) - penalty_weight * max(hard_floor - nominal_hard_reference, 0.0) ** 2
    best_iteration = -1
    history: List[Dict[str, Any]] = []
    soft_forward_calls = len(training)
    hard_forward_calls = len(training)
    start = time.perf_counter()
    for iteration in range(iterations):
        fraction = iteration / max(iterations - 1, 1)
        projection_beta = beta_start * (beta_final / beta_start) ** fraction
        work = raw.detach().clone().requires_grad_(True)
        values = _soft_catalog_values(
            work,
            training,
            physics,
            process,
            projection_beta,
            order,
            target_order,
            factorization,
            enforce_y,
        )
        soft_forward_calls += len(training)
        base_reward = _risk_reward(
            method, values, weights, nominal_index, alpha, tail_beta
        )
        nominal_value = values[nominal_index]
        nominal_penalty = penalty_weight * torch.relu(
            torch.as_tensor(soft_floor, dtype=dtype, device=device) - nominal_value
        ).square()
        filtered = periodic_gaussian_filter(
            _apply_design_symmetry(work, enforce_y),
            physics["lattice_nm"],
            float(process["filter_radius_nm"]),
        )
        nominal_projection = spatial_tanh_projection(
            _apply_design_symmetry(filtered, enforce_y),
            projection_beta,
            torch.full_like(filtered, float(process["threshold"])),
        )
        grayness = torch.mean(nominal_projection * (1.0 - nominal_projection))
        objective = base_reward - nominal_penalty - binarization_weight * grayness
        gradient = torch.autograd.grad(objective, work)[0]
        if not bool(torch.isfinite(gradient).all()):
            raise RuntimeError("non-finite Gate E gradient")
        with torch.no_grad():
            momentum = beta1 * momentum + (1.0 - beta1) * gradient
            velocity = beta2 * velocity + (1.0 - beta2) * gradient.square()
            corrected_momentum = momentum / (1.0 - beta1 ** (iteration + 1))
            corrected_velocity = velocity / (1.0 - beta2 ** (iteration + 1))
            raw = torch.clamp(
                work
                + learning_rate
                * corrected_momentum
                / torch.sqrt(corrected_velocity + epsilon),
                0.0,
                1.0,
            ).detach()
            raw = _apply_design_symmetry(raw, enforce_y)
        audit_value = float("nan")
        hard_nominal = float("nan")
        if iteration % audit_interval == 0 or iteration == iterations - 1:
            mask, hard_values = _hard_catalog_values(
                raw,
                training,
                physics,
                process,
                order,
                target_order,
                factorization,
                enforce_y,
                device,
                dtype,
            )
            hard_forward_calls += len(training)
            hard_nominal = float(hard_values[nominal_index])
            audit_value = _risk_reward_float(
                method,
                hard_values,
                training,
                nominal_index,
                alpha,
                tail_beta,
            ) - penalty_weight * max(hard_floor - hard_nominal, 0.0) ** 2
            if audit_value > best_audit:
                best_audit = audit_value
                best_iteration = iteration
                best_raw = raw.detach().clone()
                best_mask = mask.detach().clone()
        history.append(
            {
                "iteration": iteration,
                "projection_beta": projection_beta,
                "soft_objective": float(objective.detach().cpu()),
                "soft_mean_efficiency": float(
                    weighted_mean_reward(values, weights).detach().cpu()
                ),
                "soft_lcvar_efficiency": float(
                    lower_tail_cvar(values, tail_beta, weights).detach().cpu()
                ),
                "soft_nominal_efficiency": float(nominal_value.detach().cpu()),
                "gradient_norm": float(torch.linalg.vector_norm(gradient).detach().cpu()),
                "gray_fraction_proxy": float(grayness.detach().cpu()),
                "hard_audit_reward": audit_value,
                "hard_nominal_efficiency": hard_nominal,
            }
        )
    elapsed = time.perf_counter() - start
    metadata = {
        "method": method,
        "target_order": list(target_order),
        "iterations": iterations,
        "optimization_half_orders": list(order),
        "training_scenarios": len(training),
        "soft_forward_calls": soft_forward_calls,
        "hard_forward_calls": hard_forward_calls,
        "backward_calls": iterations,
        "wall_time_s": elapsed,
        "initial_soft_nominal_efficiency": nominal_soft_reference,
        "initial_hard_nominal_efficiency": nominal_hard_reference,
        "nominal_soft_floor": soft_floor,
        "nominal_hard_floor": hard_floor,
        "selected_hard_audit_iteration": best_iteration,
        "selected_hard_audit_reward": best_audit,
    }
    return best_raw.detach().cpu(), best_mask.detach().cpu(), metadata, history


def _evaluate_frozen_design(
    raw_density: torch.Tensor,
    held_out: Sequence[ProcessScenario],
    physics: Mapping[str, Any],
    config: Mapping[str, Any],
    target_order: Sequence[int],
    device: torch.device,
    dtype: torch.dtype,
) -> Tuple[torch.Tensor, Dict[str, Any], List[Dict[str, Any]]]:
    process = config["process_model"]
    scoring = config["scoring"]
    optimization = config["optimization"]
    order = parse_half_orders(scoring["half_orders"])
    validation_order = parse_half_orders(scoring["validation_half_orders"])
    factorization = str(scoring["factorization"])
    enforce_y = bool(optimization["enforce_y_mirror_symmetry"])
    nominal_index = _find_nominal_index(held_out)
    work = raw_density.to(device=device, dtype=dtype)
    hard_mask, hard_values = _hard_catalog_values(
        work,
        held_out,
        physics,
        process,
        order,
        target_order,
        factorization,
        enforce_y,
        device,
        dtype,
    )
    with torch.no_grad():
        soft_values_tensor = _soft_catalog_values(
            work,
            held_out,
            physics,
            process,
            float(optimization["projection_beta_final"]),
            order,
            target_order,
            factorization,
            enforce_y,
            allow_unmodeled_hard_morphology=True,
        )
    soft_values = [float(value) for value in soft_values_tensor.detach().cpu()]
    weights = [scenario.weight for scenario in held_out]
    statistics = reward_statistics(
        hard_values, float(optimization["lcvar_beta"]), weights
    )
    statistics["nominal"] = float(hard_values[nominal_index])
    soft_worst_index = int(np.argmin(soft_values))
    hard_worst_index = int(np.argmin(hard_values))
    attack_gap = float(hard_values[soft_worst_index] - hard_values[hard_worst_index])
    attack_tolerance = float(scoring["relaxation_attack_absolute_tolerance"])
    critical_indices = sorted({nominal_index, hard_worst_index})
    validation_records = []
    all_validation_pass = True
    for index in critical_indices:
        value = _hard_scenario_value(
            hard_mask,
            held_out[index],
            physics,
            validation_order,
            target_order,
            factorization,
            device,
            dtype,
        )
        relative_change = abs(value - hard_values[index]) / max(abs(value), 1e-15)
        passed = relative_change <= float(scoring["order_relative_tolerance"])
        all_validation_pass = all_validation_pass and passed
        validation_records.append(
            {
                "scenario": held_out[index].name,
                "role": "nominal" if index == nominal_index else "hard_worst",
                "reference_half_orders": list(order),
                "validation_half_orders": list(validation_order),
                "reference_efficiency": float(hard_values[index]),
                "validation_efficiency": value,
                "relative_change": relative_change,
                "pass": passed,
            }
        )
    rows = []
    for scenario, soft_value, hard_value in zip(
        held_out, soft_values, hard_values
    ):
        row = scenario.to_dict()
        row.update(
            {
                "target_order": list(target_order),
                "reference_half_orders": list(order),
                "soft_surrogate_target_efficiency": soft_value,
                "hard_target_efficiency": hard_value,
                "soft_minus_hard": soft_value - hard_value,
                "soft_surrogate_includes_hard_morphology": scenario.morphology
                == "none",
            }
        )
        rows.append(row)
    summary = {
        "objective_definition": "absolute target-order transmitted diffraction efficiency P_target_transmitted/P_incident; x-polarized (0,0) incidence; both output polarizations included",
        "statistics": statistics,
        "soft_worst_scenario": held_out[soft_worst_index].name,
        "hard_worst_scenario": held_out[hard_worst_index].name,
        "hard_efficiency_at_soft_worst": float(hard_values[soft_worst_index]),
        "hard_worst_efficiency": float(hard_values[hard_worst_index]),
        "relaxation_attack_gap": attack_gap,
        "soft_attack_reproduced_hard_tail": attack_gap <= attack_tolerance,
        "reference_validation": validation_records,
        "all_reference_validations_pass": all_validation_pass,
    }
    return hard_mask, summary, rows


def _build_target_comparison(
    methods: Mapping[str, Mapping[str, Any]], config: Mapping[str, Any]
) -> Dict[str, Any]:
    optimization = config["optimization"]
    scoring = config["scoring"]
    baseline = methods["nominal"]["evaluation"]["statistics"]
    robust = methods["mean_lcvar"]["evaluation"]["statistics"]
    nominal_loss = (baseline["nominal"] - robust["nominal"]) / max(
        abs(baseline["nominal"]), 1e-15
    )
    lcvar_improvement = robust["lower_tail_cvar"] - baseline["lower_tail_cvar"]
    p10_improvement = robust["p10"] - baseline["p10"]
    minimum_improvement = robust["minimum"] - baseline["minimum"]
    references_pass = all(
        bool(method["evaluation"]["all_reference_validations_pass"])
        for method in methods.values()
    )
    empirical_support = (
        lcvar_improvement >= float(scoring["minimum_lcvar_improvement"])
        and nominal_loss <= float(optimization["nominal_loss_budget_fraction"])
    )
    if not references_pass:
        decision = "UNRESOLVED_REFERENCE"
    elif empirical_support:
        decision = "SUPPORT_WITHIN_FROZEN_CATALOG"
    else:
        decision = "NO_GO_WITHIN_FROZEN_CATALOG"
    return {
        "primary_comparison": "mean_lcvar minus nominal on held-out hard catalog",
        "held_out_lcvar_improvement": lcvar_improvement,
        "held_out_p10_improvement": p10_improvement,
        "held_out_minimum_improvement": minimum_improvement,
        "nominal_efficiency_loss_fraction": nominal_loss,
        "reference_validations_pass": references_pass,
        "empirical_support_before_reference_gate": empirical_support,
        "h3_decision": decision,
    }


def run_gate_e(
    config: Mapping[str, Any],
    gate_cd_config: Mapping[str, Any],
    gate_cd_summary: Mapping[str, Any],
    output_dir: Path,
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """Optimize three manufacturing objectives and run a frozen hard blind audit."""
    if bool(config.get("excluded_legacy_examples_used", True)):
        raise ValueError("Gate E must explicitly exclude legacy examples")
    if bool(gate_cd_summary.get("excluded_legacy_examples_used", True)):
        raise ValueError("Gate-D input is not marked legacy-free")
    gate_c_summary = gate_cd_summary.get("gate_c", {})
    gate_d_summary = gate_cd_summary.get("gate_d", {})
    if not bool(gate_c_summary.get("reference_qualified", False)):
        raise ValueError(
            "Gate E is locked: Gate C has not qualified a value-and-gradient FFT reference"
        )
    if str(gate_d_summary.get("status")) != "PASS":
        raise ValueError(
            "Gate E is locked: Gate D has not passed the preregistered FOC-TR criteria"
        )
    process = config["process_model"]
    training = build_scenario_catalog(process["training_scenarios"], "train")
    held_out = build_scenario_catalog(process["held_out_scenarios"], "held_out")
    validate_blind_split(training, held_out)
    optimization = config["optimization"]
    scoring = config["scoring"]
    if str(optimization["factorization"]) != "fft_baseline" or str(
        scoring["factorization"]
    ) != "fft_baseline":
        raise ValueError("Gate E re-entry requires the same fft_baseline solver family")
    gate_d_reference = parse_half_orders(
        gate_d_summary["optimization_fidelity"]["reference_half_orders"]
    )
    if parse_half_orders(scoring["validation_half_orders"]) != gate_d_reference:
        raise ValueError(
            "Gate E validation_half_orders must equal Gate D's qualified reference"
        )
    requested_methods = tuple(str(value) for value in optimization["methods"])
    if requested_methods != METHODS:
        raise ValueError("Gate E methods must be nominal, mean, mean_lcvar in frozen order")
    physics = dict(gate_cd_config["gate_d"])
    _validate_square_pixel_grid(physics)
    targets = [tuple(int(value) for value in target) for target in config["target_orders"]]
    device = _resolve_device(str(optimization["device"]))
    dtype = _real_dtype(str(optimization["dtype"]))
    output_dir.mkdir(parents=True, exist_ok=True)
    structures_dir = output_dir / "structures"
    checkpoints_dir = output_dir / "optimization_checkpoints"
    checkpoints_dir.mkdir(parents=True, exist_ok=True)
    base_config_signature = hashlib.sha256(
        json.dumps(
            {"gate_e": config, "inherited_gate_d_physics": physics},
            sort_keys=True,
            default=str,
        ).encode("utf-8")
    ).hexdigest()
    resume_checkpoints = bool(
        optimization.get("resume_optimization_checkpoints", True)
    )
    optimized: Dict[str, Dict[str, Any]] = {}
    histories: List[Dict[str, Any]] = []
    # Phase 1: optimize and freeze every method.  Held-out scenarios are not read here.
    for target in targets:
        key = _target_slug(target)
        gate_d_target = gate_cd_summary["gate_d"]["per_target"][key]
        source_method = str(gate_d_target["best_authoritative_method"])
        initial = _load_density_exact(
            gate_d_target["methods"][source_method]["saved_density"]
        )
        _validate_source_density_shape(initial, physics, key)
        config_signature = hashlib.sha256(
            (base_config_signature + ":" + _tensor_sha256(initial)).encode("utf-8")
        ).hexdigest()
        optimized[key] = {
            "target_order": list(target),
            "gate_d_source_method": source_method,
            "methods": {},
        }
        for method in requested_methods:
            checkpoint_path = checkpoints_dir / (key + "__" + method + ".json")
            checkpoint = None
            if resume_checkpoints and checkpoint_path.exists():
                candidate = json.loads(checkpoint_path.read_text(encoding="utf-8"))
                if candidate.get("config_signature") == config_signature:
                    checkpoint = candidate
            if checkpoint is None:
                print(
                    "Gate E optimize target ({:+d},{:+d}) method {}".format(
                        target[0], target[1], method
                    ),
                    flush=True,
                )
                raw, mask, metadata, history = _optimize_method(
                    method,
                    initial,
                    training,
                    physics,
                    config,
                    target,
                    device,
                    dtype,
                )
            else:
                print(
                    "Gate E resume target ({:+d},{:+d}) method {}".format(
                        target[0], target[1], method
                    ),
                    flush=True,
                )
                raw = torch.load(
                    checkpoint["raw_density"]["path"],
                    map_location="cpu",
                    weights_only=True,
                )
                mask = torch.load(
                    checkpoint["nominal_binary_mask"]["path"],
                    map_location="cpu",
                    weights_only=True,
                )
                if _tensor_sha256(raw) != checkpoint["raw_density"]["sha256"]:
                    raise RuntimeError("Gate E raw checkpoint hash changed")
                if _tensor_sha256(mask) != checkpoint["nominal_binary_mask"]["sha256"]:
                    raise RuntimeError("Gate E mask checkpoint hash changed")
                metadata = checkpoint["optimization"]
                history = checkpoint["history"]
            raw_manifest = _save_tensor(
                structures_dir / (key + "__" + method + "__raw.pt"), raw
            )
            mask_manifest = _save_tensor(
                structures_dir / (key + "__" + method + "__nominal_binary.pt"),
                mask,
            )
            if checkpoint is None:
                checkpoint_path.write_text(
                    json.dumps(
                        {
                            "config_signature": config_signature,
                            "target_order": list(target),
                            "method": method,
                            "raw_density": raw_manifest,
                            "nominal_binary_mask": mask_manifest,
                            "optimization": metadata,
                            "history": history,
                        },
                        indent=2,
                        ensure_ascii=False,
                    ),
                    encoding="utf-8",
                )
            optimized[key]["methods"][method] = {
                "optimization": metadata,
                "raw_density": raw_manifest,
                "nominal_binary_mask": mask_manifest,
                "frozen_before_held_out_evaluation": True,
                "_raw_tensor": raw,
            }
            for row in history:
                record = dict(row)
                record.update(
                    {
                        "stage": "optimization",
                        "method": method,
                        "target_order": list(target),
                    }
                )
                histories.append(record)
            if device.type == "cuda":
                torch.cuda.empty_cache()
    # Phase 2: blind hard evaluation after all methods and tensors are frozen.
    rows: List[Dict[str, Any]] = list(histories)
    relaxation_misses = 0
    relaxation_audits = 0
    per_target: Dict[str, Any] = {}
    for target in targets:
        key = _target_slug(target)
        target_entry = optimized[key]
        per_target[key] = {
            "target_order": list(target),
            "gate_d_source_method": target_entry["gate_d_source_method"],
            "methods": {},
        }
        for method in requested_methods:
            print(
                "Gate E blind audit target ({:+d},{:+d}) method {}".format(
                    target[0], target[1], method
                ),
                flush=True,
            )
            method_entry = target_entry["methods"][method]
            raw = method_entry.pop("_raw_tensor")
            mask, evaluation, scenario_rows = _evaluate_frozen_design(
                raw,
                held_out,
                physics,
                config,
                target,
                device,
                dtype,
            )
            evaluated_mask_manifest = _save_tensor(
                structures_dir
                / (key + "__" + method + "__evaluated_nominal_binary.pt"),
                mask,
            )
            if evaluated_mask_manifest["sha256"] != method_entry[
                "nominal_binary_mask"
            ]["sha256"]:
                raise RuntimeError("frozen nominal mask changed before blind evaluation")
            method_entry["evaluation"] = evaluation
            method_entry["evaluated_nominal_binary_mask"] = evaluated_mask_manifest
            per_target[key]["methods"][method] = method_entry
            relaxation_audits += 1
            if not evaluation["soft_attack_reproduced_hard_tail"]:
                relaxation_misses += 1
            for row in scenario_rows:
                record = dict(row)
                record.update(
                    {
                        "stage": "held_out_hard_audit",
                        "method": method,
                    }
                )
                rows.append(record)
        per_target[key]["comparison"] = _build_target_comparison(
            per_target[key]["methods"], config
        )
    decisions = [entry["comparison"]["h3_decision"] for entry in per_target.values()]
    references_pass = all(
        entry["comparison"]["reference_validations_pass"]
        for entry in per_target.values()
    )
    if all(decision == "SUPPORT_WITHIN_FROZEN_CATALOG" for decision in decisions):
        h3_status = "SUPPORTED_WITHIN_CATALOG"
    elif any(decision == "UNRESOLVED_REFERENCE" for decision in decisions):
        h3_status = "UNRESOLVED_REFERENCE"
    else:
        h3_status = "NO_GO_WITHIN_CATALOG"
    calibration_status = str(process["calibration_status"])
    scientific_pass = (
        calibration_status == "foundry_calibrated"
        and h3_status == "SUPPORTED_WITHIN_CATALOG"
        and references_pass
    )
    summary = {
        "schema_version": 1,
        "status": "PASS" if scientific_pass else "CONDITIONAL",
        "infrastructure_pass": True,
        "scientific_pass": scientific_pass,
        "h3_status": h3_status,
        "objective_contract": "eta_T(m,n)=P_target_transmitted/P_incident; x-polarized (0,0) incidence; x/y output polarization power summed; this is efficiency, not amplitude or gradient",
        "risk_contract": "LCVaR_beta=max_t[t-E(max(t-eta,0))/beta]; J_alpha=(1-alpha)E[eta]+alpha*LCVaR_beta",
        "process_claim_level": calibration_status,
        "process_claim": (
            "normalized sensitivity study; not a foundry yield prediction"
            if calibration_status != "foundry_calibrated"
            else "calibrated process-distribution study"
        ),
        "training_catalog_scope": "exact enumeration over the finite listed training catalog",
        "held_out_catalog_scope": "exact enumeration over listed deterministic corners; LER entries are sampled statistical extremes, not exact continuous worst cases",
        "training_scenarios": [scenario.to_dict() for scenario in training],
        "held_out_scenarios": [scenario.to_dict() for scenario in held_out],
        "training_held_out_names_disjoint": True,
        "held_out_accessed_only_after_all_methods_frozen": True,
        "physics": physics,
        "optimization": dict(optimization),
        "scoring": dict(config["scoring"]),
        "per_target": per_target,
        "relaxation_audit": {
            "audits": relaxation_audits,
            "hard_search_miss_count": relaxation_misses,
            "hard_search_miss_rate": relaxation_misses / max(relaxation_audits, 1),
        },
        "reference_validations_pass": references_pass,
        "excluded_legacy_examples_used": False,
        "allowed_claim": (
            "Tail improvement may be reported only per target and only with the unresolved/reference status shown."
        ),
    }
    return rows, summary


def build_gate_e_report(summary: Mapping[str, Any]) -> str:
    lines = [
        "# Gate E 制造分布与下尾风险报告",
        "",
        "> 本报告不使用旧候选或旧 TORCWA sample；所有结构来自当前 Gate D。",
        "",
        "## 定义",
        "",
        "- 目标效率：`eta_T(m,n)=P_target_transmitted/P_incident`，x 偏振零级入射，目标级两种输出偏振功率求和。",
        "- `mean`、`LCVaR`、`p10`、`minimum` 均作用于上述效率，不是梯度。",
        "- lower-tail CVaR：`max_t[t-E(max(t-eta,0))/beta]`。",
        "- 当前扰动范围没有 foundry 数据校准，因此只称归一化敏感性研究。",
        "",
        "## 结果",
        "",
        "| target | method | nominal | mean | LCVaR | p10 | minimum | ref N→N+1 |",
        "|---|---|---:|---:|---:|---:|---:|---|",
    ]
    for target in summary["per_target"].values():
        label = "({:+d},{:+d})".format(*target["target_order"])
        for method, record in target["methods"].items():
            evaluation = record["evaluation"]
            stats = evaluation["statistics"]
            lines.append(
                "| {} | {} | {:.6f} | {:.6f} | {:.6f} | {:.6f} | {:.6f} | {} |".format(
                    label,
                    method,
                    stats["nominal"],
                    stats["mean"],
                    stats["lower_tail_cvar"],
                    stats["p10"],
                    stats["minimum"],
                    "PASS" if evaluation["all_reference_validations_pass"] else "FAIL",
                )
            )
    lines.extend(["", "## H3 按目标判定", ""])
    for target in summary["per_target"].values():
        label = "({:+d},{:+d})".format(*target["target_order"])
        comparison = target["comparison"]
        lines.append(
            "- {} H3: `{}`；LCVaR 改变量 `{:.6f}`；名义效率损失比例 `{:.3%}`。".format(
                label,
                comparison["h3_decision"],
                comparison["held_out_lcvar_improvement"],
                comparison["nominal_efficiency_loss_fraction"],
            )
        )
    lines.extend(
        [
            "",
            "## 优化交付点",
            "",
            "`initial` 表示所有后续硬审计候选都没有超过输入 Gate-D 结构；它不是缺失数据。不同 objective 的 audit reward 不可横向比较。",
            "",
            "| target | method | selected hard-audit iteration | binary SHA-256 prefix |",
            "|---|---|---:|---|",
        ]
    )
    for target in summary["per_target"].values():
        label = "({:+d},{:+d})".format(*target["target_order"])
        for method, record in target["methods"].items():
            iteration = int(
                record["optimization"]["selected_hard_audit_iteration"]
            )
            lines.append(
                "| {} | {} | {} | `{}` |".format(
                    label,
                    method,
                    "initial" if iteration < 0 else iteration,
                    record["nominal_binary_mask"]["sha256"][:12],
                )
            )
    duplicate_notes = []
    for target in summary["per_target"].values():
        by_hash: Dict[str, List[str]] = {}
        for method, record in target["methods"].items():
            by_hash.setdefault(
                record["nominal_binary_mask"]["sha256"], []
            ).append(method)
        for methods in by_hash.values():
            if len(methods) > 1:
                duplicate_notes.append(
                    "- Target ({:+d},{:+d}): `{}` 交付了完全相同的二值 mask；不能把重合点解释成两份独立证据。".format(
                        *target["target_order"], " / ".join(methods)
                    )
                )
    if duplicate_notes:
        lines.extend(["", *duplicate_notes])
    lines.extend(
        [
            "",
            "## 关键 N=6→7 参考检查",
            "",
            "以下检查针对每个交付设计的 nominal 和其 N=6 hard-worst 场景。它是 critical-scenario spot check，不等于完整 N=7 catalog 已收敛。",
            "",
            "| target | method | role | scenario | eta N=6 | eta N=7 | relative change | pass |",
            "|---|---|---|---|---:|---:|---:|---|",
        ]
    )
    for target in summary["per_target"].values():
        label = "({:+d},{:+d})".format(*target["target_order"])
        for method, record in target["methods"].items():
            for validation in record["evaluation"]["reference_validation"]:
                lines.append(
                    "| {} | {} | {} | {} | {:.6f} | {:.6f} | {:.1%} | {} |".format(
                        label,
                        method,
                        validation["role"],
                        validation["scenario"],
                        validation["reference_efficiency"],
                        validation["validation_efficiency"],
                        validation["relative_change"],
                        "PASS" if validation["pass"] else "FAIL",
                    )
                )
    audit = summary["relaxation_audit"]
    lines.extend(
        [
            "",
            "## 松弛反查",
            "",
            "- soft worst 在硬 catalog 上的 miss rate：`{:.1%}`（{}/{}）。".format(
                audit["hard_search_miss_rate"],
                audit["hard_search_miss_count"],
                audit["audits"],
            ),
            "- 该结果只对冻结 catalog 精确；LER 仍是抽样极值。",
            "- hard opening/closing 在 soft audit 中被刻意留作未建模操作；soft–hard 差值正是 relaxation gap，而不是为非光滑形貌伪造梯度。",
            "",
            "## Gate",
            "",
            "- infrastructure：`{}`".format(
                "PASS" if summary["infrastructure_pass"] else "FAIL"
            ),
            "- H3：`{}`".format(summary["h3_status"]),
            "- scientific Gate E：`{}`".format(summary["status"]),
            "",
            "所有 critical N=6→7 检查未通过时，N=6 distribution/Pareto 图只能作失败诊断；即使某个目标在 N=6 上满足预设 LCVaR 改善，也不得写成 H3 已支持。",
            "",
            "在参考阶未稳定或过程范围未校准时，不得写成 foundry yield、exact worst case 或 guaranteed fabrication robustness。",
            "",
        ]
    )
    return "\n".join(lines)
