"""Project-asset regression for the trusted 1D TM baseline."""

from pathlib import Path
from typing import Any, Dict, List, Mapping, Tuple

import numpy as np
import torch

from trustworthy_fmm.solvers.rcwa_1d import solve_1d_tm


def load_candidate_mask(asset: Path, candidate_id: int) -> np.ndarray:
    with np.load(str(asset), allow_pickle=False) as data:
        matches = np.flatnonzero(data["candidate_ids"] == candidate_id)
        if matches.size != 1:
            raise ValueError("candidate id {} does not identify exactly one mask".format(candidate_id))
        return data["masks"][int(matches[0])].astype(np.float64)


def run_project_regression(
    config: Mapping[str, Any], workspace_root: Path
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    asset = workspace_root / config["assets"]["candidate_119_masks"]
    mask = load_candidate_mask(asset, 119)
    solver = config["solver"]
    upsample = int(solver["mask_upsample"])
    if upsample > 1:
        mask = np.repeat(mask, upsample)
    epsilon = torch.as_tensor(
        1.0 + (solver["material_index"] ** 2 - 1.0) * mask,
        dtype=torch.complex128,
    )
    target_order = tuple(config["reference_values"]["candidate_119"]["target_order"])
    reference = float(config["reference_values"]["candidate_119"]["target_power"])
    rows: List[Dict[str, Any]] = []
    previous_target = None
    for half_order in solver["half_orders"]:
        result = solve_1d_tm(
            epsilon,
            solver["thickness_nm"],
            solver["wavelength_nm"],
            solver["period_nm"],
            solver["incident_index"],
            solver["output_index"],
            int(half_order),
        )
        target = float(result.transmitted_power(target_order))
        rows.append(
            {
                "candidate_id": 119,
                "half_order": int(half_order),
                "target_order": str(target_order),
                "target_power": target,
                "reference_target_power": reference,
                "absolute_reference_error": abs(target - reference),
                "adjacent_target_change": float("nan") if previous_target is None else abs(target - previous_target),
                "total_T": float(result.total_T),
                "total_R": float(result.total_R),
                "energy_residual": float(result.energy_residual),
                "min_eigen_gap": float(result.diagnostics["min_eigen_gap"]),
                "modal_condition": float(result.diagnostics["modal_condition"]),
            }
        )
        previous_target = target
    final = rows[-1]
    thresholds = config["thresholds"]
    summary = {
        "candidate_id": 119,
        "reference_target_power": reference,
        "final_half_order": final["half_order"],
        "final_target_power": final["target_power"],
        "final_absolute_reference_error": final["absolute_reference_error"],
        "final_energy_residual": final["energy_residual"],
        "target_power_pass": final["absolute_reference_error"] <= thresholds["target_power_absolute_error"],
        "energy_pass": final["energy_residual"] <= thresholds["energy_residual"],
        "sample_350_vector_2d_pending": True,
        "torcwa_example6_vector_2d_pending": True,
    }
    return rows, summary

