"""Held-out fabrication perturbation evaluation for candidate 119."""

from pathlib import Path
from typing import Any, Dict, List, Mapping, Tuple

import numpy as np
import torch

from trustworthy_fmm.benchmark.project_regression import load_candidate_mask
from trustworthy_fmm.fabrication.process import (
    binary_opening_closing,
    cd_bias,
    sdf_smooth,
    sidewall_stack,
)
from trustworthy_fmm.solvers.rcwa_1d import solve_1d_tm, solve_multilayer_1d


def _epsilon(mask: np.ndarray, index: float, upsample: int) -> torch.Tensor:
    if upsample > 1:
        mask = np.repeat(mask.astype(np.float64), upsample)
    return torch.as_tensor(1.0 + (index ** 2 - 1.0) * mask, dtype=torch.complex128)


def run_fabrication_validation(
    config: Mapping[str, Any], workspace_root: Path
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    asset = workspace_root / "stage_c1_topopt_freeform" / "analysis" / "freeform_1d_reduced_basis_round2_seed49_4_minus1penalty_k91" / "candidate_masks.npz"
    mask = load_candidate_mask(asset, int(config["candidate_id"]))
    upsample = int(config["mask_upsample"])
    base_mask = np.repeat(mask.astype(bool), upsample) if upsample > 1 else mask.astype(bool)
    effective_pixel_nm = config["pixel_size_nm"] / upsample
    variants: Dict[str, np.ndarray] = {"nominal": base_mask}
    for sigma in config["sdf_sigmas_px"]:
        variants["sdf_sigma_{}px".format(sigma)] = sdf_smooth(base_mask, float(sigma) * upsample)
    for bias in config["cd_biases_nm"]:
        variants["cd_{:+.0f}nm".format(bias)] = cd_bias(base_mask, float(bias), effective_pixel_nm)
    variants.update(binary_opening_closing(base_mask, int(config["morphology_radius_px"]) * upsample))
    rows: List[Dict[str, Any]] = []
    target_order = tuple(config["target_order"])

    def record(name: str, result, category: str, value: float) -> None:
        rows.append(
            {
                "variant": name,
                "category": category,
                "perturbation_value": value,
                "target_power": float(result.transmitted_power(target_order)),
                "total_T": float(result.total_T),
                "total_R": float(result.total_R),
                "energy_residual": float(result.energy_residual),
            }
        )

    for name, variant in variants.items():
        epsilon = _epsilon(variant, config["material_index"], 1)
        result = solve_1d_tm(
            epsilon,
            config["height_nm"],
            config["wavelength_nm"],
            config["period_nm"],
            config["incident_index"],
            config["output_index"],
            int(config["half_order"]),
        )
        record(name, result, "geometry", 0.0)
    nominal_epsilon = _epsilon(base_mask, config["material_index"], 1)
    for thickness in config["thicknesses_nm"]:
        result = solve_1d_tm(
            nominal_epsilon,
            float(thickness),
            config["wavelength_nm"],
            config["period_nm"],
            config["incident_index"],
            config["output_index"],
            int(config["half_order"]),
        )
        record("thickness_{:.0f}nm".format(thickness), result, "thickness", float(thickness))
    for material_index in config["material_indices"]:
        epsilon = _epsilon(base_mask, float(material_index), 1)
        result = solve_1d_tm(
            epsilon,
            config["height_nm"],
            config["wavelength_nm"],
            config["period_nm"],
            config["incident_index"],
            config["output_index"],
            int(config["half_order"]),
        )
        record("index_{:.3f}".format(material_index), result, "material_index", float(material_index))
    sidewall = config["sidewall"]
    stack_masks = sidewall_stack(
        base_mask,
        float(sidewall["top_bias_nm"]),
        float(sidewall["bottom_bias_nm"]),
        effective_pixel_nm,
        int(sidewall["layers"]),
    )
    profiles = [
        _epsilon(layer, config["material_index"], 1)
        for layer in stack_masks
    ]
    result = solve_multilayer_1d(
        profiles,
        [config["height_nm"] / len(profiles)] * len(profiles),
        config["wavelength_nm"],
        config["period_nm"],
        config["incident_index"],
        config["output_index"],
        int(config["half_order"]),
        polarization="tm",
    )
    record("three_layer_sidewall", result, "sidewall", float(sidewall["top_bias_nm"]))
    powers = np.asarray([row["target_power"] for row in rows], dtype=np.float64)
    nominal_power = next(row["target_power"] for row in rows if row["variant"] == "nominal")
    summary = {
        "candidate_id": int(config["candidate_id"]),
        "variants": len(rows),
        "nominal_target_power": nominal_power,
        "mean_target_power": float(np.mean(powers)),
        "minimum_target_power": float(np.min(powers)),
        "p10_target_power": float(np.quantile(powers, 0.1)),
        "maximum_absolute_change": float(np.max(np.abs(powers - nominal_power))),
        "structured_process_increment_evaluable": False,
    }
    return rows, summary
