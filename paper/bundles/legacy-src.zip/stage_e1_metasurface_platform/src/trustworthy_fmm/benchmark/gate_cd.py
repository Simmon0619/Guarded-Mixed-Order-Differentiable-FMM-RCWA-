"""Public entry point and shared protocol helpers for Gate C/D.

The scientific implementation lives in :mod:`gate_cd_fft`.  Advanced Fourier
factorizations are intentionally absent from this project-facing path and are
retained only by their dedicated supplementary regression benchmarks.
"""

import hashlib
import math
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

import torch


def _float(value: torch.Tensor) -> float:
    return float(value.detach().cpu())


def _validate_square_pixel_grid(config: Mapping[str, Any]) -> Tuple[float, float]:
    """Validate the declared 20 nm square design grid and return ``(dy,dx)``."""
    if "pixel_size_nm" not in config:
        raise ValueError("pixel_size_nm must be declared for the optimization grid")
    lattice = tuple(float(value) for value in config["lattice_nm"])
    shape = tuple(int(value) for value in config["grid_yx"])
    if len(lattice) != 2 or len(shape) != 2:
        raise ValueError("lattice_nm and grid_yx must each contain two values")
    lx, ly = lattice
    ny, nx = shape
    pixel_size = float(config["pixel_size_nm"])
    if lx <= 0 or ly <= 0 or ny <= 0 or nx <= 0 or pixel_size <= 0:
        raise ValueError("lattice, grid shape, and pixel size must be positive")
    pixel_yx = (ly / ny, lx / nx)
    if not all(
        math.isclose(value, pixel_size, rel_tol=0.0, abs_tol=1e-12)
        for value in pixel_yx
    ):
        raise ValueError(
            "grid_yx={} samples lattice_nm={} at (dy,dx)={} nm, not the "
            "declared {} nm square pixels".format(
                list(shape), list(lattice), pixel_yx, pixel_size
            )
        )
    return pixel_yx


def _grid(config: Mapping[str, Any]) -> Tuple[torch.Tensor, torch.Tensor]:
    ny, nx = (int(value) for value in config["grid_yx"])
    return torch.meshgrid(
        torch.arange(ny, dtype=torch.float64),
        torch.arange(nx, dtype=torch.float64),
        indexing="ij",
    )


def _density(config: Mapping[str, Any], kind: str) -> torch.Tensor:
    y, x = _grid(config)
    ny, nx = y.shape
    if kind == "smooth_periodic":
        density = (
            0.48
            + 0.16 * torch.cos(2 * torch.pi * x / nx)
            + 0.11 * torch.sin(2 * torch.pi * y / ny)
            + 0.05 * torch.cos(2 * torch.pi * (x / nx + y / ny))
        )
    elif kind == "soft_ellipse":
        radius = torch.sqrt(
            ((x + 0.5 - nx / 2) / (0.24 * nx)) ** 2
            + ((y + 0.5 - ny / 2) / (0.27 * ny)) ** 2
        )
        density = 0.15 + 0.7 * torch.sigmoid(8.0 * (1.0 - radius))
    elif kind == "symmetric_cross":
        density = 0.5 + 0.18 * torch.cos(4 * torch.pi * x / nx) * torch.cos(
            4 * torch.pi * y / ny
        )
    else:
        raise ValueError("unknown Gate C/D geometry {!r}".format(kind))
    return torch.clamp(density, 0.02, 0.98)


def _directions(config: Mapping[str, Any]) -> List[torch.Tensor]:
    y, x = _grid(config)
    ny, nx = y.shape
    return [
        torch.sin(2 * torch.pi * x / nx + 0.17),
        torch.cos(2 * torch.pi * y / ny + 0.31),
        torch.sin(2 * torch.pi * (x / nx + y / ny) + 0.23),
    ]


def _rms_to_l2_radius(point: torch.Tensor, rms_radius: float) -> float:
    if rms_radius <= 0:
        raise ValueError("RMS radius must be positive")
    return float(rms_radius) * math.sqrt(point.numel())


def _tensor_sha256(tensor: torch.Tensor) -> str:
    canonical = tensor.detach().cpu().contiguous()
    return hashlib.sha256(canonical.numpy().tobytes()).hexdigest()


def _target_slug(target_order: Sequence[int]) -> str:
    def component(value: int) -> str:
        return (
            "p{}".format(value)
            if value > 0
            else "m{}".format(abs(value))
            if value < 0
            else "0"
        )

    return "target_{}_{}".format(
        component(int(target_order[0])), component(int(target_order[1]))
    )


def _target_is_propagating(
    config: Mapping[str, Any], target_order: Sequence[int]
) -> bool:
    theta = math.radians(float(config["theta_deg"]))
    phi = math.radians(float(config["phi_deg"]))
    incident = abs(complex(config["incident_index"]))
    output = abs(complex(config["output_index"]))
    wavelength = float(config["wavelength_nm"])
    lattice_x, lattice_y = (float(value) for value in config["lattice_nm"])
    kx_over_k0 = (
        incident * math.sin(theta) * math.cos(phi)
        + int(target_order[0]) * wavelength / lattice_x
    )
    ky_over_k0 = (
        incident * math.sin(theta) * math.sin(phi)
        + int(target_order[1]) * wavelength / lattice_y
    )
    return kx_over_k0**2 + ky_over_k0**2 <= output**2


def _project_candidate(
    center: torch.Tensor, candidate: torch.Tensor, radius: float
) -> torch.Tensor:
    step = candidate - center
    norm = torch.linalg.vector_norm(step)
    if float(norm) > radius:
        step = step * (radius / norm)
    return torch.clamp(center + step, 0.0, 1.0)


def _apply_design_symmetry(
    config: Mapping[str, Any], density: torch.Tensor
) -> torch.Tensor:
    if bool(config.get("enforce_y_mirror_symmetry", False)):
        density = 0.5 * (density + torch.flip(density, dims=(0,)))
    return density


def _save_density(
    output_dir: Path,
    target_order: Sequence[int],
    method: str,
    density: torch.Tensor,
) -> Dict[str, Any]:
    output_dir.mkdir(parents=True, exist_ok=True)
    path = output_dir / "{}__{}.pt".format(_target_slug(target_order), method)
    canonical = density.detach().cpu().contiguous()
    torch.save(canonical, path)
    return {
        "path": str(path.resolve()),
        "sha256": _tensor_sha256(canonical),
        "shape": list(canonical.shape),
        "dtype": str(canonical.dtype),
        "minimum": _float(torch.min(canonical)),
        "maximum": _float(torch.max(canonical)),
        "mean": _float(torch.mean(canonical)),
        "standard_deviation": _float(torch.std(canonical)),
    }


def _load_density_exact(manifest: Mapping[str, Any]) -> torch.Tensor:
    density = torch.load(str(manifest["path"]), map_location="cpu", weights_only=True)
    if not isinstance(density, torch.Tensor):
        raise TypeError("saved final density must contain a tensor")
    if _tensor_sha256(density) != str(manifest["sha256"]):
        raise RuntimeError("saved final density hash changed before reference scoring")
    return density


def run_gate_cd(
    config: Mapping[str, Any],
    structure_output_dir: Path,
    *,
    mode: Optional[str] = None,
    checkpoint_dir: Optional[Path] = None,
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    from trustworthy_fmm.benchmark.gate_cd_fft import run_gate_cd_fft

    return run_gate_cd_fft(
        config,
        structure_output_dir,
        mode=mode,
        checkpoint_dir=checkpoint_dir,
    )
