"""Patterned observable-gradient audit across order, precision, and direction."""

from typing import Any, Dict, List, Mapping, Tuple

import numpy as np
import torch

from trustworthy_fmm.audit.gradients import (
    directional_derivative_audit,
    objective_and_gradient,
    gradient_cosine,
)
from trustworthy_fmm.solvers.rcwa_1d import solve_1d_te, solve_1d_tm


def _profile(samples: int, dtype: torch.dtype) -> torch.Tensor:
    x = torch.arange(samples, dtype=dtype)
    phase = 2 * torch.pi * x / samples
    return 1.55 + 0.22 * torch.cos(phase) + 0.11 * torch.sin(2 * phase)


def run_patterned_gradient_audit(
    config: Mapping[str, Any]
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    generator = torch.Generator().manual_seed(int(config["seed"]))
    directions64 = [
        torch.randn(config["samples"], dtype=torch.float64, generator=generator)
        for _ in range(config["directions"])
    ]
    rows: List[Dict[str, Any]] = []
    gradients: Dict[Tuple[str, str, int], torch.Tensor] = {}
    max_errors = {"complex64": 0.0, "complex128": 0.0}
    target_order = tuple(config["target_order"])
    for dtype_name in config["dtypes"]:
        complex_dtype = getattr(torch, dtype_name)
        real_dtype = torch.float32 if complex_dtype == torch.complex64 else torch.float64
        point = _profile(config["samples"], real_dtype)
        for polarization in config["polarizations"]:
            solver = solve_1d_te if polarization == "te" else solve_1d_tm
            for half_order in config["half_orders"]:
                def objective(value: torch.Tensor, solver=solver, half_order=half_order) -> torch.Tensor:
                    result = solver(
                        value.to(complex_dtype),
                        config["thickness_nm"],
                        config["wavelength_nm"],
                        config["period_nm"],
                        config["incident_index"],
                        config["output_index"],
                        int(half_order),
                        config["theta_deg"],
                    )
                    return result.transmitted_power(target_order)

                value, gradient = objective_and_gradient(objective, point)
                gradients[(dtype_name, polarization, int(half_order))] = gradient.to(torch.float64)
                for direction_index, direction in enumerate(directions64):
                    audit = directional_derivative_audit(
                        objective,
                        point,
                        direction.to(real_dtype),
                        config["finite_difference_steps"],
                    )
                    max_errors[dtype_name] = max(max_errors[dtype_name], audit.relative_error)
                    rows.append(
                        {
                            "dtype": dtype_name,
                            "polarization": polarization,
                            "half_order": int(half_order),
                            "direction": direction_index,
                            "objective": value,
                            "ad_directional": audit.ad_directional,
                            "best_fd": audit.best_fd,
                            "best_step": audit.best_step,
                            "relative_error": audit.relative_error,
                            "gradient_norm": audit.gradient_norm,
                        }
                    )
    final_cosines: Dict[str, float] = {}
    low_order, high_order = config["half_orders"][-2:]
    for dtype_name in config["dtypes"]:
        for polarization in config["polarizations"]:
            cosine = gradient_cosine(
                gradients[(dtype_name, polarization, int(low_order))],
                gradients[(dtype_name, polarization, int(high_order))],
            )
            final_cosines["{}_{}".format(dtype_name, polarization)] = cosine
            rows.append(
                {
                    "dtype": dtype_name,
                    "polarization": polarization,
                    "half_order": "{}->{}".format(low_order, high_order),
                    "direction": "cross_fidelity",
                    "gradient_cosine": cosine,
                }
            )
    thresholds = config["thresholds"]
    summary = {
        "directions_per_case": int(config["directions"]),
        "max_complex128_directional_error": max_errors["complex128"],
        "max_complex64_directional_error": max_errors["complex64"],
        "minimum_final_gradient_cosine": min(final_cosines.values()),
        "complex128_directional_pass": max_errors["complex128"] <= thresholds["complex128_directional_error"],
        "complex64_directional_pass": max_errors["complex64"] <= thresholds["complex64_directional_error"],
        "final_gradient_cosine_pass": min(final_cosines.values()) >= thresholds["final_gradient_cosine"],
        "cosines": final_cosines,
    }
    return rows, summary

