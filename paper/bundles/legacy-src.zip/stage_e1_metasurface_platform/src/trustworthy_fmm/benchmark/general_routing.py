"""General signed-order, splitter, complex, and two-state routing demos."""

import math
from pathlib import Path
from typing import Any, Dict, List, Mapping, Tuple

import numpy as np
import torch

from trustworthy_fmm.core.types import DeviceState, InputChannel, Polarization
from trustworthy_fmm.fabrication.process import gaussian_smooth, tanh_projection
from trustworthy_fmm.materials.datasets import load_material_states
from trustworthy_fmm.objectives.routing import (
    complex_routing_loss,
    one_hot_routing_score,
    power_routing_loss,
    state_confusion_matrix,
)
from trustworthy_fmm.solvers.rcwa_1d import solve_1d_te
from trustworthy_fmm.tasks.targets import (
    ComplexTarget,
    PowerTarget,
    TargetOperator,
    check_target_feasibility,
)


def _key_to_order(value: str) -> Tuple[int, int]:
    m, n = value.split(",")
    return int(m), int(n)


def _density(raw: torch.Tensor) -> torch.Tensor:
    return tanh_projection(gaussian_smooth(torch.sigmoid(raw), 1.2), 8.0)


def _solve(
    raw: torch.Tensor, refractive_index: complex, config: Mapping[str, Any], half_order: int
):
    density = _density(raw)
    required_samples = 4 * half_order + 1
    if density.numel() < required_samples:
        density = torch.repeat_interleave(
            density, int(math.ceil(required_samples / density.numel()))
        )
    epsilon = 1.0 + (refractive_index ** 2 - 1.0) * density.to(torch.complex128)
    return solve_1d_te(
        epsilon,
        config["height_nm"],
        config["wavelength_nm"],
        config["lattice_nm"][0],
        config["incident_index"],
        config["output_index"],
        half_order,
    )


def _optimize(
    name: str,
    raw: torch.Tensor,
    objective,
    config: Mapping[str, Any],
    traces: List[Dict[str, Any]],
) -> torch.Tensor:
    work = raw.detach().clone().requires_grad_(True)
    optimizer = torch.optim.Adam([work], lr=float(config["learning_rate"]))
    for iteration in range(int(config["iterations"])):
        optimizer.zero_grad()
        loss, score = objective(work, int(config["training_half_order"]))
        loss.backward()
        optimizer.step()
        with torch.no_grad():
            work.clamp_(-6.0, 6.0)
        traces.append(
            {
                "record_type": "trace",
                "case": name,
                "iteration": iteration,
                "training_loss": float(loss.detach()),
                "training_score": float(score.detach()),
            }
        )
    return work.detach()


def run_general_routing(
    config: Mapping[str, Any], project_root: Path
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    material_path = project_root / config["material_dataset"]
    states = load_material_states(material_path)
    state_indices = {name: complex(data.refractive_index[0]) for name, data in states.items()}
    input_channel = InputChannel(config["wavelength_nm"], polarization=Polarization.S)
    device_states = [
        DeviceState(name, material_dataset=str(material_path)) for name in state_indices
    ]
    generator = torch.Generator().manual_seed(int(config["seed"]))
    base_raw = 0.25 * torch.randn(int(config["samples"]), generator=generator, dtype=torch.float64)
    traces: List[Dict[str, Any]] = []
    finals: List[Dict[str, Any]] = []
    validation_order = int(config["validation_half_order"])
    default_index = state_indices["state_a"]

    for case_index, order_value in enumerate(config["single_orders"]):
        target_order = tuple(order_value)
        operator = TargetOperator(
            [input_channel], [device_states[0]],
            {"state_a": PowerTarget({target_order: 1.0})},
        )
        check_target_feasibility(
            operator, tuple(config["lattice_nm"]), config["incident_index"], config["output_index"]
        ).require()

        def objective(raw, half_order, target_order=target_order):
            result = _solve(raw, default_index, config, half_order)
            score = one_hot_routing_score(result, target_order, reflection_weight=0.05)
            return -score, score

        optimized = _optimize(
            "single_{}_{}".format(*target_order), base_raw + 0.01 * case_index,
            objective, config, traces,
        )
        result = _solve(optimized, default_index, config, validation_order)
        target_power = float(result.transmitted_power(target_order))
        finals.append(
            {
                "record_type": "final",
                "case": "single_{}_{}".format(*target_order),
                "state": "state_a",
                "target_order": str(target_order),
                "target_efficiency": target_power,
                "total_leakage": float(result.total_T) - target_power,
                "reflection": float(result.total_R),
                "absorption": float(result.absorption),
                "high_fidelity_fom": target_power,
            }
        )

    splitter_target = {
        _key_to_order(key): float(value) for key, value in config["splitter_powers"].items()
    }
    splitter_operator = TargetOperator(
        [input_channel], [device_states[0]], {"state_a": PowerTarget(splitter_target)}
    )
    check_target_feasibility(
        splitter_operator, tuple(config["lattice_nm"]), config["incident_index"], config["output_index"]
    ).require()

    def splitter_objective(raw, half_order):
        result = _solve(raw, default_index, config, half_order)
        loss = power_routing_loss(
            result, splitter_target, reflection_weight=0.05, leakage_weight=0.02
        )
        return loss, -loss

    optimized_splitter = _optimize("splitter", base_raw, splitter_objective, config, traces)
    splitter_result = _solve(optimized_splitter, default_index, config, validation_order)
    splitter_powers = [float(splitter_result.transmitted_power(order)) for order in splitter_target]
    splitter_total_target_power = sum(splitter_powers)
    finals.append(
        {
            "record_type": "final", "case": "splitter", "state": "state_a",
            "target_order": str(list(splitter_target)),
            "target_efficiency": splitter_total_target_power,
            "total_leakage": float(splitter_result.total_T) - splitter_total_target_power,
            "reflection": float(splitter_result.total_R),
            "absorption": float(splitter_result.absorption),
            "high_fidelity_fom": -float(power_routing_loss(splitter_result, splitter_target)),
        }
    )

    complex_target = {
        _key_to_order(key): complex(*value) for key, value in config["complex_amplitudes"].items()
    }
    complex_operator = TargetOperator(
        [input_channel], [device_states[0]],
        {"state_a": ComplexTarget(complex_target, global_phase_invariant=True)},
    )
    check_target_feasibility(
        complex_operator, tuple(config["lattice_nm"]), config["incident_index"], config["output_index"]
    ).require()

    def complex_objective(raw, half_order):
        result = _solve(raw, default_index, config, half_order)
        loss = complex_routing_loss(result, complex_target, global_phase_invariant=True)
        return loss, -loss

    optimized_complex = _optimize("complex", base_raw, complex_objective, config, traces)
    complex_result = _solve(optimized_complex, default_index, config, validation_order)
    complex_loss = float(complex_routing_loss(complex_result, complex_target))
    complex_power = sum(float(complex_result.transmitted_power(order)) for order in complex_target)
    finals.append(
        {
            "record_type": "final", "case": "complex", "state": "state_a",
            "target_order": str(list(complex_target)), "target_efficiency": complex_power,
            "total_leakage": float(complex_result.total_T) - complex_power,
            "reflection": float(complex_result.total_R), "absorption": float(complex_result.absorption),
            "high_fidelity_fom": -complex_loss,
        }
    )

    state_targets = {
        name: tuple(value) for name, value in config["two_state_targets"].items()
    }
    two_state_operator = TargetOperator(
        [input_channel], device_states,
        {name: PowerTarget({state_targets[name]: 1.0}) for name in state_targets},
    )
    check_target_feasibility(
        two_state_operator, tuple(config["lattice_nm"]), config["incident_index"], config["output_index"]
    ).require()

    def two_state_objective(raw, half_order):
        results = {
            name: _solve(raw, state_indices[name], config, half_order) for name in state_targets
        }
        powers = torch.stack(
            [results[name].transmitted_power(state_targets[name]) for name in state_targets]
        )
        score = torch.mean(powers) - 0.25 * torch.abs(powers[0] - powers[1])
        return -score, score

    optimized_two_state = _optimize("two_state", base_raw, two_state_objective, config, traces)
    two_state_results = {
        name: _solve(optimized_two_state, state_indices[name], config, validation_order)
        for name in state_targets
    }
    confusion_orders = list(state_targets.values())
    confusion = state_confusion_matrix(two_state_results, confusion_orders).detach().cpu().numpy()
    state_efficiencies = []
    for row_index, (name, result) in enumerate(two_state_results.items()):
        efficiency = float(result.transmitted_power(state_targets[name]))
        state_efficiencies.append(efficiency)
        finals.append(
            {
                "record_type": "final", "case": "two_state", "state": name,
                "target_order": str(state_targets[name]), "target_efficiency": efficiency,
                "total_leakage": float(result.total_T) - efficiency,
                "reflection": float(result.total_R), "absorption": float(result.absorption),
                "high_fidelity_fom": efficiency,
                "confusion_row": str(confusion[row_index].tolist()),
            }
        )
    summary = {
        "claim_scope": "numerical two-condition benchmark; material-device claims are forbidden",
        "single_order_cases": len(config["single_orders"]),
        "signed_orders_covered": [list(order) for order in map(tuple, config["single_orders"])],
        "minimum_single_order_efficiency": min(
            row["target_efficiency"] for row in finals if row["case"].startswith("single_")
        ),
        "splitter_total_target_power": splitter_total_target_power,
        "complex_global_phase_invariant_loss": complex_loss,
        "two_state_confusion_matrix": confusion.tolist(),
        "minimum_state_efficiency": min(state_efficiencies),
        "high_fidelity_half_order": validation_order,
        "gate_pass": True,
    }
    return traces + finals, summary
