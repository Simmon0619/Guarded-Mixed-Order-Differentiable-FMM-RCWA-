"""Publication-oriented figures for Gate E manufacturing risk."""

from pathlib import Path
from typing import Any, Dict, Mapping, Sequence

import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
import torch


METHODS = ("nominal", "mean", "mean_lcvar")
METHOD_LABELS = {
    "nominal": "Nominal",
    "mean": "Mean robust",
    "mean_lcvar": "Mean–LCVaR",
}


def _save(figure: Any, stem: Path) -> Dict[str, str]:
    stem.parent.mkdir(parents=True, exist_ok=True)
    outputs = {}
    for suffix in ("png", "pdf", "svg"):
        path = stem.with_suffix("." + suffix)
        figure.savefig(
            path,
            dpi=320 if suffix == "png" else None,
            bbox_inches="tight",
            pad_inches=0.04,
        )
        outputs[suffix] = str(path.resolve())
    plt.close(figure)
    return outputs


def plot_gate_e_tail_distributions(
    rows: Sequence[Mapping[str, Any]],
    summary: Mapping[str, Any],
    output_stem: Path,
) -> Dict[str, str]:
    held = [row for row in rows if row.get("stage") == "held_out_hard_audit"]
    targets = [tuple(entry["target_order"]) for entry in summary["per_target"].values()]
    colors = plt.get_cmap("tab10").colors
    figure, axes = plt.subplots(1, len(targets), figsize=(4.0 * len(targets), 3.6), sharey=True)
    axes = np.atleast_1d(axes)
    for axis, target in zip(axes, targets):
        distributions = []
        nominal_values = []
        for method in METHODS:
            selected = [
                row
                for row in held
                if tuple(row["target_order"]) == target and row["method"] == method
            ]
            distributions.append([float(row["hard_target_efficiency"]) for row in selected])
            nominal_values.append(
                next(
                    float(row["hard_target_efficiency"])
                    for row in selected
                    if row["category"] == "nominal"
                )
            )
        boxes = axis.boxplot(
            distributions,
            positions=np.arange(len(METHODS)),
            widths=0.58,
            patch_artist=True,
            showfliers=True,
        )
        for index, patch in enumerate(boxes["boxes"]):
            patch.set_facecolor(colors[index])
            patch.set_alpha(0.28)
            patch.set_edgecolor(colors[index])
        for index, value in enumerate(nominal_values):
            axis.scatter(index, value, marker="D", s=36, color=colors[index], zorder=5)
        axis.set_xticks(np.arange(len(METHODS)))
        axis.set_xticklabels([METHOD_LABELS[m] for m in METHODS], rotation=18, ha="right")
        axis.set_title("Target ({:+d},{:+d})".format(*target))
        axis.grid(True, axis="y", color="0.88", linewidth=0.6)
        axis.set_ylim(bottom=0.0)
    axes[0].set_ylabel("Held-out hard target diffraction efficiency")
    title = "Manufacturing distribution: box = blind catalog, diamond = nominal"
    if not bool(summary.get("reference_validations_pass", False)):
        title = "Diagnostic only—critical N=6→7 checks failed\n" + title
    figure.suptitle(title, fontsize=11)
    figure.subplots_adjust(left=0.07, right=0.99, top=0.84, bottom=0.23, wspace=0.10)
    return _save(figure, output_stem)


def plot_gate_e_nominal_tail_pareto(
    summary: Mapping[str, Any], output_stem: Path
) -> Dict[str, str]:
    colors = plt.get_cmap("tab10").colors
    markers = ("o", "s", "^")
    figure, axis = plt.subplots(figsize=(5.4, 4.3))
    for target_index, target in enumerate(summary["per_target"].values()):
        for method_index, method in enumerate(METHODS):
            stats = target["methods"][method]["evaluation"]["statistics"]
            axis.scatter(
                stats["nominal"],
                stats["lower_tail_cvar"],
                color=colors[method_index],
                marker=markers[target_index % len(markers)],
                s=62,
                edgecolor="white",
                linewidth=0.7,
                zorder=4,
            )
    axis.set_xlabel("Nominal hard target diffraction efficiency")
    axis.set_ylabel("Held-out lower-tail CVaR")
    axis.grid(True, color="0.88", linewidth=0.6)
    axis.set_xlim(left=0.0)
    axis.set_ylim(bottom=0.0)
    title = "Nominal–tail Pareto audit (higher is better)"
    if not bool(summary.get("reference_validations_pass", False)):
        title = "Diagnostic only—critical N=6→7 checks failed\n" + title
    axis.set_title(title)
    method_handles = [
        Patch(facecolor=colors[index], label=METHOD_LABELS[method])
        for index, method in enumerate(METHODS)
    ]
    target_handles = [
        Line2D(
            [0],
            [0],
            marker=markers[index % len(markers)],
            linestyle="none",
            color="0.2",
            markersize=7,
            label="Target ({:+d},{:+d})".format(*target["target_order"]),
        )
        for index, target in enumerate(summary["per_target"].values())
    ]
    method_legend = axis.legend(
        handles=method_handles, frameon=False, loc="upper left", title="Objective"
    )
    axis.add_artist(method_legend)
    axis.legend(
        handles=target_handles, frameon=False, loc="lower right", title="Diffraction order"
    )
    figure.tight_layout()
    return _save(figure, output_stem)


def plot_gate_e_relaxation_audit(
    rows: Sequence[Mapping[str, Any]],
    output_stem: Path,
    summary: Mapping[str, Any] = None,
) -> Dict[str, str]:
    held = [row for row in rows if row.get("stage") == "held_out_hard_audit"]
    colors = plt.get_cmap("tab10").colors
    figure, axis = plt.subplots(figsize=(5.0, 4.4))
    all_values = []
    for method_index, method in enumerate(METHODS):
        selected = [row for row in held if row["method"] == method]
        soft = np.asarray(
            [float(row["soft_surrogate_target_efficiency"]) for row in selected]
        )
        hard = np.asarray([float(row["hard_target_efficiency"]) for row in selected])
        all_values.extend(soft.tolist())
        all_values.extend(hard.tolist())
        axis.scatter(
            soft,
            hard,
            s=24,
            alpha=0.58,
            color=colors[method_index],
            label=METHOD_LABELS[method],
        )
    maximum = max(all_values) if all_values else 1.0
    axis.plot([0, maximum], [0, maximum], color="0.3", linestyle="--", linewidth=1.0)
    axis.set_xlim(0.0, maximum * 1.04)
    axis.set_ylim(0.0, maximum * 1.04)
    axis.set_xlabel("Soft process surrogate efficiency")
    axis.set_ylabel("Hard process efficiency")
    title = "Relaxation audit: soft prediction versus hard morphology"
    if summary is not None and not bool(summary.get("reference_validations_pass", False)):
        title = "Diagnostic only—critical N=6→7 checks failed\n" + title
    axis.set_title(title)
    axis.grid(True, color="0.9", linewidth=0.55)
    axis.legend(frameon=False)
    figure.tight_layout()
    return _save(figure, output_stem)


def plot_gate_e_binary_structures(
    summary: Mapping[str, Any], output_stem: Path
) -> Dict[str, str]:
    """Plot the nine frozen nominal hard masks selected before blind scoring."""
    targets = list(summary["per_target"].values())
    physics = summary["physics"]
    period_x_um = float(physics["lattice_nm"][0]) / 1000.0
    period_y_um = float(physics["lattice_nm"][1]) / 1000.0
    figure, axes = plt.subplots(
        len(targets),
        len(METHODS),
        figsize=(3.5 * len(METHODS), 2.45 * len(targets) + 0.7),
        squeeze=False,
    )
    for row_index, target in enumerate(targets):
        for column_index, method in enumerate(METHODS):
            axis = axes[row_index, column_index]
            record = target["methods"][method]
            mask = torch.load(
                record["nominal_binary_mask"]["path"],
                map_location="cpu",
                weights_only=True,
            ).numpy()
            axis.imshow(
                mask,
                origin="lower",
                interpolation="nearest",
                cmap="gray_r",
                vmin=0.0,
                vmax=1.0,
                extent=(0.0, period_x_um, 0.0, period_y_um),
                aspect="auto",
            )
            iteration = int(
                record["optimization"]["selected_hard_audit_iteration"]
            )
            axis.text(
                0.02,
                0.96,
                "fill={:.1%}; selected={}".format(
                    float(mask.mean()), "initial" if iteration < 0 else iteration
                ),
                transform=axis.transAxes,
                ha="left",
                va="top",
                fontsize=7,
                color="tab:red",
                bbox={"facecolor": "white", "alpha": 0.78, "edgecolor": "none"},
            )
            if row_index == 0:
                axis.set_title(METHOD_LABELS[method])
            if column_index == 0:
                axis.set_ylabel(
                    "Target ({:+d},{:+d})\ny [µm]".format(*target["target_order"])
                )
            else:
                axis.tick_params(labelleft=False)
            if row_index == len(targets) - 1:
                axis.set_xlabel("x [µm]")
            else:
                axis.tick_params(labelbottom=False)
    title = "Frozen nominal hard masks selected before held-out scoring"
    if not bool(summary.get("reference_validations_pass", False)):
        title = "Diagnostic only—critical N=6→7 checks failed\n" + title
    figure.suptitle(title, fontsize=11)
    figure.subplots_adjust(left=0.08, right=0.99, top=0.88, bottom=0.08, hspace=0.18, wspace=0.08)
    return _save(figure, output_stem)
