"""Plots for anisotropic FFT Gate C/D evidence."""

from pathlib import Path
from typing import Any, Mapping, Sequence

import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from trustworthy_fmm.benchmark.gate_cd import _target_slug


METHODS = ("fixed_M", "fixed_H", "order_continuation", "FOC-TR", "MGDA-TR")
METHOD_LABELS = {
    "fixed_M": "Fixed M",
    "fixed_H": "Fixed H",
    "order_continuation": "Continuation",
    "FOC-TR": "FOC-TR",
    "MGDA-TR": "MGDA-TR",
}


def _save(figure: Any, output_stem: Path) -> None:
    output_stem.parent.mkdir(parents=True, exist_ok=True)
    for suffix in ("png", "pdf", "svg"):
        figure.savefig(
            output_stem.with_suffix("." + suffix),
            dpi=320 if suffix == "png" else None,
            bbox_inches="tight",
            pad_inches=0.05,
        )


def plot_value_gradient_separation(
    rows: Sequence[Mapping[str, Any]],
    summary: Mapping[str, Any],
    output_stem: Path,
) -> None:
    """Plot value error and gradient cosine against retained mode count."""
    ladder = summary["gate_c"]["gradient_convergence_ladder"]
    ladder_rows = [
        row for row in rows
        if row.get("gate") == "C_ladder" and row.get("family") == "anisotropic"
    ]
    if not ladder_rows:
        raise ValueError("Gate C anisotropic ladder records are required")
    cases = list(dict.fromkeys(str(row["case"]) for row in ladder_rows))
    targets = [tuple(value) for value in ladder["target_orders"]]
    figure, axes = plt.subplots(
        len(targets), len(cases),
        figsize=(3.55 * len(cases), 2.55 * len(targets)),
        squeeze=False,
    )
    for row_index, target in enumerate(targets):
        for column_index, case in enumerate(cases):
            axis = axes[row_index][column_index]
            entries = sorted(
                (
                    row for row in ladder_rows
                    if str(row["case"]) == case
                    and tuple(row["target_order"]) == target
                ),
                key=lambda row: int(row["mode_count"]),
            )
            modes = [int(row["mode_count"]) for row in entries]
            value_error = [
                100.0 * float(row["objective_relative_error_to_reference"])
                for row in entries
            ]
            cosine = [float(row["gradient_cosine_to_reference"]) for row in entries]
            labels = ["({},{})".format(*row["half_orders"]) for row in entries]
            axis.semilogy(modes, value_error, "o-", color="tab:blue", label="value error [%]")
            axis.axhline(
                100.0 * float(ladder["value_relative_tolerance"]),
                color="tab:blue", linestyle=":", linewidth=1,
            )
            twin = axis.twinx()
            twin.plot(modes, cosine, "s-", color="tab:orange", label="gradient cosine")
            twin.axhline(
                float(ladder["gradient_cosine_tolerance"]),
                color="tab:orange", linestyle=":", linewidth=1,
            )
            twin.set_ylim(-1.05, 1.05)
            for x, label in zip(modes, labels):
                axis.annotate(label, (x, axis.get_ylim()[0]), xytext=(0, 3), textcoords="offset points", ha="center", fontsize=6.5)
            axis.set_title("{}  target ({:+d},{:+d})".format(case, *target))
            axis.set_xlabel("retained Fourier modes")
            axis.set_ylabel("value error [%]", color="tab:blue")
            twin.set_ylabel("gradient cosine", color="tab:orange")
            axis.grid(True, color="0.9", linewidth=0.6)
    reference = summary["gate_c"]["working_fidelities"]["reference_half_orders"]
    figure.suptitle(
        "FFT baseline: value convergence does not certify gradients; R=({},{})".format(*reference),
        y=1.01,
    )
    figure.tight_layout()
    _save(figure, output_stem)
    plt.close(figure)


def plot_gate_d_reference_comparison(
    summary: Mapping[str, Any], output_stem: Path
) -> None:
    """Compare multi-seed median final reference objectives."""
    target_entries = list(summary["gate_d"]["per_target"].values())
    if not target_entries:
        return
    x = np.arange(len(target_entries), dtype=float)
    width = 0.16
    figure, axis = plt.subplots(figsize=(8.4, 4.0))
    colors = plt.get_cmap("tab10").colors
    for index, method in enumerate(METHODS):
        values = [
            float(entry["aggregates"][method]["median_final_reference_objective"])
            for entry in target_entries
        ]
        axis.bar(
            x + (index - 2) * width,
            values,
            width=0.92 * width,
            label=METHOD_LABELS[method],
            color=colors[index],
        )
    axis.set_xticks(x)
    axis.set_xticklabels(
        ["({:+d},{:+d})".format(*entry["target_order"]) for entry in target_entries]
    )
    reference = summary["gate_d"]["optimization_fidelity"]["reference_half_orders"]
    axis.set_ylabel("median target power at R=({},{})".format(*reference))
    axis.set_xlabel("target diffraction order")
    axis.grid(True, axis="y", color="0.88", linewidth=0.6)
    axis.legend(ncol=3, frameon=False, loc="upper center", bbox_to_anchor=(0.5, -0.18))
    axis.set_title(
        "{}-seed pilot (FOC-TR primary; MGDA-TR secondary)".format(
            len(summary["gate_d"]["seeds"])
        )
    )
    figure.tight_layout()
    _save(figure, output_stem)
    plt.close(figure)


def plot_gate_d_anytime(
    rows: Sequence[Mapping[str, Any]],
    summary: Mapping[str, Any],
    output_stem: Path,
) -> None:
    """Plot certified reference objective against high-equivalent cost."""
    anytime = [row for row in rows if row.get("gate") == "D_anytime"]
    targets = [tuple(value) for value in summary["gate_d"]["target_orders"]]
    if not anytime or not targets:
        return
    figure, axes = plt.subplots(1, len(targets), figsize=(4.0 * len(targets), 3.5), squeeze=False)
    colors = plt.get_cmap("tab10").colors
    for target_index, target in enumerate(targets):
        axis = axes[0][target_index]
        for method_index, method in enumerate(METHODS):
            seed_curves = []
            for seed in summary["gate_d"]["seeds"]:
                entries = sorted(
                    (
                        row for row in anytime
                        if tuple(row["target_order"]) == target
                        and row["method"] == method
                        and int(row["seed"]) == int(seed)
                    ),
                    key=lambda row: float(row["high_equivalent_cost"]),
                )
                if entries:
                    seed_curves.append(entries)
                    axis.plot(
                        [float(row["high_equivalent_cost"]) for row in entries],
                        [float(row["reference_objective"]) for row in entries],
                        color=colors[method_index], alpha=0.18, linewidth=0.8,
                    )
            if seed_curves:
                aggregate = summary["gate_d"]["per_target"][_target_slug(target)][
                    "aggregates"
                ][method]
                aggregate_cost = float(
                    aggregate["median_cost_to_fixed_high_98_percent"]
                )
                if np.isfinite(aggregate_cost):
                    axis.scatter(
                        [aggregate_cost],
                        [aggregate["median_final_reference_objective"]],
                        color=colors[method_index], label=METHOD_LABELS[method], s=22,
                    )
                else:
                    axis.plot([], [], color=colors[method_index], label=METHOD_LABELS[method])
        axis.set_title("target ({:+d},{:+d})".format(*target))
        axis.set_xlabel("high-equivalent cost")
        axis.set_ylabel("certified reference objective")
        axis.grid(True, color="0.9", linewidth=0.6)
    axes[0][0].legend(frameon=False, fontsize=7)
    figure.tight_layout()
    _save(figure, output_stem)
    plt.close(figure)
