"""High-order convergence sweep + prior re-checks.

Headline 9 (E19 bh/rs finals + frozen parents):
    1x grid: (24,6), (28,7); 2x grid: (24,6), (28,7), (32,8), (40,10), (48,12).
Population 18 (frozen torcwa_M12 + certified, 3 targets x 3 seeds):
    (12,3)@1x, (24,6)@1x, (40,10)@2x  -> cheap-model bias/MAD vs old and new
    references.
c128/CPU spot-check at (32,8)@2x on two designs bounds the c64 error at high
order.  Engine: ours GPU/c64 by default; E20_ENGINE=torcwa switches (same call
shape).

    python e20_convergence.py         # writes ../data/convergence.json
"""
import json
import os
import time

import torch

from e20_common import (C, DATA, THREADS, load_e19_binary,
                        load_frozen_binary, ours_eta, torcwa_eta, upsample)

ENGINE = os.environ.get("E20_ENGINE", "ours")
eta = ours_eta if ENGINE == "ours" else torcwa_eta
DT = torch.complex64
DEV = "cuda"

HEADLINE = [
    ("1_0_bh", (1, 0), "e19", "1_0_bh_final"),
    ("2_0_bh", (2, 0), "e19", "2_0_bh_final"),
    ("3_0_bh", (3, 0), "e19", "3_0_bh_final"),
    ("1_0_rs", (1, 0), "e19", "1_0_rs_final"),
    ("2_0_rs", (2, 0), "e19", "2_0_rs_final"),
    ("3_0_rs", (3, 0), "e19", "3_0_rs_final"),
    ("1_0_parent", (1, 0), "frozen", "1_0_2031_certified_screened_latent.npy"),
    ("2_0_parent", (2, 0), "frozen", "2_0_2030_torcwa_M12_latent.npy"),
    ("3_0_parent", (3, 0), "frozen", "3_0_2029_torcwa_M12_latent.npy"),
]
LADDER_1X = [(24, 6), (28, 7)]
LADDER_2X = [(24, 6), (28, 7), (32, 8), (40, 10), (48, 12)]
SPOT_C128 = ["2_0_bh", "2_0_parent"]     # (32,8)@2x on CPU/c128


def load(kind, name):
    return (load_e19_binary(name) if kind == "e19"
            else load_frozen_binary(name))


def main():
    torch.set_num_threads(THREADS)
    t_start = time.perf_counter()
    out = {"engine": ENGINE, "headline": [], "population": [],
           "spot_c128": []}

    # ---- headline ladder ---------------------------------------------------
    for tag, tgt, kind, name in HEADLINE:
        b1 = load(kind, name)
        b2 = upsample(b1, 2)
        row = {"tag": tag, "target": list(tgt), "levels": {}}
        for lv in LADDER_1X:
            row["levels"]["%s@1x" % (lv,)] = eta(b1, lv, tgt, DT, DEV)
        for lv in LADDER_2X:
            row["levels"]["%s@2x" % (lv,)] = eta(b2, lv, tgt, DT, DEV)
        out["headline"].append(row)
        ls = row["levels"]
        print("%-12s 24@1x %.4f  28@1x %.4f | 24@2x %.4f  28@2x %.4f  "
              "32@2x %.4f  40@2x %.4f  48@2x %.4f   [%.0f s]"
              % (tag, ls["(24, 6)@1x"], ls["(28, 7)@1x"], ls["(24, 6)@2x"],
                 ls["(28, 7)@2x"], ls["(32, 8)@2x"], ls["(40, 10)@2x"],
                 ls["(48, 12)@2x"], time.perf_counter() - t_start),
              flush=True)

    # ---- c128 spot check ---------------------------------------------------
    for tag, tgt, kind, name in HEADLINE:
        if tag not in SPOT_C128:
            continue
        b2 = upsample(load(kind, name), 2)
        v64 = next(r for r in out["headline"]
                   if r["tag"] == tag)["levels"]["(32, 8)@2x"]
        v128 = ours_eta(b2, (32, 8), tgt, torch.complex128, "cpu")
        out["spot_c128"].append({"tag": tag, "eta_c64": v64,
                                 "eta_c128": v128,
                                 "rel": abs(v64 - v128) / max(v128, 1e-12)})
        print("spot c128 %s (32,8)@2x: c64 %.6f vs c128 %.6f (rel %.1e)"
              % (tag, v64, v128, out["spot_c128"][-1]["rel"]), flush=True)

    # ---- population: cheap-model error vs old and new references ----------
    for m in (1, 2, 3):
        for seed in (2029, 2030, 2031):
            for arm in ("torcwa_M12", "certified"):
                name = "%d_0_%d_%s_latent.npy" % (m, seed, arm)
                tgt = (m, 0)
                b1 = load_frozen_binary(name)
                b2 = upsample(b1, 2)
                e12 = eta(b1, (12, 3), tgt, DT, DEV)
                e24 = eta(b1, (24, 6), tgt, DT, DEV)
                e40 = eta(b2, (40, 10), tgt, DT, DEV)
                out["population"].append(
                    {"name": name, "target": list(tgt),
                     "eta_12_3": e12, "eta_24_6_1x": e24,
                     "eta_40_10_2x": e40})
                print("pop %-34s (12,3) %.4f  (24,6) %.4f  (40,10) %.4f"
                      "   [%.0f s]" % (name, e12, e24, e40,
                                       time.perf_counter() - t_start),
                      flush=True)

    # ---- summary statistics ------------------------------------------------
    def med(v):
        s = sorted(v)
        return s[len(s) // 2]

    pop = out["population"]
    rel_old = [(p["eta_12_3"] - p["eta_24_6_1x"]) / max(p["eta_24_6_1x"], 1e-9)
               for p in pop]
    rel_new = [(p["eta_12_3"] - p["eta_40_10_2x"])
               / max(p["eta_40_10_2x"], 1e-9) for p in pop]
    ref_drift = [(p["eta_40_10_2x"] - p["eta_24_6_1x"])
                 / max(p["eta_24_6_1x"], 1e-9) for p in pop]
    summary = {
        "cheap_vs_24_6_median": med(rel_old),
        "cheap_vs_24_6_mad": med([abs(x - med(rel_old)) for x in rel_old]),
        "cheap_vs_40_10_median": med(rel_new),
        "cheap_vs_40_10_mad": med([abs(x - med(rel_new)) for x in rel_new]),
        "ref_24_to_40_median": med(ref_drift),
        "ref_24_to_40_p10_p90": [sorted(ref_drift)[1],
                                 sorted(ref_drift)[-2]],
    }
    # headline drift + per-target ranking at each reference
    for r in out["headline"]:
        ls = r["levels"]
        r["drift_28_1x_to_40_2x"] = (ls["(40, 10)@2x"] - ls["(28, 7)@1x"]) \
            / max(ls["(28, 7)@1x"], 1e-9)
        r["drift_40_to_48"] = (ls["(48, 12)@2x"] - ls["(40, 10)@2x"]) \
            / max(ls["(40, 10)@2x"], 1e-9)
        r["grid_effect_28"] = (ls["(28, 7)@2x"] - ls["(28, 7)@1x"]) \
            / max(ls["(28, 7)@1x"], 1e-9)
    ranking = {}
    for tstr in ("(1, 0)", "(2, 0)", "(3, 0)"):
        sub = {r["tag"]: r["levels"] for r in out["headline"]
               if str(tuple(r["target"])) == tstr}
        ranking[tstr] = {
            lvk: sorted(sub, key=lambda t: -sub[t][lvk])
            for lvk in ("(28, 7)@1x", "(40, 10)@2x", "(48, 12)@2x")}
    summary["ranking"] = ranking
    out["summary"] = summary

    with open(os.path.join(DATA, "convergence.json"), "w") as f:
        json.dump(out, f, indent=1)
    print()
    print("cheap (12,3) error: vs (24,6)@1x median %+.1f%% MAD %.1f%% | "
          "vs (40,10)@2x median %+.1f%% MAD %.1f%%"
          % (100 * summary["cheap_vs_24_6_median"],
             100 * summary["cheap_vs_24_6_mad"],
             100 * summary["cheap_vs_40_10_median"],
             100 * summary["cheap_vs_40_10_mad"]))
    print("reference drift (24,6)@1x -> (40,10)@2x: median %+.1f%%  "
          "p10/p90 %+.1f%%/%+.1f%%"
          % (100 * summary["ref_24_to_40_median"],
             100 * summary["ref_24_to_40_p10_p90"][0],
             100 * summary["ref_24_to_40_p10_p90"][1]))
    for tstr, rk in ranking.items():
        print("ranking %s: 28@1x %s | 40@2x %s | 48@2x %s"
              % (tstr, rk["(28, 7)@1x"], rk["(40, 10)@2x"],
                 rk["(48, 12)@2x"]))
    print("wrote convergence.json  (%.0f s total)"
          % (time.perf_counter() - t_start))


if __name__ == "__main__":
    main()
