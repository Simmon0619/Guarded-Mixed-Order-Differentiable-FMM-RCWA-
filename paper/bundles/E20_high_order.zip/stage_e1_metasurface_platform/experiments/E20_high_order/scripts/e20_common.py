"""E20 wiring: high-order evaluation on upsampled grids, two engines.

The delivered structures are piecewise-constant on the frozen 35x120 grid
(20 nm pixels).  ``upsample(mask, k)`` block-replicates to a k-times finer
grid, which represents the IDENTICAL physical permittivity; only the DFT
aliasing sum changes.  Our solver's n >= 4m+1 constraint then admits orders
up to (56,14) at k=2.

Engines expose the same call shape so the bench and the sweep cannot drift:
    ours_eta(density, level, target, dtype, device)         -> float
    ours_eta_grad(density, level, target, dtype, device)    -> (float, grad)
    torcwa_eta(density, level, target, dtype, device)       -> float
    torcwa_eta_grad(...)                                    -> (float, grad)
Gradients are d(eta)/d(density grid) -- engine cost only, no design map.
"""
import os
import sys

import numpy as np
import torch

THREADS = int(os.environ.get("P0_THREADS", "3"))
torch.set_num_threads(THREADS)

_HERE = os.path.dirname(os.path.abspath(__file__))
_E16_SCRIPTS = os.path.abspath(os.path.join(
    _HERE, "..", "..", "E16_inherited_baseline", "scripts"))
if _E16_SCRIPTS not in sys.path:
    sys.path.insert(0, _E16_SCRIPTS)

import e10_common as C  # noqa: E402
import trustworthy_fmm.fourier.convolution as _conv  # noqa: E402
import trustworthy_fmm.solvers.vector_2d as _v2d  # noqa: E402
from trustworthy_fmm.solvers.vector_2d import solve_multilayer_vector_2d  # noqa: E402

_conv.VECTORIZED_CONV = True
_v2d.FAST_DIAGNOSTICS = True

E16_DESIGNS = os.path.abspath(os.path.join(
    _HERE, "..", "..", "E16_inherited_baseline", "data", "main", "designs"))
E19_DESIGNS = os.path.abspath(os.path.join(
    _HERE, "..", "..", "E19_stage2_bh_chain", "data", "designs"))
DATA = os.path.abspath(os.path.join(_HERE, "..", "data"))


def load_frozen_binary(latent_name):
    lat = torch.from_numpy(
        np.load(os.path.join(E16_DESIGNS, latent_name)).astype("float64"))
    return C.hard_binary(lat, C.DEFAULT)


def load_e19_binary(tag):
    return torch.from_numpy(
        np.load(os.path.join(E19_DESIGNS, tag + "_binary.npy"))
        .astype("float64"))


def upsample(mask, k):
    """Exact block replication: identical physical structure on a k-x grid."""
    return torch.repeat_interleave(
        torch.repeat_interleave(mask, k, dim=0), k, dim=1)


# --------------------------------------------------------------- our engine
def _ours_solve(density, level, dtype, device):
    eps = (C.EPS_BG + (C.EPS_FEAT - C.EPS_BG) * density).to(dtype).to(device)
    return solve_multilayer_vector_2d(
        [eps], [C.THICK], C.WL, C.LATTICE, C.N_IN, C.N_OUT, tuple(level),
        incident_jones=C.DEFAULT.incident_jones)


def ours_eta(density, level, target, dtype, device):
    with torch.no_grad():
        r = _ours_solve(density, level, dtype, device)
        return float(r.power_t[r.orders.index(tuple(target))])


def ours_eta_grad(density, level, target, dtype, device):
    x = density.detach().clone().requires_grad_(True)
    r = _ours_solve(x, level, dtype, device)
    j = r.power_t[r.orders.index(tuple(target))]
    j.backward()
    return float(j.detach()), x.grad.detach()


# ------------------------------------------------------------ TORCWA engine
def _torcwa_sim(density, level, dtype, device):
    import torcwa
    real_dtype = torch.float32 if dtype == torch.complex64 else torch.float64
    eps_xy = (C.EPS_BG + (C.EPS_FEAT - C.EPS_BG)
              * density.transpose(0, 1).to(device=device, dtype=real_dtype))
    sim = torcwa.rcwa(freq=1.0 / C.WL,
                      order=[int(level[0]), int(level[1])],
                      L=list(C.LATTICE), dtype=dtype, device=device,
                      stable_eig_grad=True)
    sim.add_input_layer(eps=C.N_IN ** 2)
    sim.add_output_layer(eps=C.N_OUT ** 2)
    sim.set_incident_angle(inc_ang=0.0, azi_ang=0.0)
    sim.add_layer(C.THICK, eps_xy)
    sim.solve_global_smatrix()
    return sim


def _torcwa_power(sim, target):
    txx = sim.S_parameters(orders=list(target), direction="forward",
                           port="transmission", polarization="xx",
                           ref_order=[0, 0])
    tyx = sim.S_parameters(orders=list(target), direction="forward",
                           port="transmission", polarization="yx",
                           ref_order=[0, 0])
    return torch.sum(torch.abs(txx) ** 2 + torch.abs(tyx) ** 2)


def torcwa_eta(density, level, target, dtype, device):
    with torch.no_grad():
        sim = _torcwa_sim(density, level, dtype, device)
        return float(_torcwa_power(sim, target))


def torcwa_eta_grad(density, level, target, dtype, device):
    x = density.detach().clone().requires_grad_(True)
    sim = _torcwa_sim(x, level, dtype, device)
    j = _torcwa_power(sim, target)
    g = torch.autograd.grad(j, x)[0]
    return float(j.detach()), g.detach()
