"""Engine duel: ours (fast paths) vs TORCWA, same GPU, same c64, same grid,
same design, forward and value+grad timed separately (median of 5), with a
numerical-agreement column.

Ladder: 1x grid (35x120): (12,3), (16,4), (24,6), (28,7);
        2x grid (70x240): (32,8), (40,10); (48,12) forward-only.

    python e20_torcwa_bench.py        # writes ../data/engine_bench.json
"""
import json
import os
import time

import torch

from e20_common import (DATA, THREADS, load_frozen_binary, ours_eta,
                        ours_eta_grad, torcwa_eta, torcwa_eta_grad, upsample)

DT = torch.complex64
DEV = "cuda"
LADDER = [
    ((12, 3), 1), ((16, 4), 1), ((24, 6), 1), ((28, 7), 1),
    ((32, 8), 2), ((40, 10), 2),
]
FWD_ONLY = [((48, 12), 2)]
TARGET = (2, 0)
REPS = 5


def med_time(fn, reps=REPS):
    fn()
    torch.cuda.synchronize()
    ts = []
    for _ in range(reps):
        t0 = time.perf_counter()
        out = fn()
        torch.cuda.synchronize()
        ts.append(time.perf_counter() - t0)
    return sorted(ts)[len(ts) // 2], out


def main():
    torch.set_num_threads(THREADS)
    b1 = load_frozen_binary("2_0_2030_torcwa_M12_latent.npy")
    grids = {1: b1, 2: upsample(b1, 2)}
    rows = []
    for lv, k in LADDER:
        d = grids[k]
        t_of, v_ours = med_time(lambda: ours_eta(d, lv, TARGET, DT, DEV))
        t_tf, v_tor = med_time(lambda: torcwa_eta(d, lv, TARGET, DT, DEV))
        t_og, _ = med_time(lambda: ours_eta_grad(d, lv, TARGET, DT, DEV))
        t_tg, _ = med_time(lambda: torcwa_eta_grad(d, lv, TARGET, DT, DEV))
        rows.append({"level": list(lv), "grid_k": k,
                     "ours_fwd_s": t_of, "torcwa_fwd_s": t_tf,
                     "ours_vg_s": t_og, "torcwa_vg_s": t_tg,
                     "eta_ours": v_ours, "eta_torcwa": v_tor,
                     "rel_diff": abs(v_ours - v_tor) / max(abs(v_tor), 1e-12)})
        print("%s @%dx | fwd ours %.3f vs torcwa %.3f (%.2fx) | "
              "v+g ours %.3f vs torcwa %.3f (%.2fx) | d_eta %.1e"
              % (lv, k, t_of, t_tf, t_of / t_tf, t_og, t_tg, t_og / t_tg,
                 rows[-1]["rel_diff"]), flush=True)
    for lv, k in FWD_ONLY:
        d = grids[k]
        t_of, v_ours = med_time(lambda: ours_eta(d, lv, TARGET, DT, DEV),
                                reps=3)
        t_tf, v_tor = med_time(lambda: torcwa_eta(d, lv, TARGET, DT, DEV),
                               reps=3)
        rows.append({"level": list(lv), "grid_k": k, "fwd_only": True,
                     "ours_fwd_s": t_of, "torcwa_fwd_s": t_tf,
                     "eta_ours": v_ours, "eta_torcwa": v_tor,
                     "rel_diff": abs(v_ours - v_tor) / max(abs(v_tor), 1e-12)})
        print("%s @%dx | fwd ours %.3f vs torcwa %.3f (%.2fx) | d_eta %.1e"
              % (lv, k, t_of, t_tf, t_of / t_tf, rows[-1]["rel_diff"]),
              flush=True)
    with open(os.path.join(DATA, "engine_bench.json"), "w") as f:
        json.dump({"rows": rows, "dtype": "complex64", "device": "cuda",
                   "target": list(TARGET), "threads": THREADS,
                   "design": "2_0_2030_torcwa_M12"}, f, indent=1)
    print("wrote engine_bench.json")


if __name__ == "__main__":
    main()
